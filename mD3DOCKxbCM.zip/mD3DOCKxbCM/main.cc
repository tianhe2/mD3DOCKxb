/* AutoDock
   $Id: main.cc,v 1.114 2009/12/15 06:21:01 mp Exp $

 **  Function: Performs Automated Docking of Small Molecule into Macromolecule
 **Copyright (C) 2009 The Scripps Research Institute. All rights reserved.
 ** All Rights Reserved.
 **____________________________________________________________________________
 ** Primary Authors: 
 **            Garrett Matthew Morris, C/C++ version 
 **            David Goodsell, Original FORTRAN version 1.0
 **                                       e-mail: goodsell@scripps.edu
 **
 ** Other Contributors: see file AUTHORS
 **            
 **            Laboratory of Arthur J. Olson
 **            The Scripps Research Institute
 **            Department of Molecular Biology, MB5
 **            10550 North Torrey Pines Road
 **            La Jolla, CA 92037.
 **____________________________________________________________________________
 **    Inputs: Control file, Small Molecule PDBQT file, macromolecular grid map
 **            files.
 **   Returns: Autodock Log File, includes docked conformation clusters (PDBQT)
 **____________________________________________________________________________
 ** Modification Record (pre-CVS)
 ** Date     Inits   Comments
 ** 09/06/95 RSH     Added code to handle GA/LS stuff
 **          DSG     Quaternion rotations
 **          DSG     Generates torsions from annotated pdb list
 **          DSG     Generates internal energies
 **          DSG     Performs a limited Cluster analysis of conformations
 ** 05/07/92 GMM     C translation
 ** 05/14/92 GMM     Time-dependent seed in random-number generation
 ** 10/29/92 GMM     Application Visualization System (AVS) readable grid
 **                  display file input.
 **                  [AVS is a trademark of Stardent Computer Inc.]
 **                  Also added the 'total_charge' check.
 ** 11/19/93 GMM     #ifdef NOSQRT, with non-square-rooting acceleration.
 ** 09/26/94 GMM     Cluster analysis now outputs RMS deviations.
 ** 09/28/94 GMM     Modularized code.
 ** 10/02/94 GMM     Distance constraints added, for Ed Moret. Accelerated.
 ** 09/06/95 RSH     Incorporation of GA/SW tokens
 AutoDock is a Trade Mark of The Scripps Research Institute.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *******************************************************************************/
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#define AUTODOCK_MPI
#define PERF_PROFILING
//#define MPI_DEBUG
//#define MPIING
#define FOR_MPI
#define _OPENMP
#ifdef AUTODOCK_MPI
#include <mpi.h>
#include <errno.h>
#endif
#include <sys/types.h> // time_t time(time_t *tloc);
#include <time.h>      // time_t time(time_t *tloc);
#include <sys/times.h>
#include <stdlib.h>
#include <math.h>
#include <list>
#include <unistd.h>

#include <sys/param.h>
#include <ctype.h> // tolower
#include <unistd.h> // sysconf
/* the BOINC API header file */
#ifdef BOINC
#include "diagnostics.h"
#include "boinc_api.h"
#include "filesys.h"                 // boinc_fopen(), etc... */
#endif

#include "autoglobal.h"

#ifdef _OPENMP
#include <omp.h>
#endif
// code for generating the blue gene Q location coordinates for use in node computational verification
#ifdef BGQ_NODE_VERIFICATION
#include "kernel/location.h"
#include "kernel/process.h"
#include "personality.h"
#include "common/uci.h"
#endif
// pkcoff: turn the main into a function call for mpi
#ifdef AUTODOCK_MPI

int mpi_slave_main(int argc, char ** argv,int mpirank, int seedtype, int mapusagetype,char*dockingDirectoryName);
#endif

/**************************
//YTLIU_EDIT 2013.01.02
 **************************/

//#define min(x,y)     ( ((x) < (y)) ? (x) : (y) )
//#define max(x,y)     ( ((x) > (y)) ? (x) : (y) )

/**************************
//YTLIU_EDIT 2012.12.30
 **************************/

static const char* const ident[] = {ident[1], "@(#)$Id: main.cc,v 1.114 2009/12/15 06:21:01 mp Exp $"};

FourByteLong L_Xm1[MIC_MAX_NUM_THREADS],L_Xm2[MIC_MAX_NUM_THREADS],L_Xa1[MIC_MAX_NUM_THREADS],L_Xa2[MIC_MAX_NUM_THREADS],
			 L_Xcg1[MIC_MAX_NUM_THREADS][32],L_Xcg2[MIC_MAX_NUM_THREADS][32],L_Xa1w[MIC_MAX_NUM_THREADS],L_Xa2w[MIC_MAX_NUM_THREADS],
			 L_Xig1[MIC_MAX_NUM_THREADS][32],L_Xig2[MIC_MAX_NUM_THREADS][32],L_Xlg1[MIC_MAX_NUM_THREADS][32],
			 L_Xlg2[MIC_MAX_NUM_THREADS][32],L_Xa1vw[MIC_MAX_NUM_THREADS],L_Xa2vw[MIC_MAX_NUM_THREADS];
FourByteLong L_Xqanti[MIC_MAX_NUM_THREADS][32];
__declspec(target(mic))int sel_prop_count = 0;
__declspec(target(mic))static Boole B_found_about_keyword = FALSE; //set false by 'move' true by 'about'
__declspec(target(mic))static Boole B_found_elecmap = FALSE;
__declspec(target(mic))static Boole B_found_desolvmap = FALSE;
__declspec(target(mic))static void exit_if_missing_elecmap_desolvmap_about(char*  keyword); // see bottom of main.cc
/*********************
// YTLIU_EDIT 2013.01.04
 *********************/
Boole readXBPMFPairwiseParms(
				char* xbpmf_1d_parm_fn,
				char* xbpmf_2d_hb_parm_fn,
				char* xbpmf_2d_xb_parm_fn,
				Real xbpmf_1d_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM],
				Real xbpmf_2d_hb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
				Real xbpmf_2d_xb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
				Clock jobStart,
				struct tms tms_jobStart);

/************************
// YTLIU_EDIT 2013.01.25
 ************************/
static void initializeXBEmpiricalParms(XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES]);
static Boole setupXBEmpiricalParms(char* xbemp_parm_fn, XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES]);
//XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES];
__declspec(target(mic))Boole halogen_found = FALSE;
__declspec(target(mic))static int strindex( const char s[], const char t[] )
{
		register int i,c1,c2;

		for (i=0; s[i] != '\0'; i++) {
				for (c1=i, c2=0; s[c1]==t[c2] && t[c2]!='\0'; c1++, c2++)
						;
				if (c2>0 && t[c2]=='\0')
						return( i );
		}
		return( -1 );
}

__declspec(target(mic)) void ShowMIC(char s[],int i)
{
#ifdef __MIC__
		sprintf(s,"MIC:Parallel %d...\n",i);
#endif
}

void ShowCPU(int i)
{
		printf("CPU:Parallel %d...\n",i);
}

__declspec(target(mic))void ShowConfMIC(Real cf[],int begin,int end)
{
		int count=0;
		for(int i=begin;i<end;i++)
		{
				printf("econf[%d]=%f\t",i,cf[i]);
				fflush(0);
				count++;
				if(count==3)
				{
						count=0;
						printf("\n");
						fflush(0);
				}
		}
		printf("\n");
		fflush(0);
}

#pragma offload_attribute(push,target(mic))
class L_Representation
{
		protected:
				unsigned int number_of_pts;
				RepType mytype;
				unsigned char normalized; // =1 means the vector's normalized

		public:
				L_Representation(void);
				L_Representation(unsigned int);
				virtual ~L_Representation(void);
				virtual L_Representation &operator=(const L_Representation &) = 0;
				unsigned int number_of_points(void) const;
				int is_normalized(void) const;
				void set_normalized_true(void);
				void set_normalized_false(void);
				virtual RepType type(void) const; 
				virtual void write(unsigned char, int) = 0;
				virtual void write(FourByteLong, int) = 0;
				virtual void write(double, int) = 0;
				virtual void write(const Element, int) = 0;
				virtual const Element gene(unsigned int) const = 0;
				virtual L_Representation *clone(void) const = 0;
				virtual const void *internals(void) const = 0;
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_IntVector : public L_Representation
{
		//   friend void debug(IntVector &);
		protected:
				static FourByteLong low, high;
				FourByteLong *vector;

				const void *internals(void) const;
				L_Representation *clone(void) const;

		public:
				L_IntVector(void);
				L_IntVector(int);
				L_IntVector(int, FourByteLong *);
				L_IntVector(int, FourByteLong, FourByteLong);
				L_IntVector(const L_IntVector &);
				~L_IntVector(void);
				void write(unsigned char, int);
				void write(FourByteLong, int);
				void write(double, int);
				void write(const Element, int);
				L_Representation &operator=(const L_Representation &);
				const Element gene(unsigned int) const;
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_RealVector : public L_Representation
{
		//   friend void debug(RealVector &);
		protected:
				Real high, low;
				double *vector;

				const void *internals(void) const;
				L_Representation *clone(void) const;

		public:
				L_RealVector(void)
						: L_Representation(0), 
						high(REALV_HIGH), low(REALV_LOW), 
						vector((double *)NULL)
		{ 
				mytype = T_RealV;
		}

				L_RealVector(int);
				L_RealVector(int, double *);
				L_RealVector(int, double, double);
				// Use this to set the first value in the vector--useful for random quaternions
				L_RealVector(int, double, double, double); 
				L_RealVector(int, double, double, double, double, double, double);  // sets a quaternion's x,y,z,w values
				// Use this to create a vector of length 3 with these values--useful for random quaternions
				L_RealVector(int, double, double, double, double, double ); 
				L_RealVector(const L_RealVector &);
				~L_RealVector(void);
				void write(unsigned char, int);
				void write(FourByteLong, int);
				//    void write(const void *, int);
				void write(const Element, int);
				L_Representation &operator=(const L_Representation &);
				//    const void *gene(unsigned int) const;
#ifdef DEBUG
				/*
				   inline const Element gene(unsigned int gene_number) const
				   {
				   Element retval;
				   retval.real = vector[gene_number];
				   return retval;
				   }
				   inline void write(double value, int gene)
				   {
				   value = value < low  ? low  : 
				   value > high ? high :
				   value;
				   vector[gene] = value;
				   }
				   */
				// non-inlined versions, possibly with range checking
				void write(double, int);
				const Element gene(unsigned int) const;
#else
				// non-inlined versions, possibly with range checking
				void write(double, int);
				const Element gene(unsigned int) const;
#endif
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_ConstrainedRealVector : public L_Representation
{
		//   friend debug(ConstrainedRealVector &);
		protected:
				static Real high, low;
				static double sum;
				double *vector;

				const void *internals(void) const;
				L_Representation *clone(void) const;
				void normalize(void);

		public:
				L_ConstrainedRealVector(void);
				L_ConstrainedRealVector(int);
				L_ConstrainedRealVector(int, double *);
				L_ConstrainedRealVector(int, double, double);
				L_ConstrainedRealVector(const L_ConstrainedRealVector &);
				~L_ConstrainedRealVector(void);
				void write(unsigned char, int);
				void write(FourByteLong, int);
				void write(double, int);
				void write(const Element, int);
				void write(double, double, double, double);
				L_Representation &operator=(const L_Representation &);
				const Element gene(unsigned int) const;
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_BitVector : public L_Representation
{
		//   friend void debug(BitVector &);
		protected:
				static Real one_prob;
				unsigned char *vector;

				const void *internals(void) const;
				L_Representation *clone(void) const;

		public:
				L_BitVector(void);
				L_BitVector(int);
				L_BitVector(int, unsigned char *);
				L_BitVector(int, Real);
				L_BitVector(const L_BitVector &);
				~L_BitVector(void);
				void write(unsigned char, int);
				void write(FourByteLong, int);
				void write(double, int);
				void write(const Element, int);
				L_Representation &operator=(const L_Representation &);
				const Element gene(unsigned int) const;
};
#pragma offload_attribute(pop)
/*
#pragma offload_attribute(push,target(mic))
extern struct Lookup;
#pragma offload_attribute(pop)
*/
#pragma offload_attribute(push,target(mic))
class L_Genotype
{
		//friend void debug(Genotype &);
		protected:
				//  Could some of these be made static?
				unsigned int number_of_genes;
				unsigned int number_of_vectors; // #vectors in rep_vector
				Lookup *lookup;		      // a table that helps in looking up a gene
				L_Representation **rep_vector; /* the actual representation of the genotype
												  like arrays of reals, bits, ints */
				unsigned modified : 1; /* used in caching for genotype operators, 
										  e.g. crossover */

		public:
				L_Genotype(void);
				L_Genotype(L_Genotype &); /* copy constructor */
				L_Genotype(L_Genotype const &);
				L_Genotype(unsigned int, L_Representation **); /* creates a genotype from the
																  representation & total # vectors */
				~L_Genotype(void); /* destructor */
				L_Genotype &operator=(const L_Genotype &);
				unsigned int num_vectors(void); /* e.g. "real,bit,bit,int" would = 4 */
				unsigned int num_genes(void); /* returns number_of_genes (see above) */
				RepType gtype(int); /* returns the type (real,bit,int) for 
									   a particular gene */
				const Element gread(int);
				const L_Representation *vread(int);
				void write(Element, int);
				void write(unsigned char, int);
				void write(FourByteLong, int);
				void write(double, int);
				void write(const L_Representation &, int);
				Quat readQuat();
				void writeQuat( Quat q );
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Phenotype
{
		//friend void debug(Phenotype &);
		protected:
				unsigned int number_of_dimensions, number_of_points;
				Lookup *lookup;
				L_Representation **value_vector;
				double value;
				unsigned evalflag : 1;  //  =1 means that this is the current evaluation
				unsigned modified : 1;  //  =1 means that this has been modified

		public:
				L_Phenotype(void);
				L_Phenotype(const L_Phenotype &);
				//Phenotype(const Genotype &);//to do
				L_Phenotype(unsigned int, L_Representation **);
				~L_Phenotype(void);
				L_Phenotype &operator=(const L_Phenotype &);
				RepType gtype(int);
				const Element gread(int);
				const L_Representation *vread(int);
				void write(Element, int);
				void write(unsigned char, int);
				void write(FourByteLong, int);
				void write(double, int);
				void write(const L_Representation &, int);
				double evaluate(EvalMode);  //  This should return evaluation if that's the right answer, and it should evaluate otherwise.
				State make_state(int);
				unsigned int num_dimensions(void);
				unsigned int num_pts(void);
				Quat readQuat();
				void writeQuat( Quat q );
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Individual
{
		//friend void debug(Individual &);
		public:
				L_Genotype genotyp;   /* Genotype  is operated upon by *global search* operators */
				L_Phenotype phenotyp; /* Phenotype  "     "      "   " *local search*  operators, eg SW */
				Molecule *mol;		/* molecule */
				unsigned long age;	/* age of this individual; gmm, 1998-07-10 */

				L_Individual(void);
				L_Individual(L_Individual &); /* copy constructor */
				L_Individual(L_Individual const &);
				L_Individual(L_Genotype &, L_Phenotype &);
				~L_Individual(void); /* destructor */
				L_Individual &operator=(const L_Individual &); /* assignment function for
																  individuals */
				L_Individual &mapping(void);         //updates phenotype from current genotype values 
				L_Individual &inverse_mapping(void); //updates genotype from current phenotype values 
				//Phenotype mapping(void); /* takes the genotype and converts it into a phenotype.  */
				//Genotype inverse_mapping(void);  // Scott should do: Also copy Phenotype's value
				double value(EvalMode); /* evaluation of the individual gives its value */
				State state(int); /* state variables in AutoDock */
				void  getMol(Molecule *); /* converts phenotype to mol's state and returns this individual's mol data */
				void printIndividualsState(FILE *, int, int); /* print out the state of this individual */
				void incrementAge(); /* make individual grow 1 generation older */
				int serial; // serial number of this individual
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Population
{
		//friend void debug(Population &);
		protected:
				int lhb;  //  These keep track of the lower & upper heap bounds
				int size; /* the number of individuals in the population */
				L_Individual *heap; /* a heap of individuals -- special binary tree */
				void swap(L_Individual &, L_Individual &); /* for maintaining the heap order*/
				void SiftUp(void); /* for maintaining the heap order*/
				void SiftDown(void); /* for maintaining the heap order*/
				int end_of_branch[MAX_TORS]; // For Branch Crossover Mode

		public:
				L_Population(void);
				L_Population(int); /* create a pop. with this many individuals */
				L_Population(int, L_Individual *); /* takes an array of ind's and turns into pop. */
				L_Population(L_Population &); /* copy constructor */
				~L_Population(void); /* destructor */
				L_Individual &operator[](int);  /* for accessing a particular indiv.in pop*/
				L_Population &operator=(const L_Population &);
				unsigned int num_individuals(void); /* returns the size of the pop. */
				void msort(int); /* sorts the first m individuals using heap properties */
				// void print(ostream &, int); /* prints top int energies */
				void print(FILE *, int); /* like above */
				int printPopulationStatistics(FILE *, int, Boole); /* prints best, worse, mean, etc energies */
				int printPopulationStatisticsVerbose(FILE *, unsigned int, long int, const char []); /* print with generations & #evals */
				void printPopulationAsStates(FILE *, int, int); /*prints energies,states of top energies */
				void printPopulationAsCoordsEnergies(FILE *, int, int); /*prints energies,states of top energies */
				void set_eob(int init_end_of_branch[MAX_TORS]); // For Branch Crossover Mode
				int get_eob(int init_tor); // For Branch Crossover Mode
};
#pragma offload_attribute(pop)

#pragma offload_attribute(push,target(mic))
class L_Eval
{
		private:
				UnsignedFourByteLong num_evals;
				int natom, Nnb;
				GridMapSetInfo *info;
				Real eval_elec[MAX_ATOMS]; // gmm added 21-Jan-1998, for writePDBQState
				Real eval_emap[MAX_ATOMS]; // gmm added 21-Jan-1998, for writePDBQState
				Boole B_calcIntElec, B_isGaussTorCon, B_ShowTorE;
				State stateNow;
				unsigned short *US_TorE, (*US_torProfile)[NTORDIVS];
				int *type, (*tlist)[MAX_ATOMS];
				NonbondParam *nonbondlist;
				Real *charge, *abs_charge, *qsp_abs_charge;
				Real (*crd)[SPACE], (*vt)[SPACE], (*crdpdb)[SPACE], (*crdreo)[SPACE];
				EnergyTables *ptr_ad_energy_tables;
				Real (*map)[MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS];
				Boole *B_isTorConstrained;
				Molecule mol;
				int ignore_inter[MAX_ATOMS]; // gmm 2002-05-21, for CA, CB in flexible sidechains
				Boole         B_include_1_4_interactions; // gmm 2005-01-8, for scaling 1-4 nonbonds
				Real scale_1_4;                  // gmm 2005-01-8, for scaling 1-4 nonbonds
				//ParameterEntry *parameterArray;
				Real  unbound_internal_FE;
				Boole B_compute_intermol_energy; // use for computing unbound state
				Boole B_use_non_bond_cutoff;  // set this to FALSE if we are computing unbound extended conformations
				Boole B_have_flexible_residues;
				/************************
				// YTLIU_EDIT 2013.01.04
				 ************************/
				int recep_natom;
				Real (*recep_crdpdb)[SPACE];
				char (*recep_atomtypes)[MAX_LEN_AUTOGRID_TYPE + 1];
				char (*xbligand_atomtypes)[MAX_LEN_AUTOGRID_TYPE + 1];
				Real (*xbpmf_1d_pw_parms)[XBPMF_AT_NUM][XBPMF_SHELL_NUM];
				Real (*xbpmf_2d_hb_pw_parms)[XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM];
				Real (*xbpmf_2d_xb_pw_parms)[XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM];
				MapType (*xbpmf_1d_map)[MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM];
				MapType (*xbpmf_hb_map)[MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM];
				int recep_acceptor_natom;
				Real (*recep_acceptor_crdpdb)[NTRN];
				char (*recep_acceptor_atomtype)[MAX_LEN_AUTOGRID_TYPE + 1];
				/************************
				// YTLIU_EDIT 2013.01.16
				 ************************/
				int (*xbpmf_hb_label)[MAX_RECEPTOR_ATOMS];
				int (*xbpmf_xb_label)[MAX_RECEPTOR_ATOMS];
				int (*xbpmf_ligand_hb_donorH_ids)[5];
				int (*xbpmf_ligand_xb_donorX_id);
				int (*xbpmf_ligand_at_index);
				int (*xbpmf_receptor_at_index);
				int (*xbpmf_ligand_hb_acceptor);
				int (*xbpmf_ligand_hb_donor);
				int (*xbpmf_ligand_xb_donor);
				int (*xbpmf_receptor_hb_acceptor);
				/**********************************
				// YTLIU_EDIT 2013.01.26
				 **********************************/
				Real xb_empirical_vdw;
				Real xb_empirical_es;
				Real ad_vdw;
				Real ad_es;
				Real ad_desolv;
				/*--------------------------------------------------*/
				/*acceleration: 2013.05.23 by ytliu@mail.shcnc.ac.cn*/
				/*--------------------------------------------------*/
				Real (*xb_vdw_profile)[MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8];
				Real (*xb_es_profile)[MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8];
				Real (*xb_desolv_profile)[MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8];
				// Real (*xb_vdw_profile)[MAX_XBACCEPTOR_TYPES][MAX_DIST][2];
				// Real (*xb_es_profile)[MAX_XBACCEPTOR_TYPES][MAX_DIST][2];
				// Real (*xb_desolv_profile)[MAX_XBACCEPTOR_TYPES][MAX_DIST][2];

				XBEmpiricalParm (*xbempirical_parms)[MAX_XBACCEPTOR_TYPES];
				Boole halogen_found;
				Real (*xbempirical_recep_crdpdb)[NTRN];
				int (*xbempirical_ligand_xbdonor)[2];
				int (*xbempirical_receptor_acceptor_index);

		public:
				L_Eval(void);
				void setup( Real init_crd[MAX_ATOMS][SPACE],
								Real  init_charge[MAX_ATOMS],
								Real  init_abs_charge[MAX_ATOMS],
								Real  init_qsp_abs_charge[MAX_ATOMS],
								int            init_type[MAX_ATOMS], int init_natom,
								Real  init_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS],

								Real  init_elec[MAX_ATOMS], // gmm added 21-Jan-1998, for writePDBQState
								Real  init_emap[MAX_ATOMS], // gmm added 21-Jan-1998, for writePDBQState

								NonbondParam *init_nonbondlist,
								EnergyTables   *init_ptr_ad_energy_tables,
								int init_Nnb,
								Boole          init_B_calcIntElec,
								Boole          init_B_isGaussTorCon, Boole init_B_isTorConstrained[MAX_TORS],
								Boole          init_B_ShowTorE, unsigned short init_US_TorE[MAX_TORS],
								unsigned short init_US_torProfile[MAX_TORS][NTORDIVS],
								Real  init_vt[MAX_TORS][SPACE], int init_tlist[MAX_TORS][MAX_ATOMS],
								Real  init_crdpdb[MAX_ATOMS][SPACE],
								Real  init_crdreo[MAX_ATOMS][SPACE],
								State stateInit, Molecule molInit,
								int            init_ignore_inter[MAX_ATOMS],
								Boole          init_B_include_1_4_interactions, // gmm 2005-01-8, for scaling 1-4 nonbonds
								Real  init_scale_1_4,                   // gmm 2005-01-8, for scaling 1-4 nonbonds
								//ParameterEntry init_parameterArray[MAX_ATOM_TYPES], // input  nonbond and desolvation parameters
								Real  init_unbound_internal_FE,
								GridMapSetInfo *init_info,
								Boole  init_B_use_non_bond_cutoff,  // set this to FALSE if we are computing unbound extended conformations
								Boole  init_B_have_flexible_residues,
								/**********************************
								// YTLIU_EDIT 2013.01.26
								 **********************************/
								Real init_xb_empirical_vdw,
								Real init_xb_empirical_es,
								Real init_ad_vdw,
								Real init_ad_es,
								Real init_ad_desolv,
								Real init_xb_vdw_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
								Real init_xb_es_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
								Real init_xb_desolv_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],

								XBEmpiricalParm init_xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES],
								Boole init_halogen_found,
								Real init_xbempirical_recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
								int init_xbempirical_ligand_xbdonor[MAX_ATOMS][2],
								int xbempirical_receptor_acceptor_index[MAX_RECEPTOR_ATOMS]
										);

				/************************
				// YTLIU_EDIT 2013.01.04
				 ************************/
				void setup( Real init_crd[MAX_ATOMS][SPACE],
								Real  init_charge[MAX_ATOMS],
								Real  init_abs_charge[MAX_ATOMS],
								Real  init_qsp_abs_charge[MAX_ATOMS],
								int            init_type[MAX_ATOMS], int init_natom,
								Real  init_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS],

								Real  init_elec[MAX_ATOMS], // gmm added 21-Jan-1998, for writePDBQState
								Real  init_emap[MAX_ATOMS], // gmm added 21-Jan-1998, for writePDBQState

								NonbondParam *init_nonbondlist,
								EnergyTables   *init_ptr_ad_energy_tables,
								int init_Nnb,
								Boole          init_B_calcIntElec,
								Boole          init_B_isGaussTorCon, Boole init_B_isTorConstrained[MAX_TORS],
								Boole          init_B_ShowTorE, unsigned short init_US_TorE[MAX_TORS],
								unsigned short init_US_torProfile[MAX_TORS][NTORDIVS],
								Real  init_vt[MAX_TORS][SPACE], int init_tlist[MAX_TORS][MAX_ATOMS],
								Real  init_crdpdb[MAX_ATOMS][SPACE], 
								Real  init_crdreo[MAX_ATOMS][SPACE], 
								State stateInit, Molecule molInit,
								int            init_ignore_inter[MAX_ATOMS],
								Boole          init_B_include_1_4_interactions, // gmm 2005-01-8, for scaling 1-4 nonbonds
								Real  init_scale_1_4,                   // gmm 2005-01-8, for scaling 1-4 nonbonds
								//ParameterEntry init_parameterArray[MAX_ATOM_TYPES], // input  nonbond and desolvation parameters
								Real  init_unbound_internal_FE,
								GridMapSetInfo *init_info,
								Boole  init_B_use_non_bond_cutoff,  // set this to FALSE if we are computing unbound extended conformations
								Boole  init_B_have_flexible_residues,
								Real init_xbpmf_1d_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM],
								Real init_xbpmf_2d_hb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
								Real init_xbpmf_2d_xb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
								int  init_recep_natom,
								Real init_recep_crdpdb[MAX_RECEPTOR_ATOMS][SPACE],
								char init_recep_atomtypes[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
								char init_xbligand_atomtypes[MAX_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
								MapType init_xbpmf_1d_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM],
								MapType init_xbpmf_hb_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM],
								int init_recep_acceptor_natom,
								Real init_recep_acceptor_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
								char init_recep_acceptor_atomtype[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
								int init_xbpmf_hb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS],
								int init_xbpmf_xb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS],
								int init_xbpmf_ligand_hb_donorH_ids[MAX_ATOMS][5],
								int init_xbpmf_ligand_xb_donorX_id[MAX_ATOMS],
								int init_xbpmf_ligand_at_index[MAX_ATOMS],
								int init_xbpmf_receptor_at_index[MAX_RECEPTOR_ATOMS],
								int init_xbpmf_ligand_hb_acceptor[MAX_ATOMS],
								int init_xbpmf_ligand_hb_donor[MAX_ATOMS],
								int init_xbpmf_ligand_xb_donor[MAX_ATOMS],
								int init_xbpmf_receptor_hb_acceptor[MAX_RECEPTOR_ATOMS]
										);

				void update_crds( Real init_crdreo[MAX_ATOMS][SPACE], 
								Real init_vt[MAX_TORS][SPACE] );

				double operator()(L_Representation **);
				double operator()(L_Representation **, int); // GMM - allows calculation of a particular term of the total energy
#if defined(USING_COLINY)
				double operator()(double*, int);
#endif
				double eval();    // WEH - a basic change that facilitates the use of Coliny
				double eval(int); // GMM - allows calculation of a particular term of the total energy
				UnsignedFourByteLong evals(void);
				void reset(void);
				int write(FILE *out_file, L_Representation **rep);
				double evalpso(State *state);
				void compute_intermol_energy(Boole init_B_compute_intermol_energy); // for computing unbound state
};

#pragma offload_attribute(pop)
__declspec(target(mic))L_Eval L_evaluate[MIC_MAX_NUM_THREADS];

//extern union Element;
#pragma offload_attribute(push,target(mic))
class L_Global_Search
{
		public:
				L_Global_Search(void);
				virtual ~L_Global_Search(void);
				unsigned int cg_count; // statistics - crossover gene-by-gene count
				unsigned int ci_count; // statistics - crossover indiv-by-indiv count
				unsigned int mg_count; // statistics - mutation gene-by-gene count
				unsigned int mi_count; // statistics - mutation indiv-by-indiv count
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Genetic_Algorithm : public L_Global_Search
{
		//   friend void debug(Genetic_Algorithm &, Population &);
		private:
				EvalMode e_mode;
				Selection_Mode s_mode;
				Xover_Mode c_mode;
				Worst_Mode w_mode;
				unsigned int elitism;
				Real c_rate;
				Real m_rate;
				unsigned int window_size;
				Real alpha;
				Real beta;
				Real tranStep, quatStep, torsStep;
				int low, high; // should these be int or Real?
				unsigned int generations; 
				unsigned int max_generations;
				unsigned int outputEveryNgens; // gmm 2000.11.1,2003.08.18
				unsigned int converged; // gmm 7-jan-98
				Real *alloc;
				Real *mutation_table;
				unsigned int *ordering;	  
				unsigned int m_table_size;
				double worst, avg;
				double *worst_window;
				Real linear_ranking_selection_probability_ratio;

				double worst_this_generation(L_Population &);
				void set_worst(L_Population &);
				void make_table(int, Real);
				int check_table(Real);
				M_mode m_type(RepType);
				void mutate(L_Genotype &, int);
				void mutation(L_Population &);
				void crossover(L_Population &);
				void crossover_2pt(L_Genotype &, L_Genotype &, unsigned int, unsigned int);
				void crossover_uniform(L_Genotype &, L_Genotype &, unsigned int);
				void crossover_arithmetic(L_Genotype &, L_Genotype &, Real);
				void selection_proportional(L_Population &, L_Individual *);
				void selection_linear_ranking(L_Population &, L_Individual *);
				void selection_tournament(L_Population &, L_Individual *);
				L_Individual *selection(L_Population &);

		public:
				L_Genetic_Algorithm(void);
				// Genetic_Algorithm(EvalMode, Selection_Mode, Xover_Mode, Worst_Mode, int, Real, Real, int, unsigned int); // before 2000.11.1
				L_Genetic_Algorithm(EvalMode, Selection_Mode, Xover_Mode, Worst_Mode, int, Real, Real, int, unsigned int, unsigned int); // after 2000.11.1
				void setValue(EvalMode, Selection_Mode, Xover_Mode, Worst_Mode, int, Real, Real, int, unsigned int, unsigned int);
				~L_Genetic_Algorithm(void);
				void initialize(unsigned int, unsigned int);
				void mutation_values(int, int, Real, Real,  Real, Real, Real );
				unsigned int num_generations(void);
				void reset(void);
				void reset(unsigned int);
				int terminate(void);
				int search(L_Population &);
				int set_linear_ranking_selection_probability_ratio(Real);
};
#pragma offload_attribute(pop)

#pragma offload_attribute(push,target(mic))
class L_Local_Search
{
		public:
				L_Local_Search(void);
				virtual ~L_Local_Search(void);
				//virtual void reset(void) = 0;
				//virtual int terminate(void) = 0;
				//virtual int search(Individual &)=0;
				unsigned int count;//search invocation count, for run statistics
				int SearchType;
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Pattern_Search : public L_Local_Search
{
		protected:
				unsigned int size; 
				unsigned int max_success;
				Real step_size, current_step_size;
				Real step_threshold, expansion, contraction;
				Real search_frequency;
				Real *pattern;
				unsigned int *index;
				unsigned int successes;
				//int HJ_bias; // not implemented
				//Real * step_scales; // not implemented
				L_Phenotype exploratory_move(const L_Phenotype&);
				L_Phenotype pattern_explore(const L_Phenotype&);
				L_Phenotype pattern_move(const L_Phenotype&);
				void reset_pattern(void);
				void reset_indexes(void);
				void shuffle_indexes(void);
		public:
				L_Pattern_Search(void);
				L_Pattern_Search(unsigned int, unsigned int, Real, Real, Real, Real, Real);
				~L_Pattern_Search(void);
				void reset(void);
				int terminate(void);
				int search(L_Individual &);
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Solis_Wets_Base : public L_Local_Search
{
		protected:
				unsigned int size, max_its, max_successes, max_failures;
				Real expansion, contraction;
				Real search_frequency;
				Real *deviates, *bias;

		public:
				L_Solis_Wets_Base(void);
				L_Solis_Wets_Base(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real);
				virtual ~L_Solis_Wets_Base(void);
				//virtual double gen_deviates(Real) = 0;
				//virtual Boole SW(Phenotype &) = 0;
				virtual void reset(void);
				virtual int terminate(void);
				int search(L_Individual &);
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Solis_Wets : public L_Solis_Wets_Base
{
		protected:
				Real rho, lower_bound_on_rho;

		public:
				L_Solis_Wets(void);
				L_Solis_Wets(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real, Real, Real);
				virtual ~L_Solis_Wets(void);
				//virtual double gen_deviates(Real) = 0;
				Boole SW(L_Phenotype &);
};
#pragma offload_attribute(push,target(mic))
class L_Pseudo_Solis_Wets : public L_Solis_Wets_Base
{
		protected:
				Real *rho, *lower_bound_on_rho;
				Real *temp_rho;

		public:
				L_Pseudo_Solis_Wets(void);
				L_Pseudo_Solis_Wets(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real);
				L_Pseudo_Solis_Wets(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real, Real *, Real *);
				virtual ~L_Pseudo_Solis_Wets(void);
				//virtual double gen_deviates(Real) = 0;
				Boole SW(L_Phenotype &);
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Solis_Wets1 : public L_Solis_Wets
{
		public:
				L_Solis_Wets1(void);
				L_Solis_Wets1(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real, Real, Real);
				~L_Solis_Wets1(void);
				double gen_deviates(Real);
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Solis_Wets2 : public L_Solis_Wets
{
		public:
				L_Solis_Wets2(void);
				L_Solis_Wets2(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real, Real, Real);
				~L_Solis_Wets2(void);
				double gen_deviates(Real);
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Pseudo_Solis_Wets1 : public L_Pseudo_Solis_Wets
{
		public:
				L_Pseudo_Solis_Wets1(void);
				L_Pseudo_Solis_Wets1(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real);
				L_Pseudo_Solis_Wets1(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real, Real *, Real *);
				~L_Pseudo_Solis_Wets1(void);
				double gen_deviates(Real);
};
#pragma offload_attribute(pop)
#pragma offload_attribute(push,target(mic))
class L_Pseudo_Solis_Wets2 : public L_Pseudo_Solis_Wets
{
		public:
				L_Pseudo_Solis_Wets2(void);
				L_Pseudo_Solis_Wets2(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real);
				L_Pseudo_Solis_Wets2(unsigned int, unsigned int, unsigned int, unsigned int, Real, Real, Real, Real *, Real *);
				~L_Pseudo_Solis_Wets2(void);
				double gen_deviates(Real);
};
#pragma offload_attribute(pop)

#pragma offload_attribute(push,target(mic))
L_Phenotype L_genPh(const L_Phenotype &original, Real sign, Real *deviates, Real *bias);
double L_avg_in_window(double *window, int size);
double L_worst_in_window(double *window, int size);
Quat L_uniformQuat( void );
Quat L_normRot( Quat q );
Quat L_convertQuatToRot( Quat q );
Quat L_normQuat( Quat q );
void L_make_state_from_rep(L_Representation **rep, State *stateNow);
void L_qmultiply( Quat *q,register const Quat *ql,register const Quat *qr );  //right
Real L_scauchy2();
Quat L_slerp( const Quat qa, const Quat qb, const double t );
Real L_a_range_reduction( Real a );
Real L_alerp( Real a, Real b, Real fract );
Molecule L_copyStateToMolecule(State *S, Molecule *mol);
int L_doublecompare(const void *p1, const void *p2);
double L_compute_k_quantile(const int k, const int q,const double energy[], const int size);
void L_advnst(FourByteLong k);
Real L_genbet(Real aa,Real bb);
Real L_genchi(Real df);
Real L_genexp(Real av);
Real L_genf(Real dfn, Real dfd);
Real L_gengam(Real a,Real r);
void L_genmn(Real *parm,Real *x,Real *work);
void L_genmul(FourByteLong n,Real *p,FourByteLong ncat,FourByteLong *ix);
Real L_gennch(Real df,Real xnonc);
Real L_gennf(Real dfn, Real dfd, Real xnonc);
Real L_gennor(Real av,Real sd);
void L_genprm(FourByteLong *iarray,int larray);
Real L_genunf(Real low,Real high);
void L_getsd(FourByteLong *iseed1,FourByteLong *iseed2);
void L_gscgn(FourByteLong getset,FourByteLong *g);
void L_gsrgs(FourByteLong getset,FourByteLong *qvalue);
void L_gssst(FourByteLong getset,FourByteLong *qset);
FourByteLong L_ignbin(FourByteLong n,Real pp);
FourByteLong L_ignnbn(FourByteLong n,Real p);
FourByteLong L_ignlgi(void);
FourByteLong L_ignpoi(Real mu);
FourByteLong L_ignuin(FourByteLong low,FourByteLong high);
void L_initgn(FourByteLong isdtyp);
void L_inrgcm(void);
FourByteLong L_lennob( char *str );
FourByteLong L_mltmod(FourByteLong a,FourByteLong s,FourByteLong m);
void L_phrtsd(char* phrase,FourByteLong* seed1,FourByteLong* seed2);
Real L_ranf(void);
void L_setall(FourByteLong iseed1,FourByteLong iseed2);
void L_setant(FourByteLong qvalue);
void L_setgmn(Real *meanv,Real *covm,FourByteLong p,Real *parm);
void L_setsd(FourByteLong iseed1,FourByteLong iseed2);
Real L_sexpo(void);
Real L_sgamma(Real a);
Real L_snorm(void);
Real L_rcauchy(Real, Real);
Real L_scauchy1(void);
void L_ftnstop(char* msg);
Real L_fsign(Real num,Real sign);
Real L_sdot(FourByteLong n,Real *sx,FourByteLong incx,Real *sy,FourByteLong incy);
void L_spofa(Real *a,FourByteLong lda,FourByteLong n,FourByteLong *info);
//Quat L_normQuat( Quat q );
void L_Add_copyState( State *D,State  S );
//void L_make_state_from_rep(L_Representation **rep, State *stateNow);
void L_torsion( const State now,Real crd[MAX_ATOMS][SPACE],const Real v[MAX_TORS][SPACE],\
				const int tlist[MAX_TORS][MAX_ATOMS],const int ntor );
void L_qtransform( const Coord T,const Quat  q,Real tcoord[MAX_ATOMS][SPACE],const int   natom);
void L_cnv_state_to_coords( const State now,Real vt[MAX_TORS][SPACE],int tlist[MAX_TORS][MAX_ATOMS],\
				const int ntor,Real crdpdb[MAX_ATOMS][SPACE],Real crd[MAX_ATOMS][SPACE],const int natom);
Real L_calc3VectorsAngle(Real x1, Real y1, Real z1, Real x2, Real y2, Real z2, Real x3, Real y3, Real z3);
Real L_trilinterp( 
				const int first_atom, // loop begins at this atom  for (i=first_atom;
				const int last_atom, // loop ends at this atom - 1       i<last_atom; i++)
				const Real tcoord[MAX_ATOMS][SPACE], // temporary coordinates
				const Real charge[MAX_ATOMS], // partial atomic charges
				const Real abs_charge[MAX_ATOMS], // absolute magnitude of partial charges
				const int   type[MAX_ATOMS], // atom type of each atom
				MapType map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS], 
				GridMapSetInfo *info, // info->lo[X],info->lo[Y],info->lo[Z],    minimum coordinates in x,y,z
				int some_atoms_outside_grid, // boolean
				int ignore_inter[MAX_ATOMS], // array of booleans, says to ignore computation intermolecular energies per atom
				Real elec[MAX_ATOMS], // set if not NULL - electrostatic energies, atom by atom
				Real emap[MAX_ATOMS],  // set if not NULL - intermolecular energies
				Real *p_elec_total, // set if not NULL - total electrostatic energy
				Real *p_emap_total, // set if not NULL - total intermolecular energy
				/**********************************
				// YTLIU_EDIT 2013.01.25
				 **********************************/
				Real &xb_empirical_vdw,
				Real &xb_empirical_es,
				Real &ad_vdw,
				Real &ad_es,
				Real &ad_desolv,
				Real xb_vdw_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real xb_es_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real xb_desolv_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES],
				Boole halogen_found,
				Real xbempirical_recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
				int xbempirical_ligand_xbdonor[MAX_ATOMS][2],
				int xbempirical_receptor_acceptor_index[MAX_RECEPTOR_ATOMS]
				);
				Real L_trilinterp(CONST_INT first_atom,
								CONST_INT last_atom,
								CONST_FLOAT tcoord[MAX_ATOMS][SPACE],
								int some_atoms_outside_grid,
								GridMapSetInfo *info,
								Real xbpmf_1d_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM],
								Real xbpmf_2d_hb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
								Real xbpmf_2d_xb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
								MapType xbpmf_1d_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM],
								MapType xbpmf_hb_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM],
								int recep_acceptor_natom,
								Real recep_acceptor_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
								char recep_acceptor_atomtype[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
								CONST_INT recep_natom,
								Real recep_crdpdb[MAX_RECEPTOR_ATOMS][SPACE],
								char recep_atomtypes[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
								char xbligand_atomtypes[MAX_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
								Real &out_grid_penalty,
								Real &xbpmf_1d,
								Real &xbpmf_2d_hb,
								Real &xbpmf_2d_xb,
								int xbpmf_hb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS],
								int xbpmf_xb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS],
								int xbpmf_ligand_hb_donorH_ids[MAX_ATOMS][5],
								int xbpmf_ligand_xb_donorX_id[MAX_ATOMS],
								int xbpmf_ligand_at_index[MAX_ATOMS],
								int xbpmf_receptor_at_index[MAX_RECEPTOR_ATOMS],
								int xbpmf_ligand_hb_acceptor[MAX_ATOMS],
								int xbpmf_ligand_hb_donor[MAX_ATOMS],
								int xbpmf_ligand_xb_donor[MAX_ATOMS],
								int xbpmf_receptor_hb_acceptor[MAX_RECEPTOR_ATOMS]);
Real L_eintcal( NonbondParam * const nonbondlist,
				const EnergyTables  *ptr_ad_energy_tables,
				const Real tcoord[MAX_ATOMS][SPACE],
				const int           Nnb,
				const Boole         B_calcIntElec,
				const Boole         B_include_1_4_interactions,
				const Real scale_1_4,
				const Real qsp_abs_charge[MAX_ATOMS],
				const Boole B_use_non_bond_cutoff,
				const Boole B_have_flexible_residues  // if the receptor has flexibile residues, this will be set to TRUE
			  );
//void L_make_state_from_rep(Representation **rep, State *stateNow);
#if defined(USING_COLINY)
void L_make_state_from_rep(double *rep, int n, State *now);
double L_ADEvalFn(double* x, int n);
#endif
void L_print_PDBQ_atom_resstr( FILE *logFile, 
				const char prefix[MAX_CHARS],
				int atom_num, // 0-origin 
				const char atomstuff[],
				const Real crd[MAX_ATOMS][SPACE],
				const Real vdW,
				const Real Elec,
				const Real charge,
				const char * suffix //newline or empty
				);
void L_mkUnitQuat( Quat *q );
void L_create_random_orientation( Quat *ptr_quat );
void L_reorient( const int true_ligand_atoms, 
				char atomstuff[MAX_ATOMS][MAX_CHARS],
				Real crdpdb[MAX_ATOMS][SPACE],  // original PDB coordinates from input
				Real charge[MAX_ATOMS],
				int type[MAX_ATOMS],
				ParameterEntry  parameterArray[MAX_ATOM_TYPES],
				Quat q_reorient,
				Coord origin,
				const int ntor,
				int tlist[MAX_TORS][MAX_ATOMS],
				Real vt[MAX_TORS][SPACE],
				Molecule *ptr_ligand,
				const int debug );
void L_torNorVec( Real crdpdb[MAX_ATOMS][SPACE],int ntor,int tlist[MAX_TORS][MAX_ATOMS],Real vt[MAX_TORS][SPACE] );
void L_update_torsion_vectors( Real crdpdb[MAX_ATOMS][SPACE],int ntor,int  tlist[MAX_TORS][MAX_ATOMS],
				Real vt[MAX_TORS][SPACE],Molecule *ligand,int debug );
L_Representation **L_generate_R_quaternion(int num_torsions, GridMapSetInfo *info);
L_Genotype L_generate_Gtype(int num_torsions, GridMapSetInfo *info);
L_Phenotype L_generate_Ptype(int num_torsions, GridMapSetInfo *info);
L_Individual L_random_ind(int num_torsions,  GridMapSetInfo *info);
State L_call_glss(L_Global_Search *global_method, L_Local_Search *local_method, 
				State sInit,unsigned int num_evals, unsigned int pop_size, 
				int outlev,unsigned int extOutputEveryNgens, Molecule *mol, 
				Boole B_RandomTran0, Boole B_RandomQuat0, Boole B_RandomDihe0,
				GridMapSetInfo *info, char *FN_pop_file,int end_of_branch[MAX_TORS]);
void L_printState( FILE *fp,State S,int detail );
void L_writeState( FILE *fp, State S );
#pragma offload_attribute(pop)
#if defined(USING_COLINY) // {
double L_Eval::operator()(double* vec, int len)
{
		L_make_state_from_rep(vec, len, &stateNow);
		return eval();
}

void L_make_state_from_rep(double *rep, int n, State *now)
{
		//  Do the translations
		now->T.x = rep[0];
		now->T.y = rep[1];
		now->T.z = rep[2];

		//  Set up the quaternion
		now->Q.x = rep[3];
		now->Q.y = rep[4];
		now->Q.z = rep[5];
		now->Q.w = rep[6];

		now->Q = L_convertQuatToRot( now->Q );

		//  Copy the angles
		now->ntor = n - 7;
		for (int i=0, j=7; j<n; i++, j++) {
				now->tor[i] = rep[j];
		}

		//mkUnitQuat(&(now->Q));
}

double L_ADEvalFn(double* x, int n)
{
		double sum = sqrt(x[3]*x[3]+x[4]*x[4]+x[5]*x[5]);
		if (sum < 1e-8)
				x[3]=x[4]=x[5]=1.0L/sqrt(3.0L);
		else {
				x[3] /= sum;
				x[4] /= sum;
				x[5] /= sum;
		}

		// torsion angles
		for (int i=6; i<n; i++)
				x[i] = WrpModRad(x[i]);

		return ::evaluate(x,n);
}
//
#endif // USING_COLINY // }



		L_Eval::L_Eval(void)
: num_evals(0)
{
}

void L_Eval::setup(Real init_crd[MAX_ATOMS][SPACE],
				Real init_charge[MAX_ATOMS],
				Real init_abs_charge[MAX_ATOMS],
				Real init_qsp_abs_charge[MAX_ATOMS],
				int init_type[MAX_ATOMS],
				int init_natom,
				Real init_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS],

				Real init_elec[MAX_ATOMS], // gmm added 21-Jan-1998, for writePDBQState
				Real init_emap[MAX_ATOMS], // gmm added 21-Jan-1998, for writePDBQState
				NonbondParam *init_nonbondlist,
				EnergyTables   *init_ptr_ad_energy_tables,
				int init_Nnb,
				Boole init_B_calcIntElec, 
				Boole init_B_isGaussTorCon,
				Boole init_B_isTorConstrained[MAX_TORS],
				Boole init_B_ShowTorE,
				unsigned short init_US_TorE[MAX_TORS],
				unsigned short init_US_torProfile[MAX_TORS][NTORDIVS],
				Real init_vt[MAX_TORS][SPACE],
				int init_tlist[MAX_TORS][MAX_ATOMS],
				Real init_crdpdb[MAX_ATOMS][SPACE],
				Real init_crdreo[MAX_ATOMS][SPACE],
				State stateInit,
				Molecule molInit,

				int init_ignore_inter[MAX_ATOMS],

				Boole init_B_include_1_4_interactions,
				Real init_scale_1_4,

				//ParameterEntry init_parameterArray[MAX_ATOM_TYPES], // input  nonbond and desolvation parameters

				Real init_unbound_internal_FE,
				GridMapSetInfo *init_info,
				Boole init_B_use_non_bond_cutoff,  // set this to FALSE if we are computing unbound extended conformations
				Boole init_B_have_flexible_residues,
				/**********************************
				// YTLIU_EDIT 2013.01.26
				 **********************************/
				Real init_xb_empirical_vdw,
				Real init_xb_empirical_es,
				Real init_ad_vdw,
				Real init_ad_es,
				Real init_ad_desolv,
				// Real init_xb_vdw_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
				// Real init_xb_es_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
				// Real init_xb_desolv_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
				/*--------------------------------------------------*/
				/*acceleration: 2013.05.23 by ytliu@mail.shcnc.ac.cn*/
				/*--------------------------------------------------*/
				Real init_xb_vdw_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real init_xb_es_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real init_xb_desolv_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				XBEmpiricalParm init_xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES],
				Boole init_halogen_found,
				Real init_xbempirical_recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
				int init_xbempirical_ligand_xbdonor[MAX_ATOMS][2],
				int init_xbempirical_receptor_acceptor_index[MAX_RECEPTOR_ATOMS]
				)

{
		register int i;

		//    printf("xb_empirical setup begin.\n");
		xb_empirical_vdw = init_xb_empirical_vdw;
		xb_empirical_es = init_xb_empirical_es;
		ad_vdw = init_ad_vdw;
		ad_es = init_ad_es;
		ad_desolv = init_ad_desolv;
		xb_vdw_profile = init_xb_vdw_profile;
		xb_es_profile = init_xb_es_profile;
		xb_desolv_profile = init_xb_desolv_profile;
		xbempirical_parms = init_xbempirical_parms;
		halogen_found = init_halogen_found;
		xbempirical_recep_crdpdb = init_xbempirical_recep_crdpdb;
		xbempirical_ligand_xbdonor = init_xbempirical_ligand_xbdonor;
		xbempirical_receptor_acceptor_index = init_xbempirical_receptor_acceptor_index;

		//    printf("autodock setup begin.\n");

		crd = init_crd;
		charge = init_charge;
		abs_charge = init_abs_charge;
		qsp_abs_charge = init_qsp_abs_charge;
		type = init_type;
		natom = init_natom;
		map = init_map;

		nonbondlist = init_nonbondlist;
		ptr_ad_energy_tables = init_ptr_ad_energy_tables;
		Nnb = init_Nnb;
		B_calcIntElec = init_B_calcIntElec;
		B_isGaussTorCon = init_B_isGaussTorCon;
		B_isTorConstrained = init_B_isTorConstrained;
		B_ShowTorE = init_B_ShowTorE;
		US_TorE = init_US_TorE;
		US_torProfile = init_US_torProfile;
		vt = init_vt;
		tlist = init_tlist;
		crdpdb = init_crdpdb;
		crdreo = init_crdreo;
		// set all of the components of the State, one at a time...
		L_Add_copyState( &stateNow, stateInit );
#ifdef DEBUG
		pr(logFile, "\n\nstateNow:\n");
		L_printState( logFile, stateNow, 2 );
#endif
		num_evals = 0;
		for (i=0; i<MAX_ATOMS; i++) {
				init_elec[i] = init_emap[i] = 0.0;
				ignore_inter[i] = init_ignore_inter[i];
		}
		mol = molInit;

		B_include_1_4_interactions = init_B_include_1_4_interactions;
		scale_1_4 = init_scale_1_4;

		//parameterArray = init_parameterArray;

		unbound_internal_FE = init_unbound_internal_FE;

		info = init_info;
		B_compute_intermol_energy = TRUE; // default is "Yes, calculate the intermolecular energy".

		B_use_non_bond_cutoff = init_B_use_non_bond_cutoff;  // set this to FALSE if we are computing unbound extended conformations
		B_have_flexible_residues = init_B_have_flexible_residues;
}

/****************************
// YTLIU_EDIT 2013.01.04
 ****************************/
void L_Eval::setup(Real init_crd[MAX_ATOMS][SPACE],
				Real init_charge[MAX_ATOMS],
				Real init_abs_charge[MAX_ATOMS],
				Real init_qsp_abs_charge[MAX_ATOMS],
				int init_type[MAX_ATOMS],
				int init_natom,
				Real init_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS],

				Real init_elec[MAX_ATOMS], // gmm added 21-Jan-1998, for writePDBQState
				Real init_emap[MAX_ATOMS], // gmm added 21-Jan-1998, for writePDBQState
				NonbondParam *init_nonbondlist,
				EnergyTables   *init_ptr_ad_energy_tables,
				int init_Nnb,
				Boole init_B_calcIntElec, 
				Boole init_B_isGaussTorCon,
				Boole init_B_isTorConstrained[MAX_TORS],
				Boole init_B_ShowTorE,
				unsigned short init_US_TorE[MAX_TORS],
				unsigned short init_US_torProfile[MAX_TORS][NTORDIVS],
				Real init_vt[MAX_TORS][SPACE],
				int init_tlist[MAX_TORS][MAX_ATOMS],
				Real init_crdpdb[MAX_ATOMS][SPACE],
				Real init_crdreo[MAX_ATOMS][SPACE],
				State stateInit,
				Molecule molInit,

				int init_ignore_inter[MAX_ATOMS],

				Boole init_B_include_1_4_interactions,
				Real init_scale_1_4,

				//ParameterEntry init_parameterArray[MAX_ATOM_TYPES], // input  nonbond and desolvation parameters

				Real init_unbound_internal_FE,
				GridMapSetInfo *init_info,
				Boole init_B_use_non_bond_cutoff,  // set this to FALSE if we are computing unbound extended conformations
				Boole init_B_have_flexible_residues,

				Real init_xbpmf_1d_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM],
				Real init_xbpmf_2d_hb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
				Real init_xbpmf_2d_xb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
				int init_recep_natom,
				Real init_recep_crdpdb[MAX_RECEPTOR_ATOMS][SPACE],
				char init_recep_atomtypes[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
				char init_xbligand_atomtypes[MAX_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
				MapType init_xbpmf_1d_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM],
				MapType init_xbpmf_hb_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM],
				int init_recep_acceptor_natom,
				Real init_recep_acceptor_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
				char init_recep_acceptor_atomtype[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
				int init_xbpmf_hb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS],
				int init_xbpmf_xb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS],
				int init_xbpmf_ligand_hb_donorH_ids[MAX_ATOMS][5],
				int init_xbpmf_ligand_xb_donorX_id[MAX_ATOMS],
				int init_xbpmf_ligand_at_index[MAX_ATOMS],
				int init_xbpmf_receptor_at_index[MAX_RECEPTOR_ATOMS],
				int init_xbpmf_ligand_hb_acceptor[MAX_ATOMS],
				int init_xbpmf_ligand_hb_donor[MAX_ATOMS],
				int init_xbpmf_ligand_xb_donor[MAX_ATOMS],
				int init_xbpmf_receptor_hb_acceptor[MAX_RECEPTOR_ATOMS])
{
		register int i;

		xbpmf_1d_pw_parms = init_xbpmf_1d_pw_parms;
		xbpmf_2d_hb_pw_parms = init_xbpmf_2d_hb_pw_parms;
		xbpmf_2d_xb_pw_parms = init_xbpmf_2d_xb_pw_parms;
		recep_natom = init_recep_natom;
		recep_crdpdb = init_recep_crdpdb;
		recep_atomtypes = init_recep_atomtypes;
		xbligand_atomtypes = init_xbligand_atomtypes;
		xbpmf_1d_map = init_xbpmf_1d_map;
		xbpmf_hb_map = init_xbpmf_hb_map;
		recep_acceptor_natom = init_recep_acceptor_natom;
		recep_acceptor_crdpdb = init_recep_acceptor_crdpdb;
		recep_acceptor_atomtype = init_recep_acceptor_atomtype;
		xbpmf_hb_label = init_xbpmf_hb_label;
		xbpmf_xb_label = init_xbpmf_xb_label;
		xbpmf_ligand_hb_donorH_ids = init_xbpmf_ligand_hb_donorH_ids;
		xbpmf_ligand_xb_donorX_id = init_xbpmf_ligand_xb_donorX_id;
		xbpmf_ligand_at_index = init_xbpmf_ligand_at_index;
		xbpmf_receptor_at_index = init_xbpmf_receptor_at_index;
		xbpmf_ligand_hb_acceptor = init_xbpmf_ligand_hb_acceptor;
		xbpmf_ligand_hb_donor = init_xbpmf_ligand_hb_donor;
		xbpmf_ligand_xb_donor = init_xbpmf_ligand_xb_donor;
		xbpmf_receptor_hb_acceptor = init_xbpmf_receptor_hb_acceptor;

		crd = init_crd;
		charge = init_charge;
		abs_charge = init_abs_charge;
		qsp_abs_charge = init_qsp_abs_charge;
		type = init_type;
		natom = init_natom;
		map = init_map;

		nonbondlist = init_nonbondlist;
		ptr_ad_energy_tables = init_ptr_ad_energy_tables;
		Nnb = init_Nnb;
		B_calcIntElec = init_B_calcIntElec;
		B_isGaussTorCon = init_B_isGaussTorCon;
		B_isTorConstrained = init_B_isTorConstrained;
		B_ShowTorE = init_B_ShowTorE;
		US_TorE = init_US_TorE;
		US_torProfile = init_US_torProfile;
		vt = init_vt;
		tlist = init_tlist;
		crdpdb = init_crdpdb;
		crdreo = init_crdreo;
		// set all of the components of the State, one at a time...
		L_Add_copyState( &stateNow, stateInit );
#ifdef DEBUG
		pr(logFile, "\n\nstateNow:\n");
		L_printState( logFile, stateNow, 2 );
#endif
		num_evals = 0;
		for (i=0; i<MAX_ATOMS; i++) {
				init_elec[i] = init_emap[i] = 0.0;
				ignore_inter[i] = init_ignore_inter[i];
		}
		mol = molInit;

		B_include_1_4_interactions = init_B_include_1_4_interactions;
		scale_1_4 = init_scale_1_4;

		//parameterArray = init_parameterArray;

		unbound_internal_FE = init_unbound_internal_FE;

		info = init_info;
		B_compute_intermol_energy = TRUE; // default is "Yes, calculate the intermolecular energy".

		B_use_non_bond_cutoff = init_B_use_non_bond_cutoff;  // set this to FALSE if we are computing unbound extended conformations
		B_have_flexible_residues = init_B_have_flexible_residues;
}

void L_Eval::update_crds( Real init_crdreo[MAX_ATOMS][SPACE], 
				Real init_vt[MAX_TORS][SPACE] )
{
		crdreo = init_crdreo;
		vt = init_vt;
}

void L_Eval::compute_intermol_energy(Boole init_B_compute_intermol_energy)
		// For computing the conformation and the internal energy of the unbound state.
{
		B_compute_intermol_energy = init_B_compute_intermol_energy;
}


UnsignedFourByteLong L_Eval::evals(void)
{
		return(num_evals);
}

void L_Eval::reset(void)
{
		num_evals = 0;
}

double L_Eval::operator()(L_Representation **rep)
{
		L_make_state_from_rep(rep, &stateNow);
		return eval();
}

double L_Eval::operator()(L_Representation **rep, int term)
{
		L_make_state_from_rep(rep, &stateNow);
		return eval(term);
}


double L_Eval::eval()
{
		return eval(3); // default is total energy
}


double L_Eval::eval(int term)
{
		register int i;
		int   B_outside = 0;
		int   I_tor = 0;
		int   indx = 0;
		double energy = 0.0L;
		double retval = 0.0L;

		Real emap_total = 0.0L;
		Real elec_total = 0.0L;
		Real emap[MAX_ATOMS] = { 0.0L };
		Real elec[MAX_ATOMS] = { 0.0L };
		// Ligand could be inside or could still be outside, check all the atoms...
		// cnv_state_to_coords(stateNow, vt, tlist, stateNow.ntor, crdreo, crd, natom);
		L_cnv_state_to_coords(stateNow, vt, tlist, stateNow.ntor, crdpdb, crd, natom);


		//  Check to see if crd is valid
		for (i=0; (i<natom)&&(!B_outside); i++) {
				B_outside = is_out_grid_info(crd[i][0], crd[i][1], crd[i][2]);
		}

		// Use standard energy function

		Real outside_grid_penalty = 0.0;
		Real xbpmf_1d_energy = 0.0;
		Real xbpmf_2d_hb_energy = 0.0;
		Real xbpmf_2d_xb_energy = 0.0;
		if (B_compute_intermol_energy) {
				if(term==3) // do not need energy breakdown in this eval() case
				{
						/*********************
						// YTLIU_EDIT 2013.01.04
						 *********************/
						if(xbpmf_scoring)
						{
								energy = L_trilinterp(0, natom, crd, 
												B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID,
												info, xbpmf_1d_pw_parms,xbpmf_2d_hb_pw_parms, 
												xbpmf_2d_xb_pw_parms,xbpmf_1d_map,xbpmf_hb_map,
												recep_acceptor_natom,recep_acceptor_crdpdb,
												recep_acceptor_atomtype,recep_natom,recep_crdpdb, 
												recep_atomtypes,xbligand_atomtypes,outside_grid_penalty,
												xbpmf_1d_energy,xbpmf_2d_hb_energy,xbpmf_2d_xb_energy,xbpmf_hb_label,xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
								//				(void)fprintf(logFile,"XBPMF Score: %15.5f\n",energy);
						}
						else
								energy = L_trilinterp( 0, natom, crd, charge, abs_charge, type, map, 
												info, B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID, 
												ignore_inter,NULL_ELEC,NULL_EVDW,NULL_ELEC_TOTAL,NULL_EVDW_TOTAL,				      xb_empirical_vdw, xb_empirical_es,
												ad_vdw, ad_es, ad_desolv, xb_vdw_profile, xb_es_profile,
												xb_desolv_profile, xbempirical_parms, halogen_found,
												xbempirical_recep_crdpdb,
												xbempirical_ligand_xbdonor,
												xbempirical_receptor_acceptor_index);
				}
				else
				{
						/*********************
						// YTLIU_EDIT 2013.01.04
						 *********************/
						if(xbpmf_scoring)
						{
								energy = L_trilinterp(0, natom, crd, 
												B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID,
												info, xbpmf_1d_pw_parms,xbpmf_2d_hb_pw_parms, 
												xbpmf_2d_xb_pw_parms,xbpmf_1d_map,xbpmf_hb_map,
												recep_acceptor_natom,recep_acceptor_crdpdb,
												recep_acceptor_atomtype,recep_natom,recep_crdpdb, 
												recep_atomtypes, xbligand_atomtypes,outside_grid_penalty,
												xbpmf_1d_energy,xbpmf_2d_hb_energy,xbpmf_2d_xb_energy,xbpmf_hb_label,xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
								//				(void)fprintf(logFile,"XBPMF Score: %15.5f\n",energy);
						}
						else
								energy = L_trilinterp( 0, natom, crd, charge, abs_charge, type, map, 
												info, B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID, 
												ignore_inter, elec, emap, &elec_total, &emap_total,
												xb_empirical_vdw, xb_empirical_es,
												ad_vdw, ad_es, ad_desolv, xb_vdw_profile, xb_es_profile,
												xb_desolv_profile, xbempirical_parms, halogen_found,
												xbempirical_recep_crdpdb,
												xbempirical_ligand_xbdonor,
												xbempirical_receptor_acceptor_index);
				}
		}


		/*********************
		// YTLIU_EDIT 2013.01.04
		 *********************/
		//	if(xbpmf_scoring==0)
		energy += L_eintcal( nonbondlist, ptr_ad_energy_tables, crd, Nnb,
						B_calcIntElec, B_include_1_4_interactions, 
						scale_1_4, qsp_abs_charge,
						B_use_non_bond_cutoff, B_have_flexible_residues);

		if (B_isGaussTorCon) {
				for (I_tor = 0; I_tor <= stateNow.ntor; I_tor++) {
						if (B_isTorConstrained[I_tor] == 1) {
								indx = RadiansToDivs( WrpModRad(stateNow.tor[I_tor]) );
								if (B_ShowTorE) {
										/*********************
										// YTLIU_EDIT 2013.01.04
										 *********************/
										//					if(xbpmf_scoring==0)
										energy += (double)(US_TorE[I_tor] = US_torProfile[I_tor][indx]);
								} else {
										/*********************
										// YTLIU_EDIT 2013.01.04
										 *********************/
										//					if(xbpmf_scoring==0)
										energy += (double)US_torProfile[I_tor][indx];
								}
						}
				} // I_tor
		}/*if*/

		// increment evaluation counter only for "total energy" case
		if(term==3) num_evals++;

		if ((!finite(energy)) || ISNAN(energy)) {
				energy=100000.0;
		} // i

		switch (term) {
				default:
				case 0:
				case 3:
						// Return the total energy.
						retval = energy;
						break;
				case 1:
						// Return the non-bonded energy, vdW+Hb+desolv.
						/*********************
						// YTLIU_EDIT 2013.01.04
						 *********************/
						if(xbpmf_scoring)
								retval = energy;
						else
								retval = (double)emap_total;
						break;
				case 2:
						// Return the electrostatics energy.
						/*********************
						// YTLIU_EDIT 2013.01.04
						 *********************/
						if(xbpmf_scoring)
								retval = energy;
						else
								retval = (double)elec_total;
						break;
		}
		return(retval);
}


int L_Eval::write(FILE *out_file, L_Representation **rep)
{
		int i=0, retval=0;

		L_make_state_from_rep(rep, &stateNow);
		// cnv_state_to_coords(stateNow, vt, tlist, stateNow.ntor, crdreo, crd, natom);
		L_cnv_state_to_coords(stateNow, vt, tlist, stateNow.ntor, crdpdb, crd, natom);
		for (i=0; i<natom; i++) {
				L_print_PDBQ_atom_resstr( logFile, "", i,   " C   RES     1 ", crd,0.0, 0.0, charge[i],"\n"); 
		} // i
		return retval;
}


double L_Eval::evalpso(State *state)
{
		register int i;
		int   B_outside = 0;
		int   I_tor = 0;
		int   indx = 0;
		double energy = 0.0;

		//double einter = 0.0; 
		//double eintra = 0.0; 
		Real emap_total = 0.0L;
		Real elec_total = 0.0L;
		Real emap[MAX_ATOMS] = { 0.0L };
		Real elec[MAX_ATOMS] = { 0.0L };


		L_mkUnitQuat( &(state->Q) );
		L_Add_copyState(&stateNow, *state);

		// Ligand could be inside or could still be outside, check all the atoms...
		L_cnv_state_to_coords(stateNow, vt, tlist, stateNow.ntor, crdpdb, crd, natom);

		//  Check to see if crd is valid
		for (i=0; (i<natom)&&(!B_outside); i++) {
				B_outside = is_out_grid_info(crd[i][0], crd[i][1], crd[i][2]);
		} // i

		Real outside_grid_energy = 0.0;
		Real xbpmf_1d_energy = 0.0;
		Real xbpmf_2d_hb_energy = 0.0;
		Real xbpmf_2d_xb_energy = 0.0;
		//if (!B_template){
		// Use standard energy function
		if (!B_outside) {
				// formerly quicktrilinterp->last 4 arguments are NULL:
				// use NULL_ELEC, NULL_EVDW, NULL_ELEC_TOTAL, NULL_EVDW_TOTAL);

				/*********************
				// YTLIU_EDIT 2013.01.04
				 *********************/
				if(xbpmf_scoring)
				{
						energy = L_trilinterp(0, natom, crd, 
										B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID, 
										info, xbpmf_1d_pw_parms,xbpmf_2d_hb_pw_parms, 
										xbpmf_2d_xb_pw_parms,xbpmf_1d_map,xbpmf_hb_map,
										recep_acceptor_natom,recep_acceptor_crdpdb,
										recep_acceptor_atomtype,recep_natom,recep_crdpdb, 
										recep_atomtypes,xbligand_atomtypes,outside_grid_energy,
										xbpmf_1d_energy,xbpmf_2d_hb_energy,xbpmf_2d_xb_energy,xbpmf_hb_label,xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
						//			(void)fprintf(logFile,"XBPMF Score: %15.5f\n",energy);
				}
				else
						energy = L_trilinterp( 0, natom, crd, charge, abs_charge, type, map, 
										info, B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID, 
										ignore_inter, elec, emap, &elec_total, &emap_total,
										xb_empirical_vdw, xb_empirical_es,
										ad_vdw, ad_es, ad_desolv, xb_vdw_profile, xb_es_profile,
										xb_desolv_profile, xbempirical_parms, halogen_found,
										xbempirical_recep_crdpdb,
										xbempirical_ligand_xbdonor,
										xbempirical_receptor_acceptor_index);
				//ignore_inter, NULL_ELEC, NULL_EVDW, NULL_ELEC_TOTAL, NULL_EVDW_TOTAL);

				/*********************
				// YTLIU_EDIT 2013.01.04
				 *********************/
				//		if(xbpmf_scoring==0)
				energy += L_eintcal( nonbondlist, ptr_ad_energy_tables, crd, Nnb,
								B_calcIntElec, B_include_1_4_interactions,
								scale_1_4, qsp_abs_charge,
								B_use_non_bond_cutoff, B_have_flexible_residues);

				if (B_isGaussTorCon) {
						for (I_tor = 0; I_tor <= stateNow.ntor; I_tor++) {
								if (B_isTorConstrained[I_tor] == 1) {
										indx = RadiansToDivs( WrpModRad(stateNow.tor[I_tor]) );
										if (B_ShowTorE) {
												/*********************
												// YTLIU_EDIT 2013.01.04
												 *********************/
												//						if(xbpmf_scoring==0)
												energy += (double)(US_TorE[I_tor] = US_torProfile[I_tor][indx]);
										} else {
												/*********************
												// YTLIU_EDIT 2013.01.04
												 *********************/
												//						if(xbpmf_scoring==0)
												energy += (double)US_torProfile[I_tor][indx];
										}
								}
						} // I_tor
				}/*if isGaussTorCon*/
		} else { 
				/*********************
				// YTLIU_EDIT 2013.01.04
				 *********************/
				if(xbpmf_scoring)
				{
						energy = L_trilinterp(0, natom, crd, 
										B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID, 
										info, xbpmf_1d_pw_parms,xbpmf_2d_hb_pw_parms, 
										xbpmf_2d_xb_pw_parms,xbpmf_1d_map,xbpmf_hb_map,
										recep_acceptor_natom,recep_acceptor_crdpdb,
										recep_acceptor_atomtype,recep_natom,recep_crdpdb, 
										recep_atomtypes, xbligand_atomtypes,outside_grid_energy,
										xbpmf_1d_energy,xbpmf_2d_hb_energy,xbpmf_2d_xb_energy,xbpmf_hb_label,xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
						//			(void)fprintf(logFile,"XBPMF Score: %15.5f\n",energy);
				}
				else
						energy = L_trilinterp( 0, natom, crd, charge, abs_charge, type, map, 
										info, B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID, 
										ignore_inter, elec, emap, &elec_total, &emap_total,
										xb_empirical_vdw, xb_empirical_es,
										ad_vdw, ad_es, ad_desolv, xb_vdw_profile, xb_es_profile,
										xb_desolv_profile, xbempirical_parms, halogen_found,
										xbempirical_recep_crdpdb,
										xbempirical_ligand_xbdonor,
										xbempirical_receptor_acceptor_index);

				/*********************
				// YTLIU_EDIT 2013.01.04
				 *********************/
				//		if(xbpmf_scoring==0)
				energy += L_eintcal( nonbondlist, ptr_ad_energy_tables, crd, Nnb,
								B_calcIntElec, B_include_1_4_interactions,
								scale_1_4, qsp_abs_charge,
								B_use_non_bond_cutoff, B_have_flexible_residues);


				// + eintcal( nonbondlist, e_internal, crd, type, Nnb,
				//            B_calcIntElec, q1q2);
				if (B_isGaussTorCon) {
						for (I_tor = 0; I_tor <= stateNow.ntor; I_tor++) {
								if (B_isTorConstrained[I_tor] == 1) {
										indx = RadiansToDivs( WrpModRad(stateNow.tor[I_tor]) );
										if (B_ShowTorE) {
												/*********************
												// YTLIU_EDIT 2013.01.04
												 *********************/
												//							if(xbpmf_scoring==0)
												energy += (double)(US_TorE[I_tor] = US_torProfile[I_tor][indx]);
										} else {
												/*********************
												// YTLIU_EDIT 2013.01.04
												 *********************/
												//							if(xbpmf_scoring==0)
												energy += (double)US_torProfile[I_tor][indx];
										}
								}
						} // I_tor
				} // if
		}

		num_evals++;
		if (!finite(energy)) {
				energy=100000.0;
		}
		if (ISNAN(energy)) {
				energy=100000.0;
		}

		return(energy);
}

void L_Add_copyState( State *D,State  S ) 
{
		register int i;

		D->T = S.T;

		D->Q = S.Q;

		D->ntor   = S.ntor;

		for ( i=0; i < S.ntor; i++ ) {
				D->tor[i] = S.tor[i];
		}

		D->hasEnergy = S.hasEnergy;

		D->e = S.e;
}

void L_torsion( const State now,Real crd[MAX_ATOMS][SPACE],const Real v[MAX_TORS][SPACE],\
				const int tlist[MAX_TORS][MAX_ATOMS],const int ntor )
{
		register double crdtemp[SPACE];
		register double  d[SPACE];
		register double sv[SPACE];
		register double ov[SPACE];
		register double  k[SPACE][SPACE];
		register double s, c, o, vni, this_tor;                /* "o" is: 1. - c, "One minus c". */
		register int n, a, mvatm, atmnum, numatmmoved;

		for (n = 0;  n < ntor;  n++) {                /* "n"-th Torsion */
				s = sin(this_tor = ModRad(now.tor[n]));
				o = 1. - (c = cos(this_tor));
				/*
				   atmnum = Serial number of Atom 0 in Torsion n, (0)--(1) 
				   This atom is at the origin of the current torsion
				   vector, about which we are rotating...
				   */
				atmnum = tlist[n][0];
				crdtemp[X] = (double)crd[atmnum][X];
				crdtemp[Y] = (double)crd[atmnum][Y];
				crdtemp[Z] = (double)crd[atmnum][Z];

				sv[X] = s * (vni = v[n][X]);
				k[X][X] = (ov[X] = o * vni) * vni + c;

				sv[Y] = s * (vni = v[n][Y]);
				k[Y][Y] = (ov[Y] = o * vni) * vni + c;

				sv[Z] = s * (vni = v[n][Z]);
				k[Z][Z] = (ov[Z] = o * vni) * vni + c;

				k[Y][Z]  =  v[n][Y] * ov[Z]  -  sv[X];
				k[Z][X]  =  v[n][Z] * ov[X]  -  sv[Y];
				k[X][Y]  =  v[n][X] * ov[Y]  -  sv[Z];

				k[Z][Y]  =  v[n][Z] * ov[Y]  +  sv[X];
				k[X][Z]  =  v[n][X] * ov[Z]  +  sv[Y];
				k[Y][X]  =  v[n][Y] * ov[X]  +  sv[Z];

				numatmmoved = tlist[n][NUM_ATM_MOVED] + 3; 
				for (a = 3;  a < numatmmoved;  a++ )  {        
						mvatm = tlist[n][a]; /* mvatm = Serial Num of Atom to be moved by this Torsion */
						d[X] = (double)crd[mvatm][X] - crdtemp[X];
						d[Y] = (double)crd[mvatm][Y] - crdtemp[Y];
						d[Z] = (double)crd[mvatm][Z] - crdtemp[Z];
						crd[mvatm][X] = (double)crdtemp[X] + d[X] * k[X][X] + d[Y] * k[X][Y] + d[Z] * k[X][Z]; 
						crd[mvatm][Y] = (double)crdtemp[Y] + d[X] * k[Y][X] + d[Y] * k[Y][Y] + d[Z] * k[Y][Z]; 
						crd[mvatm][Z] = (double)crdtemp[Z] + d[X] * k[Z][X] + d[Y] * k[Z][Y] + d[Z] * k[Z][Z]; 
				}/*a*/
		} /*n*/
}

void L_qtransform( const Coord T,const Quat  q,Real tcoord[MAX_ATOMS][SPACE],const int   natom)
{
		register int a;
		Coord  tmp;
		double w, x, y, z;
		double tx, ty, tz;
		double omtxx;
		double twx, txy, txz;
		double twy, tyy, tyz;
		double twz, tzz;
		double r11, r12, r13, r21, r22, r23, r31, r32, r33;

		w = q.w;
		x = q.x;
		y = q.y;
		z = q.z;

		/*  15 adds, 9 multiplies...      */
		tx  = x+x;
		ty  = y+y;
		tz  = z+z;

		twx = w*tx;
		omtxx = 1. - x*tx;
		txy = y*tx;
		txz = z*tx;

		twy = w*ty;
		tyy = y*ty;
		tyz = z*ty;

		twz = w*tz;
		tzz = z*tz;

		r11 = 1. - tyy - tzz;
		r12 =      txy - twz;
		r13 =      txz + twy;
		r21 =      txy + twz;
		r22 = omtxx    - tzz;
		r23 =      tyz - twx;
		r31 =      txz - twy;
		r32 =      tyz + twx;
		r33 = omtxx    - tyy;

		for (a = 0;  a < natom;  a++) {
				tmp.x = ((double)tcoord[a][X])*r11 + ((double)tcoord[a][Y])*r21 + ((double)tcoord[a][Z])*r31 + T.x;
				tmp.y = ((double)tcoord[a][X])*r12 + ((double)tcoord[a][Y])*r22 + ((double)tcoord[a][Z])*r32 + T.y;
				tmp.z = ((double)tcoord[a][X])*r13 + ((double)tcoord[a][Y])*r23 + ((double)tcoord[a][Z])*r33 + T.z;
				tcoord[a][X] = tmp.x;
				tcoord[a][Y] = tmp.y;
				tcoord[a][Z] = tmp.z;
		}
}

void L_cnv_state_to_coords( const State now,Real vt[MAX_TORS][SPACE],int tlist[MAX_TORS][MAX_ATOMS],\
				const int ntor,Real crdpdb[MAX_ATOMS][SPACE],Real crd[MAX_ATOMS][SPACE],const int natom)
{


		(void) memcpy( crd, crdpdb,  natom * 3 * sizeof(Real));

		//  memcpy is about 100x faster than these nested for-loops...
		//  for (i = 0;  i < natom;  i++) for (XYZ = 0;  XYZ < SPACE;  XYZ++) crd[i][XYZ] = crdpdb[i][XYZ];

		//  Apply torsions, if any
		if (ntor > 0) {
				L_torsion( now, crd, vt, tlist, ntor );
		}
		//  Apply quaternion rigid-body rotation and translation...
		L_qtransform( now.T, now.Q, crd, true_ligand_atoms );
}

Real L_calc3VectorsAngle(Real x1, Real y1, Real z1, Real x2, Real y2, Real z2, Real x3, Real y3, Real z3)
{
		Real dp = (sqhypotenuse((x1-x2),(y1-y2),(z1-z2)) + sqhypotenuse((x3-x2),(y3-y2),(z3-z2)) - sqhypotenuse((x1-x3),(y1-y3),(z1-z3))) / (2 * hypotenuse((x1-x2),(y1-y2),(z1-z2)) * hypotenuse((x3-x2),(y3-y2),(z3-z2)));
		if(dp < -0.9999999)
				dp = -0.9999999;
		if(dp > 0.9999999)
				dp = 0.9999999;
		if(dp > 1.0)
				dp = 1.0;
		return (Real)(RAD_TO_DEG * acos(dp));
}

Real L_trilinterp( 
				const int first_atom, // loop begins at this atom  for (i=first_atom;
				const int last_atom, // loop ends at this atom - 1       i<last_atom; i++)
				const Real tcoord[MAX_ATOMS][SPACE], // temporary coordinates
				const Real charge[MAX_ATOMS], // partial atomic charges
				const Real abs_charge[MAX_ATOMS], // absolute magnitude of partial charges
				const int   type[MAX_ATOMS], // atom type of each atom
				MapType map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS], 
				GridMapSetInfo *info, // info->lo[X],info->lo[Y],info->lo[Z],    minimum coordinates in x,y,z
				int some_atoms_outside_grid, // boolean
				int ignore_inter[MAX_ATOMS], // array of booleans, says to ignore computation intermolecular energies per atom
				Real elec[MAX_ATOMS], // set if not NULL - electrostatic energies, atom by atom
				Real emap[MAX_ATOMS],  // set if not NULL - intermolecular energies
				Real *p_elec_total, // set if not NULL - total electrostatic energy
				Real *p_emap_total, // set if not NULL - total intermolecular energy
				/**********************************
				// YTLIU_EDIT 2013.01.25
				 **********************************/
				Real &xb_empirical_vdw,
				Real &xb_empirical_es,
				Real &ad_vdw,
				Real &ad_es,
				Real &ad_desolv,
				Real xb_vdw_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real xb_es_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real xb_desolv_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES],
				Boole halogen_found,
				Real xbempirical_recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
				int xbempirical_ligand_xbdonor[MAX_ATOMS][2],
				int xbempirical_receptor_acceptor_index[MAX_RECEPTOR_ATOMS]
				)
{
		register double elec_total=0, emap_total=0;
		register int i;               /* i-th atom */

		/**********************************
		// YTLIU_EDIT 2013.01.25
		 **********************************/
		register int j;

		/**********************************
		// YTLIU_EDIT 2013.01.26
		 **********************************/
		xb_empirical_vdw = 0.;
		xb_empirical_es = 0.;
		ad_vdw = 0.;
		ad_es = 0.;
		ad_desolv = 0.;

		/*--------------------------------------------------*/
		/*acceleration: 2013.05.23 by ytliu@mail.shcnc.ac.cn*/
		/*--------------------------------------------------*/
		Real xb_egrid[2][2][2];
		Real xb_evdw[2][2][2];
		Real xb_ees[2][2][2];
		Real ad_evdw[2][2][2];
		Real ad_ees[2][2][2];
		Real ad_edesolv[2][2][2];
		int xbreceptor_id=-1;

		// for (i=0; i<total_atoms; i++) {
		for (i=first_atom; i<last_atom; i++) {
				register double e, m, d; 
				register double u,   v,   w;
				register double p0u, p0v, p0w;
				register double p1u, p1v, p1w;
				register int AtomType;        /* atom type */
				register int u0,  v0,  w0;
				register int u1,  v1,  w1;

				if (ignore_inter[i]) {
						if (elec != NULL) elec[i] = 0;
						if (emap != NULL) emap[i] = 0;
						continue;
				}

				if (some_atoms_outside_grid) {
						register double x,y,z;
						x = tcoord[i][X];
						y = tcoord[i][Y];
						z = tcoord[i][Z];
						if (is_out_grid_info(x,y,z)) {
								register double epenalty;
								x -= info->center[X];
								y -= info->center[Y];
								z -= info->center[Z];
								// sqhypotenuse(x,y,z) is the square of the distance from grid's centre to atom
								epenalty = sqhypotenuse(x,y,z) * ENERGYPENALTY;
								if (elec != NULL) elec[i] = epenalty;
								if (emap != NULL) emap[i] = epenalty;
								elec_total += epenalty;
								emap_total += epenalty;
								continue;
						}
				}

				AtomType = type[i];

				u1  = (u0 = (int) (u = ((double)tcoord[i][X]-(double)info->lo[X]) * (double)info->inv_spacing)) + 1;
				p1u = 1.0L - (p0u = u - (double) u0);

				v1  = (v0 = (int) (v = ((double)tcoord[i][Y]-(double)info->lo[Y]) * (double)info->inv_spacing)) + 1;
				p1v = 1.0L - (p0v = v - (double) v0);

				w1  = (w0 = (int) (w = ((double)tcoord[i][Z]-(double)info->lo[Z]) * (double)info->inv_spacing)) + 1;
				p1w = 1.0L - (p0w = w - (double) w0);

#ifdef MINPOINT
				register int ix,iy,iz;                      /*MINPOINT*/
				ix = (p0u < p1u)? u0 : u1;				    /*MINPOINT*/
				iy = (p0v < p1v)? v0 : v1;				    /*MINPOINT*/
				iz = (p0w < p1w)? w0 : w1;				    /*MINPOINT*/

				e = map[iz][iy][ix][ElecMap];               /*MINPOINT*/
				m = map[iz][iy][ix][AtomType]; 	            /*MINPOINT*/
				d = map[iz][iy][ix][DesolvMap]; 	        /*MINPOINT*/
#else
				e = m = d = 0.0L;

				e += p1u * p1v * p1w * map[ w0 ][ v0 ][ u0 ][ElecMap];
				m += p1u * p1v * p1w * map[ w0 ][ v0 ][ u0 ][AtomType];
				d += p1u * p1v * p1w * map[ w0 ][ v0 ][ u0 ][DesolvMap];

				d += p0u * p1v * p1w * map[ w0 ][ v0 ][ u1 ][DesolvMap];
				m += p0u * p1v * p1w * map[ w0 ][ v0 ][ u1 ][AtomType];
				e += p0u * p1v * p1w * map[ w0 ][ v0 ][ u1 ][ElecMap];

				e += p1u * p0v * p1w * map[ w0 ][ v1 ][ u0 ][ElecMap];
				m += p1u * p0v * p1w * map[ w0 ][ v1 ][ u0 ][AtomType];
				d += p1u * p0v * p1w * map[ w0 ][ v1 ][ u0 ][DesolvMap];

				d += p0u * p0v * p1w * map[ w0 ][ v1 ][ u1 ][DesolvMap];
				m += p0u * p0v * p1w * map[ w0 ][ v1 ][ u1 ][AtomType];
				e += p0u * p0v * p1w * map[ w0 ][ v1 ][ u1 ][ElecMap];

				e += p1u * p1v * p0w * map[ w1 ][ v0 ][ u0 ][ElecMap];
				m += p1u * p1v * p0w * map[ w1 ][ v0 ][ u0 ][AtomType];
				d += p1u * p1v * p0w * map[ w1 ][ v0 ][ u0 ][DesolvMap];

				d += p0u * p1v * p0w * map[ w1 ][ v0 ][ u1 ][DesolvMap];
				m += p0u * p1v * p0w * map[ w1 ][ v0 ][ u1 ][AtomType];
				e += p0u * p1v * p0w * map[ w1 ][ v0 ][ u1 ][ElecMap];

				e += p1u * p0v * p0w * map[ w1 ][ v1 ][ u0 ][ElecMap];
				m += p1u * p0v * p0w * map[ w1 ][ v1 ][ u0 ][AtomType];
				d += p1u * p0v * p0w * map[ w1 ][ v1 ][ u0 ][DesolvMap];

				d += p0u * p0v * p0w * map[ w1 ][ v1 ][ u1 ][DesolvMap];
				m += p0u * p0v * p0w * map[ w1 ][ v1 ][ u1 ][AtomType];
				e += p0u * p0v * p0w * map[ w1 ][ v1 ][ u1 ][ElecMap];
#endif /* not MINPOINT */

				elec_total += e * charge[i];
				emap_total += m + d * abs_charge[i]; 

				if (elec != NULL) elec[i] = e * charge[i];
				if (emap != NULL) emap[i] = m + d * abs_charge[i];

				/*--------------------------------------------------*/
				/*acceleration: 2013.05.23 by ytliu@mail.shcnc.ac.cn*/
				/*--------------------------------------------------*/
				if(xb_empirical_scoring && halogen_found){
						if(xbempirical_ligand_xbdonor[i][0] != -1){

								int n,s,t;
								for(n=w0; n<=w1; n++){
										for(s=v0; s<=v1; s++){
												for(t=u0; t<=u1; t++){

														xb_egrid[n-w0][s-v0][t-u0]=999999.0;
														xb_evdw[n-w0][s-v0][t-u0]=999999.0;
														xb_ees[n-w0][s-v0][t-u0]=999999.0;
														ad_evdw[n-w0][s-v0][t-u0]=999999.0;
														ad_ees[n-w0][s-v0][t-u0]=999999.0;
														ad_edesolv[n-w0][s-v0][t-u0]=999999.0;

														int lig_index = xbempirical_ligand_xbdonor[i][0];

														Real max_xb_energy=0.0;
														Real max_xb_evdw=0.0;
														Real max_xb_ees=0.0;
														Real max_ad_evdw=0.0;
														Real max_ad_ees=0.0;
														Real max_ad_edesolv=0.0;

														for(j=3; j>=0; j--){
																xbreceptor_id=(int)xb_desolv_profile[n][s][t][lig_index][2*j+1];
																Real xdist=hypotenuse(
																				(tcoord[i][X]-xbempirical_recep_crdpdb[xbreceptor_id][X]),
																				(tcoord[i][Y]-xbempirical_recep_crdpdb[xbreceptor_id][Y]),
																				(tcoord[i][Z]-xbempirical_recep_crdpdb[xbreceptor_id][Z]));


																if(xdist>NBCUTOFF || xdist<3.0){
																		if(j==3){
																				max_xb_energy=0.0;
																				max_xb_evdw=0.0;
																				max_xb_ees=0.0;
																				max_ad_evdw=0.0;
																				max_ad_ees=0.0;
																				max_ad_edesolv=0.0;
																				continue;
																		}
																		if(max_xb_energy<xb_egrid[n-w0][s-v0][t-u0]){
																				xb_egrid[n-w0][s-v0][t-u0]=max_xb_energy;
																				xb_evdw[n-w0][s-v0][t-u0]=max_xb_evdw;
																				xb_ees[n-w0][s-v0][t-u0]=max_xb_ees;
																				ad_evdw[n-w0][s-v0][t-u0]=max_ad_evdw;
																				ad_ees[n-w0][s-v0][t-u0]=max_ad_ees;
																				ad_edesolv[n-w0][s-v0][t-u0]=max_ad_edesolv;
																		}
																		continue;
																}

																int k = xbempirical_ligand_xbdonor[i][1];
																Real xangle=L_calc3VectorsAngle(
																				tcoord[k][X],tcoord[k][Y],tcoord[k][Z],
																				tcoord[i][X],tcoord[i][Y],tcoord[i][Z],
																				xbempirical_recep_crdpdb[xbreceptor_id][X],
																				xbempirical_recep_crdpdb[xbreceptor_id][Y],
																				xbempirical_recep_crdpdb[xbreceptor_id][Z]);


																if(xangle<=90.0){
																		if(j==3){
																				max_xb_energy=0.0;
																				max_xb_evdw=0.0;
																				max_xb_ees=0.0;
																				max_ad_evdw=0.0;
																				max_ad_ees=0.0;
																				max_ad_edesolv=0.0;
																				continue;
																		}
																		if(max_xb_energy<xb_egrid[n-w0][s-v0][t-u0]){
																				xb_egrid[n-w0][s-v0][t-u0]=max_xb_energy;
																				xb_evdw[n-w0][s-v0][t-u0]=max_xb_evdw;
																				xb_ees[n-w0][s-v0][t-u0]=max_xb_ees;
																				ad_evdw[n-w0][s-v0][t-u0]=max_ad_evdw;
																				ad_ees[n-w0][s-v0][t-u0]=max_ad_ees;
																				ad_edesolv[n-w0][s-v0][t-u0]=max_ad_edesolv;
																		}
																		continue;
																}

																int rec_index = xbempirical_receptor_acceptor_index[xbreceptor_id];
																Real temp_energy=0.0;
																temp_energy=xb_vdw_profile[n][s][t][lig_index][2*j+1]+xb_es_profile[n][s][t][lig_index][2*j+1]*cos(xbempirical_parms[lig_index][rec_index].ESxb_freq * xangle * PI / 180.0 + xbempirical_parms[lig_index][rec_index].ESxb_initial_phase)+xbempirical_parms[lig_index][rec_index].ESxb_constant / xdist;

																if(j==3){
																		max_xb_energy=temp_energy;
																		max_xb_evdw=xb_vdw_profile[n][s][t][lig_index][2*j+1];
																		max_xb_ees=xb_es_profile[n][s][t][lig_index][2*j+1]*cos(xbempirical_parms[lig_index][rec_index].ESxb_freq * xangle * PI / 180.0 + xbempirical_parms[lig_index][rec_index].ESxb_initial_phase)+xbempirical_parms[lig_index][rec_index].ESxb_constant / xdist;
																		max_ad_evdw=xb_vdw_profile[n][s][t][lig_index][2*j];
																		max_ad_ees=charge[i]*xb_es_profile[n][s][t][lig_index][2*j];
																		max_ad_edesolv=xb_desolv_profile[n][s][t][lig_index][2*j]*fabs(charge[i]);
																		continue;
																}
																if(temp_energy+max_xb_energy<xb_egrid[n-w0][s-v0][t-u0]){
																		xb_egrid[n-w0][s-v0][t-u0]=temp_energy+max_xb_energy;
																		xb_evdw[n-w0][s-v0][t-u0]=max_xb_evdw+xb_vdw_profile[n][s][t][lig_index][2*j+1];
																		xb_ees[n-w0][s-v0][t-u0]=max_xb_ees+xb_es_profile[n][s][t][lig_index][2*j+1]*cos(xbempirical_parms[lig_index][rec_index].ESxb_freq * xangle * PI / 180.0 + xbempirical_parms[lig_index][rec_index].ESxb_initial_phase)+xbempirical_parms[lig_index][rec_index].ESxb_constant / xdist;
																		ad_evdw[n-w0][s-v0][t-u0]=max_ad_evdw+xb_vdw_profile[n][s][t][lig_index][2*j];
																		ad_ees[n-w0][s-v0][t-u0]=max_ad_ees+charge[i]*xb_es_profile[n][s][t][lig_index][2*j];
																		ad_edesolv[n-w0][s-v0][t-u0]=max_ad_edesolv+xb_desolv_profile[n][s][t][lig_index][2*j]*fabs(charge[i]);
																}
														}

												}
										}
								}

								Real vdw1 = 0.0, vdw2 = 0.0, es1 = 0.0, es2 = 0.0, desolv1 = 0.0;
								vdw1=vdw1+p1u * p1v * p1w * ad_evdw[0][0][0]+
										p0u * p1v * p1w * ad_evdw[0][0][1]+
										p1u * p0v * p1w * ad_evdw[0][1][0]+
										p1u * p1v * p0w * ad_evdw[1][0][0]+
										p0u * p0v * p1w * ad_evdw[0][1][1]+
										p0u * p1v * p0w * ad_evdw[1][0][1]+
										p1u * p0v * p0w * ad_evdw[1][1][0]+
										p0u * p0v * p0w * ad_evdw[1][1][1];
								es1=es1+p1u * p1v * p1w * ad_ees[0][0][0]+
										p0u * p1v * p1w * ad_ees[0][0][1]+
										p1u * p0v * p1w * ad_ees[0][1][0]+
										p1u * p1v * p0w * ad_ees[1][0][0]+
										p0u * p0v * p1w * ad_ees[0][1][1]+
										p0u * p1v * p0w * ad_ees[1][0][1]+
										p1u * p0v * p0w * ad_ees[1][1][0]+
										p0u * p0v * p0w * ad_ees[1][1][1];
								desolv1=desolv1+p1u * p1v * p1w * ad_edesolv[0][0][0]+
										p0u * p1v * p1w * ad_edesolv[0][0][1]+
										p1u * p0v * p1w * ad_edesolv[0][1][0]+
										p1u * p1v * p0w * ad_edesolv[1][0][0]+
										p0u * p0v * p1w * ad_edesolv[0][1][1]+
										p0u * p1v * p0w * ad_edesolv[1][0][1]+
										p1u * p0v * p0w * ad_edesolv[1][1][0]+
										p0u * p0v * p0w * ad_edesolv[1][1][1];
								vdw2=vdw2+p1u * p1v * p1w * xb_evdw[0][0][0]+
										p0u * p1v * p1w * xb_evdw[0][0][1]+
										p1u * p0v * p1w * xb_evdw[0][1][0]+
										p1u * p1v * p0w * xb_evdw[1][0][0]+
										p0u * p0v * p1w * xb_evdw[0][1][1]+
										p0u * p1v * p0w * xb_evdw[1][0][1]+
										p1u * p0v * p0w * xb_evdw[1][1][0]+
										p0u * p0v * p0w * xb_evdw[1][1][1];
								es2=es2+p1u * p1v * p1w * xb_ees[0][0][0]+
										p0u * p1v * p1w * xb_ees[0][0][1]+
										p1u * p0v * p1w * xb_ees[0][1][0]+
										p1u * p1v * p0w * xb_ees[1][0][0]+
										p0u * p0v * p1w * xb_ees[0][1][1]+
										p0u * p1v * p0w * xb_ees[1][0][1]+
										p1u * p0v * p0w * xb_ees[1][1][0]+
										p0u * p0v * p0w * xb_ees[1][1][1];


								if(vdw2+es2-vdw1-es1-desolv1<=-1.0){
										Real bdelta=vdw1+es1-vdw2-es2+desolv1-1.0;
										if(vdw2-vdw1<=-1.0)
												vdw2+=bdelta;
										else if(es2-es1<=-1.0)
												es2+=bdelta;
										else if(vdw2-vdw1<=es2-es1)
												vdw2+=bdelta;
										else
												es2+=bdelta;
								}

								ad_vdw += vdw1;
								xb_empirical_vdw += vdw2;
								ad_es += es1;
								xb_empirical_es += es2;
								ad_desolv += desolv1;

								if (elec != NULL) elec[i] = elec[i] + es2 - es1;
								if (emap != NULL) emap[i] = emap[i] + vdw2 - vdw1 - desolv1;
						}
				}
		} // for (i=first_atom; i<last_atom; i++)

		if (p_elec_total != NULL) *p_elec_total = elec_total + xb_empirical_es - ad_es;
		if (p_emap_total != NULL) *p_emap_total = emap_total + xb_empirical_vdw - ad_vdw - ad_desolv;

		if(xb_empirical_es+xb_empirical_vdw-ad_vdw-ad_es-ad_desolv<=-5.0)
		{
				Real delta=ad_vdw+ad_es+ad_desolv-xb_empirical_es-xb_empirical_vdw-5.0;

				if(xb_empirical_vdw-ad_vdw<=-5.0)
						xb_empirical_vdw+=delta;
				else if(xb_empirical_es-ad_es<=-5.0)
						xb_empirical_es+=delta;
				else if(xb_empirical_vdw-ad_vdw<=xb_empirical_es-ad_es)
						xb_empirical_vdw+=delta;
				else
						xb_empirical_es+=delta;

				for (i=first_atom; i<last_atom; i++) {
						//	    if (elec != NULL) elec[i]+=delta/(last_atom-first_atom);
						if (emap != NULL) emap[i]+=delta/(last_atom-first_atom);
				}

				if (p_elec_total != NULL) *p_elec_total = elec_total + xb_empirical_es - ad_es;
				if (p_emap_total != NULL) *p_emap_total = emap_total + xb_empirical_vdw - ad_vdw - ad_desolv;
				return ( (Real)elec_total+emap_total-5.0);
		}
		else
				return( (Real)elec_total+emap_total+xb_empirical_es+xb_empirical_vdw-ad_vdw-ad_es-ad_desolv);
}

/**************************************
// YTLIU_EDIT 2013.01.04
 **************************************/
Real L_trilinterp(CONST_INT first_atom,
				CONST_INT last_atom,
				CONST_FLOAT tcoord[MAX_ATOMS][SPACE],
				int some_atoms_outside_grid,
				GridMapSetInfo *info,
				Real xbpmf_1d_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM],
				Real xbpmf_2d_hb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
				Real xbpmf_2d_xb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
				MapType xbpmf_1d_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM],
				MapType xbpmf_hb_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM],
				int recep_acceptor_natom,
				Real recep_acceptor_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
				char recep_acceptor_atomtype[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
				CONST_INT recep_natom,
				Real recep_crdpdb[MAX_RECEPTOR_ATOMS][SPACE],
				char recep_atomtypes[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
				char xbligand_atomtypes[MAX_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1],
				Real &out_grid_penalty,
				Real &xbpmf_1d,
				Real &xbpmf_2d_hb,
				Real &xbpmf_2d_xb,
				int xbpmf_hb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS],
				int xbpmf_xb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS],
				int xbpmf_ligand_hb_donorH_ids[MAX_ATOMS][5],
				int xbpmf_ligand_xb_donorX_id[MAX_ATOMS],
				int xbpmf_ligand_at_index[MAX_ATOMS],
				int xbpmf_receptor_at_index[MAX_RECEPTOR_ATOMS],
				int xbpmf_ligand_hb_acceptor[MAX_ATOMS],
				int xbpmf_ligand_hb_donor[MAX_ATOMS],
				int xbpmf_ligand_xb_donor[MAX_ATOMS],
				int xbpmf_receptor_hb_acceptor[MAX_RECEPTOR_ATOMS])
{
		register int i;
		register int j;
		register int k;
		for(i=first_atom; i<last_atom; i++)
		{
				register double u,   v,   w;
				register double p0u, p0v, p0w;
				register double p1u, p1v, p1w;
				register int u0,  v0,  w0;
				register int u1,  v1,  w1;

				Real xl,yl,zl;
				xl = tcoord[i][X];
				yl = tcoord[i][Y];
				zl = tcoord[i][Z];
				register int lat_index = xbpmf_ligand_at_index[i];

				if (some_atoms_outside_grid)
				{
						if (is_out_grid_info(xl,yl,zl)) {
								Real epenalty;
								xl -= info->center[X];
								yl -= info->center[Y];
								zl -= info->center[Z];
								// sqhypotenuse(x,y,z) is the square of the distance from grid's centre to atom
								epenalty = sqhypotenuse(xl,yl,zl) * ENERGYPENALTY;
								out_grid_penalty += epenalty;
								continue;
						}
				}

				u1  = (u0 = (int) (u = ((double)tcoord[i][X]-(double)info->lo[X]) * (double)info->inv_spacing)) + 1;
				p1u = 1.0L - (p0u = u - (double) u0);

				v1  = (v0 = (int) (v = ((double)tcoord[i][Y]-(double)info->lo[Y]) * (double)info->inv_spacing)) + 1;
				p1v = 1.0L - (p0v = v - (double) v0);

				w1  = (w0 = (int) (w = ((double)tcoord[i][Z]-(double)info->lo[Z]) * (double)info->inv_spacing)) + 1;
				p1w = 1.0L - (p0w = w - (double) w0);

				xbpmf_1d += p1u * p1v * p1w * xbpmf_1d_map[ w0 ][ v0 ][ u0 ][lat_index];
				xbpmf_1d += p0u * p1v * p1w * xbpmf_1d_map[ w0 ][ v0 ][ u1 ][lat_index];
				xbpmf_1d += p1u * p0v * p1w * xbpmf_1d_map[ w0 ][ v1 ][ u0 ][lat_index];
				xbpmf_1d += p0u * p0v * p1w * xbpmf_1d_map[ w0 ][ v1 ][ u1 ][lat_index];
				xbpmf_1d += p1u * p1v * p0w * xbpmf_1d_map[ w1 ][ v0 ][ u0 ][lat_index];
				xbpmf_1d += p0u * p1v * p0w * xbpmf_1d_map[ w1 ][ v0 ][ u1 ][lat_index];
				xbpmf_1d += p1u * p0v * p0w * xbpmf_1d_map[ w1 ][ v1 ][ u0 ][lat_index];
				xbpmf_1d += p0u * p0v * p0w * xbpmf_1d_map[ w1 ][ v1 ][ u1 ][lat_index];


				if(xbpmf_ligand_hb_acceptor[i])
				{
						xbpmf_2d_hb+=p1u * p1v * p1w * xbpmf_hb_map[ w0 ][ v0 ][ u0 ][lat_index];
						xbpmf_2d_hb+=p0u * p1v * p1w * xbpmf_hb_map[ w0 ][ v0 ][ u1 ][lat_index];
						xbpmf_2d_hb+=p1u * p0v * p1w * xbpmf_hb_map[ w0 ][ v1 ][ u0 ][lat_index];
						xbpmf_2d_hb+=p0u * p0v * p1w * xbpmf_hb_map[ w0 ][ v1 ][ u1 ][lat_index];
						xbpmf_2d_hb+=p1u * p1v * p0w * xbpmf_hb_map[ w1 ][ v0 ][ u0 ][lat_index];
						xbpmf_2d_hb+=p0u * p1v * p0w * xbpmf_hb_map[ w1 ][ v0 ][ u1 ][lat_index];
						xbpmf_2d_hb+=p1u * p0v * p0w * xbpmf_hb_map[ w1 ][ v1 ][ u0 ][lat_index];
						xbpmf_2d_hb+=p0u * p0v * p0w * xbpmf_hb_map[ w1 ][ v1 ][ u1 ][lat_index];
				}

				if(xbpmf_ligand_hb_donor[i]==0 && xbpmf_ligand_xb_donor[i]==0)
						continue;


				for(j=0; j<recep_acceptor_natom; j++)
				{
						register int rat_index = xbpmf_receptor_at_index[j];

						if(xbpmf_receptor_hb_acceptor[j]==0)
								continue;

						Real xr,yr,zr;
						xr = recep_acceptor_crdpdb[j][X];
						yr = recep_acceptor_crdpdb[j][Y];
						zr = recep_acceptor_crdpdb[j][Z];

						Real dist = hypotenuse((xl-xr),(yl-yr),(zl-zr));
						if(dist>XBPMF_CUTOFF)
								continue;

						register int shell_index = (int)(floor(dist/xbpmf_dist_delta));
						if(shell_index==(int)(floor(XBPMF_CUTOFF/xbpmf_dist_delta)))
								shell_index--;

						// Hydrogen Bonding
						//ligand: donor
						//receptor: acceptor
						if(xbpmf_ligand_hb_donor[i])
						{
								if(xbpmf_hb_label[i][j]>0)
								{
										for(k=0; k<xbpmf_hb_label[i][j]; k++)
										{
												Real xk, yk, zk;
												xk = tcoord[xbpmf_ligand_hb_donorH_ids[i][k]][X];
												yk = tcoord[xbpmf_ligand_hb_donorH_ids[i][k]][Y];
												zk = tcoord[xbpmf_ligand_hb_donorH_ids[i][k]][Z];
												Real theta = L_calc3VectorsAngle(xl, yl, zl, xk, yk, zk, xr, yr, zr);
												register int bin_index = (int)(floor(theta/xbpmf_angle_delta));
												if(bin_index==(int)(floor(180.0/xbpmf_angle_delta)))
														bin_index--;
												xbpmf_2d_hb += xbpmf_2d_hb_pw_parms[rat_index][lat_index][shell_index][bin_index];
										}
								}
								else
										xbpmf_1d += xbpmf_1d_pw_parms[rat_index][lat_index][shell_index];
						}
						// Halogen Bonding
						//ligand: donor
						//receptor: acceptor
						if(xbpmf_ligand_xb_donor[i])
						{
								if(xbpmf_xb_label[i][j]>0)
								{
										Real xk, yk, zk;
										xk = tcoord[xbpmf_ligand_xb_donorX_id[i]][X];
										yk = tcoord[xbpmf_ligand_xb_donorX_id[i]][Y];
										zk = tcoord[xbpmf_ligand_xb_donorX_id[i]][Z];
										Real theta = L_calc3VectorsAngle(xk, yk, zk, xl, yl, zl, xr, yr, zr);
										register int bin_index = (int)(floor(theta/xbpmf_angle_delta));
										if(bin_index==(int)(floor(180.0/xbpmf_angle_delta)))
												bin_index--;
										xbpmf_2d_xb += xbpmf_2d_xb_pw_parms[rat_index][lat_index][shell_index][bin_index];
								}
								else
										xbpmf_1d += xbpmf_1d_pw_parms[rat_index][lat_index][shell_index];
						}

				}
		}
		return (out_grid_penalty + xbpmf_1d + xbpmf_2d_hb + xbpmf_2d_xb);
}

// Calculate internal energy
Real L_eintcal( NonbondParam * const nonbondlist,
				const EnergyTables  *ptr_ad_energy_tables,
				const Real tcoord[MAX_ATOMS][SPACE],
				const int           Nnb,
				const Boole         B_calcIntElec,
				const Boole         B_include_1_4_interactions,
				const Real scale_1_4,
				const Real qsp_abs_charge[MAX_ATOMS],
				const Boole B_use_non_bond_cutoff,
				const Boole B_have_flexible_residues  // if the receptor has flexibile residues, this will be set to TRUE
			  )
{

		// if r is less than the non-bond-cutoff, 
		//  -OR-
		// If we are computing the unbound conformation then we ignore the non bond cutoff, NBC
#   ifndef  NOSQRT
		register double r=0.0L; //  SQRT
		// if we have defined USE_8A_CUTOFF, then NBC = 8
		const double nbc  = B_use_non_bond_cutoff ? NBC  : 999;
#   else
		// if we have defined USE_8A_CUTOFF, then NBC = 8 // Xcode-gmm
		const double nbc2 = B_use_non_bond_cutoff ? NBC2 : 999 * 999;
#   endif
		//  eintcal ]
		register double dx=0.0L, dy=0.0L, dz=0.0L;
		register double r2=0.0L;

		register double total_e_internal=0.0L; // total_e_internal = eint

		register double e_elec=0.0L;

		register int inb=0;
		register int a1=0, a2=0;
		register int t1=0, t2=0; // Xcode-gmm
		register int nonbond_type=0; // if = 4, it is a 1_4;  otherwise it is another kind of nonbond
		register int index_lt_NEINT=0;
		register int index_lt_NDIEL=0;
		register int nb_group=0;
		int inb_from=0;
		int inb_to=0;
		int nb_group_max = 1;  // By default, we have one nonbond group, (1) intramolecular in the ligand

		if (B_have_flexible_residues) {
				// If we have flexible residues, we need to consider three groups of nonbonds:
				// (1) intramolecular in the ligand, (2) intermolecular and (3) intramolecular in the receptor
				nb_group_max = 3;
		}

		// Loop over the nonbonding groups --
		// Either (intramolecular ligand nonbonds)
		// or (intramolecular ligand nonbonds, intermolecular nonbonds, and intramolecular receptor nonbonds)
		for (nb_group = 0;  nb_group < nb_group_max;  nb_group++) {
				if (nb_group == 0) {
						inb_from = 0;
				} else {
						inb_from = Nnb_array[nb_group-1];
				}
				inb_to   = Nnb_array[nb_group];

				// Loop over the non-bonds in this nonbond "group", "inb",
				for (inb = inb_from;  inb < inb_to;  inb++) {

						double e_internal=0;  // e_internal = epair
						double e_desolv=0;    // e_desolv = dpair

						a1 = nonbondlist[inb].a1;
						a2 = nonbondlist[inb].a2;
						t1 = nonbondlist[inb].t1; // Xcode-gmm  // t1 is a map_index
						t2 = nonbondlist[inb].t2; // Xcode-gmm  // t2 is a map_index
						nonbond_type = nonbondlist[inb].nonbond_type;
						double nb_desolv = nonbondlist[inb].desolv;
						double q1q2 = nonbondlist[inb].q1q2;

						dx = tcoord[a1][X] - tcoord[a2][X];
						dy = tcoord[a1][Y] - tcoord[a2][Y];
						dz = tcoord[a1][Z] - tcoord[a2][Z];

						// Calculate the van der Waals and/or H-bonding energy & the desolvation energy.
						//|
						//| desolvation energy = sol_fn[dist] * ( rec.vol * (lig.solpar + qsolpar * |lig.charge|)
						//|                                     + lig.vol * (rec.solpar + qsolpar * |rec.charge|) );
						//|
#ifndef NOSQRT 
						// Use square-root, slower...

						// r = the separation between the atoms a1 and a2 in this non-bond, inb, 
						r = clamp(hypotenuse(dx,dy,dz), RMIN_ELEC); // clamp prevents electrostatic potential becoming too high when shorter than RMIN_ELEC
						r2 = r*r;
						register const int index = Ang_to_index(r); // convert real-valued distance r to an index for energy lookup tables

#else   
						//  Non-square-rooting version, faster...
						r2 = sqhypotenuse(dx,dy,dz); // r2, the square of the separation between the atoms a1 and a2 in this non-bond, inb, 
						r2 = clamp(r2, RMIN_ELEC2);
						register const int index = SqAng_to_index(r2);

#endif  // NOSQRT ]

						index_lt_NEINT = BoundedNeint(index);  // guarantees that index_lt_NEINT is never greater than (NEINT - 1)
						index_lt_NDIEL = BoundedNdiel(index);  // guarantees that index_lt_NDIEL is never greater than (NDIEL - 1)

						if (B_calcIntElec) {
								//  Calculate  Electrostatic  Energy
								double r_dielectric = ptr_ad_energy_tables->r_epsilon_fn[index_lt_NDIEL];
								e_elec = q1q2 * r_dielectric;
								e_internal = e_elec;
						}
						if  ( r2 < nbc ) {   
								e_desolv = ptr_ad_energy_tables->sol_fn[index_lt_NEINT] * nb_desolv;
								if (B_include_1_4_interactions != 0 && nonbond_type == 4) {
										//| Compute a scaled 1-4 interaction,
										e_internal += scale_1_4 * (ptr_ad_energy_tables->e_vdW_Hb[index_lt_NEINT][t2][t1] + e_desolv);
								} else {
										e_internal += ptr_ad_energy_tables->e_vdW_Hb[index_lt_NEINT][t2][t1] + e_desolv;
								}
						}


						total_e_internal += e_internal;
				} //  inb -- next non-bond interaction

				if (nb_group == INTRA_LIGAND) { // [0]
						// Intramolecular energy of ligand
						nb_group_energy[INTRA_LIGAND] = total_e_internal;
				} else if (nb_group == INTER) { // [1]
						// intermolecular energy
						nb_group_energy[INTER] = total_e_internal - nb_group_energy[INTRA_LIGAND];
				} else if (nb_group == INTRA_RECEPTOR) { // [2]
						// intramolecular energy of receptor
						nb_group_energy[INTRA_RECEPTOR] = total_e_internal - nb_group_energy[INTRA_LIGAND] - nb_group_energy[INTER];
				}

		} // nb_group -- intra lig, inter, intra rec
		return (Real) total_e_internal;
}

void L_mkUnitQuat( Quat *q )
{	
		double inv_nmag, hqang, s;

		inv_nmag = 1. / hypotenuse( q->nx, q->ny, q->nz );
		q->nx *= inv_nmag;       /* Normalize q */
		q->ny *= inv_nmag;       /* Normalize q */
		q->nz *= inv_nmag;       /* Normalize q */

		hqang = 0.5 * q->ang;
		s     = sin( hqang );

		q->w  = cos( hqang );
		q->x  = s * q->nx;
		q->y  = s * q->ny;
		q->z  = s * q->nz;

		/* q->qmag = hypotenuse4( q->x,  q->y,  q->z,  q->w  ); */
} // mkUnitQuat( Quat *q )

void L_print_PDBQ_atom_resstr( FILE *logFile, 
				const char prefix[MAX_CHARS],
				int atom_num, // 0-origin 
				const char atomstuff[],
				const Real crd[MAX_ATOMS][SPACE],
				const Real vdW,
				const Real Elec,
				const Real charge,
				const char * suffix //newline or empty
				)
{
		char  rec15[16];
		strncpy( rec15, atomstuff+12, (size_t)15);
		rec15[15]='\0';
#define FORMAT_PDBQ_ATOM_RESSTR         "%sATOM  %5d %.15s   %8.3f%8.3f%8.3f%+6.2f%+6.2f    %+6.3f%s"
		pr(logFile, FORMAT_PDBQ_ATOM_RESSTR,prefix,atom_num+1,rec15,crd[atom_num][X], crd[atom_num][Y], crd[atom_num][Z],\
						vdW,Elec,charge, suffix);
}

#define ABS(x) ((x) >= 0 ? (x) : -(x))
#define MIN(a,b) ((a) <= (b) ? (a) : (b))
#define MAX(a,b) ((a) >= (b) ? (a) : (b))
#define EPS     1.e-12
Molecule L_copyStateToMolecule(State *S, Molecule *mol) /* S is the source */
{
		register int i;
		mol->S.T.x = S->T.x;
		mol->S.T.y = S->T.y;
		mol->S.T.z = S->T.z;
		mol->S.Q.nx = S->Q.nx;
		mol->S.Q.ny = S->Q.ny;
		mol->S.Q.nz = S->Q.nz;
		mol->S.Q.ang = S->Q.ang;
		mol->S.Q.x = S->Q.x;
		mol->S.Q.y = S->Q.y;
		mol->S.Q.z = S->Q.z;
		mol->S.Q.w = S->Q.w;
		mol->S.Q.qmag = S->Q.qmag;
		mol->S.ntor = S->ntor;
		for (i = 0; i  < MAX_TORS;  i++ ) {
				mol->S.tor[i] = S->tor[i];
		}
		return *mol;
}
Quat L_uniformQuat( void )
{
		double x0, r1, r2, t1, t2;  // for uniformly distributed quaternion calculation
		Quat q;
		t1 = L_genunf(0., TWOPI);
		// q.x = sin( t1 ) * (  r1 = ( (genunf(0., 1.) < 0.5) ?  (-1.) : (+1.) ) * sqrt( 1. - (x0 = genunf(0., 1.)) )  );  // random sign version
		q.x = sin( t1 ) * (  r1 = sqrt( 1. - (x0 = L_genunf(0., 1.)) )  );  // strict Shoemake version
		q.y = cos( t1 ) * r1;
		t2 = L_genunf(0., TWOPI);
		// q.z = sin( t2 ) * (  r2 = ( (genunf(0., 1.) < 0.5) ?  (-1.) : (+1.) ) * sqrt( x0 )  );  // random sign version
		q.z = sin( t2 ) * (  r2 = sqrt( x0 )  );  // strict Shoemake version
		q.w = cos( t2 ) * r2;

		return q;
}
void L_qmultiply( Quat *q, //result
				register const Quat *ql,   //left
				register const Quat *qr )  //right
{ 
		register double x,y,z,w;

		x = (double) (ql->w*qr->x + ql->x*qr->w + ql->y*qr->z - ql->z*qr->y);
		y = (double) (ql->w*qr->y + ql->y*qr->w + ql->z*qr->x - ql->x*qr->z);
		z = (double) (ql->w*qr->z + ql->z*qr->w + ql->x*qr->y - ql->y*qr->x);
		w = (double) (ql->w*qr->w - ql->x*qr->x - ql->y*qr->y - ql->z*qr->z);

		q->x = x;
		q->y = y;
		q->z = z;
		q->w = w;
}
Quat L_normQuat( Quat q )
		// Normalise the 4D quaternion, x,y,z,w
{
		register double mag4 = hypotenuse4( q.x, q.y, q.z, q.w );
		if (mag4 > APPROX_ZERO) {
				register double inv_mag4 = 1. / mag4;
				q.x *= inv_mag4;
				q.y *= inv_mag4;
				q.z *= inv_mag4;
				q.w *= inv_mag4;
		}
		return q;
}
Real L_scauchy2()
{
		register Real x, y, r1, r2;

		do {
				r1 = L_ranf();
				// Using addition is faster than multiplication
				x = r1 + r1 - 1.0;
				r2 = L_ranf();
				// Using addition is faster than multiplication
				y = r2 + r2 - 1.0;
		} while (x * x + y * y > 1.0);

		if (fabs(x) < EPS)
				x = (x < 0.0 ? x - EPS : x + EPS);

		return (y / x);
}
Quat L_slerp( const Quat qa, const Quat qb, const double t )
{
		Quat qm; // quaternion to return
		Quat qb_local;
		double halfTheta, sinHalfTheta;
		double ratioA, ratioB;

		assert( t >= 0.  &&  t <= 1. );

		// Calculate angle between them.
		double cosHalfTheta = qa.w * qb.w + qa.x * qb.x + qa.y * qb.y + qa.z * qb.z;
		// Ensure we choose the shorter angular displacement between qa and qb:
		if (cosHalfTheta < 0.) {
				cosHalfTheta = -cosHalfTheta;
				qb_local.w = -qb.w;
				qb_local.x = -qb.x;
				qb_local.y = -qb.y;
				qb_local.z = -qb.z;
		} else {
				qb_local = qb;
		}
		// Calculate coefficients
		if ((1. - cosHalfTheta) > 1e-6) {
				// standard case (slerp)
				halfTheta = acos(cosHalfTheta);
				sinHalfTheta = sqrt(1.0 - cosHalfTheta*cosHalfTheta);
				ratioA = sin((1 - t) * halfTheta) / sinHalfTheta;
				ratioB = sin(t * halfTheta) / sinHalfTheta; 
		} else {
				// qa and qb (qb_local) are very close, so we can do a linear interpolation
				ratioA = 1 - t ;
				ratioB = t; 
		}
		// Calculate final values
		qm.w = qa.w * ratioA + qb_local.w * ratioB;
		qm.x = qa.x * ratioA + qb_local.x * ratioB;
		qm.y = qa.y * ratioA + qb_local.y * ratioB;
		qm.z = qa.z * ratioA + qb_local.z * ratioB;

		return qm;
}
/* Radians */
#define ONE_ROTATION TWOPI // Degrees // #define ONE_ROTATION 360.
#define HALF_ROTATION PI // Degrees // #define HALF_ROTATION 180.

/* Angles that go from -half-a-rotation to half-a-rotation */
#define MIN_ANGLE -HALF_ROTATION // Angles that go from 0 to one-rotation // #define MIN_ANGLE 0.
#define MAX_ANGLE HALF_ROTATION // Angles that go from 0 to one-rotation // #define MAX_ANGLE ONE_ROTATION

Real L_a_range_reduction( Real a )
{
		if (a <= MIN_ANGLE) {
				do a += ONE_ROTATION;
				while (a <= MIN_ANGLE);
		} else if (a >= MAX_ANGLE) {
				do a -= ONE_ROTATION;
				while (a >= MAX_ANGLE);
		}
		return a;
}

Real L_alerp( Real a, Real b, Real fract )
{
		// if fract==0, return a
		// if fract==1, return b
		Real delta;
		a = L_a_range_reduction( a );
		b = L_a_range_reduction( b );
		delta = b - a;
		if (delta > HALF_ROTATION) {
				delta -= ONE_ROTATION;
		} else if (delta < -HALF_ROTATION) {
				delta += ONE_ROTATION;
		}
		return L_a_range_reduction( a + delta*fract );
}



Real L_sdot(FourByteLong n,Real *sx,FourByteLong incx,Real *sy,FourByteLong incy)
{
		static FourByteLong i,ix,iy,m,mp1;
		static Real sdot,stemp;

#pragma omp threadprivate (i,ix,iy,m,mp1, sdot,stemp)

		stemp = sdot = 0.0;
		if(n <= 0) return sdot;
		if(incx == 1 && incy == 1) goto S20;
		ix = iy = 1;
		if(incx < 0) ix = (-n+1)*incx+1;
		if(incy < 0) iy = (-n+1)*incy+1;
		for (i=1; i<=n; i++) {
				stemp += (*(sx+ix-1)**(sy+iy-1));
				ix += incx;
				iy += incy;
		}
		sdot = stemp;
		return sdot;
S20:
		m = n % 5L;
		if(m == 0) goto S40;
		for (i=0; i<m; i++) stemp += (*(sx+i)**(sy+i));
		if(n < 5) goto S60;
S40:
		mp1 = m+1;
		for (i=mp1; i<=n; i+=5) stemp += (*(sx+i-1)**(sy+i-1)+*(sx+i)**(sy+i)+*(sx+i
								+1)**(sy+i+1)+*(sx+i+2)**(sy+i+2)+*(sx+i+3)**(sy+i+3));
S60:
		sdot = stemp;
		return sdot;
}
void L_spofa(Real *a,FourByteLong lda,FourByteLong n,FourByteLong *info)
{
		static FourByteLong j,jm1,k;
		static Real t,s;

#pragma omp threadprivate (j,jm1,k,t,s)

		for (j=1; j<=n; j++) {
				*info = j;
				s = 0.0;
				jm1 = j-1;
				if(jm1 < 1) goto S20;
				for (k=0; k<jm1; k++) {
						t = *(a+k+(j-1)*lda)-L_sdot(k,(a+k*lda),1L,(a+(j-1)*lda),1L);
						t /=  *(a+k+k*lda);
						*(a+k+(j-1)*lda) = t;
						s += (t*t);
				}
S20:
				s = *(a+j-1+(j-1)*lda)-s;
				if(s <= 0.0) goto S40;
				*(a+j-1+(j-1)*lda) = sqrt(s);
		}
		*info = 0;
S40:
		return;
}
Real L_fsign( Real num, Real sign )
{
		if ( ( sign>0.0f && num<0.0f ) || ( sign<0.0f && num>0.0f ) )
				return -num;
		else return num;
}
void L_ftnstop(char* msg)
{
		if (msg != NULL) fprintf(stderr,"%s\n",msg);
		slaveExit(0);
}
void L_advnst(FourByteLong k)
{
#define numg 32L

		static FourByteLong g,i,ib1,ib2;
		static FourByteLong qrgnin;

#pragma omp threadprivate (g,i,ib1,ib2,qrgnin)
		L_gsrgs(0L,&qrgnin);
		if(qrgnin) goto S10;
		//fputs(" ADVNST called before random generator initialized - ABORT",stderr);
		slaveExit(1);
S10:
		L_gscgn(0L,&g);
		ib1 = L_Xa1[threadID];
		ib2 = L_Xa2[threadID];
		for (i=1; i<=k; i++) {
				ib1 = L_mltmod(ib1,ib1,L_Xm1[threadID]);
				ib2 = L_mltmod(ib2,ib2,L_Xm2[threadID]);
		}
		L_setsd(L_mltmod(ib1,*(L_Xcg1[threadID]+g-1),L_Xm1[threadID]),L_mltmod(ib2,*(L_Xcg2[threadID]+g-1),L_Xm2[threadID]));

#undef numg
}
void L_getsd(FourByteLong *iseed1,FourByteLong *iseed2)
{
#define numg 32L
		static FourByteLong g;
		static FourByteLong qrgnin;

#pragma omp threadprivate (g,qrgnin)
		/*
		   Abort unless random number generator initialized
		   */
		L_gsrgs(0L,&qrgnin);
		if(qrgnin) goto S10;
		//fprintf(stderr,"%s\n"," GETSD called before random number generator  initialized -- abort!");
		slaveExit(0);
S10:
		L_gscgn(0L,&g);
		*iseed1 = *(L_Xcg1[threadID]+g-1);
		*iseed2 = *(L_Xcg2[threadID]+g-1);
#undef numg
}
FourByteLong L_ignlgi(void)
{
#define numg 32L
		extern FourByteLong L_Xm1[],L_Xm2[],L_Xa1[],L_Xa2[],L_Xcg1[MIC_MAX_NUM_THREADS][32],L_Xcg2[MIC_MAX_NUM_THREADS][32];
		extern FourByteLong L_Xqanti[MIC_MAX_NUM_THREADS][32];
		static FourByteLong ignlgi,curntg,k,s1,s2,z;
		static FourByteLong qqssd,qrgnin;
#pragma omp threadprivate (ignlgi,curntg,k,s1,s2,z,qqssd,qrgnin )
		L_gsrgs(0L,&qrgnin);
		if(!qrgnin) L_inrgcm();
		L_gssst(0,&qqssd);
		if(!qqssd) L_setall(1234567890L,123456789L);
		/*
		   Get Current Generator
		   */
		L_gscgn(0L,&curntg);
		s1 = *(L_Xcg1[threadID]+curntg-1);
		s2 = *(L_Xcg2[threadID]+curntg-1);
		k = s1/53668L;
		s1 = L_Xa1[threadID]*(s1-k*53668L)-k*12211;
		if(s1 < 0) s1 += L_Xm1[threadID];
		k = s2/52774L;
		s2 = L_Xa2[threadID]*(s2-k*52774L)-k*3791;
		if(s2 < 0) s2 += L_Xm2[threadID];
		*(L_Xcg1[threadID]+curntg-1) = s1;
		*(L_Xcg2[threadID]+curntg-1) = s2;
		z = s1-s2;
		if(z < 1) z += (L_Xm1[threadID]-1);
		if(*(L_Xqanti[threadID]+curntg-1)) z = L_Xm1[threadID]-z;
		ignlgi = z;
		return ignlgi;
#undef numg
}
void L_initgn(FourByteLong isdtyp)
{
#define numg 32L
		extern FourByteLong L_Xm1[],L_Xm2[],L_Xa1w[],L_Xa2w[],L_Xig1[MIC_MAX_NUM_THREADS][32],L_Xig2[MIC_MAX_NUM_THREADS][32],
			   L_Xlg1[MIC_MAX_NUM_THREADS][32],L_Xlg2[MIC_MAX_NUM_THREADS][32],L_Xcg1[MIC_MAX_NUM_THREADS][32],L_Xcg2[MIC_MAX_NUM_THREADS][32];
		static FourByteLong g;
		static FourByteLong qrgnin;

#pragma omp threadprivate (g,qrgnin )
		/*
		   Abort unless random number generator initialized
		   */
		L_gsrgs(0L,&qrgnin);
		if(qrgnin) goto S10;
		//fprintf(stderr,"%s\n"," INITGN called before random number generator  initialized -- abort!");
		slaveExit(1);
S10:
		L_gscgn(0L,&g);
		if(-1 != isdtyp) goto S20;
		*(L_Xlg1[threadID]+g-1) = *(L_Xig1[threadID]+g-1);
		*(L_Xlg2[threadID]+g-1) = *(L_Xig2[threadID]+g-1);
		goto S50;
S20:
		if(0 != isdtyp) goto S30;
		goto S50;
S30:
		/*
		   do nothing
		   */
		if(1 != isdtyp) goto S40;
		//printf("in initgn,Xlg1: a=%d, s=%d, m=%d\n",Xa1w[threadID],*(Xlg1[threadID]+g-1),Xm1[threadID]);
		*(L_Xlg1[threadID]+g-1) = L_mltmod(L_Xa1w[threadID],*(L_Xlg1[threadID]+g-1),L_Xm1[threadID]);
		//printf("in initgn,Xlg2: a=%d ,s=%d, m=%d\n",Xa2w[threadID],*(Xlg2[threadID]+g-1),Xm2[threadID]);
		*(L_Xlg2[threadID]+g-1) = L_mltmod(L_Xa2w[threadID],*(L_Xlg2[threadID]+g-1),L_Xm2[threadID]);
		goto S50;
S40:
		//fprintf(stderr,"%s\n","isdtyp not in range in INITGN");
		slaveExit(1);
S50:
		*(L_Xcg1[threadID]+g-1) = *(L_Xlg1[threadID]+g-1);
		*(L_Xcg2[threadID]+g-1) = *(L_Xlg2[threadID]+g-1);
#undef numg
}
void L_inrgcm(void)
{
#define numg 32L
		extern FourByteLong L_Xm1[],L_Xm2[],L_Xa1[],L_Xa2[],L_Xa1w[],L_Xa2w[],L_Xa1vw[],L_Xa2vw[];
		extern FourByteLong L_Xqanti[MIC_MAX_NUM_THREADS][32];
		static FourByteLong T1;
		static FourByteLong i;

#pragma omp threadprivate (T1,i )

		for (int iter1=0;iter1<MIC_MAX_NUM_THREADS;iter1++) {
				L_Xm1[iter1] = 2147483563L;
				L_Xm2[iter1] = 2147483399L;
				L_Xa1[iter1] = 40014L;
				L_Xa2[iter1] = 40692L;
				L_Xa1w[iter1] = 1033780774L;
				L_Xa2w[iter1] = 1494757890L;
				L_Xa1vw[iter1] = 2082007225L;
				L_Xa2vw[iter1] = 784306273L;
				for (i=0; i<numg; i++) *(L_Xqanti[iter1]+i) = 0;
		}
		T1 = 1;
		/*
		   Tell the world that common has been initialized
		   */
		L_gsrgs(1L,&T1);
#undef numg
}
void L_setall(FourByteLong iseed1,FourByteLong iseed2)
{
#define numg 32L
		extern FourByteLong L_Xm1[],L_Xm2[],L_Xa1vw[],L_Xa2vw[],L_Xig1[MIC_MAX_NUM_THREADS][32],L_Xig2[MIC_MAX_NUM_THREADS][32];
		static FourByteLong T1;
		static FourByteLong g,ocgn;
		static FourByteLong qrgnin;

#pragma omp threadprivate (T1,g,ocgn,qrgnin )

		T1 = 1;
		L_gssst(1,&T1);
		L_gscgn(0L,&ocgn);
		/*
		   Initialize Common Block if Necessary
		   */
		L_gsrgs(0L,&qrgnin);
		if(!qrgnin) L_inrgcm();
		*L_Xig1[threadID] = iseed1;
		*L_Xig2[threadID] = iseed2;
		L_initgn(-1L);
		for (g=2; g<=numg; g++) {
				//        printf("in setall, thread %d Xig1: a=%d, s=%d, m=%d\n",threadID,Xa1vw[threadID],*(Xig1[threadID]+g-2),Xm1[threadID]);
				*(L_Xig1[threadID]+g-1) = L_mltmod(L_Xa1vw[threadID],*(L_Xig1[threadID]+g-2),L_Xm1[threadID]);
				//        printf("in setall, thread %d Xig2: a=%d, s=%d, m=%d\n",threadID,Xa2vw[threadID],*(Xig2[threadID]+g-2),Xm2[threadID]);
				*(L_Xig2[threadID]+g-1) = L_mltmod(L_Xa2vw[threadID],*(L_Xig2[threadID]+g-2),L_Xm2[threadID]);
				L_gscgn(1L,&g);
				L_initgn(-1L);
		}
		L_gscgn(1L,&ocgn);
#undef numg
}
void L_setant(FourByteLong qvalue)
{
#define numg 32L
		extern FourByteLong L_Xqanti[MIC_MAX_NUM_THREADS][32];
		static FourByteLong g;
		static FourByteLong qrgnin;

#pragma omp threadprivate (g,qrgnin )

		/*
		   Abort unless random number generator initialized
		   */
		L_gsrgs(0L,&qrgnin);
		if(qrgnin) goto S10;
		//fprintf(stderr,"%s\n"," SETANT called before random number generator  initialized -- abort!");
		slaveExit(1);
S10:
		L_gscgn(0L,&g);
		L_Xqanti[threadID][g-1] = qvalue;
#undef numg
}
void L_setsd(FourByteLong iseed1,FourByteLong iseed2)
{
#define numg 32L
		extern FourByteLong L_Xig1[MIC_MAX_NUM_THREADS][32],L_Xig2[MIC_MAX_NUM_THREADS][32];
		static FourByteLong g;
		static FourByteLong qrgnin;

#pragma omp threadprivate (g,qrgnin )
		L_gsrgs(0L,&qrgnin);
		if(qrgnin) goto S10;
		//fprintf(stderr,"%s\n"," SETSD called before random number generator  initialized -- abort!");
		slaveExit(1);
S10:
		L_gscgn(0L,&g);
		*(L_Xig1[threadID]+g-1) = iseed1;
		*(L_Xig2[threadID]+g-1) = iseed2;
		L_initgn(-1L);
#undef numg
}
Real L_genbet(Real aa,Real bb)
{
#define expmax 89.0
#define infnty 1.0E38
		static Real olda = -1.0;
		static Real oldb = -1.0;
		static Real genbet,a,alpha,b,beta,delta,gamma,k1,k2,r,s,t,u1,u2,v,w,y,z;
		static FourByteLong qsame;

#pragma omp threadprivate (olda, oldb, genbet,a,alpha,b,beta,delta,gamma,k1,k2,r,s,t,u1,u2,v,w,y,z,qsame )

		qsame = olda == aa && oldb == bb;
		if(qsame) goto S20;
		if(!(aa <= 0.0 || bb <= 0.0)) goto S10;
		//fputs(" AA or BB <= 0 in GENBET - Abort!",stderr);
		//fprintf(stderr," AA: %16.6E BB %16.6E\n",aa,bb);
		slaveExit(1);
S10:
		olda = aa;
		oldb = bb;
S20:
		if(!(MIN(aa,bb) > 1.0)) goto S100;
		/*
		   Alborithm BB
		   Initialize
		   */
		if(qsame) goto S30;
		a = MIN(aa,bb);
		b = MAX(aa,bb);
		alpha = a+b;
		beta = sqrt((alpha-2.0)/(2.0*a*b-alpha));
		gamma = a+1.0/beta;
S30:
S40:
		u1 = L_ranf();
		/*
		   Step 1
		   */
		u2 = L_ranf();
		v = beta*log(u1/(1.0-u1));
		if(!(v > expmax)) goto S50;
		w = infnty;
		goto S60;
S50:
		w = a*exp(v);
S60:
		z = pow(u1,2.0)*u2;
		r = gamma*v-1.3862944;
		s = a+r-w;
		/*
		   Step 2
		   */
		if(s+2.609438 >= 5.0*z) goto S70;
		/*
		   Step 3
		   */
		t = log(z);
		if(s > t) goto S70;
		/*
		   Step 4
		   */
		if(r+alpha*log(alpha/(b+w)) < t) goto S40;
S70:
		/*
		   Step 5
		   */
		if(!(aa == a)) goto S80;
		genbet = w/(b+w);
		goto S90;
S80:
		genbet = b/(b+w);
S90:
		goto S230;
S100:
		/*
		   Algorithm BC
		   Initialize
		   */
		if(qsame) goto S110;
		a = MAX(aa,bb);
		b = MIN(aa,bb);
		alpha = a+b;
		beta = 1.0/b;
		delta = 1.0+a-b;
		k1 = delta*(1.38889E-2+4.16667E-2*b)/(a*beta-0.777778);
		k2 = 0.25+(0.5+0.25/delta)*b;
S110:
S120:
		u1 = L_ranf();
		/*
		   Step 1
		   */
		u2 = L_ranf();
		if(u1 >= 0.5) goto S130;
		/*
		   Step 2
		   */
		y = u1*u2;
		z = u1*y;
		if(0.25*u2+z-y >= k1) goto S120;
		goto S170;
S130:
		/*
		   Step 3
		   */
		z = pow(u1,2.0)*u2;
		if(!(z <= 0.25)) goto S160;
		v = beta*log(u1/(1.0-u1));
		if(!(v > expmax)) goto S140;
		w = infnty;
		goto S150;
S140:
		w = a*exp(v);
S150:
		goto S200;
S160:
		if(z >= k2) goto S120;
S170:
		/*
		   Step 4
		   Step 5
		   */
		v = beta*log(u1/(1.0-u1));
		if(!(v > expmax)) goto S180;
		w = infnty;
		goto S190;
S180:
		w = a*exp(v);
S190:
		if(alpha*(log(alpha/(b+w))+v)-1.3862944 < log(z)) goto S120;
S200:
		/*
		   Step 6
		   */
		if(!(a == aa)) goto S210;
		genbet = w/(b+w);
		goto S220;
S210:
		genbet = b/(b+w);
S230:
S220:
		return genbet;
#undef expmax
#undef infnty
}
Real L_genchi(Real df)
{
		static Real genchi;

#pragma omp threadprivate (genchi)

		if(!(df <= 0.0)) goto S10;
		//fputs("DF <= 0 in GENCHI - ABORT",stderr);
		//fprintf(stderr,"Value of DF: %16.6E\n",df);
		slaveExit(1);
S10:
		genchi = 2.0*L_gengam(1.0,df/2.0);
		return genchi;
}
Real L_genexp(Real av)
{
		static Real genexp;

#pragma omp threadprivate (genexp)

		genexp = L_sexpo()*av;
		return genexp;
}
Real L_genf(Real dfn,Real dfd)
{
		static Real genf,xden,xnum;
#pragma omp threadprivate (genf,xden,xnum)

		if(!(dfn <= 0.0 || dfd <= 0.0)) goto S10;
		fputs("Degrees of freedom nonpositive in GENF - abort!",stderr);
		fprintf(stderr,"DFN value: %16.6EDFD value: %16.6E\n",dfn,dfd);
		slaveExit(1);
S10:
		xnum = L_genchi(dfn)/dfn;
		xden = L_genchi(dfd)/dfd;
		if(!(xden <= 9.999999999998E-39*xnum)) goto S20;
		fputs(" GENF - generated numbers would cause overflow",stderr);
		fprintf(stderr," Numerator %16.6E Denominator %16.6E\n",xnum,xden);
		fputs(" GENF returning 1.0E38",stderr);
		genf = 1.0E38;
		goto S30;
S20:
		genf = xnum/xden;
S30:
		return genf;
}
Real L_gengam(Real a,Real r)
{
		static Real gengam;
#pragma omp threadprivate (gengam)

		gengam = L_sgamma(r);
		gengam /= a;
		return gengam;
}
void L_genmn(Real *parm,Real *x,Real *work)
{
		static FourByteLong i,icount,j,p,D1,D2,D3,D4;
		static Real ae;

#pragma omp threadprivate (i,icount,j,p,D1,D2,D3,D4,ae)

		p = (FourByteLong) (*parm);
		/*
		   Generate P independent normal deviates - WORK ~ N(0,1)
		   */
		for (i=1; i<=p; i++) *(work+i-1) = L_snorm();
		for (i=1,D3=1,D4=(p-i+D3)/D3; D4>0; D4--,i+=D3) {
				icount = 0;
				ae = 0.0;
				for (j=1,D1=1,D2=(i-j+D1)/D1; D2>0; D2--,j+=D1) {
						icount += (j-1);
						ae += (*(parm+i+(j-1)*p-icount+p)**(work+j-1));
				}
				*(x+i-1) = ae+*(parm+i);
		}
}
void L_genmul(FourByteLong n,Real *p,FourByteLong ncat,FourByteLong *ix)
{
		static Real prob,ptot,sum;
		static FourByteLong i,icat,ntot;

#pragma omp threadprivate (prob,ptot,sum, i,icat,ntot)

		if(n < 0) L_ftnstop("N < 0 in GENMUL");
		if(ncat <= 1) L_ftnstop("NCAT <= 1 in GENMUL");
		ptot = 0.0F;
		for (i=0; i<ncat-1; i++) {
				if(*(p+i) < 0.0F) L_ftnstop("Some P(i) < 0 in GENMUL");
				if(*(p+i) > 1.0F) L_ftnstop("Some P(i) > 1 in GENMUL");
				ptot += *(p+i);
		}
		if(ptot > 0.99999F) L_ftnstop("Sum of P(i) > 1 in GENMUL");
		/*
		   Initialize variables
		   */
		ntot = n;
		sum = 1.0F;
		for (i=0; i<ncat; i++) ix[i] = 0;
		/*
		   Generate the observation
		   */
		for (icat=0; icat<ncat-1; icat++) {
				prob = *(p+icat)/sum;
				*(ix+icat) = L_ignbin(ntot,prob);
				ntot -= *(ix+icat);
				if(ntot <= 0) return;
				sum -= *(p+icat);
		}
		*(ix+ncat-1) = ntot;
		/*
		   Finished
		   */
		return;
}
Real L_gennch(Real df,Real xnonc)
{
		static Real gennch;

#pragma omp threadprivate (gennch)

		if(!(df <= 1.0 || xnonc < 0.0)) goto S10;
		fputs("DF <= 1 or XNONC < 0 in GENNCH - ABORT",stderr);
		fprintf(stderr,"Value of DF: %16.6E Value of XNONC%16.6E\n",df,xnonc);
		slaveExit(1);
S10:
		gennch = L_genchi(df-1.0)+pow(L_gennor(sqrt(xnonc),1.0),2.0);
		return gennch;
}
Real L_gennf(Real dfn,Real dfd,Real xnonc)
{
		static Real gennf,xden,xnum;
		static FourByteLong qcond;

#pragma omp threadprivate (gennf,xden,xnum,qcond)

		qcond = dfn <= 1.0 || dfd <= 0.0 || xnonc < 0.0;
		if(!qcond) goto S10;
		fputs("In GENNF - Either (1) Numerator DF <= 1.0 or",stderr);
		fputs("(2) Denominator DF < 0.0 or ",stderr);
		fputs("(3) Noncentrality parameter < 0.0",stderr);
		fprintf(stderr,"DFN value: %16.6EDFD value: %16.6EXNONC value: \n%16.6E\n",dfn,dfd,xnonc);
		slaveExit(1);
S10:
		xnum = L_gennch(dfn,xnonc)/dfn;
		/*
		   GENNF = ( GENNCH( DFN, XNONC ) / DFN ) / ( GENCHI( DFD ) / DFD )
		   */
		xden = L_genchi(dfd)/dfd;
		if(!(xden <= 9.999999999998E-39*xnum)) goto S20;
		fputs(" GENNF - generated numbers would cause overflow",stderr);
		fprintf(stderr," Numerator %16.6E Denominator %16.6E\n",xnum,xden);
		fputs(" GENNF returning 1.0E38",stderr);
		gennf = 1.0E38;
		goto S30;
S20:
		gennf = xnum/xden;
S30:
		return gennf;
}
Real L_gennor(Real av,Real sd)
{
		static Real gennor;
#pragma omp threadprivate (gennor)

		gennor = sd*L_snorm()+av;
		return gennor;
}
void L_genprm(FourByteLong *iarray,int larray)
{
		static FourByteLong i,itmp,iwhich,D1,D2;
#pragma omp threadprivate (i,itmp,iwhich,D1,D2)

		for (i=1,D1=1,D2=(larray-i+D1)/D1; D2>0; D2--,i+=D1) {
				iwhich = L_ignuin(i,larray);
				itmp = *(iarray+iwhich-1);
				*(iarray+iwhich-1) = *(iarray+i-1);
				*(iarray+i-1) = itmp;
		}
}
Real L_genunf(Real low,Real high)
{
		static Real T_genunf;
#pragma omp threadprivate (T_genunf)

		if(!(low > high)) goto S10;
		fprintf(stderr,"LOW > HIGH in GENUNF: LOW %16.6E HIGH: %16.6E\n",low,high);
		fputs("Abort",stderr);
		slaveExit(1);
S10:
		T_genunf = low+(high-low)*L_ranf();
		return T_genunf;
}
void L_gscgn(FourByteLong getset,FourByteLong *g)
{
#define numg 32L
		static FourByteLong curntg = 1;

#pragma omp threadprivate (curntg)

		if(getset == 0) *g = curntg;
		else  {
				if(*g < 0 || *g > numg) {
						fputs(" Generator number out of range in GSCGN",stderr);
						slaveExit(0);
				}
				curntg = *g;
		}
#undef numg
}
void L_gsrgs(FourByteLong getset,FourByteLong *qvalue)
{
		static FourByteLong qinit = 0;
#pragma omp threadprivate (qinit)

		if(getset == 0) *qvalue = qinit;
		else qinit = *qvalue;
}
void L_gssst(FourByteLong getset,FourByteLong *qset)
{
		static FourByteLong qstate = 0;
#pragma omp threadprivate (qstate)

		if(getset != 0) qstate = 1;
		else  *qset = qstate;
}
FourByteLong L_ignbin(FourByteLong n,Real pp)
{
		static Real psave = -1.0;
		static FourByteLong nsave = -1;
		static FourByteLong ignbin,i,ix,ix1,k,m,mp,T1;
		static Real al,alv,amaxp,c,f,f1,f2,ffm,fm,g,p,p1,p2,p3,p4,q,qn,r,u,v,w,w2,x,x1,
					x2,xl,xll,xlr,xm,xnp,xnpq,xr,ynorm,z,z2;

#pragma omp threadprivate (psave ,nsave, ignbin,i,ix,ix1,k,m,mp,T1, al,alv,amaxp,c,f,f1,f2,ffm,fm,g,p,p1,p2,p3,p4,q,qn,r,u,v,w,w2,x,x1,x2,xl,xll,xlr,xm,xnp,xnpq,xr,ynorm,z,z2)

		if(pp != psave) goto S10;
		if(n != nsave) goto S20;
		if(xnp < 30.0) goto S150;
		goto S30;
S10:
		/*
		 *****SETUP, PERFORM ONLY WHEN PARAMETERS CHANGE
		 */
		psave = pp;
		p = MIN(psave,1.0-psave);
		q = 1.0-p;
S20:
		xnp = n*p;
		nsave = n;
		if(xnp < 30.0) goto S140;
		ffm = xnp+p;
		m = (FourByteLong) ffm;
		fm = m;
		xnpq = xnp*q;
		p1 = (FourByteLong) (2.195*sqrt(xnpq)-4.6*q)+0.5;
		xm = fm+0.5;
		xl = xm-p1;
		xr = xm+p1;
		c = 0.134+20.5/(15.3+fm);
		al = (ffm-xl)/(ffm-xl*p);
		xll = al*(1.0+0.5*al);
		al = (xr-ffm)/(xr*q);
		xlr = al*(1.0+0.5*al);
		p2 = p1*(1.0+c+c);
		p3 = p2+c/xll;
		p4 = p3+c/xlr;
S30:
		/*
		 *****GENERATE VARIATE
		 */
		u = L_ranf()*p4;
		v = L_ranf();
		/*
		   TRIANGULAR REGION
		   */
		if(u > p1) goto S40;
		ix = (FourByteLong) (xm-p1*v+u);
		goto S170;
S40:
		/*
		   PARALLELOGRAM REGION
		   */
		if(u > p2) goto S50;
		x = xl+(u-p1)/c;
		v = v*c+1.0-ABS(xm-x)/p1;
		if(v > 1.0 || v <= 0.0) goto S30;
		ix = (FourByteLong) x;
		goto S70;
S50:
		/*
		   LEFT TAIL
		   */
		if(u > p3) goto S60;
		ix = (FourByteLong) (xl+log(v)/xll);
		if(ix < 0) goto S30;
		v *= ((u-p2)*xll);
		goto S70;
S60:
		/*
		   RIGHT TAIL
		   */
		ix = (FourByteLong) (xr-log(v)/xlr);
		if(ix > n) goto S30;
		v *= ((u-p3)*xlr);
S70:
		/*
		 *****DETERMINE APPROPRIATE WAY TO PERFORM ACCEPT/REJECT TEST
		 */
		k = ABS(ix-m);
		if(k > 20 && k < xnpq/2-1) goto S130;
		/*
		   EXPLICIT EVALUATION
		   */
		f = 1.0;
		r = p/q;
		g = (n+1)*r;
		T1 = m-ix;
		if(T1 < 0) goto S80;
		else if(T1 == 0) goto S120;
		else  goto S100;
S80:
		mp = m+1;
		for (i=mp; i<=ix; i++) f *= (g/i-r);
		goto S120;
S100:
		ix1 = ix+1;
		for (i=ix1; i<=m; i++) f /= (g/i-r);
S120:
		if(v <= f) goto S170;
		goto S30;
S130:
		/*
		   SQUEEZING USING UPPER AND LOWER BOUNDS ON ALOG(F(X))
		   */
		amaxp = k/xnpq*((k*(k/3.0+0.625)+0.1666666666666)/xnpq+0.5);
		ynorm = -(k*k/(2.0*xnpq));
		alv = log(v);
		if(alv < ynorm-amaxp) goto S170;
		if(alv > ynorm+amaxp) goto S30;
		/*
		   STIRLING'S FORMULA TO MACHINE ACCURACY FOR
		   THE FINAL ACCEPTANCE/REJECTION TEST
		   */
		x1 = ix+1.0;
		f1 = fm+1.0;
		z = n+1.0-fm;
		w = n-ix+1.0;
		z2 = z*z;
		x2 = x1*x1;
		f2 = f1*f1;
		w2 = w*w;
		if(alv <= xm*log(f1/x1)+(n-m+0.5)*log(z/w)+(ix-m)*log(w*p/(x1*q))+(13860.0-
								(462.0-(132.0-(99.0-140.0/f2)/f2)/f2)/f2)/f1/166320.0+(13860.0-(462.0-
												(132.0-(99.0-140.0/z2)/z2)/z2)/z2)/z/166320.0+(13860.0-(462.0-(132.0-
																(99.0-140.0/x2)/x2)/x2)/x2)/x1/166320.0+(13860.0-(462.0-(132.0-(99.0
																				-140.0/w2)/w2)/w2)/w2)/w/166320.0) goto S170;
		goto S30;
S140:
		/*
		   INVERSE CDF LOGIC FOR MEAN LESS THAN 30
		   */
		qn = pow(q,(double)n);
		r = p/q;
		g = r*(n+1);
S150:
		ix = 0;
		f = qn;
		u = L_ranf();
S160:
		if(u < f) goto S170;
		if(ix > 110) goto S150;
		u -= f;
		ix += 1;
		f *= (g/ix-r);
		goto S160;
S170:
		if(psave > 0.5) ix = n-ix;
		ignbin = ix;
		return ignbin;
}
FourByteLong L_ignnbn(FourByteLong n,Real p)
{
		static FourByteLong ignnbn;
		static Real y,a,r;

#pragma omp threadprivate (ignnbn,y,a,r)

		if(n < 0) L_ftnstop("N < 0 in IGNNBN");
		if(p <= 0.0F) L_ftnstop("P <= 0 in IGNNBN");
		if(p >= 1.0F) L_ftnstop("P >= 1 in IGNNBN");
		/*
		   Generate Y, a random gamma (n,(1-p)/p) variable
		   */
		r = (Real)n;
		a = p/(1.0F-p);
		y = L_gengam(a,r);
		/*
		   Generate a random Poisson(y) variable
		   */
		ignnbn = L_ignpoi(y);
		return ignnbn;
}
FourByteLong L_ignpoi(Real mu)
{
		static Real a0 = -0.5;
		static Real a1 = 0.3333333;
		static Real a2 = -0.2500068;
		static Real a3 = 0.2000118;
		static Real a4 = -0.1661269;
		static Real a5 = 0.1421878;
		static Real a6 = -0.1384794;
		static Real a7 = 0.125006;
		static Real muold = 0.0;
		static Real muprev = 0.0;
		static Real fact[10] = {
				1.0,1.0,2.0,6.0,24.0,120.0,720.0,5040.0,40320.0,362880.0
		};
		static FourByteLong ignpoi,j,k,kflag,l,m;
		static Real b1,b2,c,c0,c1,c2,c3,d,del,difmuk,e,fk,fx,fy,g,omega,p,p0,px,py,q,s,
					t,u,v,x,xx,pp[35];

#pragma omp threadprivate (a0,a1,a2,a3,a4,a5,a6,a7,muold,muprev,fact,ignpoi,j,k,kflag,l,m, b1,b2,c,c0,c1,c2,c3,d,del,difmuk,e,fk,fx,fy,g,omega,p,p0,px,py,q,s,t,u,v,x,xx,pp)

		if(mu == muprev) goto S10;
		if(mu < 10.0) goto S120;
		/*
		   C A S E  A. (RECALCULATION OF S,D,L IF MU HAS CHANGED)
		   */
		muprev = mu;
		s = sqrt(mu);
		d = 6.0*mu*mu;
		l = (FourByteLong) (mu-1.1484);
S10:
		g = mu+s*L_snorm();
		if(g < 0.0) goto S20;
		ignpoi = (FourByteLong) (g);
		if(ignpoi >= l) return ignpoi;
		fk = (Real)ignpoi;
		difmuk = mu-fk;
		u = L_ranf();
		if(d*u >= difmuk*difmuk*difmuk) return ignpoi;
S20:
		if(mu == muold) goto S30;
		muold = mu;
		omega = 0.3989423/s;
		b1 = 4.166667E-2/mu;
		b2 = 0.3*b1*b1;
		c3 = 0.1428571*b1*b2;
		c2 = b2-15.0*c3;
		c1 = b1-6.0*b2+45.0*c3;
		c0 = 1.0-b1+3.0*b2-15.0*c3;
		c = 0.1069/mu;
S30:
		if(g < 0.0) goto S50;
		kflag = 0;
		goto S70;
S40:
		if(fy-u*fy <= py*exp(px-fx)) return ignpoi;
S50:
		e = L_sexpo();
		u = L_ranf();
		u += (u-1.0);
		t = 1.8+L_fsign(e,u);
		if(t <= -0.6744) goto S50;
		ignpoi = (FourByteLong) (mu+s*t);
		fk = (Real)ignpoi;
		difmuk = mu-fk;
		/*
		   'SUBROUTINE' F IS CALLED (KFLAG=1 FOR CORRECT RETURN)
		   */
		kflag = 1;
		goto S70;
S60:
		/*
		   STEP H. HAT ACCEPTANCE (E IS REPEATED ON REJECTION)
		   */
		if(c*fabs(u) > py*exp(px+e)-fy*exp(fx+e)) goto S50;
		return ignpoi;
S70:
		/*
		   STEP F. 'SUBROUTINE' F. CALCULATION OF PX,PY,FX,FY.
		   CASE IGNPOI .LT. 10 USES FACTORIALS FROM TABLE FACT
		   */
		if(ignpoi >= 10) goto S80;
		px = -mu;
		py = pow(mu,(double)ignpoi)/ *(fact+ignpoi);
		goto S110;
S80:
		/*
		   CASE IGNPOI .GE. 10 USES POLYNOMIAL APPROXIMATION
		   A0-A7 FOR ACCURACY WHEN ADVISABLE
		   .8333333E-1=1./12.  .3989423=(2*PI)**(-.5)
		   */
		del = 8.333333E-2/fk;
		del -= (4.8*del*del*del);
		v = difmuk/fk;
		if(fabs(v) <= 0.25) goto S90;
		px = fk*log(1.0+v)-difmuk-del;
		goto S100;
S90:
		px = fk*v*v*(((((((a7*v+a6)*v+a5)*v+a4)*v+a3)*v+a2)*v+a1)*v+a0)-del;
S100:
		py = 0.3989423/sqrt(fk);
S110:
		x = (0.5-difmuk)/s;
		xx = x*x;
		fx = -0.5*xx;
		fy = omega*(((c3*xx+c2)*xx+c1)*xx+c0);
		if(kflag <= 0) goto S40;
		goto S60;
S120:
		/*
		   C A S E  B. (START NEW TABLE AND CALCULATE P0 IF NECESSARY)
		   */
		muprev = 0.0;
		if(mu == muold) goto S130;
		muold = mu;
		m = MAX(1L,(FourByteLong) (mu));
		l = 0;
		p = exp(-mu);
		q = p0 = p;
S130:
		/*
		   STEP U. UNIFORM SAMPLE FOR INVERSION METHOD
		   */
		u = L_ranf();
		ignpoi = 0;
		if(u <= p0) return ignpoi;
		/*
		   STEP T. TABLE COMPARISON UNTIL THE END PP(L) OF THE
		   PP-TABLE OF CUMULATIVE POISSON PROBABILITIES
		   (0.458=PP(9) FOR MU=10)
		   */
		if(l == 0) goto S150;
		j = 1;
		if(u > 0.458) j = MIN(l,m);
		for (k=j; k<=l; k++) {
				if(u <= *(pp+k-1)) goto S180;
		}
		if(l == 35) goto S130;
S150:
		/*
		   STEP C. CREATION OF NEW POISSON PROBABILITIES P
		   AND THEIR CUMULATIVES Q=PP(K)
		   */
		l += 1;
		for (k=l; k<=35; k++) {
				p = p*mu/(Real)k;
				q += p;
				*(pp+k-1) = q;
				if(u <= q) goto S170;
		}
		l = 35;
		goto S130;
S170:
		l = k;
S180:
		ignpoi = k;
		return ignpoi;
}
FourByteLong L_ignuin(FourByteLong low,FourByteLong high)
{
#define maxnum 2147483561L
		static FourByteLong ignuin,ign,maxnow,range,ranp1;
#pragma omp threadprivate (ignuin,ign,maxnow,range,ranp1)

		if(!(low > high)) goto S10;
		fputs(" low > high in ignuin - ABORT",stderr);
		slaveExit(1);
S10:
		range = high-low;
		if(!(range > maxnum)) goto S20;
		fputs(" high - low too large in ignuin - ABORT",stderr);
		slaveExit(1);
S20:
		if(!(low == high)) goto S30;
		ignuin = low;
		return ignuin;
S30:
		ranp1 = range+1;
		maxnow = maxnum/ranp1*ranp1;
S40:
		ign = L_ignlgi()-1;
		if(!(ign <= maxnow)) goto S50;
		ignuin = low+ign%ranp1;
		return ignuin;
S50:
		goto S40;
#undef maxnum
#undef err1
#undef err2
}
FourByteLong L_lennob( char *str )
{
		FourByteLong i, i_nb;

		for (i=0, i_nb= -1L; *(str+i); i++)
				if ( *(str+i) != ' ' ) i_nb = i;
		return (i_nb+1);
}
FourByteLong L_mltmod(FourByteLong a,FourByteLong s,FourByteLong m)
{
#define h 32768L
		static FourByteLong mltmod,a0,a1,k,p,q,qh,rh;
#pragma omp threadprivate (mltmod,a0,a1,k,p,q,qh,rh)

		if(!(a <= 0 || a >= m || s <= 0 || s >= m)) goto S10;
		fputs(" a, m, s out of order in mltmod - ABORT!",stderr);
		fprintf(stderr," a = %12ld s = %12ld m = %12ld\n",a,s,m);
		fputs(" mltmod requires: 0 < a < m; 0 < s < m",stderr);
		slaveExit(1);
S10:
		if(!(a < h)) goto S20;
		a0 = a;
		p = 0;
		goto S120;
S20:
		a1 = a/h;
		a0 = a-h*a1;
		qh = m/h;
		rh = m-h*qh;
		if(!(a1 >= h)) goto S50;
		a1 -= h;
		k = s/qh;
		p = h*(s-k*qh)-k*rh;
S30:
		if(!(p < 0)) goto S40;
		p += m;
		goto S30;
S40:
		goto S60;
S50:
		p = 0;
S60:
		/*
		   P = (A2*S*H)MOD M
		   */
		if(!(a1 != 0)) goto S90;
		q = m/a1;
		k = s/q;
		p -= (k*(m-a1*q));
		if(p > 0) p -= m;
		p += (a1*(s-k*q));
S70:
		if(!(p < 0)) goto S80;
		p += m;
		goto S70;
S90:
S80:
		k = p/qh;
		/*
		   P = ((A2*H + A1)*S)MOD M
		   */
		p = h*(p-k*qh)-k*rh;
S100:
		if(!(p < 0)) goto S110;
		p += m;
		goto S100;
S120:
S110:
		if(!(a0 != 0)) goto S150;
		/*
		   P = ((A2*H + A1)*H*S)MOD M
		   */
		q = m/a0;
		k = s/q;
		p -= (k*(m-a0*q));
		if(p > 0) p -= m;
		p += (a0*(s-k*q));
S130:
		if(!(p < 0)) goto S140;
		p += m;
		goto S130;
S150:
S140:
		mltmod = p;
		return mltmod;
#undef h
}
void L_phrtsd(char* phrase,FourByteLong *seed1,FourByteLong *seed2)
{
		static char table[] =
				"abcdefghijklmnopqrstuvwxyz\
				ABCDEFGHIJKLMNOPQRSTUVWXYZ\
				0123456789\
				!@#$%^&*()_+[];:'\\\"<>?,./";

		FourByteLong ix;

		static FourByteLong twop30 = 1073741824L;
		static FourByteLong shift[5] = {
				1L,64L,4096L,262144L,16777216L
		};
		static FourByteLong i,ichr,j,lphr,values[5];

#pragma omp threadprivate(table,twop30,shift,i,ichr,j,lphr,values)

		*seed1 = 1234567890L;
		*seed2 = 123456789L;
		lphr = L_lennob(phrase); 
		if(lphr < 1) return;
		for (i=0; i<=(lphr-1); i++) {
				for (ix=0; table[ix]; ix++) if (*(phrase+i) == table[ix]) break; 
				if (!table[ix]) ix = 0;
				ichr = ix % 64;
				if(ichr == 0) ichr = 63;
				for (j=1; j<=5; j++) {
						*(values+j-1) = ichr-j;
						if(*(values+j-1) < 1) *(values+j-1) += 63;
				}
				for (j=1; j<=5; j++) {
						*seed1 = ( *seed1+*(shift+j-1)**(values+j-1) ) % twop30;
						/*gmm 2-24-98 *seed2 = ( *seed2+*(shift+j-1)**(values+6-j-1)) %  twop30;*/
						*seed2 = ( *seed2+*(shift+j-1)**(values+5-j) )  % twop30;
				}
		}
#undef twop30
}
Real L_ranf(void)
{
		static Real ranf;
#pragma omp threadprivate(ranf)

		/*
		   4.656613057E-10 is 1/M1  M1 is set in a data statement in IGNLGI
		   and is currently 2147483563. If M1 changes, change this also.
		   */
		ranf = L_ignlgi()*4.656613057E-10;
		return ranf;
}
void L_setgmn(Real *meanv,Real *covm,FourByteLong p,Real *parm)
{
		/* not used: static FourByteLong T1; */
		static FourByteLong i,icount,info,j,D2,D3,D4,D5;
#pragma omp threadprivate(i,icount,info,j,D2,D3,D4,D5)
		if(!(p <= 0)) goto S10;
		fputs("P nonpositive in SETGMN",stderr);
		fprintf(stderr,"Value of P: %12ld\n",p);
		slaveExit(1);
S10:
		*parm = p;
		for (i=2,D2=1,D3=(p+1-i+D2)/D2; D3>0; D3--,i+=D2) *(parm+i-1) = *(meanv+i-2);
		L_spofa(covm,p,p,&info);
		if(!(info != 0)) goto S30;
		fputs(" COVM not positive definite in SETGMN",stderr);
		slaveExit(1);
S30:
		icount = p+1;
		for (i=1,D4=1,D5=(p-i+D4)/D4; D5>0; D5--,i+=D4) {
				for (j=i-1; j<p; j++) {
						icount += 1;
						*(parm+icount-1) = *(covm+i-1+j*p);
				}
		}
}
Real L_sexpo(void)
{
		static Real q[8] = {
				0.6931472,0.9333737,0.9888778,0.9984959,0.9998293,0.9999833,0.9999986,1.0
		};
		static FourByteLong i;
		static Real sexpo,a,u,ustar,umin;
#pragma omp threadprivate(q)

		static Real *q1 = q;
#pragma omp threadprivate(i,sexpo,a,u,ustar,umin, q1)

		a = 0.0;
		u = L_ranf();
		goto S30;
S20:
		a += *q1;
S30:
		u += u;
		if(u <= 1.0) goto S20;
		u -= 1.0;
		if(u > *q1) goto S60;
		sexpo = a+u;
		return sexpo;
S60:
		i = 1;
		ustar = L_ranf();
		umin = ustar;
S70:
		ustar = L_ranf();
		if(ustar < umin) umin = ustar;
		i += 1;
		if(u > *(q+i-1)) goto S70;
		sexpo = a+umin**q1;
		return sexpo;
}
Real L_sgamma(Real a)
{
		static Real q1 = 4.166669E-2;
		static Real q2 = 2.083148E-2;
		static Real q3 = 8.01191E-3;
		static Real q4 = 1.44121E-3;
		static Real q5 = -7.388E-5;
		static Real q6 = 2.4511E-4;
		static Real q7 = 2.424E-4;
		static Real a1 = 0.3333333;
		static Real a2 = -0.250003;
		static Real a3 = 0.2000062;
		static Real a4 = -0.1662921;
		static Real a5 = 0.1423657;
		static Real a6 = -0.1367177;
		static Real a7 = 0.1233795;
		static Real e1 = 1.0;
		static Real e2 = 0.4999897;
		static Real e3 = 0.166829;
		static Real e4 = 4.07753E-2;
		static Real e5 = 1.0293E-2;
		static Real aa = 0.0;
		static Real aaa = 0.0;
		static Real sqrt32 = 5.656854;
		static Real sgamma,s2,s,d,t,x,u,r,q0,b,si,c,v,q,e,w,p;
#pragma omp threadprivate(q1,q2,q3,q4,q5,q6,q7,a1,a2,a3,a4,a5,a6,a7,e1,e2,e3,e4,e5,aa,aaa,sqrt32,\
				sgamma,s2,s,d,t,x,u,r,q0,b,si,c,v,q,e,w,p)

		if(a == aa) goto S10;
		if(a < 1.0) goto S120;
		/*
		   STEP  1:  RECALCULATIONS OF S2,S,D IF A HAS CHANGED
		   */
		aa = a;
		s2 = a-0.5;
		s = sqrt(s2);
		d = sqrt32-12.0*s;
S10:

		t = L_snorm();
		x = s+0.5*t;
		sgamma = x*x;
		if(t >= 0.0) return sgamma;
		u = L_ranf();
		if(d*u <= t*t*t) return sgamma;
		if(a == aaa) goto S40;
		aaa = a;
		r = 1.0/ a;
		q0 = ((((((q7*r+q6)*r+q5)*r+q4)*r+q3)*r+q2)*r+q1)*r;
		if(a <= 3.686) goto S30;
		if(a <= 13.022) goto S20;
		b = 1.77;
		si = 0.75;
		c = 0.1515/s;
		goto S40;
S20:
		/*
		   CASE 2:  3.686 .LT. A .LE. 13.022
		   */
		b = 1.654+7.6E-3*s2;
		si = 1.68/s+0.275;
		c = 6.2E-2/s+2.4E-2;
		goto S40;
S30:
		/*
		   CASE 1:  A .LE. 3.686
		   */
		b = 0.463+s+0.178*s2;
		si = 1.235;
		c = 0.195/s-7.9E-2+1.6E-1*s;
S40:
		/*
		   STEP  5:  NO QUOTIENT TEST IF X NOT POSITIVE
		   */
		if(x <= 0.0) goto S70;
		/*
		   STEP  6:  CALCULATION OF V AND QUOTIENT Q
		   */
		v = t/(s+s);
		if(fabs(v) <= 0.25) goto S50;
		q = q0-s*t+0.25*t*t+(s2+s2)*log(1.0+v);
		goto S60;
S50:
		q = q0+0.5*t*t*((((((a7*v+a6)*v+a5)*v+a4)*v+a3)*v+a2)*v+a1)*v;
S60:
		/*
		   STEP  7:  QUOTIENT ACCEPTANCE (Q)
		   */
		if(log(1.0-u) <= q) return sgamma;
S70:
		/*
		   STEP  8:  E=STANDARD EXPONENTIAL DEVIATE
		   U= 0,1 -UNIFORM DEVIATE
		   T=(B,SI)-DOUBLE EXPONENTIAL (LAPLACE) SAMPLE
		   */
		e = L_sexpo();
		u = L_ranf();
		u += (u-1.0);
		t = b+L_fsign(si*e,u);
		/*
		   STEP  9:  REJECTION IF T .LT. TAU(1) = -.71874483771719
		   */
		if(t < -0.7187449) goto S70;
		/*
		   STEP 10:  CALCULATION OF V AND QUOTIENT Q
		   */
		v = t/(s+s);
		if(fabs(v) <= 0.25) goto S80;
		q = q0-s*t+0.25*t*t+(s2+s2)*log(1.0+v);
		goto S90;
S80:
		q = q0+0.5*t*t*((((((a7*v+a6)*v+a5)*v+a4)*v+a3)*v+a2)*v+a1)*v;
S90:
		/*
		   STEP 11:  HAT ACCEPTANCE (H) (IF Q NOT POSITIVE GO TO STEP 8)
		   */
		if(q <= 0.0) goto S70;
		if(q <= 0.5) goto S100;
		w = exp(q)-1.0;
		goto S110;
S100:
		w = ((((e5*q+e4)*q+e3)*q+e2)*q+e1)*q;
S110:
		/*
		   IF T IS REJECTED, SAMPLE AGAIN AT STEP 8
		   */
		if(c*fabs(u) > w*exp(e-0.5*t*t)) goto S70;
		x = s+0.5*t;
		sgamma = x*x;
		return sgamma;
S120:
		/*
		   ALTERNATE METHOD FOR PARAMETERS A BELOW 1  (.3678794=EXP(-1.))
		   */
		aa = 0.0;
		b = 1.0+0.3678794*a;
S130:
		p = b*L_ranf();
		if(p >= 1.0) goto S140;
		sgamma = exp(log(p)/ a);
		if(L_sexpo() < sgamma) goto S130;
		return sgamma;
S140:
		sgamma = -log((b-p)/ a);
		if(L_sexpo() < (1.0-a)*log(sgamma)) goto S130;
		return sgamma;
}
Real L_snorm(void)
{
		static Real a[32] = {
				0.0,3.917609E-2,7.841241E-2,0.11777,0.1573107,0.1970991,0.2372021,0.2776904,
				0.3186394,0.36013,0.4022501,0.4450965,0.4887764,0.5334097,0.5791322,
				0.626099,0.6744898,0.7245144,0.7764218,0.8305109,0.8871466,0.9467818,
				1.00999,1.077516,1.150349,1.229859,1.318011,1.417797,1.534121,1.67594,
				1.862732,2.153875
		};
		static Real d[31] = {
				0.0,0.0,0.0,0.0,0.0,0.2636843,0.2425085,0.2255674,0.2116342,0.1999243,
				0.1899108,0.1812252,0.1736014,0.1668419,0.1607967,0.1553497,0.1504094,
				0.1459026,0.14177,0.1379632,0.1344418,0.1311722,0.128126,0.1252791,
				0.1226109,0.1201036,0.1177417,0.1155119,0.1134023,0.1114027,0.1095039
		};
		static Real t[31] = {
				7.673828E-4,2.30687E-3,3.860618E-3,5.438454E-3,7.0507E-3,8.708396E-3,
				1.042357E-2,1.220953E-2,1.408125E-2,1.605579E-2,1.81529E-2,2.039573E-2,
				2.281177E-2,2.543407E-2,2.830296E-2,3.146822E-2,3.499233E-2,3.895483E-2,
				4.345878E-2,4.864035E-2,5.468334E-2,6.184222E-2,7.047983E-2,8.113195E-2,
				9.462444E-2,0.1123001,0.136498,0.1716886,0.2276241,0.330498,0.5847031
		};
		static Real h[31] = {
				3.920617E-2,3.932705E-2,3.951E-2,3.975703E-2,4.007093E-2,4.045533E-2,
				4.091481E-2,4.145507E-2,4.208311E-2,4.280748E-2,4.363863E-2,4.458932E-2,
				4.567523E-2,4.691571E-2,4.833487E-2,4.996298E-2,5.183859E-2,5.401138E-2,
				5.654656E-2,5.95313E-2,6.308489E-2,6.737503E-2,7.264544E-2,7.926471E-2,
				8.781922E-2,9.930398E-2,0.11556,0.1404344,0.1836142,0.2790016,0.7010474
		};
		static FourByteLong i;
		static Real snorm,u,s,ustar,aa,w,y,tt;
#pragma omp threadprivate(a,d,t,h,i,snorm,u,s,ustar,aa,w,y,tt)
		u = L_ranf();
		s = 0.0;
		if(u > 0.5) s = 1.0;
		u += (u-s);
		u = 32.0*u;
		i = (FourByteLong) (u);
		if(i == 32) i = 31;
		if(i == 0) goto S100;
		ustar = u-(Real)i;
		aa = *(a+i-1);
S40:
		if(ustar <= *(t+i-1)) goto S60;
		w = (ustar-*(t+i-1))**(h+i-1);
S50:
		y = aa+w;
		snorm = y;
		if(s == 1.0) snorm = -y;
		return snorm;
S60:
		u = L_ranf();
		w = u*(*(a+i)-aa);
		tt = (0.5*w+aa)*w;
		goto S80;
S70:
		tt = u;
		ustar = L_ranf();
S80:
		if(ustar > tt) goto S50;
		u = L_ranf();
		if(ustar >= u) goto S70;
		ustar = L_ranf();
		goto S40;
S100:
		/*
		   START TAIL
		   */
		i = 6;
		aa = *(a+31);
		goto S120;
S110:
		aa += *(d+i-1);
		i += 1;
S120:
		u += u;
		if(u < 1.0) goto S110;
		u -= 1.0;
S140:
		w = u**(d+i-1);
		tt = (0.5*w+aa)*w;
		goto S160;
S150:
		tt = u;
S160:
		ustar = L_ranf();
		if(ustar > tt) goto S50;
		u = L_ranf();
		if(ustar >= u) goto S150;
		u = L_ranf();
		goto S140;
}


/**************************************************************************
  Inline Functions
 **************************************************************************/

		L_Representation::L_Representation(void)
: number_of_pts(0) 
{
		mytype = T_BASE;
}

		L_Representation::L_Representation(unsigned int pts)
: number_of_pts(pts) 
{
}

L_Representation::~L_Representation(void)
{
}

unsigned int L_Representation::number_of_points(void) const
{
		return(number_of_pts);
}

int L_Representation::is_normalized(void) const
{
		return(normalized);
}

void L_Representation::set_normalized_true(void)
{
		normalized = 1;
}

void L_Representation::set_normalized_false(void)
{
		normalized = 0;
}

RepType L_Representation::type(void) const
{
		return(mytype);
}

L_Representation *L_Representation::clone(void) const
{
		return(NULL);
}

		L_IntVector::L_IntVector(void)
: L_Representation(0)
{
		vector = (FourByteLong *)NULL;
		mytype = T_IntV;
}

//  This constructor does a shallow copy of the array
		L_IntVector::L_IntVector(int num_els, FourByteLong *array)
: L_Representation(num_els), vector(array)
{
		mytype = T_IntV;
}

L_IntVector::~L_IntVector(void)
{
		if(vector!=(FourByteLong *)NULL)
		{
				delete [] vector;
		}
}

L_Representation *L_IntVector::clone(void) const
{
		return(new L_IntVector(*this));
}

//  This performs a shallow copy of the array
		L_RealVector::L_RealVector(int num_els, double *array)
: L_Representation(num_els), high(REALV_HIGH), low(REALV_LOW), 
		vector(array)
{
		mytype = T_RealV;
}

L_RealVector::~L_RealVector(void)
{
		if(vector!=(double *)NULL)
		{
				delete [] vector;
		}
}

L_Representation *L_RealVector::clone(void) const
{
		return(new L_RealVector(*this));
}

		L_ConstrainedRealVector::L_ConstrainedRealVector(void)
: L_Representation(0)
{
		normalized = 1;
		vector = (double *)NULL;
		mytype = T_CRealV;
}

		L_ConstrainedRealVector::L_ConstrainedRealVector(int num_els, double *array)
:  L_Representation(num_els)
{
		normalized = 0;
		vector = array;
		mytype = T_CRealV;
}

L_ConstrainedRealVector::~L_ConstrainedRealVector(void)
{
		if(vector!=(double *)NULL)
		{ 
				delete [] vector;
		}
}

L_Representation *L_ConstrainedRealVector::clone(void) const
{
		return(new L_ConstrainedRealVector(*this));
}

		L_BitVector::L_BitVector(void)
: L_Representation(0)
{
		vector = (unsigned char *)NULL;
		mytype = T_BitV;
}

		L_BitVector::L_BitVector(int num_els, unsigned char *array)
: L_Representation(num_els)
{
		vector = array;
		mytype = T_BitV;
}

L_BitVector::~L_BitVector(void)
{
		if(vector!=(unsigned char *)NULL)
		{
				delete [] vector;
		}
}

L_Representation *L_BitVector::clone(void) const
{
		return(new L_BitVector(*this));
}

FourByteLong L_IntVector::low = -INT_MAX/4;
FourByteLong L_IntVector::high = INT_MAX/4;
Real L_ConstrainedRealVector::low = REALV_LOW;
Real L_ConstrainedRealVector::high = REALV_HIGH;
double L_ConstrainedRealVector::sum = 1.0;
Real L_BitVector::one_prob = 0.5;

		L_IntVector::L_IntVector(int number_of_els)
: L_Representation(number_of_els)
{
		register int i;
		mytype = T_IntV;
		vector = new FourByteLong[number_of_els];
		for (i=0; i<number_of_els; i++) {
				vector[i] = L_ignuin(low, high);
		}
}

		L_IntVector::L_IntVector(int num_els, FourByteLong init_low, FourByteLong init_high)
: L_Representation(num_els)
{
		register int i;

		mytype = T_IntV;
		vector = new FourByteLong[num_els];
		for (i=0; i<num_els; i++) {
				vector[i] = L_ignuin(init_low, init_high);
		}
}

		L_IntVector::L_IntVector(const L_IntVector &original)
: L_Representation(original.number_of_pts)
{
		mytype = T_IntV;
		if (original.vector!=NULL) {
				vector = new FourByteLong[number_of_pts];
		} else {
				vector = NULL;
		}

		for (register unsigned int i=0; i<number_of_pts; i++) {
				vector[i] = original.vector[i];
		}
}

void L_IntVector::write(unsigned char value, int gene)
{
		(void)fprintf(logFile,"Writing a Bit to an Int!\n"); // used to be "stderr"
		(void)fprintf(logFile,"value= \"%c\", gene= %d\n", value, gene); // used to be "stderr"
}

void L_IntVector::write(FourByteLong value, int gene)
{
		if (value<low) {
				vector[gene] = low;
		} else if (value>high) {
				vector[gene] = high;
		} else {
				vector[gene] = value;
		}
}

void L_IntVector::write(double value, int gene)
{
		(void)fprintf(logFile,"Writing a Real to an Int!\n"); // used to be "stderr"
		(void)fprintf(logFile,"value= %lf, gene= %d\n", value, gene); // used to be "stderr"
}

void L_IntVector::write(const Element value, int gene)
{
		if (value.integer<low) {
				(void)fprintf(logFile,"Writing out-of-bounds Int!\n"); // used to be "stderr"
				vector[gene] = low;
		} else if (value.integer>high) {
				(void)fprintf(logFile,"Writing out-of-bounds Int!\n"); // used to be "stderr"
				vector[gene] = high;
		} else {
				vector[gene] = value.integer;
		}
}

const Element L_IntVector::gene(unsigned int gene_number) const
{
		Element retval;
		if (gene_number>=number_of_pts) {
				(void)fprintf(logFile,"ERROR: Trying to access an out-of-bounds IntVector gene! (gene_number=%d >= number_of_pts=%d)\n", gene_number, number_of_pts); // used to be "stderr"
				retval.integer = 0;
				return(retval);
		} else {
				retval.integer = vector[gene_number];
				return(retval);  // typecast int as Element
		}
}

const void *L_IntVector::internals(void) const
{
		return((void *)(&vector[0]));
}

L_Representation &L_IntVector::operator=(const L_Representation &original)
{
		register unsigned int i;
		FourByteLong *array;
		array = (FourByteLong *)original.internals();
		if (original.type()==T_IntV) {
				number_of_pts = original.number_of_points();
				if (vector!=NULL) {
						delete [] vector;
				}

				if (array!=NULL) {
						vector = new FourByteLong[number_of_pts];
				} else {
						vector = NULL;
				}

				for (i=0; i<number_of_pts; i++) {
						vector[i] = array[i];
				}
		} else {
				(void)fprintf(logFile,"Unable to invoke operator= because Representations don't match!\n"); // used to be "stderr"
		}

		return(*this);
}

		L_RealVector::L_RealVector(int num_els)
: L_Representation(num_els)
{
		mytype = T_RealV;
		low = REALV_LOW;
		high = REALV_HIGH;
		vector = new double[num_els];
		for (; --num_els>=0;) {
				vector[num_els] = double(L_genunf(low, high));
		}
} // RealVector::RealVector(int num_els)

		L_RealVector::L_RealVector(int num_els, double init_low, double init_high)
: L_Representation(num_els)
{
		mytype = T_RealV;
		low = init_low;
		high = init_high;
		vector = new double[num_els];
		for (; --num_els>=0;) {
				vector[num_els] = double(L_genunf(init_low, init_high));
		}
} // RealVector::RealVector(int num_els, double init_low, double init_high)

		L_RealVector::L_RealVector(int num_els, double init_low, double init_high, double init_first_value)
: L_Representation(num_els)
{
		register int i=0;
		mytype = T_RealV;
		low = init_low;
		high = init_high;
		vector = new double[num_els];
		// Set the first element in the vector to "init_first_value":
		vector[i] = init_first_value;
		// Set the second and remaining elements in the vector, if any:
		for (i=1; i<num_els; i++) {
				vector[i] = double(L_genunf(init_low, init_high));
		}
} // RealVector::RealVector(int num_els, double init_low, double init_high, double init_first_value)

		L_RealVector::L_RealVector( int num_els, double init_low, double init_high, double nx, double ny, double nz )
: L_Representation(num_els)
{
		mytype = T_RealV;
		low = init_low;
		high = init_high;
		vector = new double[3];
		// Set the unit vector.
		vector[0] = nx;
		vector[1] = ny;
		vector[2] = nz;
} // RealVector::RealVector(double nx, double ny, double nz, int num_els)

		L_RealVector::L_RealVector( int num_els,  double init_low, double init_high,  double x, double y, double z, double w)
: L_Representation(num_els)
{
		mytype = T_RealV;
		low = init_low;
		high = init_high;
		vector = new double[4];
		// Set the x,y,z,w components of the quaternion.
		vector[0] = x;
		vector[1] = y;
		vector[2] = z;
		vector[3] = w;
}

		L_RealVector::L_RealVector(const L_RealVector &original)
: L_Representation(original.number_of_pts)
{
		mytype = T_RealV;
		low =  original.low;
		high = original.high;
		if (original.vector!=NULL) {
				vector = new double[original.number_of_pts];
		} else {
				vector = NULL;
		}

		for (register unsigned int i=0; i<original.number_of_pts; i++) {
				vector[i] = original.vector[i];
		}
}

void L_RealVector::write(unsigned char value, int gene)
{
		(void)fprintf(logFile,"Writing a Bit to a Real!\n"); // used to be "stderr"
		(void)fprintf(logFile,"value= \"%c\", gene= %d\n", value, gene); // used to be "stderr"
}

void L_RealVector::write(FourByteLong value, int gene)
{
		(void)fprintf(logFile,"Writing an Int to a Real!\n"); // used to be "stderr"
		(void)fprintf(logFile,"value= %ld, gene= %d\n", value, gene); // used to be "stderr"
}

void L_RealVector::write(double value, int gene)
{
		if (value<low) {
				vector[gene] = low;
		} else if (value>high) {
				vector[gene] = high;
		} else {
				vector[gene] = value;
		}
}

void L_RealVector::write(const Element value, int gene)
{
		if (value.real<low) {
				vector[gene] = low;
		} else if (value.real>high) {
				vector[gene] = high;
		} else {
				vector[gene] = value.real;
		}
}

const Element L_RealVector::gene(unsigned int gene_number) const
{

		Element retval;

		if (gene_number>=number_of_pts) {
				(void)fprintf(logFile,"ERROR: Trying to access an out-of-bounds RealVector gene (gene_number=%d >= number_of_pts=%d)\n", gene_number, number_of_pts); // used to be "stderr"
				retval.real = 0.0;
				return(retval);
		} else {
				retval.real = vector[gene_number];
				return(retval);
		}
}

const void *L_RealVector::internals(void) const
{
		return((void *)(&vector[0]));
}

L_Representation &L_RealVector::operator=(const L_Representation &original)
{
		register unsigned int i;
		double *array;

		if (original.type()==T_RealV) {
				low = ((const L_RealVector &)original).low;
				high = ((const L_RealVector &)original).high;
				array = (double *)original.internals();
				number_of_pts = original.number_of_points();
				if (vector!=NULL) {
						delete [] vector;
				}

				if (array!=NULL) {
						vector = new double[number_of_pts];
				} else {
						vector = NULL;
				}

				for (i=0; i<number_of_pts; i++) {
						vector[i] = array[i];
				}
		} else {
				(void)fprintf(logFile,"Unable to invoke operator= because Representations don't match!\n"); // used to be "stderr"
		}

		return(*this);
}

		L_ConstrainedRealVector::L_ConstrainedRealVector(int num_els)
:L_Representation(num_els)
{
		mytype = T_CRealV;
		normalized = 0;
		vector = new double[num_els];
		for (; --num_els>=0;) {
				vector[num_els] = double(L_genunf(low, high));
		}

		normalize();
}

//______________________________________________________________________________
//
		L_ConstrainedRealVector::L_ConstrainedRealVector(int num_els, double init_low, double init_high)
:L_Representation(num_els)
{
		mytype = T_CRealV;
		normalized = 0;
		low = init_low;
		high = init_high;
		vector = new double[num_els];
		for (; --num_els>=0;) {
				vector[num_els] = double(L_genunf(init_low, init_high));
		}

		normalize();
}

		L_ConstrainedRealVector::L_ConstrainedRealVector(const L_ConstrainedRealVector &original)
:L_Representation(original.number_of_pts)
{
		mytype = T_CRealV;
		normalized = original.normalized;
		if (original.vector != NULL) {
				vector = new double[original.number_of_pts];
		} else {
				vector = NULL;
		}

		for (register unsigned int i=0; i<original.number_of_pts; i++) {
				vector[i] = original.vector[i];
		}
}

void L_ConstrainedRealVector::write(unsigned char value, int gene)
{
		(void)fprintf(logFile,"Writing a Bit to a Constrained Real\n"); // used to be "stderr"
		(void)fprintf(logFile,"value= \"%c\",  gene= %d\n", value, gene); // used to be "stderr"
}

//______________________________________________________________________________
//
void L_ConstrainedRealVector::write(FourByteLong value, int gene)
{
		(void)fprintf(logFile,"Writing an Integer to a Constrained Real\n"); // used to be "stderr"
		(void)fprintf(logFile,"value= %ld, gene= %d\n",value,gene); // used to be "stderr"
}

void L_ConstrainedRealVector::write(double value, int gene)
{
		if (value<low) {
				(void)fprintf(logFile,"Writing out-of-bounds Constrained Real\n"); // used to be "stderr"
				vector[gene] = low;
		} else if (value>high) {
				(void)fprintf(logFile,"Writing out-of-bounds Constrained Real\n"); // used to be "stderr"
				vector[gene] = high;
		} else {
				vector[gene] = value;
		}

		normalized = 0;
}

void L_ConstrainedRealVector::write(double a, double b, double c, double d)
{
#define clamp_and_set_vector( value, gene ) \
		if (value<low) { \
				(void)fprintf(logFile,"Writing out-of-bounds Constrained Real\n"); \
				vector[gene] = low; \
		} else if (value>high) { \
				(void)fprintf(logFile,"Writing out-of-bounds Constrained Real\n"); \
				vector[gene] = high; \
		} else { \
				vector[gene] = value; \
		}

		assert( number_of_pts >= 4 );

		clamp_and_set_vector( a, 0 );
		clamp_and_set_vector( b, 1 );
		clamp_and_set_vector( c, 2 );
		clamp_and_set_vector( d, 3 );

		normalize();
}

void L_ConstrainedRealVector::write(const Element value, int gene)
{
		if (value.real<low) {
				vector[gene] = low;
		} else if (value.real>high) {
				vector[gene] = high;
		} else {
				vector[gene] = value.real;
		}

		normalized = 0;
}

void L_ConstrainedRealVector::normalize(void)
{
		if (!normalized) {
				register unsigned int i;
				register double tempsum = 0.0, hypotenuse;

				for (i=0; i<number_of_pts; i++) {
						tempsum += vector[i] * vector[i];
				}

				if ((tempsum - sum  >  ACCURACY) || (sum - tempsum  >  ACCURACY)) {
						hypotenuse = sqrt(tempsum);
						// normalize the vector[]
						for (i=0; i<number_of_pts; i++) {
								vector[i] /= hypotenuse;
						}
				}

				//normalized = 1;
				set_normalized_true();
		}
}

const Element L_ConstrainedRealVector::gene(unsigned int gene_number) const
{
		Element retval;
		if (gene_number>=number_of_pts) {
				(void)fprintf(logFile,
								"ERROR: Trying to access an out-of-bounds ConstrainedRealVector gene (gene_number=%d >= number_of_pts=%d)\n", 
								gene_number, number_of_pts); // used to be "stderr"
				retval.real = 0.0;
				return(retval);
		} else {
				// normalize();  // cannot normalize because gene(int) is const
				retval.real = vector[gene_number];
				return(retval);
		}
}

const void *L_ConstrainedRealVector::internals(void) const
{
		return((void *)(&vector[0]));
}

L_Representation &L_ConstrainedRealVector::operator=(const L_Representation &original)
{
		register unsigned int i;
		double *array;
		array = (double *)original.internals();
		if (original.type()==T_CRealV) {
				number_of_pts = original.number_of_points();
				normalized = original.is_normalized();
				if (vector!=NULL) {
						delete [] vector;
				}

				if (array!=NULL) {
						vector = new double[number_of_pts];
				} else {
						vector = NULL;
				}

				for (i=0; i<number_of_pts; i++) {
						vector[i] = array[i];
				}
		} else {
				(void)fprintf(logFile,"Unable to invoke operator= because Representations don't match!\n"); // used to be "stderr"
		}

		return(*this);
}

		L_BitVector::L_BitVector(int num_els)
: L_Representation(num_els)
{
		mytype = T_BitV;
		vector = new unsigned char[num_els];
		for (; --num_els>=0;) {
				vector[num_els] = ((L_ranf()<one_prob)? 1 : 0);
		}
}

		L_BitVector::L_BitVector(int num_els, Real prob)
: L_Representation(num_els)
{
		mytype = T_BitV;
		vector = new unsigned char[num_els];
		for (; --num_els>=0;) {
				vector[num_els] = ((L_ranf()<prob)? 1 : 0);
		}
}

		L_BitVector::L_BitVector(const L_BitVector &original)
: L_Representation(original.number_of_pts)
{
		mytype = T_BitV;
		if (original.vector!=NULL) {
				vector = new unsigned char[number_of_pts];
		} else {
				vector = NULL;
		}

		for (register unsigned int i=0; i<number_of_pts; i++) {
				vector[i] = original.vector[i];
		}
}

void L_BitVector::write(unsigned char value, int gene)
{
		vector[gene] = value;
}

void L_BitVector::write(FourByteLong value, int gene)
{
		(void)fprintf(logFile,"Writing Int to Bit!\n"); // used to be "stderr"
		(void)fprintf(logFile,"value= %ld, gene= %d\n",value,gene); // used to be "stderr"
}

void L_BitVector::write(double value, int gene)
{
		(void)fprintf(logFile,"Writing Real to Bit!\n"); // used to be "stderr"
		(void)fprintf(logFile,"value= %lf, gene= %d\n",value,gene); // used to be "stderr"
}

void L_BitVector::write(const Element value, int gene)
{
		vector[gene] = value.bit;
}

const Element L_BitVector::gene(unsigned int gene_number) const
{
		Element retval;
		if (gene_number>=number_of_pts) {
				(void)fprintf(logFile,
								"ERROR: Trying to access an out-of-bounds BitVector gene (gene_number=%d >= number_of_pts=%d)\n", 
								gene_number, number_of_pts); // used to be "stderr"
				retval.bit = 0;
				return(retval);
		} else {
				retval.bit = vector[gene_number];
				return(retval);
		}
}

const void *L_BitVector::internals(void) const
{
		return((void *)(&vector[0]));
}

L_Representation &L_BitVector::operator=(const L_Representation &original)
{
		register unsigned int i;
		unsigned char *array;
		array = (unsigned char *)original.internals();
		if (original.type()==T_BitV) {
				if (vector!=NULL) {
						delete [] vector;
				}

				number_of_pts = original.number_of_points();
				if (array!=NULL) {
						vector = new unsigned char[number_of_pts];
				} else {
						vector = NULL;
				}

				for (i=0; i<number_of_pts; i++) {
						vector[i] = array[i];
				}
		} else {
				(void)fprintf(logFile,"Unable to invoke operator= because Representations don't match!\n"); // used to be "stderr"
		}

		return(*this);
}


L_Genotype::L_Genotype(void)
{
		number_of_genes = number_of_vectors = 0;
		modified = 0;
		rep_vector = (L_Representation **)NULL;
		lookup = (Lookup *)NULL;
}

unsigned int L_Genotype::num_genes(void)
{
		return(number_of_genes);
}

unsigned int L_Genotype::num_vectors(void)
{
		return(number_of_vectors);
}

RepType L_Genotype::gtype(int gene_number)
{
		return(rep_vector[lookup[gene_number].vector]->type());
}

const Element L_Genotype::gread(int gene_number)
{
		return(rep_vector[lookup[gene_number].vector]->gene(lookup[gene_number].index));
}

const L_Representation *L_Genotype::vread(int vector_number)
{
		return(rep_vector[vector_number]);
}

//  More user definable stuff
L_Phenotype::L_Phenotype(void)
{
		value_vector = (L_Representation **)NULL;
		lookup = (Lookup *)NULL;
		number_of_dimensions = 0;
		number_of_points = 0;
		value = 0;
		evalflag = 0;
}

RepType L_Phenotype::gtype(int gene_number)
{
		return(value_vector[lookup[gene_number].vector]->type());
}

const Element L_Phenotype::gread(int gene_number)
{
		return(value_vector[lookup[gene_number].vector]->gene(lookup[gene_number].index));
}

const L_Representation *L_Phenotype::vread(int vector_number)
{
		return(value_vector[vector_number]);
}

unsigned int L_Phenotype::num_pts(void)
{
		return(number_of_points);
}

//  Constructs an Individual using the default constructors
L_Individual::L_Individual(void)
{
		age = 0L;
}

		L_Individual::L_Individual(L_Individual &original)
: genotyp(original.genotyp), phenotyp(original.phenotyp)
{
}

// caution, does not do mapping
		L_Individual::L_Individual(L_Genotype &init_genotyp, L_Phenotype &init_phenotyp)
: genotyp(init_genotyp), phenotyp(init_phenotyp)
{
}

L_Individual::~L_Individual(void)
{
}

L_Individual &L_Individual::operator=(const L_Individual &original)
{
		if (this == &original) {//Prevent self assignment
				return *this ;
		}
		genotyp = original.genotyp;
		phenotyp = original.phenotyp;
		mol = original.mol;
		age = original.age;
		return(*this);
}

double L_Individual::value(EvalMode mode)
{ // TO DO: check if mapping from genotyp to phenotyp is up-to-date
		// note that phenotyp.evaluate only does evaluation if evalflag is false
		return(phenotyp.evaluate(mode));
}

L_Individual &L_Individual::mapping(void)
{

#ifdef DEBUG
		(void)fprintf(logFile, "mapping.cc/Phenotype Individual::mapping(void)\n");
#endif /* DEBUG */
		//phenotyp.write sets phenotyp.evalflag to FALSE (0)
		phenotyp.write(*genotyp.vread(0), 0);
		phenotyp.write(*genotyp.vread(1), 1);
		phenotyp.write(*genotyp.vread(2), 2);
		phenotyp.write(*genotyp.vread(3), 3);
		phenotyp.write(*genotyp.vread(4), 4);
		//Possible future improvement
		//for (int i=0;i<5;i++) {
		//   if (*phenotyp.vread(i)!=*genotyp.vread(i)) phenotyp.write(*genotyp.vread(i), i);
		//}

		value(Normal_Eval);

		return(*this);
		//return(phenotyp);
}

//Genotype Individual::inverse_mapping(void)
L_Individual &L_Individual::inverse_mapping(void)
{

#ifdef DEBUG
		(void)fprintf(logFile, "mapping.cc/Genotype Individual::inverse_mapping(void)\n");
#endif /* DEBUG */

		genotyp.write(*phenotyp.vread(0), 0);
		genotyp.write(*phenotyp.vread(1), 1);
		genotyp.write(*phenotyp.vread(2), 2);
		genotyp.write(*phenotyp.vread(3), 3);
		genotyp.write(*phenotyp.vread(4), 4);

		return(*this);
		//return(genotyp);
}



		L_Population::L_Population(void)
:lhb(-1), size(0), heap((L_Individual *)NULL)
{
		for (int i=0; i<MAX_TORS; i++) {
				end_of_branch[i] = -1;
		}
}

		L_Population::L_Population(int num_inds)
: lhb(num_inds-1), size(num_inds)
{
		heap = new L_Individual[num_inds];
		for (int i=0; i<MAX_TORS; i++) {
				end_of_branch[i] = -1;
		}
}

		L_Population::L_Population(int newpopsize, L_Individual *newpop)
: size(newpopsize), heap(newpop)
{
		//  Do initialization stuff
		for (int i=0; i<MAX_TORS; i++) {
				end_of_branch[i] = -1;
		}
}

L_Population::~L_Population(void)
{
		if(heap != (L_Individual *)NULL)
		{
				delete [] heap;
		}
}

unsigned int L_Population::num_individuals(void)
{
		return(size);
}

		L_Population::L_Population(L_Population &original)
: lhb(original.lhb), size(original.size)
{
		register int i;
		heap = new L_Individual[size];
		for (i=0; i<size; i++) {
				heap[i] = original.heap[i];
				heap[i].age = 0L; // gmm, 1998-07-14
		}
}

void L_Population::swap(L_Individual &individual1, L_Individual &individual2)
{
		L_Individual temp;
		temp = individual1;
		individual1 = individual2;
		individual2 = temp;
}

void L_Population::SiftUp(void)
{
		int i, parent;

		i = lhb-1;
		while (((parent=(i+size+1)/2)<size)&&(heap[parent].value(Normal_Eval)>heap[i].value(Normal_Eval))) {
				swap(heap[parent], heap[i]);
				i = parent;
		}
		lhb--;
}

/*  This routine assumes that the heap condition is satisfied
	between lhb & size-2 initially, and that the individual at size-1
	needs to be accomodated.*/
void L_Population::SiftDown(void)
{
		int i, child;
		i = size-1;
		while ((child=2*i-size)>=lhb) {
				if (child-1>=lhb) {
						if (heap[child-1].value(Normal_Eval)<heap[child].value(Normal_Eval)) {
								child--;
						}
				}
				/*  Now child holds the index of the best child of i  */
				if (heap[i].value(Normal_Eval)<heap[child].value(Normal_Eval)) {
						break;
				} else {
						swap(heap[child], heap[i]);
						i = child;
				}
		}
}

void L_Population::msort(int m)
{
		register int i;
		//  First make a heap of the whole array, i.e lhb = 0 & uhb = size
		lhb = size-1;
		while (lhb>0) {
				SiftUp();
		}

		assert(lhb==0);

		//  Now place the m best members at the beginning of the array
		if (m==size) return; //we're done
		if (m>size) {
				//(void)fprintf(logFile, "support.cc/Population::msort(int m=%d) -- ERROR!  m > size!\n\n", m);
				slaveExit(-1);
		}

		for (i=0; i<m && i<size-1; i++) {
				swap(heap[i], heap[size-1]);
				lhb++;
				SiftDown();
		}

		//  Assert: heap[0..m-1] sorted
}

void L_Population::print(FILE *output, int num) {
		register int i;
		(void)fprintf( output, "The top %d individuals in the population:\n\n", num);
		for (i=0; i<num; i++) {
				(void)fprintf( output, "(%d):\t %8.2f\n", i+1, heap[i].value(Always_Eval));
		}
}

int L_doublecompare(const void *p1, const void *p2)
{
		double i = *((double *)p1);
		double j = *((double *)p2);
		if ( i > j ) return 1;
		if ( i < j ) return -1;
		return 0;
}
double L_compute_k_quantile(const int k, const int q,const double energy[], const int size)
{

		double p = (size-1) * k / q;
		double j_double; // integer part of p
		double g; // fractional part of p
		int ilow, ihigh; // indices to be weighted
		g = modf(p, &j_double);
		ilow = (int) j_double;
		assert(ilow>=0 && ilow<size);
		if (g == 0.0) return energy[ilow];
		ihigh=ilow+1;
		assert(ihigh<size);
		return energy[ilow] + g*(energy[ihigh]-energy[ilow]);
}

int L_Population::printPopulationStatistics(FILE *output, int level, Boole appendNewline) {

		int returnCode=0;
		double sum, best_e, worst_e;
		unsigned long oldest;
		int oldestIndividual, best_i;
		if(size<=0) return 2; // error, give up
		sum=best_e=worst_e=heap[best_i=0].value(Normal_Eval);
		oldest=heap[oldestIndividual=0].age;
		for (int i=1; i<size; i++) {
				double e = heap[i].value(Normal_Eval);
				sum+=e;
				if(e>worst_e) worst_e = e;
				if(e<best_e) {
						best_e = e;
						best_i = i;
				}
				if (heap[i].age >= oldest) {
						oldest = heap[i].age;
						oldestIndividual = i;
				}
		}

		switch (level) {
				case 1:
						(void)fprintf(output, " Oldest's energy: %.3f    Lowest energy: %.3f", 
										heap[oldestIndividual].value(Normal_Eval), best_e);
						break;
				case 2:
						(void)fprintf(output, 
										" Oldest ind.: %u/%u, age: %lu, energy: %.3f    Lowest energy individual: %u/%u, age: %lu, energy: %.3f", 
										oldestIndividual+1, size, 
										heap[oldestIndividual].age, 
										heap[oldestIndividual].value(Normal_Eval), 
										best_i+1, size, 
										heap[best_i].age, best_e);
						break;
				default:
						{
								double mean, sum_squares, median, stddev;
								//double q14, q34; // 1st and 3rd quartiles
								//double q15, q45; // 1st and 4th quintiles
								double energy[size]; // array for sorting
								mean = sum/size;
								sum_squares=0;
								for (int i=0; i<size; i++) energy[i] = heap[i].value(Normal_Eval);
								for (int i=0; i<size; i++) sum_squares += (energy[i]-mean)*(energy[i]-mean);
								if(size<2) stddev=0; else stddev=sqrt(sum_squares/(size-1));
								// compute median and quartiles 
								//  Avoid using msort because reordering the actual population
								//  causes runs to produce different results depending on statistics output level
								qsort( (void *) energy, size, sizeof(*energy), L_doublecompare); // ascend

								if( 1 == (size%2) ) median = energy[size/2]; // odd size
								else median = (energy[size/2] + energy[size/2-1])/2.0; // even size

								(void) fprintf(output, "Lowest: %.3f Highest: %.3f Mean: %.3f Median: %.3f Std.Dev: %.3f", 
												best_e, worst_e, mean, median, stddev);

								// quartiles and quintiles
								//q15 = compute_k_quantile(1, 5, energy, size);
								//q14 = compute_k_quantile(1, 4, energy, size);
								//q34 = compute_k_quantile(3, 4, energy, size);
								//q45 = compute_k_quantile(4, 5, energy, size);
#define quantile(k, q) \
								(void) fprintf(output, " Q%d/%d: %.3f", \
												k, q, L_compute_k_quantile(k, q, energy, size))

								quantile(1,10);
								quantile(1, 5);
								quantile(1, 4);
								quantile(3, 4);
								quantile(4, 5);
								quantile(9,10);

#undef quantile
								// debug print every energy:
								if(level>3) for(int i=0; i<size; i++) fprintf(output, " %.3f", energy[i]);
						}
						break;
		}
		if(appendNewline) fprintf(output, "\n");
		return returnCode;
}

int L_Population::printPopulationStatisticsVerbose(FILE * output, 
				unsigned int generations, long int nevals, const char suffix[]){ /* print with generations & #evals */
		int returnCode=0;
		// print "Population at Generation:" line with low/high/mean/median/stddev...
		(void) fprintf(output, "Population at Generation: %3u ", generations);
		// highest level, with newline at end:
		returnCode= printPopulationStatistics(logFile, 3, FALSE);
		(void) fprintf(logFile, " Num.evals: %ld%s", nevals, suffix );
		return returnCode; 
}

void L_Population::printPopulationAsStates(FILE *output, int num, int ntor) {
		register int i;
		double thisValue;

		// Print an XML-like tag indicating this is a population, with attribute size
		// being the number of individuals in the population
		(void)fprintf( output, "<population size=\"%d\">\n", num);
		for (i=0; i<num; i++) {
				thisValue = heap[i].value(Always_Eval);
				(void)fprintf( output, "%4d\t%9.4lg\t", i+1, thisValue);
				(void)fprintf( output, "%4lu\t", heap[i].age );
				heap[i].printIndividualsState(output, ntor, 0);
		}// i
		(void)fprintf( output, "</population>\n");
}

void L_Population::printPopulationAsCoordsEnergies(FILE *output, int num, int ntor) {
		register int i;
		double thisValue;
		//(void)fprintf( output, "The top %d individuals in the population:\n\n", num);
		for (i=0; i<num; i++) {

				// Print the number of this individual in the population (counting from 1, not 0)
				(void)fprintf( output, "%d\t", i+1);

				// Print the translation
				heap[i].printIndividualsState(output, ntor, 3);  // 3 means print just the translation
				//heap[i].printIndividualsState(output, ntor, 0);  // 0 means print the whole state

				// Print the energy
				thisValue = heap[i].value(Normal_Eval); // was Always_Eval before 13-Jan-2006
				(void)fprintf( output, "\t%9.2lf", thisValue);

				// Print the non-bonded energy, i.e. vdW+Hb+desolv
				thisValue = heap[i].value(Always_Eval_Nonbond);
				(void)fprintf( output, "\t%9.2lf", thisValue);

				// Print the electrostatic energy, i.e. elec
				thisValue = heap[i].value(Always_Eval_Elec);
				(void)fprintf( output, "\t%9.2lf", thisValue);

				// Write a newline at the end
				(void)fprintf( output, "\n");

				// We need the coordinates of this individual to compute the electrostatic and nonbond energies
				//cnv_state_to_coords( heap[i].state(ntor), heap[i].mol->vt,  heap[i].mol->tlist,  ntor, heap[i].mol->crdpdb,  heap[i].mol->crd,  heap[i].mol->natom);

		}// i
		(void)fprintf( output, "\n");
}

void L_Population::set_eob(int init_end_of_branch[MAX_TORS])
{
		for (register int i=0; i<MAX_TORS; i++) {
				end_of_branch[i] = init_end_of_branch[i];
		}
}

int L_Population::get_eob(int init_tor)
{
		if ((init_tor >= 0) && (init_tor < MAX_TORS)) {
				return end_of_branch[init_tor];
		} else {
				(void)fprintf(logFile, 
								"support.cc/Population::get_eob(int init_tor=%d) -- ERROR!  Attempt to access out-of-bounds torsion!\n\n", init_tor);
				slaveExit(-1);
		}
}

L_Genotype::L_Genotype(unsigned int init_number_of_vectors, L_Representation **
				init_rep_vector)
: number_of_vectors(init_number_of_vectors), rep_vector(init_rep_vector), 
		modified(0)
{
		register unsigned int i, j, k;
		number_of_genes = 0;
		for (i=0; i<number_of_vectors; i++) {
				number_of_genes += rep_vector[i]->number_of_points();
		}

		i=0;
		lookup = new Lookup[number_of_genes];
		for (j=0; j<number_of_vectors; j++) {
				for (k=0; k<rep_vector[j]->number_of_points(); k++) {
						lookup[i].vector = j;
						lookup[i].index = k;
						i++;
				}
		}
}

L_Genotype::L_Genotype(L_Genotype &original)
{
		register unsigned int i;
		number_of_genes = original.number_of_genes;
		number_of_vectors = original.number_of_vectors;
		modified = original.modified;
		if (original.rep_vector!=NULL) {
				rep_vector = new L_Representation*[number_of_vectors];
				lookup = new Lookup[number_of_genes];
		} else {
				rep_vector = NULL;
				lookup = NULL;
		}

		for (i=0; i<number_of_vectors; i++) {
				rep_vector[i] = original.rep_vector[i]->clone();
		}

		for (i=0; i<number_of_genes; i++) {
				lookup[i] = original.lookup[i];
		}
}

L_Genotype::L_Genotype(L_Genotype const &original)
{
		register unsigned int i;
		number_of_genes = original.number_of_genes;
		number_of_vectors = original.number_of_vectors;
		modified = original.modified;
		if (original.rep_vector!=NULL) {
				rep_vector = new L_Representation*[number_of_vectors];
				lookup = new Lookup[number_of_genes];
		} 
		else {
				rep_vector = NULL;
				lookup = NULL;
		}
		for (i=0; i<number_of_vectors; i++) {
				rep_vector[i] = original.rep_vector[i]->clone();
		}
		for (i=0; i<number_of_genes; i++) {
				lookup[i] = original.lookup[i];
		}
}

L_Genotype::~L_Genotype(void)
{
		register unsigned int i;
		if (rep_vector!=NULL) {
				for (i=0; i<number_of_vectors; i++) {
						delete rep_vector[i];
				}
				delete [] rep_vector;
				delete [] lookup;
		}
}

L_Genotype &L_Genotype::operator=(const L_Genotype &original)
{
		register unsigned int i;
		if (this==&original){ //Prevent self assignment
				return *this;
		}
		if (rep_vector!=NULL) {
				for (i=0; i<number_of_vectors; i++) {
						delete rep_vector[i];
				}
				delete [] rep_vector;
				delete [] lookup;
		}

		number_of_vectors = original.number_of_vectors;
		number_of_genes = original.number_of_genes;
		modified = 1;

		if (original.rep_vector!=NULL) {
				rep_vector = new L_Representation *[number_of_vectors];
				lookup = new Lookup[number_of_genes];
		} else {
				rep_vector = NULL;
				lookup = NULL;
		}

		for (i=0; i<number_of_vectors; i++) {
				rep_vector[i] = original.rep_vector[i]->clone();
		}

		for (i=0; i<number_of_genes; i++) {
				lookup[i] = original.lookup[i];
		}
		return(*this);
}

void L_Genotype::write(Element value, int gene_number)
{
		modified = 1;
		rep_vector[lookup[gene_number].vector]->write(value, lookup[gene_number].index);
}

void L_Genotype::write(unsigned char value, int gene_number)
{
		modified = 1;
		rep_vector[lookup[gene_number].vector]->write(value, lookup[gene_number].index);
}

void L_Genotype::write(FourByteLong value, int gene_number)
{
		modified = 1;
		rep_vector[lookup[gene_number].vector]->write(value, lookup[gene_number].index);
}

void L_Genotype::write(double value, int gene_number)
{
		modified = 1;
		rep_vector[lookup[gene_number].vector]->write(value, lookup[gene_number].index);
}

void L_Genotype::write(const L_Representation &value, int gene_number)
{
		modified = 1;
		*(rep_vector[gene_number]) = value;
}

Quat L_Genotype::readQuat()
{
		Quat q;
		q.x = gread(3).real;
		q.y = gread(4).real;
		q.z = gread(5).real;
		q.w = gread(6).real;
		// q = convertQuatToRot( q );
		return q;
}

void L_Genotype::writeQuat( Quat q )
{
		write( q.x, 3 );
		write( q.y, 4 );
		write( q.z, 5 );
		write( q.w, 6 );
}

Quat L_Phenotype::readQuat()
{
		Quat q;
		q.x = gread(3).real;
		q.y = gread(4).real;
		q.z = gread(5).real;
		q.w = gread(6).real;
		// q = convertQuatToRot( q );
		return q;
}

void L_Phenotype::writeQuat( Quat q )
{
		write( q.x, 3 );
		write( q.y, 4 );
		write( q.z, 5 );
		write( q.w, 6 );
}

//  Maybe we should evaluate the Phenotype?
		L_Phenotype::L_Phenotype(unsigned int init_number_of_dimensions, L_Representation **init_value_vector)
: number_of_dimensions(init_number_of_dimensions), value_vector(init_value_vector), 
		value(0.0), evalflag(0)
{
		register unsigned int i, j, k;
		number_of_points = 0;
		for (i=0; i<number_of_dimensions; i++) {
				number_of_points += value_vector[i]->number_of_points();
		}

		i = 0;
		lookup = new Lookup[number_of_points];
		for (j=0; j<number_of_dimensions; j++) {
				for (k=0; k<value_vector[j]->number_of_points(); k++) {
						assert ( i < number_of_points ); // mp!
						lookup[i].vector = j;
						lookup[i].index = k;
						i++;
				}
		}
}

L_Phenotype::L_Phenotype(const L_Phenotype &original)
{
		register unsigned int i;

		number_of_dimensions = original.number_of_dimensions;
		number_of_points = original.number_of_points;
		evalflag = original.evalflag;
		value = original.value;

		if (original.value_vector!=NULL) {
				value_vector = new L_Representation *[number_of_dimensions];
				lookup = new Lookup[number_of_points];
		} else {
				value_vector = NULL;
				lookup = NULL;
		}

		for (i=0; i<number_of_dimensions; i++) {
				value_vector[i] = original.value_vector[i]->clone();
		}

		for (i=0; i<number_of_points; i++) {
				lookup[i] = original.lookup[i];
		}
}

L_Phenotype &L_Phenotype::operator=(const L_Phenotype &original)
{
		register unsigned int i;
		if (this==&original){ //Prevent self assignment
				return *this;
		}

		//  Do the destructors get called on each element of value_vector?
		if (value_vector!=NULL) {
				for (i=0; i<number_of_dimensions; i++) {
						delete value_vector[i];
				}
				delete [] value_vector;
				delete [] lookup;
		}

		number_of_dimensions = original.number_of_dimensions;
		number_of_points = original.number_of_points;
		value = original.value;
		evalflag = original.evalflag;

		if (original.value_vector!=NULL) {
				value_vector = new L_Representation *[number_of_dimensions];
				lookup = new Lookup[number_of_points];
		} else {
				value_vector = NULL;
				lookup = NULL;
		}

		for (i=0; i<number_of_dimensions; i++) {
				value_vector[i] = original.value_vector[i]->clone();
		}

		for (i=0; i<number_of_points; i++) {
				lookup[i] = original.lookup[i];
		}

		return(*this);
}

L_Phenotype::~L_Phenotype(void)
{
		register unsigned int i;
		if (value_vector!=NULL) {
				for (i=0; i<number_of_dimensions; i++) {  
						delete value_vector[i];
				}
				delete [] value_vector;
				delete [] lookup;
		}
}

void L_Phenotype::write(Element value, int gene_number)
{
		evalflag = 0;
		value_vector[lookup[gene_number].vector]->write(value, lookup[gene_number].index);
}

void L_Phenotype::write(unsigned char value, int gene_number)
{
		evalflag = 0;
		value_vector[lookup[gene_number].vector]->write(value, lookup[gene_number].index);
}

void L_Phenotype::write(FourByteLong value, int gene_number)
{
		evalflag = 0;
		value_vector[lookup[gene_number].vector]->write(value, lookup[gene_number].index);
}

void L_Phenotype::write(double value, int gene_number)
{
		evalflag = 0;
		value_vector[lookup[gene_number].vector]->write(value, lookup[gene_number].index);
}

void L_Phenotype::write(const L_Representation &value, int gene_number)
{
		evalflag = 0;
		//   *(value_vector[lookup[gene_number].vector]) = value;
		*(value_vector[gene_number]) = value;
}

double L_Phenotype::evaluate(EvalMode mode)
{
		switch(mode)
		{
				case Always_Eval:
						value = ::L_evaluate[threadID](value_vector);
						evalflag = 1;
						break;
				case Always_Eval_Nonbond:
						value = ::L_evaluate[threadID](value_vector, 1); // term=1 as total non-bonded energy, i.e. vdW+Hb+desolv
						evalflag = 0;
						break;
				case Always_Eval_Elec:
						value = ::L_evaluate[threadID](value_vector, 2); // term=2 as total electrostatic energy
						evalflag = 0;
						break;
				case Normal_Eval:
						if (!evalflag) {
								value = ::L_evaluate[threadID](value_vector);
								evalflag = 1;
						}
						break;
				case Reset:
						evalflag = 0;
						break;
				default:
						(void)fprintf(logFile, "Unknown Evaluation Mode!\n");
						break;
		}

		return(value);
}

Quat L_normRot( Quat q )
{
		double mag3 = hypotenuse( q.nx, q.ny, q.nz );
		if (mag3 > APPROX_ZERO) {
				double inv_mag3 = 1. / mag3;
				q.nx *= inv_mag3;
				q.ny *= inv_mag3;
				q.nz *= inv_mag3;
		}
		return q;
}

Quat L_convertQuatToRot( Quat q )
{
		// TODO handle big W!  Singularities...
		Quat retval;
		assert( fabs( q.w ) <= 1.001 );
		if ( q.w > 1. ) q.w = 1.;
		if ( q.w < -1. ) q.w = -1.;

		register double angle = 2. * acos( q.w );
		register double inv_sin_half_angle = 1.;
		if ( q.w == 1. ) {
				retval.nx = 1.;
				retval.ny = 0.;
				retval.nz = 0.;
		} else {
				inv_sin_half_angle = 1. / sin( angle / 2. );

				retval.nx = q.x * inv_sin_half_angle;
				retval.ny = q.y * inv_sin_half_angle;
				retval.nz = q.z * inv_sin_half_angle;

				retval = L_normRot( retval );
		}
		angle = WrpModRad( angle );  // by convention, angles should be in the range -PI to +PI.
		retval.ang = angle;

		// Copy the existing x,y,z,w components
		retval.x = q.x;
		retval.y = q.y;
		retval.z = q.z;
		retval.w = q.w;

		return retval;
} // convertQuatToRot( Quat q )

void L_make_state_from_rep(L_Representation **rep, State *stateNow)
{
		register int i;
		//  Do the translations
		assert( !ISNAN( rep[0]->gene(0).real ) );
		stateNow->T.x = rep[0]->gene(0).real;
		assert( !ISNAN( rep[1]->gene(0).real ) );
		stateNow->T.y = rep[1]->gene(0).real;
		assert( !ISNAN( rep[2]->gene(0).real ) );
		stateNow->T.z = rep[2]->gene(0).real;

		//  Set up the quaternion
		assert( !ISNAN( rep[3]->gene(0).real ) );
		stateNow->Q.x = rep[3]->gene(0).real;
		assert( !ISNAN( rep[3]->gene(1).real ) );
		stateNow->Q.y = rep[3]->gene(1).real;
		assert( !ISNAN( rep[3]->gene(2).real ) );
		stateNow->Q.z = rep[3]->gene(2).real;
		assert( !ISNAN( rep[3]->gene(3).real ) );
		stateNow->Q.w = rep[3]->gene(3).real;

		// Generate the corresponding axis-angle ("rotation")
		Quat q_axis_angle;
		q_axis_angle = L_convertQuatToRot( stateNow->Q );

		// Update the axis-angle values in stateNow
		stateNow->Q.nx = q_axis_angle.nx;
		stateNow->Q.ny = q_axis_angle.ny;
		stateNow->Q.nz = q_axis_angle.nz;
		stateNow->Q.ang = q_axis_angle.ang;

		//  Copy the angles
		for (i=0; i<stateNow->ntor; i++) {
				assert( !ISNAN( rep[4]->gene(i).real ) );
				stateNow->tor[i] = rep[4]->gene(i).real;
		}

		// mkUnitQuat(&(stateNow->Q));
}

State L_Phenotype::make_state(int ntor)
{
		State retval;
		retval.ntor = ntor;
		L_make_state_from_rep(value_vector, &retval);
		return(retval);
}

L_Individual &L_Population::operator[](int ind_num)
{
		if ((ind_num<0)||(ind_num>=size)) {
				(void)fprintf(logFile, "ERROR: support.cc/Trying to access %d, an out of bounds individual! (0<i<%d)\n", ind_num, size);
				return(heap[0]);
		} else {
				return(heap[ind_num]);
		}
}

State L_Individual::state(int ntor)
{

		return(phenotyp.make_state(ntor));
}

void L_Individual::getMol(Molecule *returnedMol)
{
		State molState;
		Molecule molcopy;

		molState = phenotyp.make_state(mol->S.ntor);
		molcopy = L_copyStateToMolecule(&molState, mol);
		returnedMol = &molcopy;
}

void L_Individual::printIndividualsState(FILE *filePtr, int ntor, int detail) 
{
		L_printState( filePtr, state(ntor), detail ); 
		fprintf( filePtr, "\n" );
}

void L_Individual::incrementAge(void)
{
		++age;
}

L_Population &L_Population::operator=(const L_Population &original)
{
		register int i;
		if (this==&original){ //Prevent self assignement
				return *this;
		}

		if (heap!=NULL) {
				delete [] heap;
		}

		size = original.size;
		heap = new L_Individual[size];
		lhb = original.lhb;
		for (i=0; i<size; i++) {
				heap[i] = original.heap[i];
		}

		return(*this);
}
// the structure to hold all the data necessary for the master to communicate with the slaves
//#pragma offload_attribute(push,target(mic))
struct dockinfo
{
		int ctrlrank;
		int dockID;
		int jobNext;
		int slaverank;
		char baseName[100];
		int dockingSuccess;
		int endSlave;
		int endJobSubmit;
		int dockListFilePos;

#ifdef BGQ_NODE_VERIFICATION
		char bgqCoordinates[1024];
#endif

#ifdef PERF_PROFILING

		// additional data structures to hold information for performance profiling

		char masterMainSendDate[11];
		char masterMainSendTime[9];
		time_t masterMainSendTime_t;


		char masterMainRecvTime[9];
		time_t masterMainRecvTime_t;

		char secondMainSendTime[9];
		time_t secondMainSendTime_t;

		char slaveMainRecvTime[9];
		time_t slaveMainRecvTime_t;
		char slaveMainSendTime[9];
		time_t slaveMainSendTime_t;

		char slaveMainStartTime[9];
		time_t slaveMainStartTime_t;

		char slaveMainEndTime[9];
		time_t slaveMainEndTime_t;

		char UnboundExtendedStartTime[9];
		time_t UnboundExtendedStartTime_t;
		char UnboundExtendedEndTime[9];
		time_t UnboundExtendedEndTime_t;

		char LGAStartTime[9];
		time_t LGAStartTime_t;

		char LGAEndTime[9];
		time_t LGAEndTime_t;

		char SlaveMainPostLGATime[9];

		char LGASetupStartTime[9];

		Real LGAMaxRuntime;
		Real LGAMinRuntime;
		int LGAIters;
		Real LGATotalRuntime;

		Real LGAMaxRuntimeIO;
		Real LGAMinRuntimeIO;
		int LGAItersIO;
		Real LGATotalRuntimeIO;


		int firstFldFileFound;
		char FldFileStartTime[9];
		char FldFileEndTime[9];
		Real FldFileMaxDuration;
		Real FldFileMinDuration;
		int FldFileNumber;
		Real FldFileTotalDuration;

		int firstMapFileFound;
		char MapFileStartTime[9];
		char MapFileEndTime[9];
		Real MapFileMaxDuration;
		Real MapFileMinDuration;
		int MapFileNumber;
		Real MapFileTotalDuration;

		char analysisStartTime[9];
		char analysisEndTime[9];
		Real analysisDuration;

		int firstLigandFileFound;
		char LigandFileStartTime[9];
		char LigandFileEndTime[9];
		Real LigandFileTotalDuration;


#endif
};

struct dockinfo masterDockInfo;
struct dockinfo secondDockInfo;
struct dockinfo slaveDockInfo;
//	#pragma offload_attribute(pop)

#include <exception>
using namespace std;
//#pragma offload_attribute(pop)
//#pragma offload_attribute(push,target(mic))
// pkcoff: data structure for exception to enable graceful exit from docking failure so the node is available for another docking run and the master can record the failure
#pragma offload_attribute(push,target(mic))
class SlaveException : public exception
{
		public:
				int slaveRC;
};
class SEFather
{
		public:
				SlaveException* se;
};
#pragma offload_attribute(pop)
// pkcoff: exit function for slave to enable graceful exit from docking failure so the node is available for another docking run and the master can record the failure
__declspec(target(mic)) void slaveExit(int rc) 
{
		fprintf(stderr,"Abnormal exit on node %d for ligand %s with rc %d\n",slaveDockInfo.slaverank,slaveDockInfo.baseName,rc);
		/*
		   int mpitag = 1024;
		   slaveDockInfo.dockingSuccess = -1;
		   int mpirc = MPI_Send(&slaveDockInfo, sizeof(dockinfo), MPI_BYTE, 0, mpitag, MPI_COMM_WORLD);

		   if (mpirc != MPI_SUCCESS)
		   {
		   fprintf(stderr,"Failed slave on node %d cannot return to master - Terminating.\n",slaveDockInfo.slaverank);
		   MPI_Abort(MPI_COMM_WORLD, mpirc);
		   }
		   */
		// need to throw exception here
		SlaveException *se = new SlaveException();
		se->slaveRC = rc;
		SEFather se_father;
		se_father.se = se;
		throw se_father;
		// exit(-1);
}

//now it is my job,a shit

//  Inline Functions
L_Global_Search::L_Global_Search(void)
{
		cg_count = ci_count = mg_count = mi_count = 0;
}

L_Global_Search::~L_Global_Search(void)
{
}

// Default values set in this constructor.
		L_Genetic_Algorithm::L_Genetic_Algorithm(void)
: alloc(NULL), mutation_table(NULL), ordering(NULL), m_table_size(0), worst_window(NULL)
{
		generations = 0;
		elitism = window_size = low = high = 0;
		m_rate = 0.02;
		c_rate = 0.80;
		alpha = beta = 0.0;
		tranStep = 2.0;
		quatStep = torsStep = DegreesToRadians( 30.0 );
		worst = avg = 0.0L;
		converged = 0; // gmm 7-jan-98
		outputEveryNgens = OUTLEV1_GENS; // gmm 2000-nov-1
		linear_ranking_selection_probability_ratio = 2.0; //mp+rh 10/2009
}

L_Genetic_Algorithm::~L_Genetic_Algorithm(void)
{
		if (worst_window!=NULL) {
				delete [] worst_window;
		}

		if (alloc!=NULL) {
				delete [] alloc;
		}

		if (ordering!=NULL) {
				delete [] ordering;
		}

		if (mutation_table!=NULL) {
				delete [] mutation_table;
		}
}

void L_Genetic_Algorithm::mutation_values(int init_low, int init_high, 
				Real init_alpha, Real init_beta, 
				Real init_tranStep, Real init_quatStep, Real init_torStep )
{
		low = init_low;
		high = init_high;
		alpha = init_alpha;
		beta = init_beta;
		tranStep = init_tranStep;
		quatStep = init_quatStep;
		torsStep = init_torStep;
}

unsigned int L_Genetic_Algorithm::num_generations(void)
{
		return(generations);
}

int L_Genetic_Algorithm::terminate(void)
{
		if (max_generations>0) {
				// before 7-jan-98, was: return(generations>=max_generations);
				return((generations>=max_generations)||(converged==1)); // gmm 7-jan-98
		} else {
				return(0);  //  Don't terminate
		}
}

void L_Genetic_Algorithm::reset(void)
{
		generations = 0;
		converged = 0; // gmm 7-jan-98
		cg_count = ci_count = mg_count = mi_count = 0; // restart statistics
}

void L_Genetic_Algorithm::reset(unsigned int extOutputEveryNgens) // gmm 2000.11.1
{
		outputEveryNgens = extOutputEveryNgens; // gmm 2000.11.1
		generations = 0;
		converged = 0; // gmm 7-jan-98
		cg_count = ci_count = mg_count = mi_count = 0; // restart statistics
}


double L_worst_in_window(double *window, int size)
{
		register int i;
		double worst;
		worst = window[0];
		for (i=1; i<size; i++) {
				if (window[i]>worst) {
						worst = window[i];
				}
		}// for i
		return(worst);
}

double L_avg_in_window(double *window, int size)
{
		register int i;
		double mysum = 0.0, myavg = 0.0;
		for (i=0; i<size; i++) {
				mysum += window[i];
		}
		myavg = mysum / size;
		return(myavg);
}

//  Also set avg
double L_Genetic_Algorithm::worst_this_generation(L_Population &pop)
{
		register unsigned int i;
		double worstval, avgval;

		avgval = worstval = pop[0].value(Normal_Eval);
		for (i=1; i<pop.num_individuals(); i++) {
				avgval += pop[i].value(Normal_Eval);

				if (pop[i].value(Normal_Eval)>worstval) {
						worstval = pop[i].value(Normal_Eval);

				}
		}

		avg = avgval/pop.num_individuals();
#ifdef DEBUG2
		(void)fprintf(logFile, "gs.cc/Returning: avg= %.3f, worstval= %.3f\n\n", avg, worstval);
#endif
		return(worstval);
}

void L_Genetic_Algorithm::setValue(EvalMode init_e_mode, 
				Selection_Mode init_s_mode, 
				Xover_Mode init_c_mode,
				Worst_Mode init_w_mode, 
				int init_elitism, 
				Real init_c_rate, 
				Real init_m_rate, 
				int init_window_size, 
				unsigned int init_max_generations,
				unsigned int outputEveryNgens)
{
		e_mode=init_e_mode;
		s_mode=init_s_mode;
		c_mode=init_c_mode;
		w_mode=init_w_mode;
		elitism=init_elitism;
		c_rate=init_c_rate;
		m_rate=init_m_rate;
		window_size=init_window_size;
		alpha=1.0;
		beta=0.0;
		tranStep=2.0;             	//  2 Angstroms
		quatStep=DegreesToRadians( 30.0 );  // 30 degrees
		torsStep=DegreesToRadians( 30.0 );  // 30 degrees
		low=-100;
		high=100;
		generations=0;
		max_generations=init_max_generations;
		outputEveryNgens=100;
		converged=0;
		alloc=NULL;
		mutation_table=NULL;
		ordering=NULL;
		m_table_size=0;
		worst=0.0L;
		avg=0.0L;
		linear_ranking_selection_probability_ratio=2.0;
		worst_window = new double[window_size];
}

L_Genetic_Algorithm::L_Genetic_Algorithm( EvalMode init_e_mode, 
				Selection_Mode init_s_mode, 
				Xover_Mode init_c_mode,
				Worst_Mode init_w_mode, 
				int init_elitism, 
				Real init_c_rate, 
				Real init_m_rate, 
				int init_window_size, 
				unsigned int init_max_generations,
				unsigned int outputEveryNgens)

:  e_mode(init_e_mode),
		s_mode(init_s_mode),
		c_mode(init_c_mode),
		w_mode(init_w_mode),
		elitism(init_elitism),
		c_rate(init_c_rate),
		m_rate(init_m_rate),
		window_size(init_window_size),
		alpha(1.0),
		beta(0.0),
		tranStep(2.0),                         //  2 Angstroms
		quatStep( DegreesToRadians( 30.0 ) ),  // 30 degrees
		torsStep( DegreesToRadians( 30.0 ) ),  // 30 degrees
		low(-100),
		high(100),
		generations(0),
		max_generations(init_max_generations),
		outputEveryNgens(100),
		converged(0),
		alloc(NULL),
		mutation_table(NULL),
		ordering(NULL),
		m_table_size(0),
		worst(0.0L),
		avg(0.0L),
		linear_ranking_selection_probability_ratio(2.0)

{
		worst_window = new double[window_size];
}

int L_Genetic_Algorithm::set_linear_ranking_selection_probability_ratio(Real r)
{
		if (r<0.) return -1;  //ERROR!
		linear_ranking_selection_probability_ratio = r;
		return 1;
}

void L_Genetic_Algorithm::set_worst(L_Population &currentPop)
{
		double temp = 0.0;

		worst_window[generations%window_size] = worst_this_generation(currentPop);
		switch(w_mode)
		{
				//  Assume for this case that there's a window_size of 1
				case Ever:
						if (generations!=0) {
								if (temp>worst)
										worst = worst_window[0];
						} else {
								worst = worst_window[0];
						}
						break;
				case OfN:
						if (generations>=window_size) {
								worst = L_worst_in_window(worst_window, window_size);
						} else {
								worst = L_worst_in_window(worst_window, generations+1);
						}
						break;
				case AverageOfN:
						if (generations>=window_size) {
								worst = L_avg_in_window(worst_window, window_size);
						} else {
								worst = L_avg_in_window(worst_window, generations+1);
						}
						break;
				default:
						break;
		}
}

M_mode L_Genetic_Algorithm::m_type(RepType type)
{
		switch(type)
		{
				case T_BitV:
						return(BitFlip);
				case T_RealV:
				case T_CRealV:
						return(CauchyDev);
				case T_IntV:
						return(IUniformSub);
				default:
						//(void)fprintf(logFile,"gs.cc/Unrecognized Type (The allowed types are:  T_BitV, T_RealV, T_CRealV and T_IntV)!\n");
						return(ERR);
		}
}

void L_Genetic_Algorithm::make_table(int size, Real prob)
{
		register int i, j;
		double L = 0.0L;

		m_table_size = size;
		mutation_table = new Real[size+1];

		mutation_table[0] = pow(1-prob, size);
		mutation_table[size] = 1;

		i = 1;
		while (i<=(int)size*prob) {
				L = 0.0;
				for (j=1; j<=i; j++) {
						L += log(size+1-j) - log(j);
				}
				L += i*log(prob) + (size-i)*log(1-prob);
				assert( i > 0 && i<=size); // M Pique 2009-12 TODO - suspect problem if m_rate>1
				mutation_table[i] = mutation_table[i-1]+exp(L);

				i++;
		} // end while

		L = exp(L);
		for (; i<size; i++) {
				L = (L*prob*(size+1-i))/(i*(1-prob));
				mutation_table[i] = mutation_table[i-1]+L;
		}
}

int L_Genetic_Algorithm::check_table(Real prob)
{
		int low, high;
		low = 0; high = m_table_size;
		while (high-low>1) {
				if (mutation_table[(high+low)/2]<prob) {
						low = (high+low)/2;
				} else if (mutation_table[(high+low)/2]>prob) {
						high = (high+low)/2;
				} else {
						high = low = (high+low)/2;
				}
		}
		return(low);
}

void L_Genetic_Algorithm::initialize(unsigned int pop_size, unsigned int num_poss_mutations)
{
		register unsigned int i;
		if (alloc!=NULL) {
				delete [] alloc;
		}

		if (ordering!=NULL) {
				delete [] ordering;
		}

		if (mutation_table!=NULL) {
				delete [] mutation_table;
		}

		alloc = new Real[pop_size];

		ordering = new unsigned int[pop_size];
		for (i=0; i<pop_size; i++) {
				ordering[i] = i;
				assert(ordering[i] < pop_size);//debug
				alloc[i] = 1.0; // changed by gmm, 12-sep-1997.
		}

		make_table(pop_size*num_poss_mutations, m_rate);
}



void L_Genetic_Algorithm::mutate(L_Genotype &mutant, int gene_number)
{
		Element tempvar;

		switch(m_type(mutant.gtype(gene_number))) {
				case BitFlip:

						tempvar = mutant.gread(gene_number);
						//  Flip it
						tempvar.bit = 1 - tempvar.bit;
						//  write it
						mutant.write(tempvar, gene_number);
						break;

				case CauchyDev:
						// gene_numbers 3, 4, 5 and 6 correspond to the 
						// four components of the quaternion, (x,y,z,w)
						if ( is_rotation_index( gene_number ) ) {

								// Mutate all four comopnents of the quaternion, (x,y,z,w) simultaneously:
								// Generate a uniformly-distributed quaternion
								Quat q_change;
								q_change = L_uniformQuat();

								Quat q_current = mutant.readQuat();

								Quat q_new;

								// Multiply the quaternions, applying the rotation to the current orientation
								L_qmultiply( &q_new, &q_current, &q_change );
								mutant.writeQuat( q_new );
						} else {
								//  Read the real
								tempvar = mutant.gread(gene_number);

								//  Add deviate
								//  We never vary alpha and beta, so just use the faster "scauchy2()" function:
								tempvar.real += L_scauchy2();
								//  Write it
								mutant.write(tempvar, gene_number);
						}
						break;

				case IUniformSub:
						tempvar.integer = L_ignuin(low, high);

						mutant.write(tempvar, gene_number);
						break;

				default:
						//(void)fprintf(logFile,"gs.cc/Unrecognized mutation Mode!\n");
						break; 
		}
}

void L_Genetic_Algorithm::mutation(L_Population &pure)
{
		int num_mutations, individual, gene_number;

		num_mutations = check_table(L_ranf());

		if(num_mutations<=0) return;

		Boole individual_mutated[pure.num_individuals()]; // for statistics only
		for(unsigned int i=0;i<pure.num_individuals();i++) individual_mutated[i]=FALSE;

		//  Note we don't check to see if we mutate the same gene twice.
		//  So, effectively we are lowering the mutation rate, etc...
		//  Might want to check out Bentley's chapter on selection.
		for (; num_mutations>0; num_mutations--) {
				individual = L_ignlgi()%pure.num_individuals();
				gene_number = L_ignlgi()%pure[individual].genotyp.num_genes();

				mutate(pure[individual].genotyp, gene_number);
				pure[individual].age = 0L;
				pure[individual].mapping();//map genotype to phenotype and evaluate

				mg_count++; // update statistics: count of mutated genes per run
				individual_mutated[individual] = TRUE; // for statistics only
		}
		// update statistics: count of mutated individuals per run
		for(unsigned int i=0;i<pure.num_individuals();i++) \
				if(individual_mutated[i]) mi_count++; 
}

void L_Genetic_Algorithm::crossover(L_Population &original_population)
{
		register unsigned int i;
		int first_point, second_point, temp_index, temp_ordering;
		Real alpha = 0.5;
		//  Shuffle the population
		//  Permute the ordering of the population, "original_population"
		for (i=0; i<original_population.num_individuals(); i++) {
				temp_ordering = ordering[i];
				// ignlgi is GeNerate LarGe Integer and is in com.cc
				temp_index = L_ignlgi()%original_population.num_individuals();
				ordering[i] = ordering[temp_index];
				assert(ordering[i] < original_population.num_individuals());//debug
				assert(ordering[i] >= 0);//debug
				ordering[temp_index] = temp_ordering;
				assert(ordering[temp_index] < original_population.num_individuals());//debug
				assert(ordering[temp_index] >= 0);//debug
		}

		//  How does Goldberg implement crossover?

		// Loop over individuals in population
		for (i=0; i<original_population.num_individuals()-1; i=i+2) {
				// The two individuals undergoing crossover are original_population[ordering[i]] and original_population[ordering[i+1]]

				if (L_ranf() < c_rate) {
						// Perform crossover with a probability of c_rate
						int fi = ordering[i]; //index of father
						int mi = ordering[i+1]; //index of mother 
						// Assert the quaternions of the mother and father are okay:
						L_Genotype father = original_population[fi].genotyp;
						L_Genotype mother = original_population[mi].genotyp;
						Quat q_father, q_mother;
						//  Make sure the quaternion is suitable for 3D rotation
						q_father = father.readQuat();
						assertQuatOK( q_father );

						//  Make sure the quaternion is suitable for 3D rotation
						q_mother = mother.readQuat();

						assertQuatOK( q_mother );

						// Pos.  Orient. Conf.
						// 0 1 2 3 4 5 6 7 8 9
						// X Y Z x y z w t t t
						//                     num_genes() = 10
						switch(c_mode) {
								case OnePt:
										// To guarantee 1-point always creates 2 non-empty partitions,
										// the crossover point must lie in range from 1 to num_genes-1.
										// Choose one random integer in this range
										// Make sure we do not crossover inside a quaternion...
										do {
												// first_point = ignlgi()%original_population[i].genotyp.num_genes();
												first_point = L_ignuin(1, original_population[i].genotyp.num_genes()-1);
										} while ( is_within_rotation_index( first_point ) ) ;
										//  We can accomplish one point crossover by using the 2pt crossover operator
										crossover_2pt( original_population[fi].genotyp, 
														original_population[mi].genotyp,
														first_point, 
														original_population[fi].genotyp.num_genes());//either one works
										break;
								case TwoPt:
										// To guarantee 2-point always creates 3 non-empty partitions,
										// each crossover point must lie in range from 1 to num_genes-1.
										// Choose two different random integers in this range
										// Make sure we do not crossover inside a quaternion...
										do {
												first_point = L_ignuin(1, original_population[i].genotyp.num_genes()-1);
										} while ( is_within_rotation_index( first_point ) ) ;
										do {
												second_point = L_ignuin(1, original_population[i].genotyp.num_genes()-1);
										} while ( is_within_rotation_index( second_point ) || second_point == first_point );
										// Do two-point crossover, with the crossed-over offspring replacing the parents in situ:
										crossover_2pt( original_population[fi].genotyp, 
														original_population[mi].genotyp, 
														MIN( first_point, second_point ),
														MAX( first_point, second_point) );
										break;
								case Branch:
										// New crossover mode, designed to exchange just one corresponding sub-trees (or "branch")
										// between two individuals.
										// If there are only position and orientation genes, there will be only
										// 7 genes; this mode would not change anything in such rigid-body dockings.
										if (original_population[i].genotyp.num_genes() <= 7) {
												// Rigid body docking, so no torsion genes to crossover.
												continue; //TODO raise a fatal error if branch crossover with no torsions
										} else {
												// Pick a random torsion gene
												first_point = L_ignuin(7, original_population[i].genotyp.num_genes()-1);
												second_point = original_population.get_eob( first_point - 7 );
												// Do two-point crossover, with the crossed-over offspring replacing the parents in situ:
												crossover_2pt( original_population[fi].genotyp, 
																original_population[mi].genotyp, 
																MIN( first_point, second_point ),
																MAX( first_point, second_point) );
												break;
										}
								case Uniform:
										crossover_uniform( original_population[fi].genotyp, 
														original_population[mi].genotyp,
														original_population[mi].genotyp.num_genes());
										break;
								case Arithmetic:
										// select the parents A and B
										// create new offspring, a and b, where
										// a = x*A + (1-x)*B, and b = (1-x)*A + x*B    -- note: x is alpha in the code
										alpha = (Real) L_ranf();

										crossover_arithmetic( original_population[fi].genotyp, 
														original_population[mi].genotyp, 
														alpha );
										break;
								default:
										(void)fprintf(logFile,"gs.cc/ Unrecognized crossover mode!\n");
						}
						original_population[fi].age = 0L;
						original_population[mi].age = 0L;
						//map genotype to phenotype and evaluate energy
						original_population[fi].mapping();
						original_population[mi].mapping();
						// update statistics
						ci_count++; // count of crossovers, individ-by-individ
				}
		}
}

void L_Genetic_Algorithm::crossover_2pt(L_Genotype &father, L_Genotype &mother, unsigned int pt1, unsigned int pt2)
{
		// Assumes that 0<=pt1<=pt2<=number_of_pts

		// loop over genes to be crossed over
		for (unsigned int i=pt1; i<pt2; i++) {

				Element temp = father.gread(i);
				father.write(mother.gread(i), i);
				mother.write(temp, i);
				cg_count++; // count of crossovers, gene-by-gene

		}

}

void L_Genetic_Algorithm::crossover_uniform(L_Genotype &father, L_Genotype &mother, unsigned int num_genes)
{

		for (unsigned int i=0; i<num_genes; i++) {
				// Choose either father's or mother's gene/rotation gene set, with a 50/50 probability
				if (L_ranf() > 0.5 ) continue; // 50% probability of crossing a gene or gene-set; next i
				if ( ! is_rotation_index( i ) ) {
						// Exchange parent's genes
						Element temp = father.gread(i);
						father.write(mother.gread(i), i);
						mother.write(temp, i);
				} else if ( is_first_rotation_index(i) ) {
						// don't crossover within a quaternion, only at the start; next i

						// Exchange father's or mother's set of rotation genes
						for (unsigned int j=i; j<i+4; j++) {
								Element temp = father.gread(j);
								father.write(mother.gread(j), j);
								mother.write(temp, j);
						}
						// Increment gene counter, i, by 3, to skip the 3 remaining rotation genes
						i=i+3;
				} // is_rotation_index( i )
				cg_count++; // count of crossovers, gene-by-gene
		} // next i
}

void L_Genetic_Algorithm::crossover_arithmetic(L_Genotype &A, L_Genotype &B, Real alpha)
{
		register unsigned int i;
		Element temp_A, temp_B;
		Real one_minus_alpha;

		one_minus_alpha = 1.0 - alpha;

		// loop over genes to be crossed over
		// a = alpha*A + (1-alpha)*B
		// b = (1-alpha)*A + alpha*B
		for (i=0; i<A.num_genes(); i++) {
				if ( is_translation_index(i) ) {
						temp_A = A.gread(i);
						temp_B = B.gread(i);
						A.write( (one_minus_alpha * temp_A.real  +  alpha * temp_B.real), i);
						B.write( (alpha * temp_A.real  +  one_minus_alpha * temp_B.real), i);
				} else if ( is_rotation_index(i) ) {
						// Interpolate the father's and mother's set of 4 quaternion genes
						Quat q_A;
						q_A = L_slerp( A.readQuat(), B.readQuat(), alpha );
						B.writeQuat( L_slerp( A.readQuat(), B.readQuat(), one_minus_alpha ) );
						A.writeQuat( q_A );
						// Increment gene counter, i, by 3, to skip the 3 remaining quaternion genes
						i=i+3;
				} else if ( is_conformation_index(i) ) {
						// Use anglular interpolation, alerp(a,b,fract), to generate properly interpolated torsion angles
						temp_A = A.gread(i);
						temp_B = B.gread(i);
						A.write( L_alerp(temp_A.real, temp_B.real, alpha), i);
						B.write( L_alerp(temp_A.real, temp_B.real, one_minus_alpha), i);
				} else {
						// MP: BUG CHECK!
						//(void)fprintf(logFile, "Invalid gene type at i=%d\n", i);
						//(void)fflush(logFile);
						slaveExit(-1);
				}
				cg_count++; // count of crossovers, gene-by-gene
		}
}

void L_Genetic_Algorithm::selection_proportional(L_Population &original_population, L_Individual *new_pop)
{
		register unsigned int i=0, start_index = 0;
		int temp_ordering, temp_index;
		// Calculate expected number of children for each individual
		for (i=0;  i < original_population.num_individuals();  i++)
		{
				//  In our case of function minimization, the max individual is the worst
				if(avg==worst) alloc[i] = 1./(original_population.num_individuals()+1); // HACK TODO  investigate 2008-11
				else alloc[i] = (worst - original_population[i].value(e_mode))/(worst - avg);
		}

		for (i=0;  i < original_population.num_individuals();  i++) {
				temp_ordering = ordering[i];

				assert(ordering[i] < original_population.num_individuals());//debug

				temp_index = L_ignlgi()%(original_population.num_individuals());

				assert(ordering[temp_index] < original_population.num_individuals());//debug

				ordering[i] = ordering[temp_index];
				ordering[temp_index] = temp_ordering;
		}// endfor i

		//  We might get some savings here if we sorted the individuals before calling
		//  this routine
		for (i=0; (i < original_population.num_individuals()) && (start_index < original_population.num_individuals()); i++) {
				for (; (alloc[i] >= 1.0) && (start_index < original_population.num_individuals());  alloc[i]-= 1.0) {
						new_pop[start_index] = original_population[i];
						//new_pop[start_index].incrementAge();
						++start_index;
				}
		}
		i = 0;

		while (start_index < original_population.num_individuals()) {
				Real r; // local 
				assert(ordering[i] < original_population.num_individuals());//debug
				r = L_ranf();
				if (r < alloc[ordering[i]]) {
						new_pop[start_index] = original_population[ordering[i]];
						//new_pop[start_index].incrementAge();
						start_index++;
				}// endif (ranf() < alloc[ordering[i]])
				i = (i+1)%original_population.num_individuals();
		}// endwhile (start_index < original_population.num_individuals())
}

void L_Genetic_Algorithm::selection_tournament(L_Population &original_population, L_Individual *new_pop)
{
		register unsigned int i = 0, start_index = 0;
		int temp_ordering, temp_index;
		Real tournament_prob =  0.; // Dummy value - this code seems unfinished M Pique Oct 2009
		original_population.msort(original_population.num_individuals());
		for (i=0; i<original_population.num_individuals(); i++) {
				alloc[i] = original_population.num_individuals()*(2*tournament_prob - i*(4*tournament_prob - 2));
		}

		for (i=0;  (i < original_population.num_individuals()) && (start_index < original_population.num_individuals());  i++) {
				for (; (alloc[i] >= 1.0) && (start_index < original_population.num_individuals());  alloc[i] -= 1.0) {
						new_pop[start_index++] = original_population[i];
				}
		}

		for (i=0; i < original_population.num_individuals(); i++) {
				temp_ordering = ordering[i];
				temp_index = L_ignlgi()%original_population.num_individuals();
				ordering[i] = ordering[temp_index];
				ordering[temp_index] = temp_ordering;
		}

		i = 0;
		while (start_index < original_population.num_individuals()) {
				if (L_ranf() < alloc[ordering[i]]) {
						new_pop[start_index++] = original_population[ordering[i]];
				}
				i = (i+1)%original_population.num_individuals();
		}
}
void L_Genetic_Algorithm::selection_linear_ranking(L_Population &original_population, L_Individual *new_pop)
{
		register unsigned int i = 0, start_index = 0;

		Real c0 =  2*linear_ranking_selection_probability_ratio/(1+linear_ranking_selection_probability_ratio); // K
		Real c1 = 2*(c0-1);
		unsigned int num_indiv = original_population.num_individuals(); // abbreviation
		original_population.msort(original_population.num_individuals());

		for (i=0; i<num_indiv; i++) {
				Real x; // range 0..1 as i ranges 0..num_indiv-1
				if(num_indiv<2) x=0;
				else x=i/(num_indiv-1);
				alloc[i] = (c0-c1*x); // alpha
		}

		// allocate whole number parts of alloc (alpha) distribution
		for (i=0;  i<num_indiv && start_index<num_indiv;  i++) {
				while (alloc[i]>=1.0 && start_index<num_indiv) {
						new_pop[start_index++] = original_population[i];
						alloc[i] -= 1.0;
				}
		}

		int emergencydoor=25+num_indiv/10; // just in case
		unsigned int fracalloc_start = start_index; // for statistics logging
		while ( start_index < num_indiv && --emergencydoor>0 ) {
				i = L_ignlgi()%num_indiv;
				if(alloc[i]<=0) continue;
				if(alloc[i]>L_ranf()) {
						new_pop[start_index++] = original_population[i];
				}
				alloc[i]=0; // remove from further consideration
		}
		if(start_index!=num_indiv) {
				// put in log
				//(void)fprintf(logFile, "WARNING: gs.cc: linear_ranking_selection found no indiv for %d slot%s of %d.\n", num_indiv-start_index, (num_indiv-start_index)==1?"":"s", num_indiv-fracalloc_start);
				// just copy most fit indiv into rest of array
				while(start_index < num_indiv) new_pop[start_index++] = original_population[0];
		}
}

L_Individual *L_Genetic_Algorithm::selection(L_Population &solutions)
{
		L_Individual *next_generation;

		next_generation = new L_Individual[solutions.num_individuals()];

		set_worst(solutions);
		switch(s_mode)
		{
				case Proportional:
						selection_proportional(solutions, next_generation);
						break;
				case LinearRanking:
						selection_linear_ranking(solutions, next_generation);
						break;
				case Tournament:
						// M Pique October 2009 - does not work so disallowing for now
						// selection_tournament(solutions, next_generation);
						//(void)fprintf(logFile,"gs.cc/Unimplemented Selection Method - using proportional\n");
						selection_proportional(solutions, next_generation);
						break;
				case Boltzmann:
						//(void)fprintf(logFile,"gs.cc/Unimplemented Selection Method - using proportional\n");
						selection_proportional(solutions, next_generation);
						break;
				default:
						break;
		}

		return(next_generation);
}

int L_Genetic_Algorithm::search(L_Population &solutions)
{
		//#ifdef DEBUG4
		register unsigned int i;

		struct tms tms_genStart;
		struct tms tms_genEnd;

		Clock genStart;
		Clock genEnd;

		genStart = times( &tms_genStart );

		L_Population newPop(solutions.num_individuals(), selection(solutions));

		crossover(newPop);

		mutation(newPop);

		if (elitism > 0) {
				solutions.msort(elitism);
				for (i=0; i<elitism; i++) {
						newPop[solutions.num_individuals()-1-i] = solutions[i];
				}
		}

		//
		// Update current generation 
		//  
		solutions = newPop;

		//
		// Increase the number of generations
		//
		generations++;

		//
		// Increment the age of surviving individuals...
		// 
		for (i=0; i<solutions.num_individuals(); i++) {
				solutions[i].incrementAge();
		}

		genEnd = times( &tms_genEnd );

		// generation is over, tabulate statistics

		if (debug > 0) {
				(void)fprintf(logFile,"DEBUG:  Generation: %3u, outputEveryNgens = %3d, generations%%outputEveryNgens = %u\n",
								generations, outputEveryNgens, outputEveryNgens>0?generations%outputEveryNgens:0);
		}
		// Only output statistics if the output level is not 0. 
		if (outputEveryNgens != 0 && generations%outputEveryNgens == 0) {

		}
		genStart = times( &tms_genStart );
		//#endif
		return(0);
}

L_Local_Search::L_Local_Search(void)
{
		SearchType=0;
}

L_Local_Search::~L_Local_Search(void)
{
}

		L_Solis_Wets_Base::L_Solis_Wets_Base(void)
:  size(0), max_its(10), max_successes(5), max_failures(5), expansion(2.0), contraction(0.5),
		search_frequency(1.0), deviates(NULL), bias(NULL)
{
}

L_Solis_Wets_Base::L_Solis_Wets_Base(unsigned int init_size, unsigned int init_max_its, 
				unsigned int init_max_succ, unsigned int init_max_fail, 
				Real init_expansion, Real init_contraction, Real init_search_freq)
:  size(init_size), max_its(init_max_its), max_successes(init_max_succ), max_failures(init_max_fail),
		expansion(init_expansion), contraction(init_contraction), search_frequency(init_search_freq)
{
		bias = new Real[size];
		deviates = new Real[size];
}

L_Solis_Wets_Base::~L_Solis_Wets_Base(void)
{
		if(deviates!=NULL)
		{
				delete [] deviates;
		}

		if(bias!=NULL)
		{
				delete [] bias;
		}
}

void L_Solis_Wets_Base::reset(void)
{
		count = 0; // reset Statistics
}

int L_Solis_Wets_Base::terminate(void)
{
		return(0);  //  Don't terminate
}

		L_Solis_Wets::L_Solis_Wets(void)
:L_Solis_Wets_Base(), rho(1.0), lower_bound_on_rho(0.0)
{
}

L_Solis_Wets::L_Solis_Wets(unsigned int init_size, unsigned int init_max_its, unsigned int init_max_succ, 
				unsigned int init_max_fail, Real init_rho, Real init_lb_on_rho, 
				Real init_expansion, Real init_contraction, Real init_search_freq)
:  L_Solis_Wets_Base(init_size, init_max_its, init_max_succ, init_max_fail, init_expansion, init_contraction, 
				init_search_freq), rho(init_rho), lower_bound_on_rho(init_lb_on_rho)
{
}

L_Solis_Wets::~L_Solis_Wets(void)
{
}

		L_Pseudo_Solis_Wets::L_Pseudo_Solis_Wets(void)
:L_Solis_Wets_Base(), rho(NULL), lower_bound_on_rho(NULL), temp_rho(NULL)
{
}

L_Pseudo_Solis_Wets::L_Pseudo_Solis_Wets(unsigned int init_size, unsigned init_max_its, 
				unsigned int init_max_succ, unsigned int init_max_fail, 
				Real init_expansion, Real init_contraction, Real init_search_freq)
:L_Solis_Wets_Base(init_size, init_max_its, init_max_succ, init_max_fail, init_expansion, init_contraction, 
				init_search_freq), rho(NULL), lower_bound_on_rho(NULL), temp_rho(NULL)
{
}

L_Pseudo_Solis_Wets::L_Pseudo_Solis_Wets(unsigned int init_size, unsigned init_max_its, 
				unsigned int init_max_succ, unsigned int init_max_fail, 
				Real init_expansion, Real init_contraction, Real init_search_freq, 
				Real *init_rho, Real *init_lb_on_rho)
:  L_Solis_Wets_Base(init_size, init_max_its, init_max_succ, init_max_fail, init_expansion, init_contraction, 
				init_search_freq), rho(init_rho), lower_bound_on_rho(init_lb_on_rho)
{
		temp_rho = new Real[init_size];
}

L_Pseudo_Solis_Wets::~L_Pseudo_Solis_Wets(void)
{
		if (rho!=NULL)
		{
				delete [] rho;
		}

		if (lower_bound_on_rho!=NULL)
		{
				delete [] lower_bound_on_rho;
		}

		if (temp_rho!=NULL)
		{
				delete [] temp_rho;
		}
}

		L_Solis_Wets1::L_Solis_Wets1(void)
:L_Solis_Wets()
{
}

L_Solis_Wets1::L_Solis_Wets1(unsigned int init_size, unsigned int init_max_its, unsigned int init_max_succ, 
				unsigned int init_max_fail, Real init_rho, Real init_lb_on_rho, 
				Real init_expansion, Real init_contraction, Real init_search_freq)
:L_Solis_Wets(init_size, init_max_its, init_max_succ, init_max_fail, init_rho, init_lb_on_rho, init_expansion, 
				init_contraction, init_search_freq)
{
}

L_Solis_Wets1::~L_Solis_Wets1(void)
{
}

double L_Solis_Wets1::gen_deviates(Real rho)
{
		return(L_gennor(0.0, rho));
}

		L_Solis_Wets2::L_Solis_Wets2(void)
:L_Solis_Wets()
{
}

L_Solis_Wets2::L_Solis_Wets2(unsigned int init_size, unsigned int init_max_its, unsigned int init_max_succ, 
				unsigned int init_max_fail, Real init_rho, Real init_lb_on_rho, 
				Real init_expansion, Real init_contraction, Real init_search_freq)
:L_Solis_Wets(init_size, init_max_its, init_max_succ, init_max_fail, init_rho, init_lb_on_rho, init_expansion,
				init_contraction, init_search_freq)
{
}

L_Solis_Wets2::~L_Solis_Wets2(void)
{
}

double L_Solis_Wets2::gen_deviates(Real rho)
{
		return(L_genunf(-rho/2.0, rho/2.0));
}

		L_Pseudo_Solis_Wets1::L_Pseudo_Solis_Wets1(void)
:L_Pseudo_Solis_Wets()
{
}

L_Pseudo_Solis_Wets1::L_Pseudo_Solis_Wets1(unsigned int init_size, unsigned int init_max_its, 
				unsigned int init_max_succ, unsigned int init_max_fail,  
				Real init_expansion, Real init_contraction, 
				Real init_search_freq)
:L_Pseudo_Solis_Wets(init_size, init_max_its, init_max_succ, init_max_fail, init_expansion,
				init_contraction, init_search_freq)
{
}

L_Pseudo_Solis_Wets1::L_Pseudo_Solis_Wets1(unsigned int init_size, unsigned int init_max_its, 
				unsigned int init_max_succ, unsigned int init_max_fail,  
				Real init_expansion, Real init_contraction, 
				Real init_search_freq, Real *init_rho,
				Real *init_lb_on_rho)
:L_Pseudo_Solis_Wets(init_size, init_max_its, init_max_succ, init_max_fail, init_expansion,
				init_contraction, init_search_freq, init_rho, init_lb_on_rho)
{
}

L_Pseudo_Solis_Wets1::~L_Pseudo_Solis_Wets1(void)
{
}

double L_Pseudo_Solis_Wets1::gen_deviates(Real rho)
{
		return(L_gennor(0.0, rho));
}

		L_Pseudo_Solis_Wets2::L_Pseudo_Solis_Wets2(void)
:  L_Pseudo_Solis_Wets()
{
}

L_Pseudo_Solis_Wets2::L_Pseudo_Solis_Wets2(unsigned int init_size, unsigned int init_max_its, 
				unsigned int init_max_succ, unsigned int init_max_fail,  
				Real init_expansion, Real init_contraction, 
				Real init_search_freq)
:  L_Pseudo_Solis_Wets(init_size, init_max_its, init_max_succ, init_max_fail, init_expansion,
				init_contraction, init_search_freq)
{
}

L_Pseudo_Solis_Wets2::L_Pseudo_Solis_Wets2(unsigned int init_size, unsigned int init_max_its, 
				unsigned int init_max_succ, unsigned int init_max_fail,  
				Real init_expansion, Real init_contraction, 
				Real init_search_freq, Real *init_rho,
				Real *init_lb_on_rho)
:  L_Pseudo_Solis_Wets(init_size, init_max_its, init_max_succ, init_max_fail, init_expansion,
				init_contraction, init_search_freq, init_rho, init_lb_on_rho)
{
}

L_Pseudo_Solis_Wets2::~L_Pseudo_Solis_Wets2(void)
{
}

double L_Pseudo_Solis_Wets2::gen_deviates(Real rho)
{
		return(L_genunf(-rho/2.0, rho/2.0));
}

L_Phenotype L_genPh(const L_Phenotype &original, Real sign, Real *deviates, Real *bias)
{
		RepType genetype;
		register unsigned int i, index = 0;
		L_Phenotype retval(original);

		for (i=0; i < retval.num_pts(); i++) {
				genetype = retval.gtype(i);
				if ((genetype == T_RealV)||(genetype == T_CRealV)) {
						// 4/2009 experiment with gene-by-gene scaling,mp+rh
						//if(index>=0 && index<=2) scale = 1;//hack translation
						//else if(index>=3 && index<=6) scale = QSCALE;//hack quaternion
						//else scale = 1;//hack torsion

						retval.write(retval.gread(i).real + sign * (deviates[index] + bias[index]), i);
						index++;
				}
		}

		Quat q;
		q = retval.readQuat();
		retval.writeQuat( L_normQuat( q ) );

		return(retval);
}

Boole L_Solis_Wets::SW(L_Phenotype &vector)
{
		register unsigned int i, j, num_successes = 0, num_failures = 0;
		register Real temp_rho = rho;
		L_Phenotype newPh;
		Boole modified = FALSE;

		//  Reset bias
		for (i=0; i < size; i++) {
				bias[i] = 0.0;
		}

		for (i=0; i < max_its; i++) {
				// Generate deviates
				for (j=0; j < size; j++) {
						deviates[j] =dynamic_cast<L_Solis_Wets1*>(this)->gen_deviates(temp_rho);
				}

				// zeta = x + bias + deviates
				newPh = L_genPh(vector, +1., deviates, bias); // zeta; +1 means 'forward' step
				// Evaluate
				if (newPh.evaluate(Normal_Eval) < vector.evaluate(Normal_Eval)) {
						num_successes++;
						num_failures = 0;
						vector = newPh;
						modified = TRUE;
						for (j=0; j < size; j++) {
								// bias[j] = 0.20*bias[j] + 0.40*deviates[j];  // original & questionable
								bias[j] = 0.60*bias[j] + 0.40*deviates[j]; // strict Solis+Wets
						}
				} else {
						// We need to check if the opposite move does any good (move = bias[j] + deviates[j])
						newPh = L_genPh(vector, -1., deviates, bias); // 2x - zeta = x - move
						if (newPh.evaluate(Normal_Eval) < vector.evaluate(Normal_Eval)) {
								num_successes++;
								num_failures = 0;
								vector = newPh;
								modified = TRUE;
								for (j=0; j < size; j++) {
										// bias[j] -= 0.40*deviates[j]; // incorrect
										bias[j] = 0.60*bias[j] - 0.40*deviates[j]; // correct if deviates is not changed
								}
						} else {
								num_failures++;
								num_successes = 0;
								for (j=0; j < size; j++) {
										bias[j] *= 0.50;
								}
						}
				}

				// Check to see if we need to expand or contract
				if (num_successes >= max_successes) {
						temp_rho *= expansion;
						num_successes = num_failures = 0;
				} else if (num_failures >= max_failures) {
						temp_rho *= contraction;
						num_successes = num_failures = 0;
				}

				if (temp_rho < lower_bound_on_rho)
						break;  // GMM - this breaks out of the i loop...
		} // i-loop
		return modified;
} // void Solis_Wets::SW(Phenotype &vector)

Boole L_Pseudo_Solis_Wets::SW(L_Phenotype &vector)
{
		register unsigned int i, j, num_successes = 0, num_failures = 0,  all_rho_stepsizes_too_small = 1;

		L_Phenotype newPh;
		Boole modified = FALSE;
		//  Initialize the temp_rho's
		for (i=0; i < size; i++) {
				temp_rho[i] = rho[i];
		}
		//  Reset bias or 'momentum'
		for (i=0; i < size; i++) {
				bias[i] = 0.0;
		}

		for (i=0; i < max_its; i++) {
				// Generate deviates
				for (j=0; j < size; j++) {
						deviates[j] = dynamic_cast<L_Pseudo_Solis_Wets1*>(this)->gen_deviates(temp_rho[j]);
				}

				newPh = L_genPh(vector, +1., deviates, bias);
				// Evaluate
				if (newPh.evaluate(Normal_Eval) < vector.evaluate(Normal_Eval)) {
						num_successes++;
						num_failures = 0;
						vector = newPh;
						modified = TRUE;
						for (j=0; j < size; j++) {
								// bias[j] = 0.20*bias[j] + 0.40*deviates[j]; 
								bias[j] = 0.60*bias[j] + 0.40*deviates[j]; // strict Solis+Wets
						}
				} else  {
						//  We need to check if the opposite move does any good (move = bias[j] + deviates[j])
						newPh = L_genPh(vector, -1., deviates, bias);
						if (newPh.evaluate(Normal_Eval) < vector.evaluate(Normal_Eval)) {
								num_successes++;
								num_failures = 0;
								vector = newPh;
								modified = TRUE;
								for (j=0; j < size; j++) {
										// bias[j] -= 0.40*deviates[j];
										bias[j] = 0.60*bias[j] - 0.40*deviates[j]; // correct if deviates is not changed
								}
						} else {
								num_failures++;
								num_successes = 0;
								// vector is unchanged  // x
								for (j=0; j < size; j++) {
										bias[j] *= 0.50;
								}
						}
				}

				// DEBUG TRACE used to be here, mp+rh 4/09
				// Check to see if we need to expand or contract
				if (num_successes >= max_successes) {
						for(j=0; j < size; j++) {
								temp_rho[j] *= expansion;
						}
						num_successes = num_failures = 0;
				} else if (num_failures >= max_failures) {
						for(j=0; j < size; j++) {
								temp_rho[j] *= contraction;
						}
						num_successes = num_failures = 0;
				}

				//  WEH - Scott's code doesn't do anything!!! no stopping based upon step scale!!!
				//  GMM - corrected Scott's code; this does now stop correctly, based upon step scale.
				//  GMM - This version only exits if all the step sizes are too small...
				all_rho_stepsizes_too_small = 1;
				for(j=0; j < size; j++) {   
						if (temp_rho[j]>= lower_bound_on_rho[j]){
								all_rho_stepsizes_too_small = FALSE;
								break;
						}
				} //  j-loop
				if (all_rho_stepsizes_too_small) {
						break; //  GMM - THIS breaks out of i loop, which IS what we want...
				}
		} //  i-loop
		return modified;
} // Boole Pseudo_Solis_Wets::SW(Phenotype &vector)

int L_Solis_Wets_Base::search(L_Individual &solution)
{
		if (L_ranf() < search_frequency) {
				// Do inverse mapping if SW changed phenotyp 
				if(SearchType==1)
				{
						if (dynamic_cast<L_Solis_Wets1*>(this)->SW(solution.phenotyp)) 
						{
								solution.inverse_mapping();
								count++;      
						}
				}
				else if(SearchType==2)
				{
						if (dynamic_cast<L_Pseudo_Solis_Wets1*>(this)->SW(solution.phenotyp)) 
						{
								solution.inverse_mapping();
								count++;      
						}
				}
				else
				{
						printf("Solis_Wets_Base::search failed...\n");
				}
		}

		return(0);
}

L_Pattern_Search::L_Pattern_Search(void)
{
}

		L_Pattern_Search::L_Pattern_Search(unsigned int init_size, unsigned int init_max_success, Real init_step_size, Real init_step_threshold, Real init_expansion, Real init_contraction, Real init_search_frequency)
: size(init_size), max_success(init_max_success), step_size(init_step_size), step_threshold(init_step_threshold), expansion(init_expansion), contraction(init_contraction), search_frequency(init_search_frequency)
{
		current_step_size = step_size;
		pattern = new Real[size];
		index = new unsigned int[size];
		reset_pattern();
		reset_indexes();
		successes = 0;
}

L_Pattern_Search::~L_Pattern_Search(void)
{
		delete []pattern;
		delete []index;
}

void L_Pattern_Search::reset()
{
		current_step_size = step_size;
		reset_pattern();
		reset_indexes();
		successes = 0;
}

void L_Pattern_Search::reset_pattern() {
		for (unsigned int i=0; i < size; i++) {
				pattern[i] = 0.0;
		}
}

void L_Pattern_Search::reset_indexes() {
		for (unsigned int i=0; i < size; i++) {
				index[i] = i;
		}
}

void L_Pattern_Search::shuffle_indexes() {
		int select;
		unsigned int temp;
		for (unsigned int i=size; i > 1; i--) {
				select = rand() % i;
				temp = index[select];
				index[select] = index[i-1];
				index[i-1] = temp;
		}
}

int L_Pattern_Search::terminate(void)
{
		return (0);
}

int L_Pattern_Search::search(L_Individual &solution)
{
		// TODO: implement scaling?

		if (L_ranf() >= search_frequency) {
				return(0);
		}

		reset();
		L_Phenotype base = solution.phenotyp;
		L_Phenotype newPoint;
		// evaluate function at base point
		while (current_step_size > step_threshold) {
				// do exploratory moves
				//fprintf(stderr, "base point energy: %f\n", base.evaluate(Normal_Eval));
				newPoint = exploratory_move(base);
				//fprintf(stderr, "newPoint energy: %f\n", newPoint.evaluate(Normal_Eval));
				if (newPoint.evaluate(Normal_Eval) < base.evaluate(Normal_Eval)) {
						// new point is more favorable than base point
						// set new point as base point
						base = newPoint;

						while (true) {
								newPoint = pattern_explore(base);
								if (newPoint.evaluate(Normal_Eval) < base.evaluate(Normal_Eval)) {
										successes++;
										base = newPoint;
								}
								else {
										break;
										successes = 0;
								}

								if (successes > max_success) {
										//fprintf(stderr, "Expanding step size\n");
										successes = 0;
										current_step_size *= expansion;
								}
						}
				}

				else {
						current_step_size *= contraction;
						successes = 0;
						reset_pattern();
						//fprintf(stderr, "Contracted to %f after %ld evaluations.\n", current_step_size, evaluate.evals());
				}
		}

		solution.phenotyp = base;
		solution.inverse_mapping();
		return (0);
}

L_Phenotype L_Pattern_Search::exploratory_move(const L_Phenotype& base) {
		L_Phenotype newBase(base);
		shuffle_indexes();
		unsigned int current_index;
		int direction;

		for (unsigned int i=0; i < size; i++) {
				L_Phenotype trialPoint(newBase);

				current_index = index[i];
				// pick a random direction
				if (rand()%2 == 0) {
						direction = 1;
				}
				else {
						direction = -1;
				}
				// try first coordinate direction
				trialPoint.write(trialPoint.gread(current_index).real+current_step_size*direction, current_index);
				// if successful, keep new point
				if (trialPoint.evaluate(Normal_Eval) < newBase.evaluate(Normal_Eval)) {
						newBase = trialPoint;
						pattern[current_index] += current_step_size*direction;
				}
				// otherwise, try opposite coordinate and test again
				else {
						trialPoint.write(trialPoint.gread(current_index).real-2.0*current_step_size*direction, current_index);
						if (trialPoint.evaluate(Normal_Eval) < newBase.evaluate(Normal_Eval)) {
								newBase = trialPoint;
								pattern[current_index] -= current_step_size*direction;
						}
				}
		}
		return newBase;
}

L_Phenotype L_Pattern_Search::pattern_explore(const L_Phenotype& base) {
		L_Phenotype newPoint = pattern_move(base);
		reset_pattern();
		L_Phenotype newBase = exploratory_move(newPoint);
		return newBase;
}

L_Phenotype L_Pattern_Search::pattern_move(const L_Phenotype& base) {
		L_Phenotype newPoint(base);
		for (unsigned int i=0; i < size; i++) {
				newPoint.write(newPoint.gread(i).real + pattern[i] , i);
		}
		return newPoint;
}
void L_create_random_orientation( Quat *ptr_quat ) 
{
		// Generate a random initial orientation for the ligand
		Quat q_random;
		// Generate a uniformly-distributed quaternion:
		// setting the x,y,z,w components
		q_random = L_uniformQuat();
		ptr_quat->x = q_random.x;
		ptr_quat->y = q_random.y;
		ptr_quat->z = q_random.z;
		ptr_quat->w = q_random.w;
		// Update the (nx,ny,nz,ang) components of the quaternion, ptr_quat:
		*ptr_quat = L_convertQuatToRot( *ptr_quat );
}

void L_reorient(const int true_ligand_atoms, 
				char atomstuff[MAX_ATOMS][MAX_CHARS],
				Real crdpdb[MAX_ATOMS][SPACE],  // original PDB coordinates from input
				Real charge[MAX_ATOMS],
				int type[MAX_ATOMS],
				ParameterEntry  parameterArray[MAX_ATOM_TYPES],
				Quat q_reorient,
				Coord origin,
				const int ntor,
				int tlist[MAX_TORS][MAX_ATOMS],
				Real vt[MAX_TORS][SPACE],
				Molecule *ptr_ligand,
				const int debug )
{
		// Apply the rotation defined by q_reorient to the input coordinates of the ligand, "crdpdb"
		L_qtransform( origin, q_reorient, crdpdb, true_ligand_atoms );

		// Update the unit vectors for the torsion rotations
		L_update_torsion_vectors( crdpdb, ntor, tlist, vt, ptr_ligand, debug );
}

void L_torNorVec( Real crdpdb[MAX_ATOMS][SPACE],
				int ntor,
				int tlist[MAX_TORS][MAX_ATOMS],
				Real vt[MAX_TORS][SPACE] )
{
		register int xyz = 0;
		register int j = 0;
		Real magVec = 0.;
		Real imagVec = 0.;
		Real v[SPACE];

		for (j=0; j<ntor; j++) 
		{
				for (xyz = 0;  xyz < SPACE;  xyz++) 
				{
						v[xyz] = crdpdb[ tlist[j][ATM2] ][xyz] - crdpdb[ tlist[j][ATM1] ][xyz];
				} /* xyz */
				magVec = hypotenuse( v[X], v[Y], v[Z] );  /* Magnitude of vector v[xyz] */
				if (magVec == 0.) 
				{
						fprintf( stderr, "Torsion %d, normal vector, magVec, is 0; imminent division by zero caught.", j );
						slaveExit( -1 );
				}

				imagVec = 1. / magVec;

				for (xyz = 0;  xyz < SPACE;  xyz++) 
				{
						vt[j][xyz] = v[xyz] * imagVec;  /* Normalize. */
				} /* xyz */
		}
		return;
}

void L_update_torsion_vectors( Real crdpdb[MAX_ATOMS][SPACE],
				int ntor,
				int  tlist[MAX_TORS][MAX_ATOMS],
				Real vt[MAX_TORS][SPACE],
				Molecule *ligand,
				int debug )
{ // Update the unit vectors for the torsion rotations
		register int i=0, j=0;
		L_torNorVec(crdpdb, ntor, tlist, vt);
		for (i = 0; i < MAX_TORS; i++) {
				ligand->vt[i][X] = vt[i][X];
				ligand->vt[i][Y] = vt[i][Y];
				ligand->vt[i][Z] = vt[i][Z];
				for (j = 0; j < MAX_ATOMS; j++) {
						ligand->tlist[i][j] = tlist[i][j];
				}
		}
		return;
} // Update the unit vectors for the torsion rotations

L_Representation **L_generate_R_quaternion(int num_torsions, GridMapSetInfo *info)
{
		L_Representation **retval;
		Quat q;

		retval = new L_Representation *[5];

		// Set the x-translation
		retval[0] = new L_RealVector( 1, info->lo[X], info->hi[X] );
		// Set the y-translation
		retval[1] = new L_RealVector( 1, info->lo[Y], info->hi[Y] );
		// Set the z-translation
		retval[2] = new L_RealVector( 1, info->lo[Z], info->hi[Z] );

		// Generate a uniformly-distributed random quaternion for a random rotation (UDQ)
		q = L_uniformQuat();
		q = L_convertQuatToRot( q );
		// Set the quaternion (x,y,z,w) genes
		retval[3] = new L_RealVector( 4, -1., 1., q.x, q.y, q.z, q.w ); // uniformly-distributed quaternion (UDQ)
		// TODO retval[3] = new ConstrainedRealVector( 4, -1., 1., q.x, q.y, q.z, q.w ); // uniformly-distributed quaternion (UDQ)

		// Set the torsion angles
		retval[4] = new L_RealVector( num_torsions, -PI, PI );

		return(retval);
}

L_Genotype L_generate_Gtype(int num_torsions, GridMapSetInfo *info)
{
		L_Genotype temp((unsigned int)5, L_generate_R_quaternion(num_torsions, info));
		return(temp);
}

L_Phenotype L_generate_Ptype(int num_torsions, GridMapSetInfo *info) 
{
		L_Phenotype temp((unsigned int)5, L_generate_R_quaternion(num_torsions, info));

		return(temp);
}

L_Individual L_random_ind(int num_torsions,  GridMapSetInfo *info) 
{
		L_Genotype temp_Gtype = L_generate_Gtype(num_torsions, info);
		L_Phenotype temp_Ptype = L_generate_Ptype(num_torsions, info); 

		//shotgun wedding: does not map genotype to phenotype
		L_Individual temp(temp_Gtype, temp_Ptype);
		temp.mapping();
		return(temp);
}

State L_call_glss(L_Global_Search *global_method, L_Local_Search *local_method, 
				State sInit,unsigned int num_evals, unsigned int pop_size, 
				int outlev,unsigned int extOutputEveryNgens, Molecule *mol, 
				Boole B_RandomTran0, Boole B_RandomQuat0, Boole B_RandomDihe0,
				GridMapSetInfo *info, char *FN_pop_file,int end_of_branch[MAX_TORS])
{
		register unsigned int i;
		register int j;
		int num_generations = 0, allEnergiesEqual = 1, numTries = 0;
		int indiv = 0; // Number of Individual in Population to set initial state variables for.
		int max_numTries = 1000;
		double firstEnergy = 0.0;
		EvalMode localEvalMode = Normal_Eval;
		//FILE *pop_fileptr;

		dynamic_cast<L_Genetic_Algorithm*>(global_method)->reset(extOutputEveryNgens);
		if(local_method->SearchType==1)
				dynamic_cast<L_Solis_Wets1*>(local_method)->reset();
		else if(local_method->SearchType==2)
				dynamic_cast<L_Pseudo_Solis_Wets1*>(local_method)->reset();
		else
				dynamic_cast<L_Pattern_Search*>(local_method)->reset();

		//local_method->reset();
		L_evaluate[threadID].reset();

		//    (void)fprintf( logFile, "\nCreating an initial population of %u individuals.\n", pop_size);
		L_Population thisPop(pop_size);
		//  Pass in the end_of_branch tree for Branch Crossover Mode.
		thisPop.set_eob( end_of_branch );

		global_ntor = sInit.ntor; //debug

		do {
				++numTries;
				// Create a population of pop_size random individuals...
				for (i=0; i<pop_size; i++) 
				{

						thisPop[i] = L_random_ind( sInit.ntor, info );

						thisPop[i].mol = mol;
						thisPop[i].age = 0L;
				}

				// If initial values were supplied, put them in thisPop[0] and remap
				if (!B_RandomTran0) 
				{
						//if (outlev > 1) { (void)fprintf(logFile, "Setting the initial translation (tran0) for individual number %d to %.2lf %.2lf %.2lf\n\n", indiv+1, sInit.T.x, sInit.T.y, sInit.T.z); }
						thisPop[indiv].genotyp.write( sInit.T.x, 0 );
						thisPop[indiv].genotyp.write( sInit.T.y, 1 );
						thisPop[indiv].genotyp.write( sInit.T.z, 2 );
						// Remember to keep the phenotype up-to-date
						thisPop[indiv].mapping();
				}
				if (!B_RandomQuat0) 
				{

						thisPop[indiv].genotyp.write( sInit.Q.x, 3 );
						thisPop[indiv].genotyp.write( sInit.Q.y, 4 );
						thisPop[indiv].genotyp.write( sInit.Q.z, 5 );
						thisPop[indiv].genotyp.write( sInit.Q.w, 6 );
						// Remember to keep the phenotype up-to-date
						thisPop[indiv].mapping();
				}
				if (sInit.ntor > 0) 
				{
						if (!B_RandomDihe0) 
						{
								//if (outlev > 1) { (void)fprintf(logFile, "Setting the initial torsions (dihe0) for individual number %d to ", indiv+1); }
								for (j=0; j<sInit.ntor; j++) 
								{
										thisPop[indiv].genotyp.write( sInit.tor[j], 7+j );
										//if (outlev > 1) { (void)fprintf(logFile, "%.2lf ", RadiansToDegrees(sInit.tor[j])); }
								};
								//if (outlev > 1) { (void)fprintf(logFile, " deg\n\n"); }
								// Remember to keep the phenotype up-to-date
								thisPop[indiv].mapping();
						}
				}
				// Now ensure that there is some variation in the energies...
				firstEnergy = thisPop[0].value(localEvalMode);

				for (i=1; i<pop_size; i++) 
				{
						allEnergiesEqual = allEnergiesEqual && (thisPop[i].value(localEvalMode) == firstEnergy);
				}
				if ( pop_size>1 && allEnergiesEqual) 
				{
						printf("NOTE: All energies are equal in population; re-initializing. (Try Number %d)\n", numTries);
						fflush(0);
				}
				if (numTries > max_numTries) 
				{
						printf("WARNING: the number of tries has exceeded the maximum number of tries permitted.\nWARNING: AutoDock will attempt continue with the currently-generated random population.\n");
						fflush(0);
						break;
				}
		} while (pop_size>1 && allEnergiesEqual);

		if(pop_size>0) 
		{
				double bestenergy = thisPop[0].value(Normal_Eval);
				for (i=1; i<pop_size; i++) 
						if(bestenergy>thisPop[i].value(Normal_Eval)) 
								bestenergy=thisPop[i].value(Normal_Eval);
		}

		do 
		{
				++num_generations;
				dynamic_cast<L_Genetic_Algorithm*>(global_method)->search(thisPop);
				for (i=0; i<pop_size; i++) 
				{
						if(local_method->SearchType==1)
								dynamic_cast<L_Solis_Wets1*>(local_method)->search(thisPop[i]);
						else if(local_method->SearchType==2)
								dynamic_cast<L_Pseudo_Solis_Wets1*>(local_method)->search(thisPop[i]);
						else
								dynamic_cast<L_Pattern_Search*>(local_method)->search(thisPop[i]);
				}
				/*
				   if (strcmp (FN_pop_file, "") != 0) 
				   { // YES, do print!
				   if ((pop_fileptr = fopen( FN_pop_file, "w")) == NULL) {
				   pr(logFile, "\n%s: ERROR:  I'm sorry, I cannot create\"%s\".\n\n", programname, FN_pop_file);
				   } else {
				   thisPop.printPopulationAsCoordsEnergies( pop_fileptr, pop_size, sInit.ntor); 
				   fclose( pop_fileptr );
				   }
				   }

				   (void)fflush(logFile);
				   */
		}while((L_evaluate[threadID].evals() < num_evals) && (!dynamic_cast<L_Genetic_Algorithm*>(global_method)->terminate()));
		thisPop.msort(1);
		return( thisPop[0].state(sInit.ntor) );
}

void L_printState( FILE *fp, 
				State S, 
				int detail )
{
		register int i;
		Real torDegTmp;

		switch( detail ) 
		{
				case 0:
				case 1:
						L_writeState(fp,S);
						break;

				case 2:
				default:
						(void)fprintf( fp, "\nSTATE VARIABLES:\n________________\n\n" );
						(void)fprintf( fp, "Translation x,y,z         = %.3f %.3f %.3f\n", S.T.x, S.T.y, S.T.z );
						(void)fprintf( fp, "Quaternion x,y,z,w        = %.3f %.3f %.3f %.3f\n", S.Q.x, S.Q.y, S.Q.z, S.Q.w );
						S.Q = L_convertQuatToRot( S.Q );
						S.Q.ang = WrpRad( ModRad( S.Q.ang ));
						(void)fprintf( fp, "Axis-Angle nx,ny,nz,angle = %.3f %.3f %.3f %.3f\n", S.Q.nx, S.Q.ny, S.Q.nz, RadiansToDegrees(S.Q.ang) );
						//(void)fprintf( fp, "Quaternion qmag           = %.3f\n", S.Q.qmag );
						(void)fprintf( fp, "Number of Torsions        = %d\n", S.ntor );
						if (S.ntor > 0) 
						{
								(void)fprintf( fp, "Torsions (degrees)        =");
								for (i=0; i<S.ntor; i++) 
								{
										S.tor[i] = WrpRad( ModRad( S.tor[i] ) );
								}
								for (i=0; i<S.ntor; i++) 
								{
										torDegTmp = RadiansToDegrees( S.tor[i] );
										torDegTmp = ModDeg( torDegTmp );
										torDegTmp = WrpDeg( torDegTmp );
										pr( fp, " %.2f", torDegTmp );
								}
						}
						(void)fprintf( fp, "\n\n");
						break;

				case 3:
						// Writes only the translation component of the state
						(void)fprintf( fp, "%.3f %.3f %.3f", S.T.x, S.T.y, S.T.z );
						break;
		}
}

void L_writeState( FILE *fp, State S )
{
		register int i;
		Real torDegTmp;
		// Write translation.
		(void)fprintf( fp, "%7.3f %7.3f %7.3f  ", S.T.x, S.T.y, S.T.z );

		// Convert quaternion to axis-angle.
		S.Q = L_convertQuatToRot( S.Q );

		// Write axis-angle.
		S.Q.ang = WrpRad( ModRad( S.Q.ang ));
		(void)fprintf( fp, "%6.3f %6.3f %6.3f %6.3f  ", S.Q.nx, S.Q.ny, S.Q.nz, RadiansToDegrees(S.Q.ang) );

		// Write torsion angles.
		if (S.ntor > 0) 
		{
				for (i=0; i<S.ntor; i++) 
				{
						S.tor[i] = WrpRad( ModRad( S.tor[i] ) );
				}
				for (i=0; i<S.ntor; i++) 
				{
						torDegTmp = RadiansToDegrees( S.tor[i] );
						torDegTmp = ModDeg( torDegTmp );
						torDegTmp = WrpDeg( torDegTmp );
						// Commented out next line to make format more consistent, now all
						// numbers are space-delimited.
						pr( fp, " %7.2f", torDegTmp );
				}
		}
}

//now job end,a neweast

#ifdef FOR_MPI
//function declarations	

#ifdef NOSQRT
/*  ACCELERATED NON-SQUARE-ROOTING VERSION  *  Look-up internal non-bond energy based on square-of-the-distance, in square Angstroms. */
#   define IndexToDistance(i) sqrt( index_to_SqAng( i ) )

#else
/*  SQUARE-ROOTING VERSION  *  Look-up internal non-bond energy based on distance, in Angstroms.  */
#   define IndexToDistance(i) index_to_Ang( i )

#endif

char *param_string_4_0[MAX_LINES] = {
		"FE_coeff_vdW    0.1560\n", 
		"FE_coeff_hbond  0.0974\n", 
		"FE_coeff_estat  0.1465\n", 
		"FE_coeff_desolv 0.1159\n", 
		"FE_coeff_tors   0.2744\n", 
		"atom_par H      2.00  0.020   0.0000   0.00051  0.0  0.0  0  -1  -1  3	# Non H-bonding Hydrogen\n", 
		"atom_par HD     2.00  0.020   0.0000   0.00051  0.0  0.0  2  -1  -1  3	# Donor 1 H-bond Hydrogen\n", 
		"atom_par HS     2.00  0.020   0.0000   0.00051  0.0  0.0  1  -1  -1  3	# Donor S Spherical Hydrogen\n", 
		"atom_par C      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0	# Non H-bonding Aliphatic Carbon\n", 
		"atom_par A      4.00  0.150  33.5103  -0.00052  0.0  0.0  0  -1  -1  0	# Non H-bonding Aromatic Carbon\n", 
		"atom_par N      3.50  0.160  22.4493  -0.00162  0.0  0.0  0  -1  -1  1	# Non H-bonding Nitrogen\n", 
		"atom_par NA     3.50  0.160  22.4493  -0.00162  1.9  5.0  4  -1  -1  1	# Acceptor 1 H-bond Nitrogen\n", 
		"atom_par NS     3.50  0.160  22.4493  -0.00162  1.9  5.0  3  -1  -1  1	# Acceptor S Spherical Nitrogen\n", 
		"atom_par OA     3.20  0.200  17.1573  -0.00251  1.9  5.0  5  -1  -1  2	# Acceptor 2 H-bonds Oxygen\n", 
		"atom_par OS     3.20  0.200  17.1573  -0.00251  1.9  5.0  3  -1  -1  2	# Acceptor S Spherical Oxygen\n", 
		"atom_par F      3.09  0.080  15.4480  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Fluorine\n", 
		"atom_par Mg     1.30  0.875   1.5600  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Magnesium\n", 
		"atom_par MG     1.30  0.875   1.5600  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Magnesium\n", 
		"atom_par P      4.20  0.200  38.7924  -0.00110  0.0  0.0  0  -1  -1  5	# Non H-bonding Phosphorus\n", 
		"atom_par SA     4.00  0.200  33.5103  -0.00214  2.5  1.0  5  -1  -1  6	# Acceptor 2 H-bonds Sulphur\n", 
		"atom_par S      4.00  0.200  33.5103  -0.00214  0.0  0.0  0  -1  -1  6	# Non H-bonding Sulphur\n", 
		"atom_par Cl     4.09  0.276  35.8235  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Chlorine\n", 
		"atom_par CL     4.09  0.276  35.8235  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Chlorine\n", 
		"atom_par Ca     1.98  0.550   2.7700  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Calcium\n", 
		"atom_par CA     1.98  0.550   2.7700  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Calcium\n", 
		"atom_par Mn     1.30  0.875   2.1400  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Manganese\n", 
		"atom_par MN     1.30  0.875   2.1400  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Manganese\n", 
		"atom_par Fe     1.30  0.010   1.8400  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Iron\n", 
		"atom_par FE     1.30  0.010   1.8400  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Iron\n", 
		"atom_par Zn     1.48  0.550   1.7000  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Zinc\n", 
		"atom_par ZN     1.48  0.550   1.7000  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Zinc\n", 
		"atom_par Br     4.33  0.389  42.5661  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Bromine\n", 
		"atom_par BR     4.33  0.389  42.5661  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Bromine\n", 
		"atom_par I      4.72  0.550  55.0585  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Iodine\n", 
		"atom_par Z      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0  # Non H-bonding covalent map\n", 
		"atom_par G      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0	# Ring closure Glue Aliphatic Carbon  # SF\n", 
		"atom_par GA     4.00  0.150  33.5103  -0.00052  0.0  0.0  0  -1  -1  0	# Ring closure Glue Aromatic Carbon   # SF\n", 
		"atom_par J      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0	# Ring closure Glue Aliphatic Carbon  # SF\n", 
		"atom_par Q      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0	# Ring closure Glue Aliphatic Carbon  # SF\n", 
};
char *param_string_4_1[MAX_LINES] = {
		"FE_coeff_vdW    0.1662\n", 
		"FE_coeff_hbond  0.1209\n", 
		"FE_coeff_estat  0.1406\n", 
		"FE_coeff_desolv 0.1322\n", 
		"FE_coeff_tors   0.2983\n", 
		"atom_par H      2.00  0.020   0.0000   0.00051  0.0  0.0  0  -1  -1  3	# Non H-bonding Hydrogen\n", 
		"atom_par HD     2.00  0.020   0.0000   0.00051  0.0  0.0  2  -1  -1  3	# Donor 1 H-bond Hydrogen\n", 
		"atom_par HS     2.00  0.020   0.0000   0.00051  0.0  0.0  1  -1  -1  3	# Donor S Spherical Hydrogen\n", 
		"atom_par C      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0	# Non H-bonding Aliphatic Carbon\n", 
		"atom_par A      4.00  0.150  33.5103  -0.00052  0.0  0.0  0  -1  -1  0	# Non H-bonding Aromatic Carbon\n", 
		"atom_par N      3.50  0.160  22.4493  -0.00162  0.0  0.0  0  -1  -1  1	# Non H-bonding Nitrogen\n", 
		"atom_par NA     3.50  0.160  22.4493  -0.00162  1.9  5.0  4  -1  -1  1	# Acceptor 1 H-bond Nitrogen\n", 
		"atom_par NS     3.50  0.160  22.4493  -0.00162  1.9  5.0  3  -1  -1  1	# Acceptor S Spherical Nitrogen\n", 
		"atom_par OA     3.20  0.200  17.1573  -0.00251  1.9  5.0  5  -1  -1  2	# Acceptor 2 H-bonds Oxygen\n", 
		"atom_par OS     3.20  0.200  17.1573  -0.00251  1.9  5.0  3  -1  -1  2	# Acceptor S Spherical Oxygen\n", 
		"atom_par F      3.09  0.080  15.4480  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Fluorine\n", 
		"atom_par Mg     1.30  0.875   1.5600  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Magnesium\n", 
		"atom_par MG     1.30  0.875   1.5600  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Magnesium\n", 
		"atom_par P      4.20  0.200  38.7924  -0.00110  0.0  0.0  0  -1  -1  5	# Non H-bonding Phosphorus\n", 
		"atom_par SA     4.00  0.200  33.5103  -0.00214  2.5  1.0  5  -1  -1  6	# Acceptor 2 H-bonds Sulphur\n", 
		"atom_par S      4.00  0.200  33.5103  -0.00214  0.0  0.0  0  -1  -1  6	# Non H-bonding Sulphur\n", 
		"atom_par Cl     4.09  0.276  35.8235  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Chlorine\n", 
		"atom_par CL     4.09  0.276  35.8235  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Chlorine\n", 
		"atom_par Ca     1.98  0.550   2.7700  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Calcium\n", 
		"atom_par CA     1.98  0.550   2.7700  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Calcium\n", 
		"atom_par Mn     1.30  0.875   2.1400  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Manganese\n", 
		"atom_par MN     1.30  0.875   2.1400  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Manganese\n", 
		"atom_par Fe     1.30  0.010   1.8400  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Iron\n", 
		"atom_par FE     1.30  0.010   1.8400  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Iron\n", 
		"atom_par Zn     1.48  0.550   1.7000  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Zinc\n", 
		"atom_par ZN     1.48  0.550   1.7000  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Zinc\n", 
		"atom_par Br     4.33  0.389  42.5661  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Bromine\n", 
		"atom_par BR     4.33  0.389  42.5661  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Bromine\n", 
		"atom_par I      4.72  0.550  55.0585  -0.00110  0.0  0.0  0  -1  -1  4	# Non H-bonding Iodine\n", 
		"atom_par Z      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0  # Non H-bonding covalent map\n", 
		"atom_par G      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0	# Ring closure Glue Aliphatic Carbon  # SF\n", 
		"atom_par GA     4.00  0.150  33.5103  -0.00052  0.0  0.0  0  -1  -1  0	# Ring closure Glue Aromatic Carbon   # SF\n", 
		"atom_par J      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0	# Ring closure Glue Aliphatic Carbon  # SF\n", 
		"atom_par Q      4.00  0.150  33.5103  -0.00143  0.0  0.0  0  -1  -1  0	# Ring closure Glue Aliphatic Carbon  # SF\n", 
};
char parameter_library[MAX_CHARS];

void M_timesys( Clock duration,struct tms  *start,struct tms  *end);
void M_timesyshms( Clock     duration, struct tms  *start, struct tms  *end);
M_stack M_stack_create(int size);
int   M_stack_pop(M_stack s);
void  M_stack_push(M_stack s, int i);
int   M_stack_size(M_stack s);
void  M_stack_trace(M_stack s, FILE *f);
int   M_stack_test(void);
int   M_stack_depth(M_stack s);
void M_swap ( int v[],int i,int j );
void M_usage( FILE * file, char * programname );
int M_setflags( int argc, char ** argv, const char * version_num);
void M_banner();
void M_show_copyright( FILE *fp );
void M_show_warranty( FILE *fp );
static unsigned int M_hash(const char key[]);					
void M_apm_enter(const char key[], PE value);
PE * M_apm_find(const char key[]);
int M_parse_param_line( char line[LINE_LEN] );
void M_setup_parameter_library( int outlev, const char * model_text, Unbound_Model unbound_model );
int M_parse_PDBQT_line( char line[LINE_LEN] );
void  M_readReceptorPDBQTLine( char line[LINE_LEN],int  *ptr_serial,Real crd[SPACE],Real *ptr_q,char* atomtype);
Receptor M_readReceptorPDBQT(int *P_natoms,Real crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
				Real charge[MAX_RECEPTOR_ATOMS],Boole *P_B_haveCharges,char pdbaname[MAX_RECEPTOR_ATOMS][5],
				char *FN_receptor,Clock jobStart,struct tms tms_jobStart,int B_include_1_4_interactions,
				Atom atoms[MAX_RECEPTOR_ATOMS]);
void print_2x( FILE *stream1,FILE *stream2,const char *string );
int M_parsetypes(char * line, char *words[], int maxwords);
void M_intnbtable( Boole *P_B_havenbp,int a1,int a2,GridMapSetInfo *info,Real cA, 
				Real cB,int xA,int xB,double coeff_desolv,double sigma,EnergyTables *ad_tables,Boole B_is_unbound_calculation );
void M_readfield( GridMapSetInfo *info, char line[LINE_LEN],Clock jobStart,struct tms tms_jobStart );
void M_warn_bad_file( char *filename,char message[LINE_LEN] );
void M_check_header_line( char s1[], char s2[] );
void M_check_header_float( Real f1, Real f2, char keyword[], char filename[] );
void M_check_header_int( int i1,int i2, char axis, char *filename );
Real M_mapc2f(char numin);
Statistics M_readmap( char line[LINE_LEN],int outlev,Clock jobStart,
				struct tms     tmsJobStart,
				Boole          B_charMap,
				Boole          *P_B_HaveMap,
				int            num_maps,
				GridMapSetInfo *info,
				Real           map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS],
				// double *maps
				char           map_type,
				Boole mapFileAlreadyLoaded,
				int mapUsageType);
int M_lookupXBPMFMAPATindex(char xbpmf_at[MAX_LEN_AUTOGRID_TYPE + 1]);
Statistics M_readxbempiricalprofile( char line[LINE_LEN],
				int outlev,
				Clock jobStart,
				struct tms tmsJobStart,
				GridMapSetInfo *info,
				Real xb_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				char profile_type);
void M_initialiseState( State *S );
void M_initialiseQuat( Quat *Q );
double M_calc_ddd_Mehler_Solmajer( double distance, double approx_zero );
void M_setup_distdepdiel( int outlev,EnergyTables *ptr_ad_energy_tables );
void M_initialise_energy_breakdown ( EnergyBreakdown * eb,Real torsFreeEnergy, Real unbound_internal_FE );
int M_parse_PDBQT_line( char line[LINE_LEN] );
void M_readPDBQTLine( char line[LINE_LEN],int  *ptr_serial,Real crd[SPACE],Real *ptr_q,ParameterEntry *this_parameter_entry );
void M_mkTorTree( int   atomnumber[ MAX_RECORDS ],
				char  Rec_line[ MAX_RECORDS ][ LINE_LEN ],
				int   nrecord,
				int   tlist[ MAX_TORS ][ MAX_ATOMS ],
				int   *P_ntor,
				int   *P_ntor_ligand,
				char  *smFileName,
				char  pdbaname[ MAX_ATOMS ][ 5 ],
				Boole *P_B_constrain,
				int   *P_atomC1,
				int   *P_atomC2,
				Real  *P_sqlower,
				Real  *P_squpper,
				int   *P_ntorsdof,
				int   ignore_inter[MAX_ATOMS]);

void M_mdist();
void M_quicksort( Real e[],int isort[],int left,int right );
void M_getbonds(const Real crdpdb[MAX_ATOMS][SPACE],const int from_atom,const int to_atom,
				const int bond_index[MAX_ATOMS],int   bonded[MAX_ATOMS][6]);
void M_printbonds(const int natom, const int bonded[MAX_ATOMS][6], const char *message, const int B_print_all_bonds);
void M_nonbonds(const Real  crdpdb[MAX_ATOMS][SPACE],
				int         nbmatrix[MAX_ATOMS][MAX_ATOMS],
				const int   natom, 
				const int   bond_index[MAX_ATOMS],
				int         B_include_1_4_interactions,
				int         bonded[MAX_ATOMS][6]);
void M_weedbonds( int natom,
				char pdbaname[MAX_ATOMS][5],
				int rigid_piece[MAX_ATOMS],
				int ntor,
				int tlist[MAX_TORS][MAX_ATOMS],
				int nbmatrix[MAX_ATOMS][MAX_ATOMS],
				int *Addr_Nnb,
				NonbondParam *nonbondlist,
				int outlev,
				int type[MAX_ATOMS] );
void M_success( char *hostnm,
				Clock jobStart,
				struct tms tms_jobStart );
Molecule M_readPDBQT(char input_line[LINE_LEN],
				int num_atom_maps,

				int *P_natom,
				Real crdpdb[MAX_ATOMS][NTRN],
				Real crdreo[MAX_ATOMS][NTRN],
				Real charge[MAX_ATOMS],
				Boole * P_B_haveCharges,
				int map_index[MAX_ATOMS], //was:int type[MAX_ATOMS]
				int bond_index[MAX_ATOMS],
				char pdbaname[MAX_ATOMS][5],

				char *FN_ligand,
				char *FN_flexres,
				Boole B_have_flexible_residues,

				char atomstuff[MAX_ATOMS][MAX_CHARS],
				int *P_n_heavy_atoms_in_ligand,

				Boole * P_B_constrain,
				int *P_atomC1,
				int *P_atomC2,
				Real *P_sqlower,
				Real *P_squpper,

				int *P_ntor1,
				int *P_ntor,
				int *P_ntor_ligand,   // the number of torsions in the ligand (excluding the flexible residues in receptor)
				int tlist[MAX_TORS][MAX_ATOMS],
				Real vt[MAX_TORS][NTRN],

				int *P_Nnb,
				NonbondParam *nonbondlist,

				Clock jobStart,
				struct tms tms_jobStart,
				char *hostnm,
				int *P_ntorsdof,
				int outlev,
				int ignore_inter[MAX_ATOMS],
				int B_include_1_4_interactions,

				Atom atoms[MAX_ATOMS],
				char PDBQT_record[MAX_RECORDS][LINE_LEN],

				int end_of_branch[MAX_TORS]);
				void M_print_PDBQ_atom_resstr( FILE *logFile, 
								const char prefix[MAX_CHARS],
								int atom_num, // 0-origin 
								const char atomstuff[],
								const Real crd[MAX_ATOMS][SPACE],
								const Real vdW,
								const Real Elec,
								const Real charge,
								const char * suffix );
void M_print_PDBQ_atom_resnum( FILE *logFile, 
				const char prefix[MAX_CHARS],
				int atom_num, // 0-origin 
				const char atomstuff[],
				const int resnum,
				const Real crd[MAX_ATOMS][SPACE],
				const Real vdW,
				const Real Elec,
				const Real charge,
				const char * suffix //newline or empty
				);
#define print1000(file, x) pr(file,  ((fabs((x)) >= 0.0) && ((fabs(x)) <= 1000.)) ? "%+7.2f" : "%+11.2e" , (x));
void M_printEnergies( EnergyBreakdown *eb,
				const char *prefixString,
				int  ligand_is_inhibitor,
				Real emap_total,
				Real elec_total,
				Boole B_have_flexible_residues, 
				Unbound_Model ad4_unbound_model);
void M_print_rem( FILE *outFile,int Rank,int NumMem,int Run,Real ref_rms);
void M_update_binding_energy_breakdown( EnergyBreakdown * eb, Unbound_Model ad4_unbound_model );
void M_initialise_binding_energy_breakdown( EnergyBreakdown * eb,
				Real torsFreeEnergy, 
				Real unbound_internal_FE ,
				Unbound_Model ad4_unbound_model);
EnergyBreakdown M_calculateBindingEnergies(
				int                  natom,                     // input  number of atoms
				int                  ntor,                      // input  number of torsions
				Real                 unbound_internal_FE,       // input  pre-calculated internal energy of unbound state
				Real                 torsFreeEnergy,            // input  constant times number of freely-rotatable bonds
				Boole                B_have_flexible_residues,  // input  boolean whether we have flexible residues in protein

				// trilinterp
				const Real           tcoord[MAX_ATOMS][SPACE],  // input  coordinates of atoms to be trilinearly-interpolated
				CONST_FLOAT          charge[MAX_ATOMS],         // input  partial atomic charges
				CONST_FLOAT          abs_charge[MAX_ATOMS],     // input  absolute magnitude of partial charges
				CONST_INT            type[MAX_ATOMS],           // input  atom type of each atom
				MapType map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS], 
				GridMapSetInfo       *info,                     // input  info->lo[X],info->lo[Y],info->lo[Z],    minimum coordinates in x,y,z
				int                  B_outside,                 // input  boolean whether some atoms are outside grid box
				int                  ignore_inter[MAX_ATOMS],   // input  array of booleans, says to ignore computation intermolecular energies per atom
				Real                 elec[MAX_ATOMS],           // output if not NULL - electrostatic energies, atom by atom
				Real                 emap[MAX_ATOMS],           // output if not NULL - intermolecular energies
				Real                 *p_elec_total,             // output if not NULL - total electrostatic energy
				Real                 *p_emap_total,             // output if not NULL - total intermolecular energy

				// eintcal
				NonbondParam * const         nonbondlist,       // input  list of nonbonds
				const EnergyTables   *ptr_ad_energy_tables,     // input  pointer to AutoDock intermolecular, dielectric, solvation lookup tables
				const int            Nnb,                       // input  total number of nonbonds
				const Boole          B_calcIntElec,             // input  boolean whether we must calculate internal electrostatics
				const Boole          B_include_1_4_interactions,// input  boolean whether to include 1,4 interactions as non-bonds
				const Real           scale_1_4,                 // input  scaling factor for 1,4 interactions, if included
				const Real           qsp_abs_charge[MAX_ATOMS], // input  q-solvation parameters
				const Boole          B_use_non_bond_cutoff,     // input  boolean whether to use a nonbond distance cutoff
				Unbound_Model ad4_unbound_model,
				/**********************************
				// YTLIU_EDIT 2013.01.26
				 **********************************/
				Real &xb_empirical_vdw,
				Real &xb_empirical_es,
				Real &ad_vdw,
				Real &ad_es,
				Real &ad_desolv,
				// Real xb_vdw_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
				// Real xb_es_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
				// Real xb_desolv_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
				/*--------------------------------------------------*/
				/*acceleration: 2013.05.23 by ytliu@mail.shcnc.ac.cn*/
				/*--------------------------------------------------*/
				Real xb_vdw_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real xb_es_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real xb_desolv_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES],
				Boole halogen_found,
				Real xbempirical_recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
				int xbempirical_ligand_xbdonor[MAX_ATOMS][2],
				int xbempirical_receptor_acceptor_index[MAX_RECEPTOR_ATOMS]
				);
				int M_cluster_analysis( Real clus_rms_tol, 
								int cluster[MAX_RUNS][MAX_RUNS], 
								int num_in_clus[MAX_RUNS], 
								int isort[MAX_RUNS], 
								int nconf, 
								int natom, 
								int type[MAX_ATOMS],
								Real crd[MAX_RUNS][MAX_ATOMS][SPACE], 
								Real crdpdb[MAX_ATOMS][SPACE], 
								Real sml_center[SPACE], 
								Real clu_rms[MAX_RUNS][MAX_RUNS], 
								Boole B_symmetry_flag,
								Real ref_crds[MAX_ATOMS][SPACE],
								int ref_natoms,
								Real ref_rms[MAX_RUNS]);
Real M_getrms ( Real Crd[MAX_ATOMS][SPACE],Real CrdRef[MAX_ATOMS][SPACE], Boole B_symmetry_flag,int natom,int type[MAX_ATOMS] );
void M_sort_enrg( Real econf[MAX_RUNS],int isort[MAX_RUNS],int nconf );
int M_getpdbcrds( char *rms_ref_crds_FN,Real ref_crds[MAX_ATOMS][SPACE] );
void M_analysis( int   Nnb, 
				char  atomstuff[MAX_ATOMS][MAX_CHARS], 
				Real charge[MAX_ATOMS], 
				Real abs_charge[MAX_ATOMS], 
				Real qsp_abs_charge[MAX_ATOMS], 
				Boole B_calcIntElec,
				Real clus_rms_tol, 
				Real crdpdb[MAX_ATOMS][SPACE], 

				const EnergyTables *ptr_ad_energy_tables,

				Real  map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS], 
				Real  econf[MAX_RUNS], 
				int   irunmax, 
				int   natom, 
				NonbondParam *nonbondlist, 
				int   nconf, 
				int   ntor, 
				State hist[MAX_RUNS], 
				char  *smFileName, 
				Real  sml_center[SPACE],
				Boole B_symmetry_flag, 
				int   tlist[MAX_TORS][MAX_ATOMS], 
				int   type[MAX_ATOMS], 
				Real  vt[MAX_TORS][SPACE],
				char  *FN_rms_ref_crds,
				Real  torsFreeEnergy,
				Boole B_write_all_clusmem,
				int   ligand_is_inhibitor,
				int   outlev,
				int   ignore_inter[MAX_ATOMS],
				const Boole   B_include_1_4_interactions,
				const Real scale_1_4,
				const Real unbound_internal_FE,

				GridMapSetInfo *info,
				Boole B_use_non_bond_cutoff,
				Boole B_have_flexible_residues,
				Boole B_rms_atoms_ligand_only,
				Unbound_Model ad4_unbound_model,
				/**********************************
				// YTLIU_EDIT 2013.01.26
				 **********************************/
				Real &xb_empirical_vdw,
				Real &xb_empirical_es,
				Real &ad_vdw,
				Real &ad_es,
				Real &ad_desolv,
				// Real xb_vdw_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
				// Real xb_es_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
				// Real xb_desolv_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
				/*--------------------------------------------------*/
				/*acceleration: 2013.05.23 by ytliu@mail.shcnc.ac.cn*/
				/*--------------------------------------------------*/
				Real xb_vdw_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real xb_es_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				Real xb_desolv_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
				XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES],
				Boole halogen_found,
				Real xbempirical_recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
				int xbempirical_ligand_xbdonor[MAX_ATOMS][2],
				int xbempirical_receptor_acceptor_index[MAX_RECEPTOR_ATOMS]);
void M_printdate( FILE *fp, int flag );
int M_parse_dpf_line( char line[LINE_LEN] );
int M_lookupXBPMFATindex(char xbpmf_at[MAX_LEN_AUTOGRID_TYPE + 1]);
void M_print_molar(FILE* file, double x);
void M_read_parameter_library(char *FN_parameter_library,int outlev);
void return_current_time(char *timeBuffer);
void return_current_date(char *dateBuffer);
//this is a final job

void return_current_time(char *timeBuffer)
{
		time_t tn; /* tn = "time_now" */
		struct tm *ts;

		tn = time( &tn );

		ts = localtime( &tn );

		sprintf(timeBuffer, "%02d:%02d:%02d\0", ts->tm_hour, ts->tm_min, ts->tm_sec);

}
void return_current_date(char *dateBuffer)
{
		time_t tn; /* tn = "time_now" */
		struct tm *ts;

		tn = time( &tn );

		ts = localtime( &tn );

		sprintf(dateBuffer, "%04d-%02d-%02d\0", 1900+ts->tm_year, (ts->tm_mon + 1), ts->tm_mday );

}

void M_read_parameter_library(char *FN_parameter_library,int outlev)
{
		static ParameterEntry thisParameter;
		FILE *parameter_library_file;
		char parameter_library_line[LINE_LEN];
		int nfields;
		int param_keyword = -1;
		int int_hbond_type = 0;

		//    pr(logFile, "Using read_parameter_library() to try to open and read \"%s\".\n\n", FN_parameter_library);

		// Open and read the parameter library
		//
		if ((parameter_library_file = fopen(FN_parameter_library, "r")) == NULL) {
				fprintf(logFile,"Sorry, I can't find or open %s\n", FN_parameter_library);
				fprintf(stderr,"Sorry, I can't find or open %s\n", FN_parameter_library);
				slaveExit(-1);
		}

		// remember this filename for report_parameter_library()
		snprintf(parameter_library, sizeof parameter_library, "from file: \"%s\"", FN_parameter_library);
		while (fgets(parameter_library_line, sizeof(parameter_library_line), parameter_library_file) != NULL) {
				param_keyword = M_parse_param_line( parameter_library_line );
				if (debug > 0) {
						pr(logFile, "DEBUG: parameter_library_line = %sDEBUG: param_keyword          = %d\n", parameter_library_line, param_keyword);
				}

				switch (param_keyword) {
						case PAR_:
						case PAR_NULL:
						case PAR_COMMENT:
								break;

						case PAR_VDW:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_vdW);
								if (nfields < 1) {
										pr( logFile, "%s: WARNING:  Please supply a coefficient as a floating point number.\n\n", programname);
										continue; // skip any parameter_library_line without enough info
								}
								//                pr( logFile, "Free energy coefficient for the van der Waals term = \t%.4lf\n\n", AD4.coeff_vdW);
								break;

						case PAR_HBOND:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_hbond);
								if (nfields < 1) {
										pr( logFile, "%s: WARNING:  Please supply a coefficient as a floating point number.\n\n", programname);
										continue; // skip any parameter_library_line without enough info
								}
								//                pr( logFile, "Free energy coefficient for the H-bonding term     = \t%.4lf\n\n", AD4.coeff_hbond);
								break;

						case PAR_ESTAT:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_estat);
								if (nfields < 1) {
										pr( logFile, "%s: WARNING:  Please supply a coefficient as a floating point number.\n\n", programname);
										continue; // skip any parameter_library_line without enough info
								}
								//                pr( logFile, "Free energy coefficient for the electrostatic term = \t%.4lf\n\n", AD4.coeff_estat);
								break;

						case PAR_DESOLV:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_desolv);
								if (nfields < 1) {
										pr( logFile, "%s: WARNING:  Please supply a coefficient as a floating point number.\n\n", programname);
										continue; // skip any parameter_library_line without enough info
								}
								//                pr( logFile, "Free energy coefficient for the desolvation term   = \t%.4lf\n\n", AD4.coeff_desolv);
								break;

						case PAR_TORS:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_tors);
								if (nfields < 1) {
										pr( logFile, "%s: WARNING:  Please supply a coefficient as a floating point number.\n\n", programname);
										continue; // skip any parameter_library_line without enough info
								}
								//                pr( logFile, "Free energy coefficient for the torsional term     = \t%.4lf\n\n", AD4.coeff_tors);
								break;

						case PAR_UNBOUND:
								//                pr( logFile, "%s: WARNING: the unbound model cannot be specified in the parameter library file.\n\n", programname);
								//                pr( logFile, "Use the DPF parameter 'unbound_model' instead.\n");
								break;

						case PAR_ATOM_PAR:
								// Read in one line of atom parameters;
								// NB: scanf doesn't try to write missing fields
								nfields = sscanf(parameter_library_line, "%*s %s %lf %lf %lf %lf %lf %lf %d %d %d %d",
												thisParameter.autogrid_type,
												&thisParameter.Rij,
												&thisParameter.epsij,
												&thisParameter.vol,
												&thisParameter.solpar,
												&thisParameter.Rij_hb,
												&thisParameter.epsij_hb,
												&int_hbond_type,
												&thisParameter.rec_index,
												&thisParameter.map_index,
												&thisParameter.bond_index);
								if (nfields < 2) {
										continue; // skip any parameter_library_line without enough info
								}

								if (int_hbond_type == 0) {
										thisParameter.hbond = NON;
								} else if (int_hbond_type == 1) {
										thisParameter.hbond = DS;
								} else if (int_hbond_type == 2) {
										thisParameter.hbond = D1;
								} else if (int_hbond_type == 3) {
										thisParameter.hbond = AS;
								} else if (int_hbond_type == 4) {
										thisParameter.hbond = A1;
								} else if (int_hbond_type == 5) {
										thisParameter.hbond = A2;
								} else {
										thisParameter.hbond = NON;
								}

								thisParameter.epsij    *= AD4.coeff_vdW;
								thisParameter.epsij_hb *= AD4.coeff_hbond;

								M_apm_enter(thisParameter.autogrid_type, thisParameter);

								break;

						default:
								break;
				} // switch
		} // while there is another line of parameters to read in
}

void M_print_molar(FILE* file, double x) {
		// 1e-3  <= x < 1     mM millimolar
		// 1e-6  <= x < 1e-3  uM micromolar
		// 1e-9  <= x < 1e-6  nM nanomolar
		// 1e-12 <= x < 1e-9  pM picomolar
		// 1e-15 <= x < 1e-12 fM femtomolar
		// 1e-18 <= x < 1e-15 aM attomolar
		// 1e-21 <= x < 1e-18 zM zeptomolar
		// 1e-24 <= x < 1e-21 yM yottomolar
		//          x < 1e-24    sub-yottomolar
		if ((fabs((x)) > 1e-3) && ((fabs(x)) <= 1.)) {
				pr(file, "%7.2f mM (millimolar)", x*1e3);
		} else if ((fabs((x)) > 1e-6) && ((fabs(x)) <= 1e-3)) {
				pr(file, "%7.2f uM (micromolar)", x*1e6);
		} else if ((fabs((x)) > 1e-9) && ((fabs(x)) <= 1e-6)) {
				pr(file, "%7.2f nM (nanomolar)", x*1e9);
		} else if ((fabs((x)) > 1e-12) && ((fabs(x)) <= 1e-9)) {
				pr(file, "%7.2f pM (picomolar)", x*1e12);
		} else if ((fabs((x)) > 1e-15) && ((fabs(x)) <= 1e-12)) {
				pr(file, "%7.2f fM (femtomolar)", x*1e15);
		} else if ((fabs((x)) > 1e-18) && ((fabs(x)) <= 1e-15)) {
				pr(file, "%7.2f aM (attomolar)", x*1e18);
		} else if ((fabs((x)) > 1e-21) && ((fabs(x)) <= 1e-18)) {
				pr(file, "%7.2f zM (zeptomolar)", x*1e21);
		} else if ((fabs((x)) > 1e-24) && ((fabs(x)) <= 1e-21)) {
				pr(file, "%7.2f yM (yottomolar)", x*1e24);
		} else {
				pr(file, "%11.2e M (molar)", x);
		}
}

int M_lookupXBPMFATindex(char xbpmf_at[MAX_LEN_AUTOGRID_TYPE + 1])
{
		if(equal(xbpmf_at,"CF",2))
				return CF;
		else if(equal(xbpmf_at,"CP",2))
				return CP;
		else if(equal(xbpmf_at,"cF",2))
				return cF;
		else if(equal(xbpmf_at,"cP",2))
				return cP;
		else if(equal(xbpmf_at,"CO",2))
				return CO;
		else if(equal(xbpmf_at,"CN",2))
				return CN;
		else if(equal(xbpmf_at,"NC",2))
				return NC;
		else if(equal(xbpmf_at,"ND",2))
				return ND;
		else if(equal(xbpmf_at,"NA",2))
				return NA;
		else if(equal(xbpmf_at,"OC",2))
				return OC;
		else if(equal(xbpmf_at,"OA",2))
				return OA;
		else if(equal(xbpmf_at,"OD",2))
				return OD;
		else if(equal(xbpmf_at,"SA",2))
				return SA;
		else if(equal(xbpmf_at,"SD",2))
				return SD;
		else if(equal(xbpmf_at,"ME",2))
				return ME;
		else if(equal(xbpmf_at,"OW",2))
				return OW;
		else if(equal(xbpmf_at,"HH",2))
				return HH;
		else if(equal(xbpmf_at,"C3",2))
				return C3;
		else if(equal(xbpmf_at,"CW",2))
				return CW;
		else if(equal(xbpmf_at,"C0",2))
				return C0;
		else if(equal(xbpmf_at,"NP",2))
				return NP;
		else if(equal(xbpmf_at,"NR",2))
				return NR;
		else if(equal(xbpmf_at,"N0",2))
				return N0;
		else if(equal(xbpmf_at,"NS",2))
				return NS;
		else if(equal(xbpmf_at,"OE",2))
				return OE;
		else if(equal(xbpmf_at,"OS",2))
				return OS;
		else if(equal(xbpmf_at,"SO",2))
				return SO;
		else if(equal(xbpmf_at,"Cl",2) || equal(xbpmf_at,"CL",2))
				return Cl;
		else if(equal(xbpmf_at,"Br",2) || equal(xbpmf_at,"BR",2))
				return Br;
		else if(equal(xbpmf_at,"HL",2))
				return HL;
		else if(equal(xbpmf_at,"P",1))
				return P;
		else if(equal(xbpmf_at,"F",1))
				return F;
		else if(equal(xbpmf_at,"I",1))
				return I;
		else
				return XX;
}

int M_parse_dpf_line( char line[LINE_LEN] )
{
		int j, i, token = DPF_;               /* return -1 if nothing is recognized. */
		char c[LINE_LEN];

		const struct {
				char *lexeme;
				int tokenvalue;
		} tokentable[] = {{"ligand", DPF_MOVE},  
				{"fld", DPF_FLD}, 
				{"map", DPF_MAP}, 
				{"move", DPF_MOVE}, 
				{"about", DPF_ABOUT}, 
				{"tran0", DPF_TRAN0}, 
				{"quat0", DPF_QUAT0}, 
				{"ndihe", DPF_NDIHE}, 
				{"dihe0", DPF_DIHE0}, 
				{"torsdof", DPF_TORSDOF}, 
				{"tstep", DPF_TSTEP}, 
				{"qstep", DPF_QSTEP}, 
				{"dstep", DPF_DSTEP}, 
				{"trnrf", DPF_TRNRF}, 
				{"quarf", DPF_QUARF}, 
				{"dihrf", DPF_DIHRF}, 
				{"flex", DPF_FLEX}, 
				{"intnbp_coeffs", DPF_INTNBP_COEFFS}, 
				{"rt0", DPF_RT0}, 
				{"rtrf", DPF_RTRF}, 
				{"runs", DPF_RUNS}, 
				{"cycles", DPF_CYCLES}, 
				{"accs", DPF_ACCS}, 
				{"rejs", DPF_REJS}, 
				{"select", DPF_SELECT}, 
				{"outlev", DPF_OUTLEV}, 
				{"rmstol", DPF_RMSTOL}, 
				{"trjfrq", DPF_TRJFRQ}, 
				{"trjbeg", DPF_TRJBEG}, 
				{"trjend", DPF_TRJEND}, 
				{"trjout", DPF_TRJOUT}, 
				{"trjsel", DPF_TRJSEL}, 
				{"extnrg", DPF_EXTNRG}, 
				{"newcrd", DPF_NEWCRD}, 
				{"cluster", DPF_CLUSTER}, 
				{"write_all", DPF_CLUSALL}, 
				{"write_all_cluster_members", DPF_CLUSALL}, 
				{"charmap", DPF_CHARMAP}, 
				{"rmsnosym", DPF_RMSNOSYM}, 
				{"rmsref", DPF_RMSREF}, 
				{"watch", DPF_WATCH}, 
				{"linear_schedule", DPF_SCHEDLIN}, 
				{"schedule_linear", DPF_SCHEDLIN}, 
				{"linsched", DPF_SCHEDLIN}, 
				{"schedlin", DPF_SCHEDLIN}, 
				{"intelec", DPF_INTELEC}, 
				{"seed", DPF_SEED}, 
				{"e0max", DPF_E0MAX}, 
				{"simanneal", DPF_SIMANNEAL}, 
				{"hardtorcon", DPF_HARDTORCON}, 
				{"intnbp_r_eps", DPF_INTNBP_REQM_EPS}, 
				{"gausstorcon", DPF_GAUSSTORCON}, 
				{"barrier", DPF_BARRIER}, 
				{"showtorpen", DPF_SHOWTORPEN}, 
				{"ga_run", DPF_GALS}, 
				{"gals_run", DPF_GALS}, 
				{"do_gals", DPF_GALS}, 
				{"set_ga", DPF_SET_GA}, 
				{"set_sw1", DPF_SET_SW1}, 
				{"set_psw1", DPF_SET_PSW1}, 
				{"analysis", DPF_ANALYSIS}, 
				{"ga_pop_size", GA_pop_size}, 
				{"ga_num_generations", GA_num_generations}, 
				{"ga_num_evals", GA_num_evals}, 
				{"ga_window_size", GA_window_size}, 
				{"ga_low", GA_low}, 
				{"ga_high", GA_high}, 
				{"ga_elitism", GA_elitism}, 
				{"ga_mutation_rate", GA_mutation_rate}, 
				{"ga_crossover_rate", GA_crossover_rate}, 
				{"ga_cauchy_alpha", GA_Cauchy_alpha}, 
				{"ga_cauchy_beta", GA_Cauchy_beta}, 
				{"sw_max_its", SW_max_its}, 
				{"sw_max_succ", SW_max_succ}, 
				{"sw_max_fail", SW_max_fail}, 
				{"sw_rho", SW_rho}, 
				{"sw_lb_rho", SW_lb_rho}, 
				{"psw_trans_scale", PSW_TRANS_SCALE}, 
				{"psw_rot_scale", PSW_ROT_SCALE}, 
				{"psw_tors_scale", PSW_TORS_SCALE}, 
				{"do_local_only", DPF_LS}, 
				{"ls_run", DPF_LS}, 
				{"do_global_only", DPF_GS}, 
				{"ga_only_run", DPF_GS}, 
				{"ls_search_freq", LS_search_freq}, 
				{"bin_energies_by_rmsd", DPF_INVESTIGATE}, 
				{"investigate", DPF_INVESTIGATE}, 
				{"ligand_is_not_inhibitor", DPF_LIG_NOT_INHIB}, 
				{"template", DPF_TEMPL_ENERGY}, 
				{"template_energy_file", DPF_TEMPL_ENERGY}, 
				{"include_1_4_interactions", DPF_INCLUDE_1_4_INTERACTIONS}, 
				{"parameter_library", DPF_PARAMETER_LIBRARY}, 
				{"parameter_file", DPF_PARAMETER_LIBRARY} 
				, {"receptor_types", DPF_RECEPTOR_TYPES}  
				, {"ligand_types", DPF_LIGAND_TYPES}      
				, {"unbound", DPF_UNBOUND}      
				, {"epdb", DPF_EPDB}      
				, {"ga_termination_criterion", DPF_TERMINATION}      
				, {"ga_termination", DPF_TERMINATION}      
				, {"ga_crossover_mode", GA_CROSSOVER_MODE}      
				, {"output_pop_file", DPF_POPFILE}      
				, {"set_pattern", DPF_SET_PATTERN}      
				, {"compute_unbound_extended", DPF_COMPUTE_UNBOUND_EXTENDED} 
				, {"set_unbound_energy", DPF_UNBOUND}      
				, {"flexible_residues", DPF_FLEXRES} 
				, {"flexres", DPF_FLEXRES} 
				, {"elecmap", DPF_ELECMAP} 
				, {"desolvmap", DPF_DESOLVMAP} 
				, {"unbound_intnbp_coeffs", DPF_UNBOUND_INTNBP_COEFFS} 
				, {"rmsatoms", DPF_RMSATOMS} 
				, {"confsampler", DPF_CONFSAMPLER} 
				, {"reorient", DPF_REORIENT} 
				, {"axisangle0", DPF_AXISANGLE0} 
				, {"quaternion0", DPF_QUATERNION0} 
				, {"copyright", DPF_COPYRIGHT} 
				, {"warranty", DPF_WARRANTY} 
				, {"autodock_parameter_version", DPF_PARAMETER_VERSION} 
				, {"unbound_model", DPF_UNBOUND_MODEL} 
				, {"unbound_energy", DPF_UNBOUND} 
				, {"ga_proportional_selection", GA_PROPORTIONAL_SELECTION}
				, {"ga_linear_ranking_selection", GA_LINEAR_RANKING_SELECTION}      
				, {"ga_tournament_selection", GA_TOURNAMENT_SELECTION}      
				, {"ga_boltzman_selection", GA_BOLTZMAN_SELECTION}
				, {"pso_c1", PSO_c1}
				, {"pso_c2", PSO_c2}
				, {"pso_w", PSO_w}
				, {"pso_w_start", PSO_w_start}
				, {"pso_w_end", PSO_w_end}
				, {"pso_mc", PSO_mc}
				, {"pso_k", PSO_k}
				, {"pso_swarm_moves", PSO_swarm_moves}
				, {"pso_ss_factor", PSO_swarm_size_factor}
				, {"pso_n_exec", PSO_n_exec}
				, {"do_cpso", DPF_PSO_CONSTRICTION}
				, {"do_spso_vw", DPF_PSO_STANDARD_VW}
				, {"do_spso_cw", DPF_PSO_STANDARD_CW}
				, {"do_ssmpso", DPF_PSO_SSM}
				, {"do_pso", DPF_PARSWARMOPT}

				/******************************
				// YTLIU_EDIT 2013.01.16
				 ******************************/
				//	      , {"xbpmf_ligand_types", DPF_XBPMF_LIGAND_TYPES}
				, {"xbpmf_ligand", DPF_XBPMF_LIGAND}
				, {"xbpmf_receptor", DPF_XBPMF_RECEPTOR}
				, {"xbpmf_1d", DPF_XBPMF_1D}
				, {"xbpmf_hb", DPF_XBPMF_HB}
				, {"xbpmf_xb", DPF_XBPMF_XB}
				/******************************
				// YTLIU_EDIT 2013.01.25
				 ******************************/
				, {"xbempirical_receptor", DPF_XBEMPIRICAL_RECEPTOR}
				, {"xbempirical_parm", DPF_XBEMPIRICAL_PARM}
				, {"xbvdwprofile", DPF_XBVDWPROFILE}
				, {"xbesprofile", DPF_XBESPROFILE}
				, {"xbdesolvprofile", DPF_XBDESOLVPROFILE}

#if defined(USING_COLINY)
				, {"coliny", DPF_COLINY}  
#endif
				, {"//END", DPF_NULL}
		};

		c[0] = '\0';
		for (j=0; line[j]!='\0' && !isspace(line[j]); j++) {
				/*  Ignore case */
				c[j] = (char)tolower((int)line[j]);
				/*(void)fprintf(stderr,"%c",c[j]);*/
		}
		if ((c[0]=='\n') || (c[0]=='\0')) {
				token = DPF_NULL;
		} else if (c[0]=='#') {
				token = DPF_COMMENT;
		} else for (i=0;  (tokentable[i].tokenvalue!=DPF_NULL) ;  i++) {
				if (strncasecmp(tokentable[i].lexeme, c, j) == 0) {
						token = tokentable[i].tokenvalue;
						break;
				}
		}
		return(token);
}

void M_timesys( Clock duration,struct tms  *start,struct tms  *end)
{
		fprintf( logFile, "Real= %.2f,  CPU= %.2f,  System= %.2f\n",     (Real)duration * idct,
						(Real)(end->tms_utime  - start->tms_utime) * idct,
						(Real)(end->tms_stime  - start->tms_stime) * idct );
}

void M_timesyshms( Clock     duration, struct tms  *start, struct tms  *end)
{
		int   h, m;
		Real t, T, s;
		const Real min = 60., hrs = 3600.;

		(void)fprintf( logFile, "Real= " );
		t = (Real)duration * idct;
		h = (int)(t/hrs);
		T = t - ((Real)h)*hrs;
		m = (int)(T/min);
		s = T - ((Real)m)*min;
		if (h == 0) {
				if (m == 0)
						(void)fprintf(logFile,       "%.2lfs",       (double)s );
				else
						(void)fprintf(logFile,    "%dm %05.2lfs",    m, (double)s );
		} else {
				(void)fprintf(logFile, "%dh %02dm %05.2lfs", h, m, (double)s );
		}

		(void)fprintf( logFile, ",  CPU= " );
		t =      (Real)((end->tms_utime  - start->tms_utime) * idct);
		h = (int)(t/hrs);
		T = t - ((Real)h)*hrs;
		m = (int)(T/min);
		s = T - ((Real)m)*min;
		if (h == 0) {
				if (m == 0)
						(void)fprintf(logFile,       "%.2lfs",       (double)s );
				else
						(void)fprintf(logFile,    "%dm %05.2lfs",    m, (double)s );
		} else {
				(void)fprintf(logFile, "%dh %02dm %05.2lfs", h, m, (double)s );
		}

		(void)fprintf( logFile, ",  System= " );
		t = (Real)((end->tms_stime  - start->tms_stime) * idct);
		h = (int)(t/hrs);
		T = t - ((Real)h)*hrs;
		m = (int)(T/min);
		s = T - ((Real)m)*min;
		if (h == 0) {
				if (m == 0)
						(void)fprintf(logFile,       "%.2lfs",       (double)s );
				else
						(void)fprintf(logFile,    "%dm %05.2lfs",    m, (double)s );
		} else {
				(void)fprintf(logFile, "%dh %02dm %05.2lfs", h, m, (double)s );
		}

		(void)fprintf( logFile, "\n" );
}

void M_swap ( int v[],int i,int j )
{
		int temp;

#ifdef DEBUG
		int k;
		char array[101];
		strncpy( array, "----------------------------------------------------------------------------------------------------", (size_t)100 );
		array[100] = '\0';
		for (k=i+1; k<j; k++) array[k]=' ';
		array[i] = '<';
		array[j] = '>';
		fprintf( logFile, "%s", array );
		fprintf( logFile, " swapping %d & %d.\n", i, j);
#endif /* DEBUG */

		temp = v[i];
		v[i] = v[j];
		v[j] = temp;
}

M_stack M_stack_create(int maxsize) 
{
		M_stack s;
		s = (integer_stack_t *) malloc( sizeof(integer_stack_t) );
		if (s == NULL) return s;
		s->base = (int *) calloc( maxsize, sizeof(int) );
		s->size = maxsize;
		s->top = 0;
		s->trace = NULL;
		return s;
}

int M_stack_pop(M_stack s)
{
		(s->top)--;
		if (s->top < 0) {
				fprintf(stderr, "Stack empty pop\n");

				if (s->trace != NULL) fprintf(s->trace, "Stack empty pop\n");
				s->top = 0;
				return 0;
		}
		if (s->trace != NULL) fprintf(s->trace, "Stack(%d/%d) pop %d\n",
						s->top, s->size, s->base[s->top]);
		return s->base[s->top];
}

void M_stack_push(M_stack s, int i)
{
		if (s->trace != NULL) fprintf(s->trace, "Stack(%d/%d) push %d\n",s->top, s->size,i);
		if (s->top > s->size) {
				fprintf(stderr, "Stack full (%d) push\n", s->size);
				if (s->trace != NULL) fprintf(s->trace, "Stack full push\n");
				s->top = s->size - 1;
		}
		s->base[s->top] = i;
		s->top++;
		return;
}

int M_stack_depth(M_stack s)
{
		if (s->trace != NULL) fprintf(s->trace, "Stack depth %d/%d\n",s->top, s->size);
		return s->top;
}

int M_stack_size(M_stack s)
{
		return s->size;
}

void M_stack_trace(M_stack s, FILE *f)
{
		if (f==NULL && s->trace != NULL) fprintf(s->trace, "Stack trace off\n");
		s->trace = f;
		if (f != NULL) fprintf(s->trace, "Stack (%d/%d) trace on\n", 
						s->top, s->size);
		return;
}

int M_stack_test(void)
{
		M_stack s;
		s = M_stack_create(10);
		M_stack_push(s, 3);
		M_stack_push(s, 1);
		M_stack_push(s, 4);
		M_stack_push(s, 1);
		M_stack_push(s, 5);
		printf("Depth of stack = %d\n", M_stack_depth(s));
		printf("Pop stack gives %d\n", M_stack_pop(s));
		printf("Pop stack gives %d\n", M_stack_pop(s));
		printf("Pop stack gives %d\n", M_stack_pop(s));
		printf("Pop stack gives %d\n", M_stack_pop(s));
		printf("Pop stack gives %d\n", M_stack_pop(s));
		printf("Pop stack gives %d\n", M_stack_pop(s));
		return 0;
}

void M_usage( FILE * file, char * programname )
{
		char    AutoDockHelp[] = \
								 "\t-p parameter_filename\n" \
								 "\t\t\t-l log_filename\n" \
								 "\t\t\t-x (Halogen bonding PMF scoring function)\n" \
								 "\t\t\t-X (Halogen bonding empirical scoring function)\n" \
								 "\t\t\t-k (Keep original residue numbers)\n" \
								 "\t\t\t-i (Ignore header-checking)\n" \
								 "\t\t\t-t (Parse the PDBQT file to check torsions, then stop.)\n" \
								 "\t\t\t-d (Increment debug level)\n" \
								 "\t\t\t-C (Print copyright notice)\n" \
								 "\t\t\t--version (Print D3DOCKxb version)\n" \
								 "\t\t\t--help (Display this message)\n\n";
		fprintf(file, "usage: %s %s\n", programname, AutoDockHelp);
}

int M_setflags( int argc, char ** argv, const char * version_num)
{
		int argindex;
		/*----------------------------------------------------------------------------*/
		/* Initialize                                                                 */
		/*----------------------------------------------------------------------------*/
		argindex = 1;
		programname = argv[0];
		parFile = stdin;
		logFile = stdout;
		char logFileName[PATH_MAX+2];
		static char * p_logFileName = "stdout"; // change with -l <NAME> or defaults
		// to parFile name with last 3 chars changed from "dpf" to "dlg"
		/*
		 * see autoglobal.h for initialization of debug, keepresnum and logicals...
		 */
		if (argc==1) { //No arguments provided
				M_usage(stdout, "D3DOCKxb");
				slaveExit(0);
		}
		/*----------------------------------------------------------------------------*/
		/* Loop over arguments                                                        */
		/*----------------------------------------------------------------------------*/
		while((argc > 1) && (argv[1][0] == '-')){
				if (argv[1][1] == '-') argv[1]++;

				switch(argv[1][1]){
#ifdef FOO
						case 'n':
								ncount = atoi(argv[2]);
								argv++;
								argc--;
								argindex++;
								break;
#endif
								/**************************
								//YTLIU_EDIT 2012.12.30
								 **************************/
						case 'x':
								xbpmf_scoring = TRUE;
								break;
						case 'X':
								xb_empirical_scoring = TRUE;
								break;
						case 'd':
								debug++;
								break;
						case 'u':
						case 'h':
								M_usage(stdout, "D3DOCKxb");
								slaveExit(0);
								break;
						case 'i':
								ignore_errors = TRUE;
								break;
						case 'k':
								keepresnum--;
								break;
						case 'C':
								//show copyright
								M_show_copyright(stdout);
								M_show_warranty(stdout);
								slaveExit(0);
								break;
						case 'c':
								//command_mode removed with 4.1 release spring 2009, mp + rh
								fprintf(stderr, "\n%s: command mode is not supported in this version of D3DOCKxb\n", programname );
								break;
						case 'l':
								p_logFileName = argv[2];
								argv++;
								argc--;
								argindex++;
								break;
						case 's':
								if ( (stateFile = fopen(argv[2], "w")) == NULL ) 
								{
#ifdef DEBUG
										fprintf(stderr, "\n State file name = %s\n", argv[2]); 
#endif /* DEBUG */
										fprintf(stderr, "\n%s: can't create state file %s\n", programname, argv[2]);
										fprintf(stderr, "\n%s: Unsuccessful Completion.\n\n", programname);
										return(-1);
								}
								else
								{
										fprintf(stateFile, "<?xml version=\"1.0\" ?>\n");
										fprintf(stateFile, "<D3DOCKxb>\n");
										fprintf(stateFile, "\t<version>%s</version>\n", version_num);
										fprintf(stateFile, "\t<autogrid_version>%s</autogrid_version>\n", version_num);
										fprintf(stateFile, "\t<output_xml_version>%5.2f</output_xml_version>\n", OUTPUT_XML_VERSION);
										write_stateFile = TRUE;
								}
								argv++;
								argc--;
								argindex++;
								break;    
						case 'p':
								snprintf(dock_param_fn, PATH_MAX -1, "%s", argv[2] );
								if ( strindex( dock_param_fn, ".dpf") != (int) strlen(dock_param_fn) - 4)
								{
										fprintf(stderr, "\n D3DOCKxb needs the extension of the docking parameter file to be \".dpf\"");
										fprintf(stderr, "\n%s: Unsuccessful Completion.\n\n", programname);
										return(-1);
								}

								if ( (parFile = fopen(dock_param_fn, "r")) == NULL ) 
								{
#ifdef DEBUG
										fprintf(stderr, "\n Parameter file name = %s\n", dock_param_fn);
#endif /* DEBUG */
										fprintf(stderr, "\n%s: can't find or open parameter file %s\n", programname, dock_param_fn);
										fprintf(stderr, "\n%s: Unsuccessful Completion.\n\n", programname);
										return(-1);
								}
								argv++;
								argc--;
								argindex++;
								break;
						case 't':
								parse_tors_mode = TRUE;
								break;
						case 'v':
								fprintf(stdout, "D3DOCKxb %-8s\n", version_num);
								fprintf(stdout, " Copyright (C) 2009 The Scripps Research Institute.\n");
								fprintf(stdout, " License GPLv2+: GNU GPL version 2 or later <http://gnu.org/licenses/gpl.html>\n");
								fprintf(stdout, " This is free software: you are free to change and redistribute it.\n");
								fprintf(stdout, " There is NO WARRANTY, to the extent permitted by law.\n");
								slaveExit(0);
								break;
						default:
								fprintf(stderr, "%s: unknown switch \"-%c\".  \n", programname, argv[1][1]);
								M_usage(stderr, programname);
								return(-1);
								/* break; */
				}
				argindex++;
				argc--;
				argv++;
		}
		// set docking log file name from parameter file name if
		// a "-p <DPF>" appeared but no "-l <DLG>" appeared

		if ( parFile != stdin  && 0==strcmp(p_logFileName, "stdout")) {
				strncpy(logFileName, dock_param_fn, strlen(dock_param_fn)-4);
				logFileName[strlen(dock_param_fn)] = '\0';
				strcat(logFileName, ".dlg");
		}
		else snprintf(logFileName, sizeof logFileName, "%s", p_logFileName);

		if ( (logFile = fopen(logFileName, "w")) == NULL ) {
#ifdef DEBUG
				fprintf(stderr, "\n Log file name = %s\n", logFileName); 
#endif /* DEBUG */
				fprintf(stderr, "\n%s: can't create log file %s\n", programname, logFileName);
				fprintf(stderr, "\n%s: Unsuccessful Completion.\n\n", programname);
				slaveExit(-1);
		}
		setlinebuf(logFile); // to ensure output even if crash
		return(argindex);
}

void M_banner()
{
		(void) fprintf(logFile,"\n");
		(void) fprintf(logFile,"     #******************************************************************************#\n");
		(void) fprintf(logFile,"     #            33                                                                #\n");
		(void) fprintf(logFile,"     #           3  3                                                               #\n");
		(void) fprintf(logFile,"     #             3                                                                #\n");
		(void) fprintf(logFile,"     #   DDDDDD  3  3   DDDDDD        OOO          CCCCC   KK   KK                  #\n");
		(void) fprintf(logFile,"     #  DD    DD  33   DD    DD     OO   OO      CC    CC  KK  KK                   #\n");
		(void) fprintf(logFile,"     #  DD     DD      DD     DD   OO     OO    CC         KK KK                    #\n");
		(void) fprintf(logFile,"     #  DD     DD      DD     DD  OOO     OOO  CCC         KKKK                     #\n");
		(void) fprintf(logFile,"     #  DD     DD      DD     DD   OO     OO    CC         KK KK                    #\n");
		(void) fprintf(logFile,"     #  DD    DD       DD    DD     OO   OO      CC    CC  KK  KK  xx   xx  bb      #\n");
		(void) fprintf(logFile,"     #   DDDDDD         DDDDDD        OOO          CCCCC   KK   KK  xx xx   bb      #\n");
		(void) fprintf(logFile,"     #                                                               xxx    bbbbb   #\n");
		(void) fprintf(logFile,"     #                                                              xx xx   bb  bb  #\n");
		(void) fprintf(logFile,"     #                                                             xx   xx  bbbbb   #\n");
		(void) fprintf(logFile,"     #******************************************************************************#\n");
		(void) fprintf(logFile,"\n\n\n");
		(void) fprintf(logFile,"                        #****************************************#\n");
		(void) fprintf(logFile,"                        #             D3DOCKxb 4.2.3             #\n");
		(void) fprintf(logFile,"                        #                                        #\n");
		(void) fprintf(logFile,"                        #            Yingtao Liu, DDDC           #\n");
		(void) fprintf(logFile,"                        #           Weiliang Zhu, DDDC           #\n");
		(void) fprintf(logFile,"                        #                                        #\n");
		(void) fprintf(logFile,"                        #            (C) 2013-, DDDC             #\n");
		(void) fprintf(logFile,"                        #  Shanghai Institute of Materia Medica  #\n");
		(void) fprintf(logFile,"                        #****************************************#\n");
		(void) fprintf(logFile,"\n\n\n");
		(void) fprintf(logFile,"                        #****************************************#\n");
		(void) fprintf(logFile,"                        #     Calculation of Halogen-Bonding     #\n");
		(void) fprintf(logFile,"                        #    Potential of Mean Force(XBPMF) &    #\n");
		(void) fprintf(logFile,"                        #  Integration of Traditional AutoDock   #\n");
		(void) fprintf(logFile,"                        #               for D3DOCKxb             #\n");
		(void) fprintf(logFile,"                        # For help, email ytliu@mail.shcnc.ac.cn #\n");
		(void) fprintf(logFile,"                        #****************************************#\n");
		(void) fprintf(logFile,"\n\n\n");
}

void M_show_copyright( FILE *fp )
{

		(void) fprintf( fp, "GNU GENERAL PUBLIC LICENSE\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "Version 2, June 1991\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "Copyright (C) 1989, 1991 Free Software Foundation, Inc. 51 Franklin\n");
		(void) fprintf( fp, "Street, Fifth Floor, Boston, MA  02110-1301, USA\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "Everyone is permitted to copy and distribute verbatim copies of this\n");
		(void) fprintf( fp, "license document, but changing it is not allowed.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "                       Preamble\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "The licenses for most software are designed to take away your freedom to\n");
		(void) fprintf( fp, "share and change it. By contrast, the GNU General Public License is\n");
		(void) fprintf( fp, "intended to guarantee your freedom to share and change free software--to\n");
		(void) fprintf( fp, "make sure the software is free for all its users. This General Public\n");
		(void) fprintf( fp, "License applies to most of the Free Software Foundation's software and\n");
		(void) fprintf( fp, "to any other program whose authors commit to using it. (Some other Free\n");
		(void) fprintf( fp, "Software Foundation software is covered by the GNU Lesser General Public\n");
		(void) fprintf( fp, "License instead.) You can apply it to your programs, too.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "When we speak of free software, we are referring to freedom, not price.\n");
		(void) fprintf( fp, "Our General Public Licenses are designed to make sure that you have the\n");
		(void) fprintf( fp, "freedom to distribute copies of free software (and charge for this\n");
		(void) fprintf( fp, "service if you wish), that you receive source code or can get it if you\n");
		(void) fprintf( fp, "want it, that you can change the software or use pieces of it in new\n");
		(void) fprintf( fp, "free programs; and that you know you can do these things.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "To protect your rights, we need to make restrictions that forbid anyone\n");
		(void) fprintf( fp, "to deny you these rights or to ask you to surrender the rights. These\n");
		(void) fprintf( fp, "restrictions translate to certain responsibilities for you if you\n");
		(void) fprintf( fp, "distribute copies of the software, or if you modify it.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "For example, if you distribute copies of such a program, whether gratis\n");
		(void) fprintf( fp, "or for a fee, you must give the recipients all the rights that you have.\n");
		(void) fprintf( fp, "You must make sure that they, too, receive or can get the source code.\n");
		(void) fprintf( fp, "And you must show them these terms so they know their rights.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "We protect your rights with two steps: (1) copyright the software, and\n");
		(void) fprintf( fp, "(2) offer you this license which gives you legal permission to copy,\n");
		(void) fprintf( fp, "distribute and/or modify the software.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "Also, for each author's protection and ours, we want to make certain\n");
		(void) fprintf( fp, "that everyone understands that there is no warranty for this free\n");
		(void) fprintf( fp, "software. If the software is modified by someone else and passed on, we\n");
		(void) fprintf( fp, "want its recipients to know that what they have is not the original, so\n");
		(void) fprintf( fp, "that any problems introduced by others will not reflect on the original\n");
		(void) fprintf( fp, "authors' reputations.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "Finally, any free program is threatened constantly by software patents.\n");
		(void) fprintf( fp, "We wish to avoid the danger that redistributors of a free program will\n");
		(void) fprintf( fp, "individually obtain patent licenses, in effect making the program\n");
		(void) fprintf( fp, "proprietary. To prevent this, we have made it clear that any patent must\n");
		(void) fprintf( fp, "be licensed for everyone's free use or not licensed at all.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "The precise terms and conditions for copying, distribution and\n");
		(void) fprintf( fp, "modification follow.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "0. This License applies to any program or other work which contains a\n");
		(void) fprintf( fp, "notice placed by the copyright holder saying it may be distributed under\n");
		(void) fprintf( fp, "the terms of this General Public License. The \"Program\", below, refers\n");
		(void) fprintf( fp, "to any such program or work, and a \"work based on the Program\" means\n");
		(void) fprintf( fp, "either the Program or any derivative work under copyright law: that is\n");
		(void) fprintf( fp, "to say, a work containing the Program or a portion of it, either\n");
		(void) fprintf( fp, "verbatim or with modifications and/or translated into another language.\n");
		(void) fprintf( fp, "(Hereinafter, translation is included without limitation in the term\n");
		(void) fprintf( fp, "\"modification\".) Each licensee is addressed as \"you\".\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "Activities other than copying, distribution and modification are not\n");
		(void) fprintf( fp, "covered by this License; they are outside its scope. The act of running\n");
		(void) fprintf( fp, "the Program is not restricted, and the output from the Program is\n");
		(void) fprintf( fp, "covered only if its contents constitute a work based on the Program\n");
		(void) fprintf( fp, "(independent of having been made by running the Program). Whether that\n");
		(void) fprintf( fp, "is true depends on what the Program does.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "1. You may copy and distribute verbatim copies of the Program's source\n");
		(void) fprintf( fp, "code as you receive it, in any medium, provided that you conspicuously\n");
		(void) fprintf( fp, "and appropriately publish on each copy an appropriate copyright notice\n");
		(void) fprintf( fp, "and disclaimer of warranty; keep intact all the notices that refer to\n");
		(void) fprintf( fp, "this License and to the absence of any warranty; and give any other\n");
		(void) fprintf( fp, "recipients of the Program a copy of this License along with the Program.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "You may charge a fee for the physical act of transferring a copy, and\n");
		(void) fprintf( fp, "you may at your option offer warranty protection in exchange for a fee.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "2. You may modify your copy or copies of the Program or any portion of\n");
		(void) fprintf( fp, "it, thus forming a work based on the Program, and copy and distribute\n");
		(void) fprintf( fp, "such modifications or work under the terms of Section 1 above, provided\n");
		(void) fprintf( fp, "that you also meet all of these conditions:\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "a) You must cause the modified files to carry prominent notices stating\n");
		(void) fprintf( fp, "that you changed the files and the date of any change.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "b) You must cause any work that you distribute or publish, that in whole\n");
		(void) fprintf( fp, "or in part contains or is derived from the Program or any part thereof,\n");
		(void) fprintf( fp, "to be licensed as a whole at no charge to all third parties under the\n");
		(void) fprintf( fp, "terms of this License.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "c) If the modified program normally reads commands interactively\n");
		(void) fprintf( fp, "when run, you must cause it, when started running for such\n");
		(void) fprintf( fp, "interactive use in the most ordinary way, to print or display an\n");
		(void) fprintf( fp, "announcement including an appropriate copyright notice and a notice that\n");
		(void) fprintf( fp, "there is no warranty (or else, saying that you provide a warranty) and\n");
		(void) fprintf( fp, "that users may redistribute the program under these conditions, and\n");
		(void) fprintf( fp, "telling the user how to view a copy of this License. (Exception: if the\n");
		(void) fprintf( fp, "Program itself is interactive but does not normally print such an\n");
		(void) fprintf( fp, "announcement, your work based on the Program is not required to print an\n");
		(void) fprintf( fp, "announcement.)\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "These requirements apply to the modified work as a whole.\n");
		(void) fprintf( fp, "If identifiable sections of that work are not derived from the Program,\n");
		(void) fprintf( fp, "and can be reasonably considered independent and separate works in\n");
		(void) fprintf( fp, "themselves, then this License, and its terms, do not apply to those\n");
		(void) fprintf( fp, "sections when you distribute them as separate works. But when you\n");
		(void) fprintf( fp, "distribute the same sections as part of a whole which is a work based on\n");
		(void) fprintf( fp, "the Program, the distribution of the whole must be on the terms of this\n");
		(void) fprintf( fp, "License, whose permissions for other licensees extend to the entire\n");
		(void) fprintf( fp, "whole, and thus to each and every part regardless of who wrote it.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "Thus, it is not the intent of this section to claim rights or contest\n");
		(void) fprintf( fp, "your rights to work written entirely by you; rather, the intent is to\n");
		(void) fprintf( fp, "exercise the right to control the distribution of derivative or\n");
		(void) fprintf( fp, "collective works based on the Program.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "In addition, mere aggregation of another work not based on the Program\n");
		(void) fprintf( fp, "with the Program (or with a work based on the Program) on a volume of a\n");
		(void) fprintf( fp, "storage or distribution medium does not bring the other work under the\n");
		(void) fprintf( fp, "scope of this License.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "3. You may copy and distribute the Program (or a work based on it, under\n");
		(void) fprintf( fp, "Section 2) in object code or executable form under the terms of Sections\n");
		(void) fprintf( fp, "1 and 2 above provided that you also do one of the following:\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "a) Accompany it with the complete corresponding machine-readable source\n");
		(void) fprintf( fp, "code, which must be distributed under the terms of Sections 1 and 2\n");
		(void) fprintf( fp, "above on a medium customarily used for software interchange; or,\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "b) above on a medium customarily used for software interchange; or, b)\n");
		(void) fprintf( fp, "Accompany it with a written offer, valid for at least three years, to\n");
		(void) fprintf( fp, "give any third party, for a charge no more than your cost of physically\n");
		(void) fprintf( fp, "performing source distribution, a complete machine-readable copy of the\n");
		(void) fprintf( fp, "corresponding source code, to be distributed under the terms of Sections\n");
		(void) fprintf( fp, "1 and 2 above on a medium customarily used for software interchange; or,\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "c) Accompany it with the information you received as to the offer to\n");
		(void) fprintf( fp, "distribute corresponding source code. (This alternative is allowed only\n");
		(void) fprintf( fp, "for noncommercial distribution and only if you received the program in\n");
		(void) fprintf( fp, "object code or executable form with such an offer, in accord with\n");
		(void) fprintf( fp, "Subsection b above.)\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "The source code for a work means the preferred form of the work\n");
		(void) fprintf( fp, "for making modifications to it. For an executable work, complete\n");
		(void) fprintf( fp, "source code means all the source code for all modules it contains,\n");
		(void) fprintf( fp, "plus any associated interface definition files, plus the scripts\n");
		(void) fprintf( fp, "used to control compilation and installation of the executable.\n");
		(void) fprintf( fp, "However, as a special exception, the source code distributed need not\n");
		(void) fprintf( fp, "include anything that is normally distributed (in either source or\n");
		(void) fprintf( fp, "binary form) with the major components (compiler, kernel, and so on) of\n");
		(void) fprintf( fp, "the operating system on which the executable runs, unless that component\n");
		(void) fprintf( fp, "itself accompanies the executable.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "If distribution of executable or object code is made by offering access\n");
		(void) fprintf( fp, "to copy from a designated place, then offering equivalent access to copy\n");
		(void) fprintf( fp, "the source code from the same place counts as distribution of the source\n");
		(void) fprintf( fp, "code, even though third parties are not compelled to copy the source\n");
		(void) fprintf( fp, "along with the object code.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "4. You may not copy, modify, sublicense, or distribute the Program\n");
		(void) fprintf( fp, "except as expressly provided under this License. Any attempt otherwise\n");
		(void) fprintf( fp, "to copy, modify, sublicense or distribute the Program is void, and will\n");
		(void) fprintf( fp, "automatically terminate your rights under this License. However, parties\n");
		(void) fprintf( fp, "who have received copies, or rights, from you under this License will\n");
		(void) fprintf( fp, "not have their licenses terminated so long as such parties remain in\n");
		(void) fprintf( fp, "full compliance.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "5. You are not required to accept this License, since you have not\n");
		(void) fprintf( fp, "signed it. However, nothing else grants you permission to modify or\n");
		(void) fprintf( fp, "distribute the Program or its derivative works. These actions are\n");
		(void) fprintf( fp, "prohibited by law if you do not accept this License. Therefore, by\n");
		(void) fprintf( fp, "modifying or distributing the Program (or any work based on the\n");
		(void) fprintf( fp, "Program), you indicate your acceptance of this License to do so, and all\n");
		(void) fprintf( fp, "its terms and conditions for copying, distributing or modifying the\n");
		(void) fprintf( fp, "Program or works based on it.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "6. Each time you redistribute the Program (or any work based on the\n");
		(void) fprintf( fp, "Program), the recipient automatically receives a license from the\n");
		(void) fprintf( fp, "original licensor to copy, distribute or modify the Program subject to\n");
		(void) fprintf( fp, "these terms and conditions. You may not impose any further restrictions\n");
		(void) fprintf( fp, "on the recipients' exercise of the rights granted herein. You are not\n");
		(void) fprintf( fp, "responsible for enforcing compliance by third parties to this License.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "7. If, as a consequence of a court judgment or allegation of patent\n");
		(void) fprintf( fp, "infringement or for any other reason (not limited to patent issues),\n");
		(void) fprintf( fp, "conditions are imposed on you (whether by court order, agreement or\n");
		(void) fprintf( fp, "otherwise) that contradict the conditions of this License, they do not\n");
		(void) fprintf( fp, "excuse you from the conditions of this License. If you cannot distribute\n");
		(void) fprintf( fp, "so as to satisfy simultaneously your obligations under this License and\n");
		(void) fprintf( fp, "any other pertinent obligations, then as a consequence you may not\n");
		(void) fprintf( fp, "distribute the Program at all. For example, if a patent license would\n");
		(void) fprintf( fp, "not permit royalty-free redistribution of the Program by all those who\n");
		(void) fprintf( fp, "receive copies directly or indirectly through you, then the only way you\n");
		(void) fprintf( fp, "could satisfy both it and this License would be to refrain entirely from\n");
		(void) fprintf( fp, "distribution of the Program.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "If any portion of this section is held invalid or unenforceable under\n");
		(void) fprintf( fp, "any particular circumstance, the balance of the section is intended to\n");
		(void) fprintf( fp, "apply and the section as a whole is intended to apply in other\n");
		(void) fprintf( fp, "circumstances.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "It is not the purpose of this section to induce you to infringe any\n");
		(void) fprintf( fp, "patents or other property right claims or to contest validity of any\n");
		(void) fprintf( fp, "such claims; this section has the sole purpose of protecting the\n");
		(void) fprintf( fp, "integrity of the free software distribution system, which is implemented\n");
		(void) fprintf( fp, "by public license practices. Many people have made generous\n");
		(void) fprintf( fp, "contributions to the wide range of software distributed through that\n");
		(void) fprintf( fp, "system in reliance on consistent application of that system; it is up to\n");
		(void) fprintf( fp, "the author/donor to decide if he or she is willing to distribute\n");
		(void) fprintf( fp, "software through any other system and a licensee cannot impose that\n");
		(void) fprintf( fp, "choice.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "This section is intended to make thoroughly clear what is believed to be\n");
		(void) fprintf( fp, "a consequence of the rest of this License.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "8. If the distribution and/or use of the Program is restricted in\n");
		(void) fprintf( fp, "certain countries either by patents or by copyrighted interfaces, the\n");
		(void) fprintf( fp, "original copyright holder who places the Program under this License may\n");
		(void) fprintf( fp, "add an explicit geographical distribution limitation excluding those\n");
		(void) fprintf( fp, "countries, so that distribution is permitted only in or among countries\n");
		(void) fprintf( fp, "not thus excluded. In such case, this License incorporates the\n");
		(void) fprintf( fp, "limitation as if written in the body of this License.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "9. The Free Software Foundation may publish revised and/or new versions\n");
		(void) fprintf( fp, "of the General Public License from time to time. Such new versions will\n");
		(void) fprintf( fp, "be similar in spirit to the present version, but may differ in detail to\n");
		(void) fprintf( fp, "address new problems or concerns.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "Each version is given a distinguishing version number. If the Program\n");
		(void) fprintf( fp, "specifies a version number of this License which applies to it and \"any\n");
		(void) fprintf( fp, "later version\", you have the option of following the terms and\n");
		(void) fprintf( fp, "conditions either of that version or of any later version published by\n");
		(void) fprintf( fp, "the Free Software Foundation. If the Program does not specify a version\n");
		(void) fprintf( fp, "number of this License, you may choose any version ever published by the\n");
		(void) fprintf( fp, "Free Software Foundation.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "10. If you wish to incorporate parts of the Program into other free\n");
		(void) fprintf( fp, "programs whose distribution conditions are different, write to the\n");
		(void) fprintf( fp, "author to ask for permission. For software which is copyrighted by the\n");
		(void) fprintf( fp, "Free Software Foundation, write to the Free Software Foundation; we\n");
		(void) fprintf( fp, "sometimes make exceptions for this. Our decision will be guided by the\n");
		(void) fprintf( fp, "two goals of preserving the free status of all derivatives of our free\n");
		(void) fprintf( fp, "software and of promoting the sharing and reuse of software generally.\n\n\n");

		return;
}

void M_show_warranty( FILE *fp )
{

		(void) fprintf( fp, "NO WARRANTY\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\n");
		(void) fprintf( fp, "FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN\n");
		(void) fprintf( fp, "OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\n");
		(void) fprintf( fp, "PROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER\n");
		(void) fprintf( fp, "EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED\n");
		(void) fprintf( fp, "WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE\n");
		(void) fprintf( fp, "ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH\n");
		(void) fprintf( fp, "YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL\n");
		(void) fprintf( fp, "NECESSARY SERVICING, REPAIR OR CORRECTION.\n");
		(void) fprintf( fp, "\n");
		(void) fprintf( fp, "12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN\n");
		(void) fprintf( fp, "WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY\n");
		(void) fprintf( fp, "AND/OR REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR\n");
		(void) fprintf( fp, "DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL\n");
		(void) fprintf( fp, "DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM\n");
		(void) fprintf( fp, "(INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED\n");
		(void) fprintf( fp, "INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF\n");
		(void) fprintf( fp, "THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR\n");
		(void) fprintf( fp, "OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.\n\n\n");

		return;
}


#define MAXKEY 256*256
PE *dictionary[MAXKEY];
static unsigned int M_hash(const char key[]) {
		switch (strlen(key)) {
				case 0: return 0;
				case 1: return (unsigned int)key[0];
				default: return (unsigned int)key[0] + 256*(unsigned int)key[1];
		}
}

void M_apm_enter(const char key[], PE value) {
		if (dictionary[M_hash(key)] == NULL) {
				dictionary[M_hash(key)] = (PE *) calloc(1, sizeof(PE));
		}
		*(dictionary[M_hash(key)]) = value;  // this replaces, as well as inserts
		return;
}

PE * M_apm_find(const char key[]) {
		return dictionary[M_hash(key)];
}
int M_parse_param_line( char line[LINE_LEN] )
{
		int j, i, token = PAR_;               /* return -1 if nothing is recognized. */
		char c[LINE_LEN];

		const int tokentablesize = 7;

		const struct {
				char *lexeme;
				int tokenvalue;
		} tokentable[] = {{"FE_coeff_vdW", PAR_VDW}, // 1
				{"FE_coeff_hbond", PAR_HBOND}, // 2
				{"FE_coeff_estat", PAR_ESTAT}, // 3
				{"FE_coeff_desolv", PAR_DESOLV}, // 4
				{"FE_coeff_tors", PAR_TORS}, // 5
				{"FE_unbound_model", PAR_UNBOUND}, // 6
				{"atom_par", PAR_ATOM_PAR} // 7
		}; // 7 tokens  // remember to set tokentablesize earlier

		c[0] = '\0';
		for (j=0; ((line[j]!='\0')&&(line[j]!=' ')&&(line[j]!='\t')&&(line[j]!='\n')); j++) {
				/*  Ignore case */
				c[j] = (char)tolower((int)line[j]);
				if (debug > 0) {
						(void)fprintf(logFile,"%c",c[j]);
				}
		}
		if (debug > 0) {
				(void)fprintf(logFile,"\nj = %d\n",j);
		}

		/*  Recognize one character tokens  */

		if ((c[0]=='\n') || (c[0]=='\0')) {
				token = PAR_NULL;
		} else if (c[0]=='#') {
				token = PAR_COMMENT;
		}

		/*  Recognize token strings  */

		for (i=0;  (i < tokentablesize) && (token == PAR_);  i++) {
				if (debug > 0) {
						(void)fprintf(logFile,"i = %d, tokentable[i].lexeme = %s, tokentable[i].value = %d, c = %s\n",i,tokentable[i].lexeme,tokentable[i].tokenvalue,c);
				}
				if (strncasecmp(tokentable[i].lexeme, c, j) == 0) {
						token = tokentable[i].tokenvalue;
				}
		}
		return(token);
}

void M_setup_parameter_library( int outlev, const char * model_text, Unbound_Model unbound_model )
{
		static ParameterEntry thisParameter;
		char parameter_library_line[LINE_LEN];
		int nfields;
		int param_keyword = -1;
		int int_hbond_type = 0;
		register int counter = 0;
		char ** param_string;
		if (unbound_model==Extended) {
				param_string=param_string_4_0;
				strncpy(parameter_library, "'extended' [AutoDock 4.0 default]", sizeof parameter_library);
		}
		else if (unbound_model==Unbound_Same_As_Bound) {
				param_string=param_string_4_1;
				strncpy(parameter_library, "'same as bound' [AutoDock 4.2 default]", sizeof parameter_library);
		}
		else {
				pr(logFile, "DEBUG: cannot determine %s parameter values \n",model_text);
				slaveExit(-1);
		}


		while ( param_string[counter] != NULL) {
				param_keyword = M_parse_param_line( param_string[counter] );

				(void)strcpy(parameter_library_line, param_string[counter]);
				counter++;
				if (debug > 0) {
						pr(logFile, "DEBUG: parameter_library_line = %sDEBUG: param_keyword          = %d\n", parameter_library_line, param_keyword);
				}

				switch (param_keyword) {
						case PAR_:
						case PAR_NULL:
						case PAR_COMMENT:
								break;

						case PAR_VDW:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_vdW);
								if (nfields < 1) {
										continue; // skip any parameter_library_line without enough info
								}
								break;

						case PAR_HBOND:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_hbond);
								if (nfields < 1) {
										continue; // skip any parameter_library_line without enough info
								}
								break;

						case PAR_ESTAT:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_estat);
								if (nfields < 1) {
										continue; // skip any parameter_library_line without enough info
								}
								break;

						case PAR_DESOLV:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_desolv);
								if (nfields < 1) {
										continue; // skip any parameter_library_line without enough info
								}
								break;

						case PAR_TORS:
								nfields = sscanf(parameter_library_line, "%*s %lf", &AD4.coeff_tors);
								if (nfields < 1) {
										continue; // skip any parameter_library_line without enough info
								}
								break;

						case PAR_UNBOUND:
								break;

						case PAR_ATOM_PAR:
								// Read in one line of atom parameters;
								// NB: scanf doesn't try to write missing fields
								nfields = sscanf(parameter_library_line, "%*s %s %lf %lf %lf %lf %lf %lf %d %d %d %d",
												thisParameter.autogrid_type,
												&thisParameter.Rij,
												&thisParameter.epsij,
												&thisParameter.vol,
												&thisParameter.solpar,
												&thisParameter.Rij_hb,
												&thisParameter.epsij_hb,
												&int_hbond_type,
												&thisParameter.rec_index,
												&thisParameter.map_index,
												&thisParameter.bond_index);
								if (nfields < 2) {
										continue; // skip any parameter_library_line without enough info
								}

								if (int_hbond_type == 0) {
										thisParameter.hbond = NON;
								} else if (int_hbond_type == 1) {
										thisParameter.hbond = DS;
								} else if (int_hbond_type == 2) {
										thisParameter.hbond = D1;
								} else if (int_hbond_type == 3) {
										thisParameter.hbond = AS;
								} else if (int_hbond_type == 4) {
										thisParameter.hbond = A1;
								} else if (int_hbond_type == 5) {
										thisParameter.hbond = A2;
								} else {
										thisParameter.hbond = NON;
								}

								thisParameter.epsij    *= AD4.coeff_vdW;
								thisParameter.epsij_hb *= AD4.coeff_hbond;

								M_apm_enter(thisParameter.autogrid_type, thisParameter);
								break;

						default:
								break;
				} // switch
		} // while there is another line of parameters to read in
}

int M_parse_PDBQT_line( char line[LINE_LEN] )
{
		int l, i, token = PDBQ_UNRECOGNIZED;
		char c[LINE_LEN];

		if ((l = strindex(line, " ")) == -1) {
				l = strlen(line);
		}
		for (i=0; i<l && i<(LINE_LEN-1); i++) {
				c[i] = (char)tolower( (int)line[i] );
		}
		c[i] = '\0';

		if ((c[0]=='\n')||(c[0]=='\0')) {
				token = PDBQ_NULL;
		} else if (l >= 4) {
				if ((strncmp(c,"rema",4)==0) || (strncmp(c,"user",4)==0)) {
						token = PDBQ_REMARK;
				} else if (strncmp(c,"root",4)==0) {
						token = PDBQ_ROOT;
				} else if (strncmp(c,"endr",4)==0) {
						token = PDBQ_ENDROOT;
				} else if (strncmp(c,"atom",4)==0) {
						token = PDBQ_ATOM;
				} else if (strncmp(c,"heta",4)==0) {
						token = PDBQ_HETATM;
				} else if ((strncmp(c,"tors",4)==0) && (strncmp(c,"torsdof",7)!=0)) {
						token = PDBQ_TORS;
				} else if ((strlen(c) >= 7) && (strncmp(c,"torsdof",7)==0)) {
						token = PDBQ_TORSDOF;
				} else if (strncmp(c,"tdof",4)==0) {
						token = PDBQ_TORSDOF;
				} else if (strncmp(c,"endt",4)==0) {
						token = PDBQ_ENDTORS;
				} else if (strncmp(c,"bran",4)==0) {
						token = PDBQ_BRANCH;
				} else if (strncmp(c,"endb",4)==0) {
						token = PDBQ_ENDBRANCH;
				} else if (strncmp(c,"cons",4)==0) {
						token = PDBQ_CONSTRAINT;
				} else if (strncmp(c,"begin_res",9)==0) {
						token = PDBQ_BEGIN_RES;
				} else if (strncmp(c,"end_res",7)==0) {
						token = PDBQ_END_RES;
				} else if (strncmp(c,"conect",6)==0) {
						token = PDBQ_CONECT;
				} else if (strncmp(c,"user",4)==0) {
						token = PDBQ_NULL;
				}
		} 
		/**********************
		//YTLIU_EDIT 2012.12.29
		 **********************/
		else if (l == 3) {
				if (strncmp(c,"ter",3)==0) {
						token = PDBQ_TER;
				}
		}else {
				token = PDBQ_UNRECOGNIZED;
		}

		return( token );
}

void  M_readReceptorPDBQTLine( char line[LINE_LEN],int  *ptr_serial,Real crd[SPACE],Real *ptr_q,char* atomtype)
{
		char char8[9];
		char char6[7];
		char char5[6];
		char char2[3];

		static char message[LINE_LEN];

		// Initialise char5
		(void) strcpy( char5, "    0" );
		char5[5] = '\0';

		// Initialise char8
		(void) strcpy( char8, "   0.000" );
		char8[8] = '\0';

		// Initialise char6
		(void) strcpy( char6, "  0.00" );
		char6[6] = '\0';

		// Initialise char2
		(void) strcpy( char2, "C " );
		char2[2] = '\0';

#define check_sscanf( str, fmt, val, fieldname )  if (1 != sscanf( str, fmt, val ))  {\
		sprintf(message, "\n%s: WARNING! Could not read " fieldname " in PDBQT line \"%s\".\n", programname, line );\
		pr_2x(stderr, logFile, message); }

		// Read in the serial number of this atom
		(void) strncpy( char5, &line[6], (size_t)5 );
		char5[5] = '\0';
		check_sscanf( char5, "%d", ptr_serial, "serial number" );

		// Read in the X, Y, Z coordinates
		(void) strncpy( char8, &line[30], (size_t)8 );
		char8[8] = '\0';
		check_sscanf( char8, FDFMT, &crd[X], "x-coordinate" );

		(void) strncpy( char8, &line[38], (size_t)8 );
		char8[8] = '\0';
		check_sscanf( char8, FDFMT, &crd[Y], "y-coordinate" );

		(void) strncpy( char8, &line[46], (size_t)8 );
		char8[8] = '\0';
		check_sscanf( char8, FDFMT, &crd[Z], "z-coordinate" );

		// partial charge, q
		(void) strncpy( char6, &line[70], (size_t)6 );
		char6[6] = '\0';
		check_sscanf( char6, FDFMT, ptr_q, "partial charge" );

		// atom type name
		(void) strncpy( char2, &line[77], (size_t)2 );
		char2[2] = '\0';
		check_sscanf( char2, "%s", atomtype, "atom type" );
#undef check_sscanf


}


Receptor M_readReceptorPDBQT(int *P_natoms,Real crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
				Real charge[MAX_RECEPTOR_ATOMS],Boole *P_B_haveCharges,char pdbaname[MAX_RECEPTOR_ATOMS][5],
				char *FN_receptor,Clock jobStart,struct tms tms_jobStart,int B_include_1_4_interactions,
				Atom atoms[MAX_RECEPTOR_ATOMS])
{
		FILE           *FP_receptor;
		static char     dummy[LINE_LEN];
		static char     error_message[LINE_LEN];
		static char     message[LINE_LEN];

		register int    i = 0;
		register int    j = 0;

		char PDBQT_record[MAX_RECEPTOR_ATOMS][LINE_LEN];
		//    char atomstuff[MAX_RECEPTOR_ATOMS][MAX_CHARS];
		Receptor recep;

		//  Attempt to open the receptor PDBQT file...
		//if (openFile(FN_receptor, "r", &FP_receptor, jobStart, tms_jobStart, TRUE)) {
		//        pr(logFile, "Receptor PDBQT file = \"%s\"\n\n", FN_receptor);
		//}
		if((FP_receptor=fopen(FN_receptor, "r"))==NULL)
		{
				fprintf(stderr,"Read receptor file failed\n");
				slaveExit(-1);
		}
		int nrecord = 0;
		//  Count the number of records in the Receptor PDBQT file first...
		int nreceptor_record = 0;
		while (fgets(dummy, LINE_LEN, FP_receptor) != NULL) {
				++nreceptor_record;
		}
		(void) fclose(FP_receptor);

		nrecord = nreceptor_record;

		// Set the nrecord-th entry of PDBQT_record to NULL, aka '\0'
		(void) strcpy(PDBQT_record[nrecord], "\0");

		if(nrecord > MAX_RECEPTOR_ATOMS) {
				prStr(error_message, "ERROR: %d records read in, but only dimensioned for %d.\nChange \"MAX_RECEPTOR_ATOMS\" in \"constants.h\".", nrecord, MAX_RECEPTOR_ATOMS);
				//stop(error_message);
				slaveExit(-1);
		}
		else{
				// Read in the input receptor pdbqt file...
				//if(openFile(FN_receptor, "r", &FP_receptor, jobStart, tms_jobStart, TRUE)){
				//if(openfile(FN_receptor, "r", &FP_receptor))
				if((FP_receptor=fopen(FN_receptor, "r"))!=NULL)
				{
						//            pr(logFile, "INPUT RECEPTOR PDBQT FILE:");
						//			pr(logFile,"\n________________________\n\n");
						for(i=0;i<nreceptor_record;i++){
								if (fgets(PDBQT_record[i], LINE_LEN, FP_receptor) != NULL) {
										//					pr(logFile, "INPUT-RECEPTOR-PDBQT: %s", PDBQT_record[i]);
								}
						}
						//			pr(logFile, UnderLine);
				}
				else
				{
						fprintf(stderr,"Read receptor file failed\n");
						slaveExit(-1);
				}
				(void) fclose(FP_receptor);

		}

		int natom = 0;

		// Loop over all the lines in either the receptor file
		int keyword_id = -1;
		char input_line[LINE_LEN];
		for(i=0;i<nrecord;i++){
				strncpy(input_line, PDBQT_record[i], (size_t) LINE_LEN);
				// Parse this line in the ligand file
				keyword_id = M_parse_PDBQT_line(input_line);

				switch(keyword_id) {
						case PDBQ_ATOM:
								// Check that the line is at least 78 characters long
								if (strlen(input_line) < 78) {
										pr(logFile, "%s: FATAL ERROR: line %d is too short!\n", programname, i+1);
										pr(logFile, "%s: FATAL ERROR: line \"%s\".\n", programname, input_line);
										pr(stderr, "%s: FATAL ERROR: line %d is too short!\n", programname, i+1);
										pr(stderr, "%s: FATAL ERROR: line \"%s\".\n", programname, input_line);
										slaveExit(-1);
								}

								int serial;

								// Read the coordinates and store them in crdpdb[],
								// read the partial atomic charge and store it in charge[],
								// and read the parameters of this atom and store them in this_parameter_entry,
								// setting the "autogrid_type" in this_parameter_entry.
								char atomtype[MAX_LEN_AUTOGRID_TYPE + 1];
								M_readReceptorPDBQTLine(input_line, &serial, crdpdb[natom], &charge[natom], atomtype);

								for (j = 0; j < NTRN; j++) {
										recep.crdpdb[natom][j]=crdpdb[natom][j];
										recep.crd[natom][j]=crdpdb[natom][j];
								}
								recep.charge[natom]=charge[natom];
								strcpy(recep.atomtype[natom], atomtype);
								*P_B_haveCharges = TRUE;

								//                strncpy(atomstuff[natom], input_line, (size_t) 30);
								//                atomstuff[natom][30] = '\0';
								//                strcpy(recep.atomstr[natom], atomstuff[natom]);
								sscanf(&input_line[12], "%s", pdbaname[natom]);
								++natom;
								break;
						case PDBQ_TER:
								//                pr(logFile, "%s: End of a chain\n", programname );
								break;
						case PDBQ_UNRECOGNIZED:
						default:
								break;
				}
		}
		recep.natom = natom;
		*P_natoms = natom;
		return recep;
		}

		void print_2x( FILE *stream1,
						FILE *stream2,
						const char *string )

		{
				fprintf( stream1, string );
				fprintf( stream2, string );
		}					
		int M_parsetypes(char * line, char *words[], int maxwords)
		{
				char *char_ptr = line;
				int num_types = 0;
				/*flag for first word which is always a keyword*/
				int found_keyword = 0;

				while(1) {
						/*skip spaces*/
						while(isspace(*char_ptr)){
								char_ptr++;
						}
						/*done parsing when get eol 'null' character*/
						/* could get null after a space*/
						if (*char_ptr == '\0'){
								/*return number of 'types' found*/
								return num_types;
						}
						/* the first word is the keyword not a type*/
						if(found_keyword==0){
								found_keyword++;
						} else {
								/*words is a list of indicies of beginning of 1 or 2 char types*/
								/*if there are too many types, return*/
								if(num_types >= maxwords) return -1;

								words[num_types++] = char_ptr;
						}
						/*once in a type, skip possible 2nd characters up to a space or null
						 * character*/
						while(!isspace(*char_ptr) && *char_ptr!='\0'){
								char_ptr++;
						}
						/*done parsing when get eol 'null' character*/
						/* could get null after a character*/
						if(*char_ptr=='\0'){
								return num_types;
						}
						/*make each 'type' a null terminated string*/
						*char_ptr++ = '\0';
				}
		}


		void M_intnbtable( Boole *P_B_havenbp,int a1,int a2,GridMapSetInfo *info,Real cA, 
						Real cB,int xA,int xB,double coeff_desolv,double sigma,EnergyTables *ad_tables,Boole B_is_unbound_calculation )
		{
				double rA;
				double rB;
				double r;
				double minus_inv_two_sigma_sqd = -0.5L / (sigma * sigma);

				register int i;

				//    struct tms tms_nbeEnd;
				//    struct tms tms_nbeStart;

				char calc_type[128];

				if (B_is_unbound_calculation == TRUE) {
						strcpy(calc_type, "unbound");
				} else {
						strcpy(calc_type, "internal");
				}

				*P_B_havenbp = TRUE;

				for ( i = 1;  i < NEINT;  i++ ) {
						// i is the lookup-table index that corresponds to the distance

						// r is the distance that corresponds to the lookup index
						r = IndexToDistance(i); 

						// Compute the distance-dependent gaussian component of the desolvation energy, sol_fn[i];
						// Weight this by the coefficient for desolvation, coeff_desolv.
						ad_tables->sol_fn[i] = coeff_desolv * exp( minus_inv_two_sigma_sqd * sq(r) );

						// Compute r^xA and r^xB:
						rA = pow( r, (double)xA );
						rB = pow( r, (double)xB );

						if ( B_is_unbound_calculation ) {
								ad_tables->e_vdW_Hb[i][a1][a2]  =  ad_tables->e_vdW_Hb[i][a2][a1]  =  min( EINTCLAMP, (cA/rA) ) - r;
						} else {
								ad_tables->e_vdW_Hb[i][a1][a2]  =  ad_tables->e_vdW_Hb[i][a2][a1]  =  min( EINTCLAMP, (cA/rA - cB/rB) );
						}

				} // next i // for ( i = 1;  i < NEINT;  i++ )

		}

		void M_readfield( GridMapSetInfo *info, char line[LINE_LEN],Clock jobStart,struct tms tms_jobStart )
		{
				FILE *fldFile;
				char rec9[9], inputline[LINE_LEN];
				double localSpacing;
				register int i = 0;

				/*
				 ** GRID_DATA_FILE
				 ** Read the (AVS-format) grid data file, .fld
				 ** _____________________________________________________________
				 **/
				(void) sscanf( line, "%*s %s", info->FN_gdfld);

				//if ( openfile( info->FN_gdfld, "r", &fldFile))
				//{}
				if((fldFile=fopen(info->FN_gdfld, "r"))==NULL)
				{
						fprintf(stderr,"Can not find %s\n",info->FN_gdfld);
						slaveExit(-1);
				}
				//, jobStart, tms_jobStart, TRUE )) {
				//        pr( logFile, "Opening Grid Map Dimensions file:\t\t%s\n\n", info->FN_gdfld);
				//  }

				/*
				 ** Skip over the AVS-readable .fld  header comments, until 
				 **
				 ** #SPACING
				 */
				while( fgets(line, LINE_LEN, fldFile) != NULL ) {
						(void) sscanf(line,"%s", rec9);
						if (equal(rec9,"#SPACING", 8)) {
								(void) sscanf(line,"%*s %lf", &localSpacing);
								info->spacing = localSpacing;
								break;
						}
				} /* endwhile */
				info->inv_spacing = 1. / (info->spacing);
				//    pr( logFile, "Grid Point Spacing =\t\t\t\t%.3f Angstroms\n\n", info->spacing);

				/*
				 ** #NELEMENTS 
				 */
				(void) fgets(inputline, LINE_LEN, fldFile);
				(void) sscanf(inputline,"%*s %d %d %d", &info->num_points[X], &info->num_points[Y], &info->num_points[Z]);
				/* Check that these are all even numbers... */
				for (i=0; i<SPACE; i++) {
						if ( (info->num_points[i])%2 != 0 ) {
								//stop("the number of user-specified grid points must be even in the \"#NELEMENTS\" line in the \".fld\" file.");
								slaveExit(-1);
						}
				}

				//    pr( logFile, "Even Number of User-specified Grid Points =\t%d x-points\n\t\t\t\t\t\t%d y-points\n\t\t\t\t\t\t%d z-points\n\n", info->num_points[X],info->num_points[Y],info->num_points[Z]);
				for (i = 0;  i < SPACE;  i++) {
						info->num_points1[i] = info->num_points[i] + 1;
				} /* i */
				//    pr( logFile, "Adding the Central Grid Point makes:\t\t%d x-points\n\t\t\t\t\t\t%d y-points\n\t\t\t\t\t\t%d z-points\n\n", info->num_points1[X], info->num_points1[Y], info->num_points1[Z]);
				if ( (info->num_points[X] <= 0)||(info->num_points[Y] <= 0)||(info->num_points[Z] <= 0) ) {
						//stop("insufficient grid points." );
						slaveExit( -1 );
				} else if ((info->num_points[X] > MAX_GRID_PTS)||(info->num_points[Y] > MAX_GRID_PTS)||(info->num_points[Z] > MAX_GRID_PTS)) {
						//stop("too many grid points." );
						slaveExit( -1 );
				}

				/*
				 ** #CENTER 
				 */
				(void) fgets(inputline, LINE_LEN, fldFile);
				(void) sscanf(inputline,"%*s %lf %lf %lf", &info->center[X], &info->center[Y], &info->center[Z]);
				//    pr( logFile, "Coordinates of Central Grid Point of Maps =\t(%.3f, %.3f, %.3f)\n\n", info->center[X],  info->center[Y],  info->center[Z]);

				/*
				 ** #MACROMOLECULE 
				 */
				(void) fgets(inputline, LINE_LEN, fldFile);
				(void) sscanf(inputline,"%*s %s", info->FN_receptor);
				//    pr( logFile, "Macromolecule file used to create Grid Maps =\t%s\n\n", info->FN_receptor);

				/*
				 ** #GRID_PARAMETER_FILE 
				 */
				(void) fgets(inputline, LINE_LEN, fldFile);
				(void) sscanf(inputline,"%*s %s", info->FN_gpf);
				//    pr( logFile, "Grid Parameter file used to create Grid Maps =\t%s\n\n", info->FN_gpf);

				/*
				 ** Close Grid-dimensions data file 
				 */
				fclose(fldFile);

				/*
				 ** Determine the dimensions of the grids,
				 */
				for (i = 0;  i < SPACE;  i++) {
						info->lo[i] = info->center[i] - (info->num_points[i]/2) * (info->spacing);
						info->hi[i] = info->center[i] + (info->num_points[i]/2) * (info->spacing);
				}

				//    pr( logFile, "Minimum coordinates in grid = (%.3f, %.3f, %.3f)\n",   info->lo[X], info->lo[Y], info->lo[Z]);
				//    pr( logFile, "Maximum coordinates in grid = (%.3f, %.3f, %.3f)\n\n", info->hi[X], info->hi[Y], info->hi[Z]);
				//    fflush( logFile );
		}

		void M_warn_bad_file( char *filename,char message[LINE_LEN] )
		{
				char out[LINE_LEN];

				sprintf( out, "%s: WARNING: possibly unsuitable/old version grid-map file %s\n", programname, filename );
				print_2x( logFile, stderr, out );
				sprintf( out, "%s: %s\n", programname, message );
				print_2x( logFile, stderr, out );
		}

		void M_check_header_line( char s1[], char s2[] )
		{
				if ( !equal(s1, s2, strlen(s1) ) ) 
				{
						fprintf( logFile,"%s: Filename mismatch:\t\t\"%s\" :: \"%s\"\n", programname, s1,s2); 
				}
		}

		void M_check_header_float( Real f1, Real f2, char keyword[], char filename[] )
		{
				if ( f1 != f2 ) { 
						fprintf(logFile, "Wrong %s in grid-map file \"%s\".\n", keyword, filename);
						fprintf(stderr, "%s: Wrong %s in grid-map file \"%s\".\n", programname, keyword, filename);

						fprintf(logFile, "Use either %.3f or %.3f throughout!\n\n", f1,f2);
						fprintf(stderr, "%s: Use either %.3f or %.3f throughout!\n", programname, f1,f2);

						//stop("Using wrong grid-map file.\n");
				}
		}

		void M_check_header_int( int i1,int i2, char axis, char *filename )
		{
				char message[LINE_LEN];

				if ( i1 != i2 ) { 

						sprintf( message, "%s: Wrong number of %c grid-points in grid-map file \"%s\".\n", programname, (char)axis, filename );

						print_2x( logFile, stderr, message );

						sprintf( message, "%s: Use either %d or %d throughout!\n", programname, i1, i2 );

						print_2x( logFile, stderr, message );

						//stop("Using wrong grid-map file.\n");
				}
		}

		Real M_mapc2f(char numin)
		{
				Real numout;
				if (numin == 0) {
						numout = 0.;
				} else if (numin > 0) {
						numout = numin * 10.;
				} else {
						numout = numin /10.;
				}
				return numout;
		}

		Statistics M_readmap( char line[LINE_LEN],int outlev,Clock jobStart,
						struct tms     tmsJobStart,
						Boole          B_charMap,
						Boole          *P_B_HaveMap,
						int            num_maps,
						GridMapSetInfo *info,
						Real           map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS],
						// double *maps
						char           map_type,
						Boole mapFileAlreadyLoaded,
						int mapUsageType)

		{
				FILE *map_file;

				char FileName[PATH_MAX];
				char FldFileName[PATH_MAX];
				char GpfName[PATH_MAX];
				char ExtGpfName[PATH_MAX];
				char message[LINE_LEN];
				char mmFileName[PATH_MAX];
				char xyz_str[4];
				char C_mapValue;
				char map_line[LINE_LEN];
				char inputline[LINE_LEN];
				char atom_type_name[MAX_CHARS];

				Real cen[SPACE];
				Real spacing = 0.;
				double map_max;
				double map_min;
				double map_total;

				int indpf = 0;
				int nel[SPACE];
				int nv=0;
				int nvExpected = 0;

				register int xyz = 0;
				register int i = 0;
				register int j = 0;
				register int k = 0;

				struct tms tms_jobEnd;
				struct tms tms_loadEnd;
				struct tms tms_loadStart;

				Clock jobEnd;
				Clock loadEnd;
				Clock loadStart;

				Statistics map_stats;

				strcpy( xyz_str, "xyz\0" );

				if (!mapFileAlreadyLoaded) {
						(void) sscanf( line, "%*s %s", FileName );
						if((map_file=fopen(FileName,"r"))!=NULL)
						{
								*P_B_HaveMap = TRUE;
								if (debug > 0) {
										for (i=0; i < info->num_atom_types; i++) {
												(void) fprintf(logFile, "info->atom_type_name[%d] = \"%s\"\n", i, info->atom_type_name[i] );
										}
								}
								// pkcoff: change to support unduplicated file loading
								if (mapUsageType == REUSE_MAPS) {
										strcpy(atom_type_name, atomTypeMap[num_maps]);
								}
								else {
										if (map_type == 'e') {
												strcpy(atom_type_name, "e\0");
										} else if (map_type == 'd') {
												strcpy(atom_type_name, "d\0");
										} else {
												strcpy(atom_type_name, info->atom_type_name[num_maps]);
										}
								}

								/*
								   \ Check header lines of grid map...
								   /
								   \ :Line 1  GRID_PARAMETER_FILE
								   */
								if (fgets(inputline, LINE_LEN, map_file) == NULL) {
										M_warn_bad_file( FileName,"Could not read GRID_PARAMETER_FILE line." );
								} else {
										(void) sscanf(inputline, "%*s %s", GpfName);
										if ( strindex( dock_param_fn, ".dpf" ) == -1) {
												pr_2x( stderr, logFile,"Can't find \".dpf\" in the dock-parameter filename.\n\n" );
												pr_2x( stderr, logFile,"AutoDock needs the extension of the grid parameter file to be \".gpf\"\nand that of the docking parameter file to be \".dpf\".\n\n" );
										} else {
												/*
												   \ replace ".dpf" with ".gpf".
												   */
												indpf = strindex( dock_param_fn, "dpf" );
												strcpy(ExtGpfName, dock_param_fn);
												ExtGpfName[ indpf ] = 'g';
										}
								} /* endif */

								/*
								   \ :Line 2  GRID_DATA_FILE
								   */
								if (fgets(inputline, LINE_LEN, map_file) == NULL) {
										M_warn_bad_file( FileName,"Could not read \".fld\" GRID_DATA_FILE line." );
								} else {
										(void) sscanf(inputline, "%*s %s", FldFileName);
										if (!ignore_errors) {
												M_check_header_line( FldFileName, info->FN_gdfld );
										} /* endif */
								} /* endif */

								/*
								   \ :Line 3  MACROMOLECULE
								   */
								if (fgets(inputline, LINE_LEN, map_file) == NULL) {
										M_warn_bad_file( FileName,"Could not read MACROMOLECULE line." );
								} else {
										(void) sscanf(inputline,"%*s %s", mmFileName);
										M_check_header_line( mmFileName, info->FN_receptor );
								} /* endif */

								/*
								   \ :Line 4  SPACING
								   */
								if (fgets(inputline, LINE_LEN, map_file) == NULL) {
										M_warn_bad_file( FileName,"Could not read SPACING line." );
								} else {
										(void) sscanf(inputline,"%*s " FDFMT, &spacing);
										M_check_header_float(spacing, info->spacing, "grid point spacing", FileName );
								} /* endif */

								/*
								   \ :Line 5  NELEMENTS
								   */
								if (fgets(inputline, LINE_LEN, map_file) == NULL) {
										M_warn_bad_file( FileName,"Could not read NELEMENTS line." );
								} else {
										(void) sscanf(inputline,"%*s %d %d %d", &nel[X], &nel[Y], &nel[Z]);
										for (xyz = 0;  xyz < SPACE;  xyz++) {
												//maps->num_points[xyz] = nel[xyz];
												//maps->num_points1[xyz] = nel[xyz] + 1;
												M_check_header_int( nel[xyz], info->num_points[xyz], xyz_str[xyz], FileName );
										} /* xyz */
								} /* endif */

								/*
								   \ :Line 6  CENTER
								   */
								if (fgets(inputline, LINE_LEN, map_file) == NULL) {
										M_warn_bad_file( FileName,"Could not read CENTER line." );
								} else {
										(void) sscanf(inputline,"%*s " FDFMT3, &cen[X], &cen[Y], &cen[Z]);
										for (xyz = 0;  xyz < SPACE;  xyz++) {
												//maps->center[xyz] = cen[xyz];
												M_check_header_float(cen[xyz], info->center[xyz], "grid-map center", FileName );
										} /* xyz */
								} /* endif */
						} /* endif */
						else
						{
								fprintf(stderr,"Can not find %s\n",FileName);
								slaveExit(-1);
						}
						//    flushLog;

						map_max = -BIG;
						map_min =  BIG;
						map_total = 0.;
						nvExpected = info->num_points1[X] * info->num_points1[Y] * info->num_points1[Z];
						nv = 0;
						flushLog;
						loadStart = times( &tms_loadStart );

						for ( k = 0;  k < info->num_points1[Z];  k++) {
								for ( j = 0;  j < info->num_points1[Y];  j++) {
										for ( i = 0;  i < info->num_points1[X];  i++) {
												if (B_charMap) {
														if (fgets(map_line, LINE_LEN, map_file) != NULL) { /*new*/
																if (sscanf( map_line,  "%c",  &C_mapValue ) != 1) continue;
																map[k][j][i][num_maps] = M_mapc2f(C_mapValue);
																nv++;
														}
												} else {
														if (fgets( map_line, LINE_LEN, map_file) != NULL) { /*new*/
																if (sscanf( map_line,  FDFMT,  &map[k][j][i][num_maps] ) != 1) continue;
																nv++;
														}
												}
												map_max = max( map_max, map[k][j][i][num_maps] );
												map_min = min( map_min, map[k][j][i][num_maps] );
												map_total += map[k][j][i][num_maps];
										}
								}
						}

						map_stats.number = nv;
						map_stats.minimum = map_min;
						map_stats.maximum = map_max;
						map_stats.mean = map_total / (double) nv;

						fclose( map_file );

						loadEnd = times( &tms_loadEnd );


						if (nv != nvExpected ) {
								prStr( message, "\n%s: wrong number of values read in. Check grid map!\n\n", programname  );
								pr_2x( stderr, logFile, message );

								jobEnd = times( &tms_jobEnd );
								M_timesys( jobEnd - jobStart, &tmsJobStart, &tms_jobEnd );
								pr_2x( logFile, stderr, UnderLine );

								/* END PROGRAM */
								slaveExit(-1);
						}

						flushLog;

				} // mapFileAlreadyLoaded
				else {
						map_max = -BIG;
						map_min =  BIG;
						map_total = 0.;
						nvExpected = info->num_points1[X] * info->num_points1[Y] * info->num_points1[Z];
						nv = 0;

						for ( k = 0;  k < info->num_points1[Z];  k++) {
								for ( j = 0;  j < info->num_points1[Y];  j++) {
										for ( i = 0;  i < info->num_points1[X];  i++) {
												map_max = max( map_max, map[k][j][i][num_maps] );
												map_min = min( map_min, map[k][j][i][num_maps] );
												map_total += map[k][j][i][num_maps];
										}
								}
						}

						map_stats.number = nv;
						map_stats.minimum = map_min;
						map_stats.maximum = map_max;
						map_stats.mean = map_total / (double) nv;

				}


				return map_stats;
		}

		int M_lookupXBPMFMAPATindex(char xbpmf_at[MAX_LEN_AUTOGRID_TYPE + 1])
		{
				if(equal(xbpmf_at,"CF",2))
						return CF;
				else if(equal(xbpmf_at,"CP",2))
						return CP;
				else if(equal(xbpmf_at,"cF",2))
						return cF;
				else if(equal(xbpmf_at,"cP",2))
						return cP;
				else if(equal(xbpmf_at,"CO",2))
						return CO;
				else if(equal(xbpmf_at,"CN",2))
						return CN;
				else if(equal(xbpmf_at,"NC",2))
						return NC;
				else if(equal(xbpmf_at,"ND",2))
						return ND;
				else if(equal(xbpmf_at,"NA",2))
						return NA;
				else if(equal(xbpmf_at,"OC",2))
						return OC;
				else if(equal(xbpmf_at,"OA",2))
						return OA;
				else if(equal(xbpmf_at,"OD",2))
						return OD;
				else if(equal(xbpmf_at,"SA",2))
						return SA;
				else if(equal(xbpmf_at,"SD",2))
						return SD;
				else if(equal(xbpmf_at,"ME",2))
						return ME;
				else if(equal(xbpmf_at,"OW",2))
						return OW;
				else if(equal(xbpmf_at,"HH",2))
						return HH;
				else if(equal(xbpmf_at,"C3",2))
						return C3;
				else if(equal(xbpmf_at,"CW",2))
						return CW;
				else if(equal(xbpmf_at,"C0",2))
						return C0;
				else if(equal(xbpmf_at,"NP",2))
						return NP;
				else if(equal(xbpmf_at,"NR",2))
						return NR;
				else if(equal(xbpmf_at,"N0",2))
						return N0;
				else if(equal(xbpmf_at,"NS",2))
						return NS;
				else if(equal(xbpmf_at,"OE",2))
						return OE;
				else if(equal(xbpmf_at,"OS",2))
						return OS;
				else if(equal(xbpmf_at,"SO",2))
						return SO;
				else if(equal(xbpmf_at,"Cl",2) || equal(xbpmf_at,"CL",2))
						return Cl;
				else if(equal(xbpmf_at,"Br",2) || equal(xbpmf_at,"BR",2))
						return Br;
				else if(equal(xbpmf_at,"HL",2))
						return HL;
				else if(equal(xbpmf_at,"P",1))
						return P;
				else if(equal(xbpmf_at,"F",1))
						return F;
				else if(equal(xbpmf_at,"I",1))
						return I;
				else
						return XX;
		}

		Statistics M_readxbempiricalprofile( char line[LINE_LEN],
						int outlev,
						Clock jobStart,
						struct tms tmsJobStart,
						GridMapSetInfo *info,
						Real xb_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
						char profile_type)
		{
				FILE* profile_file;
				char FileName[PATH_MAX];
				char xbempirical_atom_type[MAX_LEN_AUTOGRID_TYPE + 1];
				int xbempirical_index = -1;
				char inputline[LINE_LEN];
				double profile_max = -BIG;
				double profile_min = BIG;
				double profile_total = 0.;
				char profile_name[MAX_CHARS];
				char message[LINE_LEN];

				int nv=0;
				int nvExpected = info->num_points1[X] * info->num_points1[Y] * info->num_points1[Z];

				register int i = 0;
				register int j = 0;
				register int k = 0;
				register int m = 0;

				struct tms tms_jobEnd;
				struct tms tms_loadEnd;
				struct tms tms_loadStart;

				Clock jobEnd;
				Clock loadEnd;
				Clock loadStart;

				Statistics profile_stats;

				(void) sscanf(line,"%*s %s %s",xbempirical_atom_type,FileName);
				xbempirical_index = M_lookupXBPMFMAPATindex(xbempirical_atom_type);
				xbempirical_index -= Cl;

				//if ( openFile( FileName, "r", &profile_file, jobStart,tmsJobStart,TRUE )) {
				//if ( openfile( FileName, "r", &profile_file)) 
				if((profile_file=fopen(FileName,"r"))!=NULL)
				{
						if(profile_type == 'v'){
								strcpy(profile_name,"VDW");
						}
						else if(profile_type == 'e'){
								strcpy(profile_name,"Electrostatic");
						}
						else if(profile_type == 'd'){
								strcpy(profile_name,"Desolvation");
						}
						//	pr( logFile, "Opened Grid %s Profile:\t\t\t\t%s\n", profile_name,FileName );

						//	pr( logFile, "Looking for %d energies from Grid %s Profile ... \n", nvExpected, profile_name );
						//        flushLog;
						loadStart = times( &tms_loadStart );

						for ( k = 0;  k < info->num_points1[Z];  k++) {
								for ( j = 0;  j < info->num_points1[Y];  j++) {
										for ( i = 0;  i < info->num_points1[X];  i++) {
												if(profile_type == 'v' || profile_type == 'e'){
														if (fgets( inputline, LINE_LEN, profile_file) != NULL) {
																if(sscanf(inputline,"%f %f %f %f %f %f %f %f",
																						&xb_profile[k][j][i][xbempirical_index][0],
																						&xb_profile[k][j][i][xbempirical_index][1],
																						&xb_profile[k][j][i][xbempirical_index][2],
																						&xb_profile[k][j][i][xbempirical_index][3],
																						&xb_profile[k][j][i][xbempirical_index][4],
																						&xb_profile[k][j][i][xbempirical_index][5],
																						&xb_profile[k][j][i][xbempirical_index][6],
																						&xb_profile[k][j][i][xbempirical_index][7]) != 8)
																		continue;
																nv++;
																for(m=0; m < 8; m++){
																		profile_max = max(profile_max,xb_profile[k][j][i][xbempirical_index][m]);
																		profile_min = min(profile_min,xb_profile[k][j][i][xbempirical_index][m]);
																		profile_total += xb_profile[k][j][i][xbempirical_index][m];
																}
														}
												}
												else if(profile_type == 'd'){
														if (fgets( inputline, LINE_LEN, profile_file) != NULL) {
																if(sscanf(inputline,"%f %f %f %f %f %f %f %f",
																						&xb_profile[k][j][i][xbempirical_index][0],
																						&xb_profile[k][j][i][xbempirical_index][1],
																						&xb_profile[k][j][i][xbempirical_index][2],
																						&xb_profile[k][j][i][xbempirical_index][3],
																						&xb_profile[k][j][i][xbempirical_index][4],
																						&xb_profile[k][j][i][xbempirical_index][5],
																						&xb_profile[k][j][i][xbempirical_index][6],
																						&xb_profile[k][j][i][xbempirical_index][7]) != 8)
																		continue;
																nv++;
																for(m=0; m < 4; m++){
																		profile_max = max(profile_max,xb_profile[k][j][i][xbempirical_index][2*m]);
																		profile_min = min(profile_min,xb_profile[k][j][i][xbempirical_index][2*m]);
																		profile_total += xb_profile[k][j][i][xbempirical_index][2*m];
																}
														}
												}
										}
								}
						}

						profile_stats.number = nv;
						profile_stats.minimum = profile_min;
						profile_stats.maximum = profile_max;
						if(profile_type == 'v' || profile_type == 'e')
								profile_stats.mean = profile_total / (double) (nv*8);
						else if(profile_type == 'd')
								profile_stats.mean = profile_total / (double) (nv*4);

				}
				else
				{
						fprintf(stderr,"Can not find %s\n",FileName);
						slaveExit(-1);
				}	
				//    pr( logFile, "Closing file.\n" );
				fclose( profile_file );

				//    pr( logFile, "%d energies found for %s profile\n", nv, profile_name );
				//    pr( logFile, "Minimum %s potential = %.2f,  maximum %s potential = %.2f\n\n",profile_name, profile_min, profile_name, profile_max );
				//    pr( logFile, "Time taken (s): " );

				loadEnd = times( &tms_loadEnd );
				//    pr(logFile,"readxbempiricalprofile\t");
				//    timesys( loadEnd - loadStart, &tms_loadStart, &tms_loadEnd );

				//    pr( logFile, "\n" );

				if (nv != nvExpected ) {
						prStr( message, "\n%s: wrong number of values read in. Check grid map!\n\n", programname  );
						pr_2x( stderr, logFile, message );

						jobEnd = times( &tms_jobEnd );
						M_timesys( jobEnd - jobStart, &tmsJobStart, &tms_jobEnd );
						pr_2x( logFile, stderr, UnderLine );

						/* END PROGRAM */
						slaveExit(-1);
				}

				flushLog;

				return profile_stats;
		}

		void M_initialiseState( State *S )
		{
				register int i;
				S->T.x = 0.0;
				S->T.y = 0.0;
				S->T.z = 0.0;
				M_initialiseQuat( &(S->Q) );
				S->ntor = 0;
				for (i = 0; i  < MAX_TORS;  i++ ) {
						S->tor[i] = 0.0;
				}
		}

		void M_initialiseQuat( Quat *Q )
		{
				Q->nx = 1.0;
				Q->ny = 0.0;
				Q->nz = 0.0;
				Q->ang = 0.0;
				Q->x = 0.0;
				Q->y = 0.0;
				Q->z = 0.0;
				Q->w = 1.0;
				Q->qmag = 1.0;
		}
		double M_calc_ddd_Mehler_Solmajer( double distance, double approx_zero ) {
				/*____________________________________________________________________________
				 * Distance-dependent dielectric ewds: Mehler and Solmajer, Prot Eng 4, 903-910.
				 *____________________________________________________________________________*/
				double epsilon = 1.0L;
				double lambda = 0.003627L;
				double epsilon0 = 78.4L;
				double A = -8.5525L;
				double B;
				B = epsilon0 - A;
				double rk= 7.7839L;
				double lambda_B;
				lambda_B = -lambda * B;

				epsilon = A + B / (1.0L + rk*exp(lambda_B * distance));

				if (epsilon < approx_zero) {
						epsilon = 1.0L;
				}
				return epsilon;
		}

		void M_setup_distdepdiel( int outlev,EnergyTables *ptr_ad_energy_tables )
		{
				register int i=0;
				register double distance=0.0L;

				//    if (outlev > 0) {
				//        pr(logFile, "Calculating distance-dependent dielectric function using the method of Mehler & Solmajer\n\n\n");
				//    }

				ptr_ad_energy_tables->epsilon_fn[0] = 1.0L;
				//    if (outlev > 1) {
				//        pr(logFile, "i, ptr_ad_energy_tables->epsilon_fn[i] = %d, %8.4lf\n", i, ptr_ad_energy_tables->epsilon_fn[i]);
				//    }
				for (i = 1;  i < NDIEL;  i++) {
						distance = IndexToDistance(i);
						ptr_ad_energy_tables->epsilon_fn[i] = M_calc_ddd_Mehler_Solmajer( distance, APPROX_ZERO );
						ptr_ad_energy_tables->r_epsilon_fn[i] = distance * M_calc_ddd_Mehler_Solmajer( distance, APPROX_ZERO );
						if (outlev > 1) {
								if (i%1000 == 0) {
										//                pr(logFile, "i = %5d,  distance = %7.2lf,  epsilon_fn[i] = %8.4lf,  r_epsilon_fn[i] = %8.4lf\n",
										//                        i, distance, ptr_ad_energy_tables->epsilon_fn[i], ptr_ad_energy_tables->r_epsilon_fn[i]);
								}
						}
						// pre-compute reciprocal to avoid having to do it later in eintcal.
						ptr_ad_energy_tables->r_epsilon_fn[i] = 1.0 /  ptr_ad_energy_tables->r_epsilon_fn[i];
				} // next i
		}

		void M_initialise_energy_breakdown ( EnergyBreakdown * eb,Real torsFreeEnergy, Real unbound_internal_FE )
		{
				eb->e_inter_moving_fixed = 0.0;      // (1)  // trilinterp( 0, true_ligand_atoms, ...)
				eb->e_intra_moving_fixed_rec = 0.0;  // (2)  // trilinterp( true_ligand_atoms, natom, ...)
				eb->e_intra_moving_moving_lig = 0.0; // (3)  // eintcal( 0, nb_array[0], ...)            // nb_group_energy[INTRA_LIGAND]
				eb->e_inter_moving_moving = 0.0;     // (4)  // eintcal( nb_array[0], nb_array[1], ...)  // nb_group_energy[INTER]
				eb->e_intra_moving_moving_rec = 0.0; // (5)  // eintcal( nb_array[1], nb_array[2], ...)  // nb_group_energy[INTRA_RECEPTOR]

				eb->e_inter = 0.0;                   // total    intermolecular energy = (1) + (4)
				eb->e_intra = 0.0;                   // total    intramolecular energy = (3)  +  (2) + (5)
				eb->e_intra_lig = 0.0;               // ligand   intramolecular energy = (3)
				eb->e_intra_rec = 0.0;               // receptor intramolecular energy = (2) + (5)

				eb->e_torsFreeEnergy = torsFreeEnergy;            // empirical torsional free energy penalty
				eb->e_unbound_internal_FE = unbound_internal_FE;  // computed internal free energy of the unbound state
				eb->deltaG = 0.0;                    // estimated change in free energy upon binding
		}

		void M_readPDBQTLine( char line[LINE_LEN],
						int  *ptr_serial,
						Real crd[SPACE],
						Real *ptr_q,
						ParameterEntry *this_parameter_entry )
		{
				char char8[9];
				char char6[7];
				char char5[6];
				char char2[3];
				static char message[LINE_LEN];

				// Initialise char5
				(void) strcpy( char5, "    0" );
				char5[5] = '\0';

				// Initialise char8
				(void) strcpy( char8, "   0.000" );
				char8[8] = '\0';

				// Initialise char6
				(void) strcpy( char6, "  0.00" );
				char6[6] = '\0';

				// Initialise char2
				(void) strcpy( char2, "C " );
				char2[2] = '\0';

#define check_sscanf( str, fmt, val, fieldname )  if (1 != sscanf( str, fmt, val ))  {\
		sprintf(message, "\n%s: WARNING! Could not read " fieldname " in PDBQT line \"%s\".\n", programname, line );\
		pr_2x(stderr, logFile, message); }

				// Read in the serial number of this atom
				(void) strncpy( char5, &line[6], (size_t)5 );
				char5[5] = '\0';
				check_sscanf( char5, "%d", ptr_serial, "serial number" );

				// Read in the X, Y, Z coordinates
				(void) strncpy( char8, &line[30], (size_t)8 );
				char8[8] = '\0';
				check_sscanf( char8, FDFMT, &crd[X], "x-coordinate" );

				(void) strncpy( char8, &line[38], (size_t)8 );
				char8[8] = '\0';
				check_sscanf( char8, FDFMT, &crd[Y], "y-coordinate" );

				(void) strncpy( char8, &line[46], (size_t)8 );
				char8[8] = '\0';
				check_sscanf( char8, FDFMT, &crd[Z], "z-coordinate" );

#ifdef DEBUG
				(void) fprintf(stderr, "readPDBQTLine: %s", line);
#endif				/* DEBUG */

				// partial charge, q
				(void) strncpy( char6, &line[70], (size_t)6 );
				char6[6] = '\0';
				check_sscanf( char6, FDFMT, ptr_q, "partial charge" );

				// atom type name
				(void) strncpy( char2, &line[77], (size_t)2 );
				char2[2] = '\0';
				check_sscanf( char2, "%s", this_parameter_entry->autogrid_type, "atom type" );

#undef check_sscanf

#ifdef DEBUG
				fprintf(stderr, "readPDBQTLine:  %d, %.3f, %.3f, %.3f, %.3f, %s\n", *ptr_serial, crd[X], crd[Y], crd[Z], *ptr_q,
								this_parameter_entry->autogrid_type);
#endif				/* DEBUG */
		}

		void M_mkTorTree( int   atomnumber[ MAX_RECORDS ],
						char  Rec_line[ MAX_RECORDS ][ LINE_LEN ],
						int   nrecord,

						int   tlist[ MAX_TORS ][ MAX_ATOMS ],
						int   *P_ntor,
						int   *P_ntor_ligand,

						char  *smFileName,

						char  pdbaname[ MAX_ATOMS ][ 5 ],
						Boole *P_B_constrain,
						int   *P_atomC1,
						int   *P_atomC2,
						Real  *P_sqlower,
						Real  *P_squpper,
						int   *P_ntorsdof,
						int   ignore_inter[MAX_ATOMS])
		{

				int   atomlast = 0;
				int   ii = 0;
				int   imax = 0;
				int   itor = 0;
				int   keyword_id = -1;
				int   nbranches = 0;
				int   ntor=0;
				int   tlistsort[ MAX_TORS ][ MAX_ATOMS ];
				int   found_new_res = 0;
				int   nres = 0;
				int   natoms_in_res = 0;
				int   natoms = 0;
				int   nrestor=0;
				int   found_first_res=0;

				register int   i = 0;
				register int   j = 0;
				register int   k = 0;

				char  error_message[ LINE_LEN ];
				char  rec5[ 5 ];

				Real lower = 0.;
				Real temp  = 0.;
				Real upper = 0.01;

#ifdef DEBUG
				int   oo = 0;
				char  C = 'A';
#endif /* DEBUG */

				/* ntor = *P_ntor; */

				/* TorsionTree torstree; */

				for (i = 0; i  < MAX_TORS;  i++ ) {
						for (j = 0;  j < MAX_ATOMS;  j++ ) {
								tlistsort[ i ][ j ] = 0;
						}
				}

				i = 0;
				j = 0;

				/* ________________________________________________________________
				   |  Work out the torsion angle tree.                              |
				   |________________________________________________________________|
				   |  tlist contains information on torsion angles:                 |
				   |                                                                |
				   |  tlist[ i ][ ATM1 ]           = | atom numbers defining torsion|
				   |  tlist[ i ][ ATM2 ]             |                              |
				   |  tlist[ i ][ NUM_ATM_MOVED ]  = number of atoms to be rotated  |
				   |  tlist[ i ][ 3 ] and on       = atom IDs to be rotated.        |
				   |________________________________________________________________|
				   | NOTE:  code does not explicitly check for keyword 'ROOT'.      |
				   |________________________________________________________________|
				   */

#ifdef DEBUG
				pr( logFile, "\n\n" );
				pr( logFile, "                                                  |Atoms|Total\n" );
				pr( logFile, "                                                  | 1| 2|Moved\n" );
				pr( logFile, "   Atom                                           |__|__|__|\n" );
				pr( logFile, "i  #  rec5 C atomlast nbranches j  ntor tlist[  ] [ 0| 1| 2| 3  4  5  6  7  8  9  10 11 12 13 14 15 ]\n" );
				pr( logFile, "__ __ ____ _ ________ _________ __ ____ _____________________________________________________________\n" );
#endif /* DEBUG */

				for (i = 0;  i < nrecord;  i++) {

						if ( (keyword_id = M_parse_PDBQT_line( Rec_line[ i ] )) == -1) {
								pr( logFile, "%s: Unrecognized keyword found while parsing PDBQT file, line:\n|%s|\n", programname, Rec_line[ i ] );
								continue;
						}

#ifdef DEBUG
						pr( logFile, "PDBQT-Line %d: %s", i+1, Rec_line[i] );
#endif /* DEBUG */

						switch( keyword_id ) {

								/*____________________________________________________________*/
								case PDBQ_REMARK:

										//                pr( logFile, "%s", Rec_line[ i ] );
										break;

										/*____________________________________________________________*/
								case PDBQ_NULL:

										break;

										/*____________________________________________________________*/
								case PDBQ_ATOM: 
								case PDBQ_HETATM:

										/* This is an ATOM or HETATM. */

										atomlast = atomnumber[ i ];

										if (found_new_res) {
												/* We are in a residue. */
												if (natoms_in_res < 2) {
														/* flag the first two atoms in each new 
														 * residue to prevent them being
														 * included in the intermolecular
														 * energy calculation.  */
														ignore_inter[natoms] = 1;
												}
												/* Keep counting the number of atoms in the residue. */
												natoms_in_res++;
										} else {
												/* We are not in a residue.
												 *
												 * "found_new_res" can only be reset to FALSE 
												 * if we encounter an "END_RES" record. 
												 * By default, found_new_res is set to FALSE. */

												/* reset the atom counter */
												natoms_in_res = 0;
										}
										/* Increment atom counter for all atoms in PDBQT file */
										natoms++;

#ifdef DEBUG
										C = 'A';
										PrintDebugTors;
										PrintDebugTors2;
										pr( logFile, "]\n" );
#endif /* DEBUG */

										break;

										/*____________________________________________________________*/
								case PDBQ_BRANCH:
										if (ntor >= MAX_TORS) {
												prStr( error_message, "ERROR: Too many torsions have been found (i.e. %d); maximum allowed is %d.\n Either: change the \"#define MAX_TORS\" line in constants.h\n Or:     edit \"%s\" to reduce the number of torsions defined.", (ntor+1), MAX_TORS, smFileName );
												//stop( error_message );
												slaveExit( -1 );
										}
										if (found_first_res) {
												sscanf(Rec_line[ i ],"%*s %d %*d", &nrestor );
												tlist[ ntor ][ ATM1 ]= nrestor + true_ligand_atoms;
										} else {
												sscanf(Rec_line[ i ],"%*s %d %*d", &tlist[ ntor ][ ATM1 ] );
										}
										tlist[ ntor ][ ATM2 ] = atomnumber[ i+1 ];
										--tlist[ ntor ][ ATM1 ];
										if ( tlist[ ntor ][ ATM2 ] == tlist[ ntor ][ ATM1 ]) {
												prStr( error_message, "ERROR: line %d:\n%s\nThe two atoms defining torsion %d are the same!", (i+1), Rec_line[ i ], (ntor+1) );
												//stop( error_message );
												slaveExit( -1 );
										} /* endif */
										nbranches = 0;

#ifdef DEBUG
										C = 'B';
										PrintDebugTors;
										PrintDebugTors2;
										pr( logFile, "]\n" );
#endif /* DEBUG */

										for ( j = (i+2); j < nrecord; j++) {
												for ( ii = 0; ii < 4; ii++ ) {
														rec5[ii] = (char)tolower( (int)Rec_line[ j ][ ii ] );
												}
												rec5[4] = '\0';
#ifdef DEBUG
												C = 'b';
												PrintDebugTors;
												PrintDebugTors2;
												pr( logFile, "]\n" );
#endif /* DEBUG */

												if (equal(rec5,"endb", 4) && (nbranches == 0))  break;
												if (equal(rec5,"endb", 4) && (nbranches != 0))  --nbranches;
												if (equal(rec5,"bran", 4))                      ++nbranches;
												if (equal(rec5,"atom", 4) || equal(rec5,"heta", 4)) {
														tlist[ ntor ][ tlist[ ntor ][ NUM_ATM_MOVED ] + 3 ] = atomnumber[ j ];
														++tlist[ ntor ][ NUM_ATM_MOVED ];
												} /* endif */
										} /* j */
										++ntor;

#ifdef DEBUG
										PrintDebugTors;
										PrintDebugTors2;
										pr( logFile, "]\n" );
#endif /* DEBUG */

										break;

										/*____________________________________________________________*/
								case PDBQ_TORS:

										tlist[ ntor ][ ATM2 ] = atomnumber[ i+1 ];
										tlist[ ntor ][ ATM1 ] = atomlast;
										if ( tlist[ ntor ][ ATM2 ] == tlist[ ntor ][ ATM1 ]) {
												prStr( error_message, "ERROR: line %d:\n%s\nThe two atoms defining torsion %d are the same!", (i+1), Rec_line[ i ], (ntor+1) );
												//stop( error_message );
												slaveExit( -1 );
										}
										nbranches = 0;

#ifdef DEBUG
										C = 'T';
										PrintDebugTors;
										PrintDebugTors2;
										pr( logFile, "]\n" );
#endif /* DEBUG */

										for ( j = (i+2); j < nrecord; j++) {
												for (ii = 0; ii < 4; ii++) {
														rec5[ ii ] = (char)tolower( (int)Rec_line[ j ][ ii ] );
												}
#ifdef DEBUG
												C = 't';
												PrintDebugTors;
												PrintDebugTors2;
												pr( logFile, "]\n" );
#endif /* DEBUG */

												if (equal(rec5,"endb", 4) && (nbranches == 0))  break;
												if (equal(rec5,"endb", 4) && (nbranches != 0))  --nbranches;
												if (equal(rec5,"bran", 4))                      ++nbranches;
												if (equal(rec5,"atom", 4) || equal(rec5,"heta", 4)) {
														tlist[ ntor ][ tlist[ ntor ][ NUM_ATM_MOVED ] + 3 ] = atomnumber[ j ];
														++tlist[ ntor ][ NUM_ATM_MOVED ];
												} /* endif */

#ifdef DEBUG
												PrintDebugTors;
												PrintDebugTors2;
												pr( logFile, "]\n" );
#endif /* DEBUG */

										} /* j */
										++ntor;

#ifdef DEBUG
										C = 't';
										PrintDebugTors;
										PrintDebugTors2;
										pr( logFile, "]\n" );
#endif /* DEBUG */

										break;

										/*____________________________________________________________*/
								case PDBQ_CONSTRAINT:

										sscanf(Rec_line[ i ],"%*s %d %d " FDFMT2, P_atomC1, P_atomC2, &lower, &upper);

										*P_B_constrain = TRUE;

										upper = fabs( (double)upper );
										lower = fabs( (double)lower );

										//                pr( logFile, "Constrain the distance between atom %d and atom %d to be within %.3f and %.3f Angstroms.\n\n", *P_atomC1, *P_atomC2, lower, upper);

										if (lower > upper) {
												pr( logFile, "WARNING!  The lower bound was larger than the upper bound. I will switch these around.\n\n");
												temp = upper;
												upper = lower;
												lower = temp;

										} else if (lower == upper) {
												pr( logFile, "WARNING!  The lower bound is the same as the upper bound.\n\n");
												upper += 0.01;
										}
										*P_sqlower = lower * lower;
										*P_squpper = upper * upper;
										break;

										/*____________________________________________________________*/
								case PDBQ_BEGIN_RES:
										found_new_res = 1;
										// if this is the first BEGIN_RES tag, then set the number of torsions in the ligand
										if (found_first_res == 0) {
												*P_ntor_ligand = ntor;
										}
										found_first_res++;
										natoms_in_res = 0; /* reset number of atoms in this residue */
										break;

										/*____________________________________________________________*/
								case PDBQ_END_RES:
										found_new_res = 0;
										nres++;
										//                pr(logFile, "Residue number %d has %d moving atoms.\n\n", nres, natoms_in_res-2);
										break;

										/*____________________________________________________________*/
								case PDBQ_TORSDOF:
										sscanf(Rec_line[i], "%*s %d", P_ntorsdof);
										//                pr( logFile, "\nTORSDOF record detected: number of torsional degress of freedom has been set to %d.\n", *P_ntorsdof );
										break;

										/*____________________________________________________________*/
								default:
										break;
										/*____________________________________________________________*/
						} /* switch -- finished parsing this line of PDBQT file*/
				} /* i --- do next record in PDBQT file... */

				/*
				   \   Sort Torsion list on number of atoms moved,
				   \______________________________________________________________
				   */
				// Checked for above, as well as in readPDBQT, but this is extra insurance
				if (ntor > MAX_TORS) {
						prStr( error_message, "ERROR: Too many torsions have been found (i.e. %d); maximum allowed is %d.\n Either: change the \"#define MAX_TORS\" line in constants.h\n Or:     edit \"%s\" to reduce the number of torsions defined.", (ntor+1), MAX_TORS, smFileName );
						//stop( error_message );
						slaveExit( -1 );
				} else {
						*P_ntor = ntor;
				}
				//if there are no flexible residues, still need to set P_ntor_ligand
				if (found_first_res == 0) {
						*P_ntor_ligand = ntor;
				}

#define check_atomnumber_ok( a )  (((a) >= 0) && ((a) < natoms))

				Boole B_atom_number_OK = TRUE;

				for (itor=0; itor<ntor; itor++ ) {
						B_atom_number_OK &= check_atomnumber_ok( tlist[ itor ][ ATM1 ] );
						B_atom_number_OK &= check_atomnumber_ok( tlist[ itor ][ ATM2 ] );
						if (B_atom_number_OK) for (int i=0;  i < tlist[ itor ][ NUM_ATM_MOVED ]; i++ ) {
								B_atom_number_OK &= check_atomnumber_ok( tlist[ itor ][ 3+i ] );
						}
						if (B_atom_number_OK) continue;
						pr( logFile, "%s: ERROR:  Torsion number %d between atom %d and atom %d has one or more atoms (out of %d atoms) that are out of range.\n\n", programname, itor+1, 1+tlist[itor][ATM1], 1+tlist[itor][ATM2], tlist[itor][NUM_ATM_MOVED] );
						pr( stderr, "%s: ERROR:  Torsion number %d between atom %d and atom %d has one or more atoms (out of %d atoms) that are out of range.\n\n", programname, itor+1, 1+tlist[itor][ATM1], 1+tlist[itor][ATM2], tlist[itor][NUM_ATM_MOVED] );
						slaveExit(-1);
				}

				itor = 0;
				for (i=0;  i<MAX_ATOMS;  i++) {
						for ( j=0; j<ntor; j++ ) {
								if (tlist[ j ][ NUM_ATM_MOVED ] == i) {
										for (k=0;  k<MAX_ATOMS;  k++) {
												tlistsort[ itor ][ k ] = tlist[ j ][ k ];
										}
										++itor;
								}
						}
				}
				for ( i=0; i<ntor; i++ ) {
						for (j=0;  j<MAX_ATOMS;  j++) {
								tlist[ i ][ j ] = tlistsort[ i ][ j ];
						}
				}
				if (ntor > 0) {
						for ( j=0; j<ntor; j++ ) {

						}

				} else { 

				}
		}

#define NUM_ENUM_ATOMTYPES 7 // this should be the length of the enumerated atom types above
		double mindist[NUM_ENUM_ATOMTYPES][NUM_ENUM_ATOMTYPES];
		double maxdist[NUM_ENUM_ATOMTYPES][NUM_ENUM_ATOMTYPES];
		void M_mdist() 
		{

				register int i,j;
#define BOND_LENGTH_TOLERANCE 0.1

				enum BOND_In{M_C=0,M_N=1,M_O=2,M_H=3,M_XX=4,M_P=5,M_S=6};  // see "bond_index" in the "AD4.1_bound.dat" or "AD4_parameters.dat" file.

#define set_minmax( a1, a2, min, max)  \
				mindist[(a1)][(a2)] = mindist[(a2)][(a1)] = (min)-BOND_LENGTH_TOLERANCE;\
				maxdist[(a1)][(a2)] = maxdist[(a2)][(a1)] = (max)+BOND_LENGTH_TOLERANCE

				// Set all the mindist and maxdist elements to the defaults for AutoDock versions 1 - 3...
				for (i=0; i<   NUM_ENUM_ATOMTYPES; i++) {
						for (j=0; j<   NUM_ENUM_ATOMTYPES; j++) {
								mindist[i][j] = 0.9 - BOND_LENGTH_TOLERANCE;
								maxdist[i][j] = 2.1 + BOND_LENGTH_TOLERANCE;
						}
				}

				set_minmax(M_C, M_C, 1.20, 1.545); // mindist[C][C] = 1.20, p. 3510 ; maxdist[C][C] = 1.545, p. 3511
				set_minmax(M_C, M_N, 1.1, 1.479); // mindist[C][N] = 1.1, p. 3510 ; maxdist[C][N] = 1.479, p. 3511
				set_minmax(M_C, M_O, 1.15, 1.47); // mindist[C][O] = 1.15, p. 3510 ; maxdist[C][O] = 1.47, p. 3512
				set_minmax(M_C, M_H, 1.022, 1.12);  // p. 3518, p. 3517
				set_minmax(M_C, M_XX, 0.9, 1.545); // mindist[C][XX] = 0.9, AutoDock 3 defaults ; maxdist[C][XX] = 1.545, p. 3511
				set_minmax(M_C, M_P, 1.85, 1.89); // mindist[C][P] = 1.85, p. 3510 ; maxdist[C][P] = 1.89, p. 3510
				set_minmax(M_C, M_S, 1.55, 1.835); // mindist[C][S] = 1.55, p. 3510 ; maxdist[C][S] = 1.835, p. 3512
				set_minmax(M_N, M_N, 1.0974, 1.128); // mindist[N][N] = 1.0974, p. 3513 ; maxdist[N][N] = 1.128, p. 3515
				set_minmax(M_N, M_O, 1.0619, 1.25); // mindist[N][O] = 1.0975, p. 3515 ; maxdist[N][O] = 1.128, p. 3515
				set_minmax(M_N, M_H, 1.004, 1.041); // mindist[N][H] = 1.004, p. 3516 ; maxdist[N][H] = 1.041, p. 3515
				set_minmax(M_N, M_XX, 0.9, 1.041); // mindist[N][XX] = 0.9, AutoDock 3 defaults ; maxdist[N][XX] = 1.041, p. 3515
				set_minmax(M_N, M_P, 1.4910, 1.4910); // mindist[N][P] = 1.4910, p. 3515 ; maxdist[N][P] = 1.4910, p. 3515
				set_minmax(M_N, M_S, 1.58, 1.672); // mindist[N][S] = 1.58, 1czm.pdb sulfonamide ; maxdist[N][S] = 1.672, J. Chem. SOC., Dalton Trans., 1996, Pages 4063-4069 
				set_minmax(M_O, M_O, 1.208, 1.51); // p.3513, p.3515
				set_minmax(M_O, M_H, 0.955, 1.0289); // mindist[O][H] = 0.955, p. 3515 ; maxdist[O][H] = 1.0289, p. 3515
				set_minmax(M_O, M_XX, 0.955, 2.1); // AutoDock 3 defaults
				set_minmax(M_O, M_P, 1.36, 1.67); // mindist[O][P] = 1.36, p. 3516 ; maxdist[O][P] = 1.67, p. 3517
				set_minmax(M_O, M_S, 1.41, 1.47); // p. 3517, p. 3515
				set_minmax(M_H, M_H, 100.,-100.); // impossible values to prevent such bonds from forming.
				set_minmax(M_H, M_XX, 0.9, 1.5); // AutoDock 4 defaults
				set_minmax(M_H, M_P, 1.40, 1.44); // mindist[H][P] = 1.40, p. 3515 ; maxdist[H][P] = 1.44, p. 3515
				set_minmax(M_H, M_S, 1.325, 1.3455); // mindist[H][S] = 1.325, p. 3518 ; maxdist[H][S] = 1.3455, p. 3516
				set_minmax(M_XX, M_XX, 0.9, 2.1); // AutoDock 3 defaults
				set_minmax(M_XX, M_P, 0.9, 2.1); // AutoDock 3 defaults
				set_minmax(M_XX, M_S, 1.325, 2.1); // mindist[XX][S] = 1.325, p. 3518 ; maxdist[XX][S] = 2.1, AutoDock 3 defaults
				set_minmax(M_P, M_P, 2.18, 2.23); // mindist[P][P] = 2.18, p. 3513 ; maxdist[P][P] = 2.23, p. 3513
				set_minmax(M_P, M_S, 1.83, 1.88); // mindist[P][S] = 1.83, p. 3516 ; maxdist[P][S] = 1.88, p. 3515
				set_minmax(M_S, M_S, 2.03, 2.05); // mindist[S][S] = 2.03, p. 3515 ; maxdist[S][S] = 2.05, p. 3515
				/* end values from Handbook of Chemistry and Physics */
		}

		void M_quicksort( Real e[],int isort[],int left,int right )
		{
				int i, last;

#ifdef DEBUG
				char array[101];
#endif  /* DEBUG */

				if (left >= right) {
						return;
				}

#ifdef DEBUG
				strncpy( array, "----------------------------------------------------------------------------------------------------", (size_t)100 );
				array[100] = '\0';
				for (i=left+1; i<right; i++) array[i]=' ';
				array[left] = 'L';
				array[right] = 'R';
				fprintf( logFile, "%s\n", array );
#endif  /* DEBUG */

				M_swap( isort, left, (left+right)/2 );

				last = left;

				for (i = left+1; i <= right; i++) {
						if (e[isort[i]] < e[isort[left]]) {
								M_swap( isort, ++last, i );
						}
				}

				M_swap( isort, (int)left, (int)last );

				M_quicksort( e, isort, left,  last-1 );
				M_quicksort( e, isort, last+1, right  );
		}

		void M_getbonds(const Real crdpdb[MAX_ATOMS][SPACE],const int from_atom,const int to_atom,
						const int bond_index[MAX_ATOMS],int   bonded[MAX_ATOMS][6])
		{
				int i,j;
				double dist,dx,dy,dz;
				Real distance[MAX_ATOMS];
				int isort[MAX_ATOMS];

				// set up all the minimum and maximum possible distances for bonds
				M_mdist();

				// determine the bonded atoms or "1-2 interactions"

				// loop over atoms, "i", from "from_atom" to "to_atom"
				for (i = from_atom;  i < to_atom;  i++) {

						// compute the distance to all the atoms
						for (j = i+1; j < to_atom; j++) {
								isort[j] = j;
						}
						for (j = i+1; j < to_atom; j++) {
								dx = crdpdb[i][X] - crdpdb[j][X];
								dy = crdpdb[i][Y] - crdpdb[j][Y];
								dz = crdpdb[i][Z] - crdpdb[j][Z];
								distance[j] = sqrt(dx*dx + dy*dy + dz*dz);  // calculate the distance from "i" to "j"
						}
						// sort by distance
						M_quicksort( distance, isort, i+1, to_atom-1 );

						// loop over the remaining atoms, from closest to furthest...
						// while on atom "i", loop over atoms "j_index", from "i+1" to "to_atom"
						for (int j_index = i+1;  j_index < to_atom;  j_index++) {

								// the isort array points to the indices sorted by distance
								j = isort[ j_index ];

								// find the shortest distance
								dist = distance[ j ];

								// if distance from "i" to "j" is in range for their atom types, 
								// set one of the atoms to which "i" is bonded to "j", and vice-versa.
								if (dist >= mindist[bond_index[i]][bond_index[j]] && 
												dist <= maxdist[bond_index[i]][bond_index[j]]) {  

										// bonded[x][5] is the current number of bonds that atom "x" has.
										// Remember:   int bonded[MAX_ATOMS][6];	

										if ((bonded[i][5] >= 5) || (bonded[j][5] >= 5)) {
												if (bonded[i][5] >= 5) {
														// bonded array for the i-th atom is full; we could return a failure code here.
														fprintf( logFile, "%s: WARNING!  Atom %d has too many bonds (%d is the maximum)!\n\n", programname, i, 5 );
												} else {
														// bonded array for the j-th atom is full; we could return a failure code here.
														fprintf( logFile, "%s: WARNING!  Atom %d has too many bonds (%d is the maximum)!\n\n", programname, j, 5 );
												}
												// Skip the addition of this bond, between i and j, and go onto the next j-th atom
												continue;
										}

										// add a bond between i and j
										bonded[i][ bonded[i][5] ] = j;
										bonded[j][ bonded[j][5] ] = i;
										// increment the number of bonds to i and j
										bonded[i][5] += 1;
										bonded[j][5] += 1;

								} //  dist is in bonding range for these atom types
						} //  j
				} //  i

				return;
		} // end of get bonds

		void M_printbonds(const int natom, const int bonded[MAX_ATOMS][6], const char *message, const int B_print_all_bonds)
		{
				register int i, j;
				pr(logFile, message);
				for (i = 0; i<natom; i++) {  // loop over atoms, "i", from 1 to natom
						pr(logFile, "DEBUG:  atom %d  bonded to ", i+1);
						if (B_print_all_bonds == 1) {
								for (j=0; j<6; j++) {  // loop over all the slots for this atom's "j" bonds
										pr(logFile, "  %d", bonded[i][j]+1);
								} // j
						} else {
								for (j=0; j<bonded[i][5]; j++) {  // loop over this atom's "j" bonds
										pr(logFile, "  %d", bonded[i][j]+1);
								} // j
						}
						pr(logFile, "\n");
				} // i
		}

		void M_nonbonds(const Real  crdpdb[MAX_ATOMS][SPACE],
						int         nbmatrix[MAX_ATOMS][MAX_ATOMS],
						const int   natom, 
						const int   bond_index[MAX_ATOMS],
						int         B_include_1_4_interactions,
						int         bonded[MAX_ATOMS][6])
		{
				int i,j,k,l;
				int nonbond_type;

				if (debug>0) {
						M_printbonds(natom, bonded, "\nDEBUG:  3. INSIDE nonbonds, bonded[][] array is:\n\n", 0);
				}

				//
				// in "nbmatrix", the values 1 (and 4) mean this pair of atoms will be included in the internal, non-bonded list
				//                           0                                         ignored

				// set all nonbonds in nbmatrix to 1, except "1-1 interactions" (self interaction)
				for (i = 0; i<MAX_ATOMS; i++) {
						for (j = 0; j<MAX_ATOMS; j++){
								nbmatrix[i][j] = 1;
						} // j
						nbmatrix[i][i] = 0; /* 2005-01-10 RH & GMM */
				} // i

				for (i = 0; i<natom; i++) {  // loop over atoms, "i", from 1 to natom
						for (j=0; j<bonded[i][5]; j++) {  // loop over this atom's "j" bonds
								// Ignore 1-2 Interactions
								nbmatrix[ i            ][ bonded[i][j] ] = 0;
								nbmatrix[ bonded[i][j] ][ i            ] = 0;
						} // j
				} // i

				for (i=0; i<natom; i++) {  // loop over all the atoms, "i"; there are "natom" atoms
						for (j=0; j<bonded[i][5]; j++) {  // loop over all the atoms "j" bonded to the current atom, "i"; there are "bonded[i][5]" bonded atoms
								for (k=0; k<bonded[bonded[i][j]][5]; k++) {  // loop over each atom "k" bonded to the current atom "j"

										// Ignore "1-3 Interactions"
										nbmatrix[bonded[bonded[i][j]][k]][i] = 0;
										nbmatrix[i][bonded[bonded[i][j]][k]] = 0;

										if (B_include_1_4_interactions == FALSE) {
												// include is FALSE,  i.e.: ignore
												// Ignore "1-4 Interactions"
												nonbond_type = 0;
										} else {
												// remember that this is a 1-4 interaction so we can scale it later...
												// Remember "1-4 Interactions"
												nonbond_type = 4;
										} //  end if we are ignoring "1-4 interactions"

										// Loop over each atom "l" bonded to the atom "k" bonded to the atom "j" bonded to the atom "i"...
										if (debug>0) {
												(void)fprintf(logFile, "bonded[ %d ][ %d ] = %d\n", bonded[i][j], k, bonded[bonded[i][j]][k] );
												(void)fprintf(logFile, "bonded[ %d ][ 5 ] = %d\n", bonded[bonded[i][j]][k], bonded[bonded[bonded[i][j]][k]][5] );
										}
										// validate the bonded[][] values before they used as indices in the for l-loop.
										if (bonded[i][j] < 0) {
												(void)fprintf(logFile, "%s:  WARNING! The count of bonds, %d, to atom %d does not match the list of bonded atoms.\n\n", programname, bonded[i][5], i);
												(void)fprintf(logFile, "%s:  WARNING! bonded[%d][] = %d, %d, %d, %d, %d, %d.\n\n", programname, i, bonded[i][0], bonded[i][1], bonded[i][2], bonded[i][3], bonded[i][4], bonded[i][5]);
												continue;
										}
										if (bonded[ bonded[i][j] ][k] < 0) {
												(void)fprintf(logFile, "%s:  WARNING! The count of bonds, %d, to atom %d does not match the list of bonded atoms.\n\n", programname, bonded[bonded[i][j]][5], bonded[i][j]);
												(void)fprintf(logFile, "%s:  WARNING! bonded[%d][] = %d, %d, %d, %d, %d, %d.\n\n", programname, bonded[i][j], bonded[bonded[i][j]][0], bonded[bonded[i][j]][1], bonded[bonded[i][j]][2], bonded[bonded[i][j]][3], bonded[bonded[i][j]][4], bonded[bonded[i][j]][5]);
												continue;
										}
										for (l=0; l<bonded[bonded[bonded[i][j]][k]][5]; l++) { 
												nbmatrix[i][bonded[bonded[bonded[i][j]][k]][l]] = nonbond_type;
												nbmatrix[bonded[bonded[bonded[i][j]][k]][l]][i] = nonbond_type;
										} //  l

								} //  k
						} //  j
				} //  i
				return;
		} // end of nonbonds

		void M_weedbonds( int natom,
						char pdbaname[MAX_ATOMS][5],
						int rigid_piece[MAX_ATOMS],
						int ntor,
						int tlist[MAX_TORS][MAX_ATOMS],
						int nbmatrix[MAX_ATOMS][MAX_ATOMS],
						int *Addr_Nnb,
						NonbondParam *nonbondlist,
						int outlev,
						int type[MAX_ATOMS] )

		{
				int a11=0;
				int a12=0;
				int a21=0;
				int a22=0;
				int p11 = 0;
				int p12 = 0;
				int p21 = 0;
				int p22 = 0;
				int p = 0;
				int Nnb = 0;

				register int i = 0;
				register int j = 0;
				register int k = 0;

				char error_message[LINE_LEN];

				for (j = 0;  j < natom;  j++) {
						for (i = 0;  i < natom;  i++) {
								// Is atom "i" in the same rigid piece as atom "j"?
								if (rigid_piece[i] == rigid_piece[j]) {
										// Set the entry for atoms "i" and "j" in the
										//    nonbond matrix to 0 ;
										// 
										// Later on, we will not calculate the interaction energy
										//    between atoms "i" and "j"
										nbmatrix[j][i] = nbmatrix[i][j] = 0;
								}
						} // i
				} // j

				/* 
				   \   Weed out bonds across torsions,
				   \______________________________________________________________
				   */
				// Loop over all "ntor" torsions, "i"
				for (i=0; i<ntor; i++) {
						nbmatrix[ tlist[i][ATM2] ][ tlist[i][ATM1] ] = 0;

						if (debug>0) {
								pr(logFile, "DEBUG: Inside weedbonds now; torsion i=%d, outlev is set to %d.\n\n", i, outlev);
						}
#ifdef DEBUG
						pr( logFile, "__2__ i=%-2d: nbmatrix[tlist[%-2d][ATM2]=%-2d][tlist[%-2d][ATM1]=%-2d]=%d\n",i,i,tlist[i][ATM2],i,tlist[i][ATM1],nbmatrix[tlist[i][ATM2]][tlist[i][ATM1]]);
#endif // DEBUG

				} // i

				/* 
				   \  Weed out bonds from atoms directly connected to rigid pieces,
				   \_ we think these are 1-3 interactions mp+rh, 10-2008______________________
				   */
				for (i=0; i<ntor; i++) {

						a11 = tlist[i][ATM1];
						a21 = tlist[i][ATM2];
						p11 = rigid_piece[a11];
						p21 = rigid_piece[a21];

						for (j=0; j<ntor; j++) {

								a12 = tlist[j][ATM1];
								a22 = tlist[j][ATM2];
								p12 = rigid_piece[a12];
								p22 = rigid_piece[a22];

								if (p11 == p12)  { nbmatrix[ a22 ][ a21 ] = nbmatrix[ a21 ][ a22 ] = 0; }
								if (p11 == p22)  { nbmatrix[ a12 ][ a21 ] = nbmatrix[ a21 ][ a12 ] = 0; }
								if (p21 == p12)  { nbmatrix[ a22 ][ a11 ] = nbmatrix[ a11 ][ a22 ] = 0; }
								if (p21 == p22)  { nbmatrix[ a12 ][ a11 ] = nbmatrix[ a11 ][ a12 ] = 0; }

						} // j

						for (k = 0;  k < natom;  k++) {
								p = rigid_piece[k];
								if (p11 == p)  { nbmatrix[ k ][ a21 ] = nbmatrix[ a21 ][ k ] = 0; }
								if (p21 == p)  { nbmatrix[ k ][ a11 ] = nbmatrix[ a11 ][ k ] = 0; }
						} // k
				} // i

				// intramolecular non-bonds for ligand
				for ( i = 0;  i < (true_ligand_atoms-1);  i++ ) {
						for ( j = i+1;  j < true_ligand_atoms;  j++ ) {
								if ( ((nbmatrix[i][j] == 1) && (nbmatrix[j][i] == 1)) || ((nbmatrix[i][j] == 4) && (nbmatrix[j][i] == 4)) ) {
										nonbondlist[Nnb].a1 = i;
										nonbondlist[Nnb].a2 = j;
										nonbondlist[Nnb].t1 = type[i];
										nonbondlist[Nnb].t2 = type[j];
										nonbondlist[Nnb].nonbond_type = nbmatrix[i][j];
										++Nnb;
								} else if ( (nbmatrix[i][j] != 0) && (nbmatrix[j][i] == 0) || (nbmatrix[i][j] == 0) && (nbmatrix[j][i] != 0) ) {
										pr( logFile, "ERROR: ASSYMMETRY detected in Non-Bond Matrix at %d,%d\n", i,j);
								}
						} // j
				} // i
				Nnb_array[INTRA_LIGAND] = Nnb;

				// intermolecular non-bonds for ligand,receptor
				for ( i = 0;  i < true_ligand_atoms;  i++ ) {
						for ( j = true_ligand_atoms;  j < natom;  j++ ) {
								if ( ((nbmatrix[i][j] == 1) && (nbmatrix[j][i] == 1)) || ((nbmatrix[i][j] == 4) && (nbmatrix[j][i] == 4)) ) {
										nonbondlist[Nnb].a1 = i;
										nonbondlist[Nnb].a2 = j;
										nonbondlist[Nnb].t1 = type[i];
										nonbondlist[Nnb].t2 = type[j];
										nonbondlist[Nnb].nonbond_type = nbmatrix[i][j];
										++Nnb;
								} else if ( (nbmatrix[i][j] != 0) && (nbmatrix[j][i] == 0) || (nbmatrix[i][j] == 0) && (nbmatrix[j][i] != 0) ) {
										pr( logFile, "ERROR: ASSYMMETRY detected in Non-Bond Matrix at %d,%d\n", i,j);
								}
						} // j
				} // i
				Nnb_array[INTER] = Nnb;

				// intramolecular non-bonds for receptor
				for ( i = true_ligand_atoms;  i < natom-1;  i++ ) {
						for ( j = i+1;  j < natom;  j++ ) {
								if ( ((nbmatrix[i][j] == 1) && (nbmatrix[j][i] == 1)) || ((nbmatrix[i][j] == 4) && (nbmatrix[j][i] == 4)) ) {
										nonbondlist[Nnb].a1 = i;
										nonbondlist[Nnb].a2 = j;
										nonbondlist[Nnb].t1 = type[i];
										nonbondlist[Nnb].t2 = type[j];
										nonbondlist[Nnb].nonbond_type = nbmatrix[i][j];
										++Nnb;
								} else if ( (nbmatrix[i][j] != 0) && (nbmatrix[j][i] == 0) || (nbmatrix[i][j] == 0) && (nbmatrix[j][i] != 0) ) {
										pr( logFile, "ERROR: ASSYMMETRY detected in Non-Bond Matrix at %d,%d\n", i,j);
								}
						} // j
				} // i
				Nnb_array[INTRA_RECEPTOR] = Nnb;

				if (Nnb > MAX_NONBONDS) {
						prStr( error_message, "too many non-bonded interactions (%d) in small molecule\n\t(increase MAX_NONBONDS from %d).", Nnb, MAX_NONBONDS );
						//stop( error_message );
						slaveExit( -1 );
				} else {
						*Addr_Nnb = Nnb;
				}

				flushLog;

		} // weedbonds

		void M_success( char *hostnm,
						Clock jobStart,
						struct tms tms_jobStart )
		{
				char message[LINE_LEN];
				Clock jobEnd;
				struct tms tms_jobEnd;

				pr_2x( logFile, stderr, "\n" );
				pr_2x( logFile, stderr, UnderLine );
				prStr( message, "%s: Successful Completion on \"%s\"\n\n", programname, hostnm );
				pr_2x( logFile, stderr, message );

				jobEnd = times( &tms_jobEnd );

				M_timesyshms( jobEnd - jobStart, &tms_jobStart, &tms_jobEnd );

				pr_2x( logFile, stderr, UnderLine );
		}

		Molecule M_readPDBQT(char input_line[LINE_LEN],
						int num_atom_maps,

						int *P_natom,
						Real crdpdb[MAX_ATOMS][NTRN],
						Real crdreo[MAX_ATOMS][NTRN],
						Real charge[MAX_ATOMS],
						Boole * P_B_haveCharges,
						int map_index[MAX_ATOMS], //was:int type[MAX_ATOMS]
						int bond_index[MAX_ATOMS],
						char pdbaname[MAX_ATOMS][5],

						char *FN_ligand,
						char *FN_flexres,
						Boole B_have_flexible_residues,

						char atomstuff[MAX_ATOMS][MAX_CHARS],
						int *P_n_heavy_atoms_in_ligand,

						Boole * P_B_constrain,
						int *P_atomC1,
						int *P_atomC2,
						Real *P_sqlower,
						Real *P_squpper,

						int *P_ntor1,
						int *P_ntor,
						int *P_ntor_ligand,   // the number of torsions in the ligand (excluding the flexible residues in receptor)
						int tlist[MAX_TORS][MAX_ATOMS],
						Real vt[MAX_TORS][NTRN],

						int *P_Nnb,
						NonbondParam *nonbondlist,

						Clock jobStart,
						struct tms tms_jobStart,
						char *hostnm,
						int *P_ntorsdof,
						int outlev,
						int ignore_inter[MAX_ATOMS],
						int B_include_1_4_interactions,

						Atom atoms[MAX_ATOMS],
						char PDBQT_record[MAX_RECORDS][LINE_LEN],

						int end_of_branch[MAX_TORS]
								)
								{
										FILE           *FP_ligand;
										FILE           *FP_flexres;
										static char     dummy[LINE_LEN];
										static char     error_message[LINE_LEN];
										static char     message[LINE_LEN];

										Real   aq = 0.;
										Real   lq = 0.;
										Real   total_charge_ligand = 0.;
										Real   uq = 0.;

										int             branch_last_piece[MAX_TORS+2];//0 unused, 1 means ROOT
										static int      atomnumber[MAX_RECORDS];
										int             iq = 0;
										int             natom = 0;
										static int      nbmatrix[MAX_ATOMS][MAX_ATOMS];
										int             nrecord = 0;
										int             nligand_record = 0;
										int             ntor = 0;
										static int      ntype[MAX_ATOMS];
										static int      rigid_piece[MAX_ATOMS];
										int             keyword_id = -1;
										int             nres = 0;
										int             nrigid_piece = 0;
										int             piece; 

										Boole           B_found_begin_res = FALSE; //tracks whether any flexres found
										Boole           B_found_first_flexres = FALSE; //tracks whether first flexres ROOT found
										Boole           B_has_conect_records = FALSE;
										Boole           B_is_in_branch = FALSE;
										Boole           B_is_in_flexres = FALSE;

										int             bonded[MAX_ATOMS][6];

										register int    i = 0;
										register int    j = 0;

										static Real QTOL = 0.050;//rh increased from 0.005 4/2009

										// Definitions to help determine the end_of_branch array for "Branch Crossover Mode".
										// The "end_of_branch" array is like a dictionary, where the index corresponds to the key
										// and is the number of the torsion to be crossed over, while the value is the number
										// of the first torsion after the last torsion in the sub-tree (or "branch") being exchanged.
										M_stack s;  // Stack used to determine the values for the end_of_branch[] array
										int parent;  

										Molecule        mol;

										ParameterEntry  this_parameter_entry;

										for (i = 0; i < MAX_RECORDS; i++) {
												atomnumber[i] = 0;
										}

										for (i = 0; i < MAX_ATOMS; i++) {
												ntype[i] = 0;
												rigid_piece[i] = 0;
										}

										for (i = 0; i < MAX_TORS+2; i++) {
												branch_last_piece[i] = 0;//0 unused, 1 means ROOT
										}

										// Create the stack
										s = M_stack_create( MAX_TORS+2 );
										if (debug > 0) {
												pr(logFile, "DEBUG: 170:  stack_create(%d)\n", MAX_TORS+2 );
										}

										// Initialize the stack
										piece = -1; // "sentinel" value
										M_stack_push(s, piece);
										if (debug > 0) {
												pr(logFile, "DEBUG: 176:  stack_push(s, %d)\n", piece );
										}

										//  Attempt to open the ligand PDBQT file...
										sscanf(input_line, "%*s %s", FN_ligand);	
										char pdbqtName[260]={'\0'};
										int pdbqtN;
										for(pdbqtN=0;dlgName[pdbqtN]!='.';pdbqtN++);
										strncpy(pdbqtName,dlgName,pdbqtN);
										pdbqtName[pdbqtN]='\0';
										strcat(pdbqtName,".pdbqt");
										strcpy(FN_ligand,pdbqtName);
										//if (openFile(FN_ligand, "r", &FP_ligand, jobStart, tms_jobStart, TRUE)) {
										//		pr(logFile, "Ligand PDBQT file = \"%s\"\n\n", FN_ligand);
										//}
										//if (openfile(FN_ligand, "r", &FP_ligand)){}
										if((FP_ligand=fopen(FN_ligand,"r"))==NULL)
										{
												fprintf(stderr,"Can not find %s\n",FN_ligand);
												slaveExit(-1);
										}
										if (B_have_flexible_residues) {
												//  Attempt to open the flexible residue PDBQT file...
												//if (openFile(FN_flexres, "r", &FP_flexres, jobStart, tms_jobStart, TRUE)) {
												//            pr(logFile, "Flexible Residues PDBQT file = \"%s\"\n\n", FN_flexres);
												//}
												//if(openfile(FN_flexres, "r", &FP_flexres)){}
												if((FP_flexres=fopen(FN_ligand,"r"))==NULL)
												{
														fprintf(stderr,"Can not find %s\n",FN_flexres);
														slaveExit(-1);
												}
										}

										//  Count the number of records in the Ligand PDBQT file first...
										nligand_record = 0;
										while (fgets(dummy, LINE_LEN, FP_ligand) != NULL) {
												++nligand_record;
										}
										(void) fclose(FP_ligand);

										nrecord = nligand_record;

										if (B_have_flexible_residues) {
												//  Count the number of records in the Flexible Residue PDBQT file next, 
												//  but don't reset the counter...
												while (fgets(dummy, LINE_LEN, FP_flexres) != NULL) {
														++nrecord;
												}
												(void) fclose(FP_flexres);
										}

										// Set the nrecord-th entry of PDBQT_record to NULL, aka '\0'
										(void) strcpy(PDBQT_record[nrecord], "\0");

										// Read in the PDBQT file(s) if there are not too many records
										if (nrecord > MAX_RECORDS) {
												prStr(error_message, "ERROR: %d records read in, but only dimensioned for %d.\nChange \"MAX_RECORDS\" in \"constants.h\".", nrecord, MAX_RECORDS);
												//stop(error_message);
												slaveExit(-1);
										} else {
												// Read in the input Ligand PDBQT file...
												//if (openFile(FN_ligand, "r", &FP_ligand, jobStart, tms_jobStart, TRUE)) {
												//if (openfile(FN_ligand, "r", &FP_ligand)) 
												if((FP_ligand=fopen(FN_ligand,"r"))!=NULL)
												{
														//			pr(logFile,   "INPUT LIGAND PDBQT FILE:");
														//			pr(logFile, "\n________________________\n\n");
														for (i = 0; i < nligand_record; i++) {
																if (fgets(PDBQT_record[i], LINE_LEN, FP_ligand) != NULL) {
																		//					pr(logFile, "INPUT-LIGAND-PDBQT: %s", PDBQT_record[i]);
																}
														} // i
														//			pr(logFile, UnderLine);
												} // if
												else
												{
														fprintf(stderr,"Can not find %s\n",FN_ligand);
														slaveExit(-1);
												}

												(void) fclose(FP_ligand);

												if (B_have_flexible_residues) {
														// Read in the input Flexible Residues PDBQT file...
														//if (openFile(FN_flexres, "r", &FP_flexres, jobStart, tms_jobStart, TRUE)) {
														//if (openfile(FN_flexres, "r", &FP_flexres)) 
														if((FP_flexres=fopen(FN_flexres, "r"))!=NULL)
														{
																//                pr(logFile,   "INPUT FLEXIBLE RESIDUES PDBQT FILE:");
																//                pr(logFile, "\n___________________________________\n\n");
																for (i = nligand_record; i < nrecord; i++) {
																		if (fgets(PDBQT_record[i], LINE_LEN, FP_flexres) != NULL) {
																				//                        pr(logFile, "INPUT-FLEXRES-PDBQT: %s", PDBQT_record[i]);
																		}
																} // i
																//                pr(logFile, UnderLine);
														} // if
														else
														{
																fprintf(stderr,"Can not find %s\n",FN_flexres);
																slaveExit(-1);
														}

														(void) fclose(FP_flexres);
												}

												} // if

												// Count the ATOMs and HETATMs; store the (x,y,z) coordinates...
												// Also, check for any BEGIN_RES records, for receptor flexibility...
												//	pr(logFile, "\nDetermining Atom Types and Parameters for the Moving Atoms\n");
												//	pr(logFile,   "__________________________________________________________\n\n");
												natom = 0;
												//debug = 1;

												// Loop over all the lines in either the ligand or the "reconstructed" combined-ligand-flexible-residues file
												for (i = 0; i < nrecord; i++) {
														strncpy(input_line, PDBQT_record[i], (size_t) LINE_LEN);
														// Parse this line in the ligand file
														keyword_id = M_parse_PDBQT_line(input_line);

														switch ( keyword_id ) {
																case PDBQ_ATOM:
																case PDBQ_HETATM:
																		if ( ! B_is_in_branch ) {
																				// Flag this as an error
																				// Incorrectly nested BRANCH/ENDBRANCH records
																				pr( logFile, "%s: ERROR:  All ATOM and HETATM records must be given before any nested BRANCHes; see line %d in PDBQT file \"%s\".\n\n", programname, i+1, FN_ligand);
																				pr( stderr, "%s: ERROR:  All ATOM and HETATM records must be given before any nested BRANCHes; see line %d in PDBQT file \"%s\".\n\n", programname, i+1, FN_ligand);
																				slaveExit( -1 );
																		}

																		// Check that the line is at least 78 characters long
																		if (strlen(input_line) < 78) {
																				pr(logFile, "%s: FATAL ERROR: line %d is too short!\n", programname, i+1);
																				pr(logFile, "%s: FATAL ERROR: line \"%s\".\n", programname, input_line);
																				pr(stderr, "%s: FATAL ERROR: line %d is too short!\n", programname, i+1);
																				pr(stderr, "%s: FATAL ERROR: line \"%s\".\n", programname, input_line);
																				slaveExit(-1);
																		}

																		ParameterEntry * found_parm;
																		int serial;

																		// Set up rigid_piece array by reading in the records of the PDBQT file;
																		// each "rigid_piece" is a self-contained rigid entity.
																		rigid_piece[natom] = piece;

																		M_readPDBQTLine(input_line, &serial, crdpdb[natom], &charge[natom], &this_parameter_entry);

																		// Set the serial atomnumber[i] for this atom
																		atomnumber[i] = natom;

																		for (j = 0; j < NTRN; j++) {
																				mol.crdpdb[natom][j] = crdpdb[natom][j];
																				mol.crd[natom][j] = crdpdb[natom][j];
																				// crdreo[natom][j] = crdpdb[natom][j];
																				/************************
																				// YTLIU_EDIT 2013.01.25
																				 ************************/
																				atoms[natom].crdpdb[j] = crdpdb[natom][j];
																		}

																		if (!B_found_begin_res) {
																				// Only accumulate charges on the ligand...
																				total_charge_ligand += charge[natom];
																		}
																		*P_B_haveCharges = TRUE;

																		strncpy(atomstuff[natom], input_line, (size_t) 30);
																		atomstuff[natom][30] = '\0';
																		strcpy(mol.atomstr[natom], atomstuff[natom]);

																		sscanf(&input_line[12], "%s", pdbaname[natom]);

																		// "map_index" is used as an index into the AutoGrid "map" array to look up 
																		// the correct energies in the current grid cell, thus:	map[][][][map_index[natom]]
																		map_index[natom] = -1;

																		/************************
																		// YTLIU_EDIT 2013.01.25
																		 ************************/
																		atoms[natom].has_charge = TRUE;
																		atoms[natom].charge = charge[natom];
																		atoms[natom].serial = natom + 1;
																		strcpy(atoms[natom].name, pdbaname[natom]);
																		strcpy(atoms[natom].stuff, atomstuff[natom]);		

																		// Find the AutoDock 4 atom type for the current atom.
																		// "apm_find" is the new AutoDock 4 atom typing mechanism
																		found_parm = M_apm_find(this_parameter_entry.autogrid_type);
																		if (found_parm != NULL) {

																				/************************
																				// YTLIU_EDIT 2013.01.25
																				 ************************/
																				strcpy(atoms[natom].type_string, found_parm->autogrid_type);

																				// We found the atom type and its parameters
																				map_index[natom] = found_parm->map_index;
																				bond_index[natom] = found_parm->bond_index;
																		} else {
																				// We could not find this parameter -- return an error
																				prStr(message, "\n%s: *** WARNING!  Unknown atom type \"%s\" found.  You should add parameters for it to the parameter library first! ***\n\n", programname, this_parameter_entry.autogrid_type);
																				pr_2x(stderr, logFile, message);
																		}

																		if (map_index[natom] == -1) {
																				prStr(message, "%s: WARNING: the atom type (%s) of atom number %d could not be found;\n\tcheck that this atom type is listed after the \"ligand_types\" keyword in the DPF,\n\tand make sure to add a \"map\" keyword to the DPF for this atom type.\n\tNote that AutoDock will use the default atom type = 1, instead.\n\n", programname, this_parameter_entry.autogrid_type, natom+1);
																				pr_2x(stderr, logFile, message);
																				map_index[natom] = 0; // we are 0-based internally, 1-based in printed output
																		}

																		// Increment the number of atoms having this atomtype
																		++ntype[map_index[natom]];

																		// Increment the number of atoms found in PDBQT file
																		++natom;

																		// Increment the number of non-hydrogen atoms in the ligand
																		if (!B_found_begin_res) {
																				if ( ! is_hydrogen_type( found_parm->autogrid_type ) ) {
																						//(void) fprintf(logFile, "DEBUG!!! is not a hydrogen atom.  Incrementing number of heavy atoms in ligand.\n");
																						++(*P_n_heavy_atoms_in_ligand);
																				}
																		}
																		break;

																case PDBQ_ROOT:
																		B_is_in_branch = TRUE;
																		if (!B_is_in_flexres ){
																				++nrigid_piece; //allocate a new rigid body for ligand root atoms 
																				piece = nrigid_piece; //CAUTION: ligand root must have value 1
																		}
																		else if  (!B_found_first_flexres) {
																				// allocate a new rigid body for FIRST flexres root atoms 
																				// Subsequent flexres root atoms will use this same piece
																				// number (so we do not run out of rigid body pieces (NTORS))
																				B_found_first_flexres = TRUE;
																				++nrigid_piece; 
																				piece = nrigid_piece; //CAUTION: 
																		}
																		M_stack_push(s, piece);
																		break;

																case PDBQ_BRANCH:
																		B_is_in_branch = TRUE;
																		if (nrigid_piece>MAX_TORS){
																				prStr(error_message, "PDBQT ERROR: too many torsions, maximum number of torsions is %d", MAX_TORS);
																				//stop(error_message);
																				slaveExit(-1);
																		}
																		M_stack_push(s, piece);//at this pt push the parent piece number
																		++nrigid_piece; //allocate a new rigid body for this branch
																		piece = nrigid_piece;
																		break;

																case PDBQ_ENDROOT:
																		B_is_in_branch = FALSE;
																		(void) M_stack_pop(s);
																		break;

																case PDBQ_ENDBRANCH:
																		B_is_in_branch = FALSE;
																		//end_of_branch[ piece ] = max( end_of_branch[ piece ], piece);
																		branch_last_piece[ piece ] = max( branch_last_piece[ piece ], piece);
																		parent = M_stack_pop(s);
																		if (parent < 0) {
																				pr(logFile,   "PDBQT ERROR: Encountered end of branch without corresponding branch");
																				prStr(error_message, "PDBQT ERROR: Encountered end of branch without corresponding branch");
																				//stop(error_message);
																				slaveExit(-1);
																		}
																		if (parent>1){ 
																				branch_last_piece[parent ] = max( branch_last_piece[parent ], branch_last_piece[piece ] );
																		} 
																		piece = parent;
																		break;

																case PDBQ_NULL:
																case PDBQ_REMARK:
																case PDBQ_TORS:
																case PDBQ_ENDTORS:
																case PDBQ_TORSDOF:
																case PDBQ_CONSTRAINT:
																		break;

																case PDBQ_CONECT:
																		// At least some of the atoms in the "ligand" may have their connectivity specified
																		// so we could set up their bonded entries. For future versions...
																		B_has_conect_records = TRUE;
																		break;

																case PDBQ_BEGIN_RES:
																		// Then a flexible receptor sidechain was found in the PDBQ file.
																		// Flag that we've found a BEGIN_RES record.
																		B_found_begin_res = TRUE;
																		//                if (debug > 0) {
																		//                    pr(logFile, "DEBUG: 457: BEGIN_RES\n");
																		//                }
																		// Increment the number of residues
																		nres++;
																		B_is_in_flexres = TRUE;
																		break;

																case PDBQ_END_RES:
																		B_is_in_flexres = FALSE;
																		break;

																case PDBQ_UNRECOGNIZED:
																default:
																		pr(logFile, "%s: WARNING: Unrecognized PDBQT record type in line:\n", programname );
																		pr(logFile, "%s: WARNING: %s\n", programname, input_line );
																		break;

														} // end switch( keyword_id )

														if (!B_found_begin_res) {
																true_ligand_atoms = natom;
														}

												} // i, next record in PDBQT file 

												//check for mismatched BRANCH/ENDBRANCH records
												// specifically:
												// stack_pop should return the sentinel ie -1
												if (B_is_in_branch || -1 != M_stack_pop(s)){
														prStr(error_message, "ERROR: BRANCH statement without a corresponding ENDBRANCH\n\n");
														//stop(error_message);
														slaveExit(-1);
												}

												for (j = 0; j < nrigid_piece-1; j++)  {
														end_of_branch[j] = branch_last_piece[j+2]-1; 
														if (end_of_branch[j] <0) {
																prStr(error_message, "ERROR: end_of_branch[%d] < 0 (%d)\n", j, end_of_branch[j]);
																//stop(error_message);
																slaveExit(-1);
														}
												}

												if (natom > MAX_ATOMS) {
														prStr(error_message, "ERROR: Too many atoms found (i.e. %d); maximum allowed is %d.\nChange the \"#define MAX_ATOMS\" line in \"constants.h\"\n.", natom, MAX_ATOMS);
														//stop(error_message);
														slaveExit(-1);
												} else {
														*P_natom = natom;
														mol.natom = natom;
												}
												// Check total charge on ligand
												iq = (int) ((aq = fabs(total_charge_ligand)) + 0.5);
												lq = iq - QTOL;
												uq = iq + QTOL;
												if (!((aq >= lq) && (aq <= uq))) {
														prStr(message, "\n%s: *** Caution!  Non-integral total charge (%.3f e) on ligand may indicate a problem... ***\n\n", programname, total_charge_ligand);
														pr_2x(stderr, logFile, message);
												}

												/*
												 * Work out where the torsions are; and what they move...
												 *
												 * Also, detect which atoms we should ignore in the
												 * intermolecular energy calculation (ignore_inter[MAX_ATOMS]
												 * array)
												 */
												M_mkTorTree(atomnumber, PDBQT_record, nrecord, tlist, &ntor, P_ntor_ligand, FN_ligand, pdbaname,
																P_B_constrain, P_atomC1, P_atomC2, P_sqlower, P_squpper, P_ntorsdof, ignore_inter);

												*P_ntor = ntor;
												*P_ntor1 = ntor - 1;

												mol.S.ntor = ntor;

												if (ntor > 0) {
														//  Create a list of internal non-bonds to be used in internal energy calculation...
														for (i = 0; i < natom; i++) {
																for (j = 0; j < 5; j++) {
																		bonded[i][j] = -1;
																} // j
																bonded[i][5] = 0;
														} // i
														// find all the bonds in the ligand
														M_getbonds(crdpdb, 0, true_ligand_atoms, bond_index, bonded);

														if (B_have_flexible_residues) {
																// find all the bonds in the receptor
																M_getbonds(crdpdb, true_ligand_atoms, natom, bond_index, bonded);
														}

														if (debug > 0) {
																M_printbonds(natom, bonded, "\nDEBUG:  2. AFTER getbonds, bonded[][] array is:\n\n", 0);
																pr(logFile, "Detecting all non-bonds.\n\n");
														}
														M_nonbonds(crdpdb, nbmatrix, natom, bond_index, B_include_1_4_interactions, bonded);

														if (debug > 0) {
																M_printbonds(natom, bonded, "\nDEBUG:  4. AFTER nonbonds, bonded[][] array is:\n\n", 0);
																pr(logFile, "Weeding out non-bonds in rigid parts of the torsion tree.\n\n");
														}
#pragma omp parallel num_threads(MaxNumThreads)
														{
																M_weedbonds(natom, pdbaname, rigid_piece, ntor, tlist, nbmatrix, P_Nnb, nonbondlist, outlev, map_index);
														}
														//		print_nonbonds(natom, pdbaname, rigid_piece, ntor, tlist, nbmatrix, *P_Nnb, nonbondlist, outlev, map_index);

														// Update the unit vectors for the torsion rotations
														L_update_torsion_vectors( crdpdb, ntor, tlist, vt, &mol, debug );

														flushLog;

												} else {
														//		fprintf(logFile, ">>> No torsions detected, so skipping \"nonbonds\", \"weedbonds\" and \"torNorVec\" <<<\n\n");
												}

												//  End program if just parsing torsions...
												if (parse_tors_mode) {
														prStr(message, "\n\n *** PARSE TORSIONS MODE - Stopping here ***\n\n");
														M_success(hostnm, jobStart, tms_jobStart);
														slaveExit(0);
												}
												return mol;
										}


										void M_print_PDBQ_atom_resstr( FILE *logFile, 
														const char prefix[MAX_CHARS],
														int atom_num, // 0-origin 
														const char atomstuff[],
														const Real crd[MAX_ATOMS][SPACE],
														const Real vdW,
														const Real Elec,
														const Real charge,
														const char * suffix )
										{
												char  rec15[16];
												strncpy( rec15, atomstuff+12, (size_t)15);
												rec15[15]='\0';
#define FORMAT_PDBQ_ATOM_RESSTR         "%sATOM  %5d %.15s   %8.3f%8.3f%8.3f%+6.2f%+6.2f    %+6.3f%s"
												pr(logFile, FORMAT_PDBQ_ATOM_RESSTR, prefix, atom_num+1, rec15, 
																crd[atom_num][X], crd[atom_num][Y], crd[atom_num][Z], 
																vdW, Elec,  charge, suffix);
										}

										void M_print_PDBQ_atom_resnum( FILE *logFile, 
														const char prefix[MAX_CHARS],
														int atom_num, // 0-origin 
														const char atomstuff[],
														const int resnum,
														const Real crd[MAX_ATOMS][SPACE],
														const Real vdW,
														const Real Elec,
														const Real charge,
														const char * suffix //newline or empty
														)
										{
												char  rec10[11];
												strncpy( rec10, atomstuff+12, (size_t)10);
												rec10[10]='\0';
#define FORMAT_PDBQ_ATOM_RESNUM         "%sATOM  %5d %.10s%4d    %8.3f%8.3f%8.3f%+6.2f%+6.2f    %+6.3f%s"
												pr(logFile, FORMAT_PDBQ_ATOM_RESNUM, prefix, atom_num+1, rec10, 
																resnum,
																crd[atom_num][X], crd[atom_num][Y], crd[atom_num][Z], 
																vdW, Elec,  charge, suffix);
										}

										void M_printEnergies( EnergyBreakdown *eb,
														const char *prefixString,
														int  ligand_is_inhibitor,
														Real emap_total,
														Real elec_total,
														Boole B_have_flexible_residues, 
														Unbound_Model ad4_unbound_model)
										{
												Real Ki = 1.0;

												// equilibrium:   E  +  I  <=>    EI
												// binding:       E  +  I   ->    EI         K(binding),      Kb
												// dissociation:     EI     ->  E  +  I      K(dissociation), Kd
												//
												//                            1
												//         K(binding) = ---------------
												//                      K(dissociation)
												// so:
												//      ln K(binding) = -ln K(dissociation)
												//              ln Kb = -ln Kd
												// Ki = dissociation constant of the enzyme-inhibitor complex = Kd
												//      [E][I]
												// Ki = ------
												//       [EI]
												// so:
												//              ln Kb = -ln Ki
												// deltaG(binding)    = -R*T*ln Kb
												// deltaG(inhibition) =  R*T*ln Ki
												//
												// Binding and Inhibition occur in opposite directions, so we 
												// lose the minus-sign:  deltaG = R*T*lnKi,  _not_ -R*T*lnKi
												// => deltaG/(R*T) = lnKi
												// => Ki = exp(deltaG/(R*T))
												if (eb->deltaG < 0.0) {
														Ki = exp((eb->deltaG*1000.)/(Rcal*TK));
												}

												if (strncmp(prefixString, "UNBOUND", 7) != 0 ) {
														pr( logFile, "%sEstimated Free Energy of Binding    = ", prefixString);
														print1000(logFile, eb->deltaG);
														/****************************
														// YTLIU_EDIT 2013.01.06
														 ****************************/
														if(xbpmf_scoring)
																pr(logFile," kcal/mol  [=(1)+(2)+(3)+(4)]\n");
														else
																pr( logFile, " kcal/mol  [=(1)+(2)+(3)-(4)]\n");

														if (xbpmf_scoring == 0) {
																if (eb->deltaG < 0.0) {
																		if (ligand_is_inhibitor == 1) {
																				pr( logFile, "%sEstimated Inhibition Constant, Ki   = ", prefixString);
																		} else {
																				pr( logFile, "%sEstimated Dissociation Constant, Kd = ", prefixString);
																		}
																		// print1000_no_sign(logFile, Ki);
																		M_print_molar(logFile, Ki);
																		pr( logFile, "  [Temperature = %.2f K]\n", TK);
																}
														}

														pr( logFile, "%s\n", prefixString);
												}

												if(xbpmf_scoring==0){
														pr( logFile, "%s(1) Final Intermolecular Energy     = ", prefixString); print1000(logFile, eb->e_inter); pr( logFile, " kcal/mol\n");
														pr( logFile, "%s    vdW + Hbond + desolv Energy     = ", prefixString); print1000(logFile, emap_total); pr( logFile, " kcal/mol\n");
														pr( logFile, "%s    Electrostatic Energy            = ", prefixString); print1000(logFile, elec_total); pr( logFile, " kcal/mol\n");

														/*************************
														// YTLIU_EDIT 2013.01.26
														 *************************/
														if(xb_empirical_scoring){
																if((eb->e_mf_xb_empirical_vdw != 0.) || (eb->e_mf_xb_empirical_es != 0.)){
																		pr(logFile,"%s    XB vdW + desolv Energy in AD4   = ",prefixString); print1000(logFile, eb->e_mf_ad_vdw+eb->e_mf_ad_desolv); pr(logFile," kcal/mol\n");
																		pr(logFile,"%s    XB Empirical vdW Energy         = ",prefixString); print1000(logFile, eb->e_mf_xb_empirical_vdw); pr(logFile," kcal/mol\n");
																		pr(logFile,"%s    XB Electrostatic Energy in AD4  = ",prefixString); print1000(logFile, eb->e_mf_ad_es); pr(logFile," kcal/mol\n");
																		pr(logFile,"%s    XB Empirical ES Energy          = ",prefixString); print1000(logFile, eb->e_mf_xb_empirical_es); pr(logFile," kcal/mol\n");
																		pr(logFile,"%s    XB Corrected Energy             = ",prefixString); print1000(logFile, eb->e_mf_xb_empirical_vdw+eb->e_mf_xb_empirical_es-eb->e_mf_ad_vdw-eb->e_mf_ad_es-eb->e_mf_ad_desolv); pr(logFile," kcal/mol\n");
																}
														}

														if (B_have_flexible_residues) {
																pr( logFile, "%s    Moving Ligand-Fixed Receptor    = ", prefixString); print1000(logFile, eb->e_inter_moving_fixed ); pr( logFile, " kcal/mol\n");
																pr( logFile, "%s    Moving Ligand-Moving Receptor   = ", prefixString); print1000(logFile, eb->e_inter_moving_moving ); pr( logFile, " kcal/mol\n");

																/*************************
																// YTLIU_EDIT 2013.01.26
																 *************************/
																if(xb_empirical_scoring){
																		if((eb->e_mfr_xb_empirical_vdw != 0.) || (eb->e_mfr_xb_empirical_es != 0.)){
																				pr(logFile,"%s    XB vdW + desolv Energy in AD4   = ",prefixString); print1000(logFile, eb->e_mfr_ad_vdw+eb->e_mfr_ad_desolv); pr(logFile," kcal/mol\n");
																				pr(logFile,"%s    XB Empirical vdW Energy         = ",prefixString); print1000(logFile, eb->e_mfr_xb_empirical_vdw); pr(logFile," kcal/mol\n");
																				pr(logFile,"%s    XB Electrostatic Energy in AD4  = ",prefixString); print1000(logFile, eb->e_mfr_ad_es); pr(logFile," kcal/mol\n");
																				pr(logFile,"%s    XB Empirical ES Energy          = ",prefixString); print1000(logFile, eb->e_mfr_xb_empirical_es); pr(logFile," kcal/mol\n");
																				pr(logFile,"%s    XB Corrected Energy             = ",prefixString); print1000(logFile, eb->e_mfr_xb_empirical_vdw+eb->e_mfr_xb_empirical_es-eb->e_mfr_ad_vdw-eb->e_mfr_ad_es-eb->e_mfr_ad_desolv); pr(logFile," kcal/mol\n");
																		}
																}

														}
												}
												if(xbpmf_scoring){
														//        if(eb->e_mf_outside_grid_penalty!=0.0)
														//        {
														//	    pr(logFile,"%s    XBPMF Outside Grid Penalty      = ",prefixString); print1000(logFile,eb->e_mf_outside_grid_penalty); pr(logFile," kcal/mol\n");
														//        }
														pr(logFile,"%s(1) XBPMF Total 1D Potential        = ",prefixString); print1000(logFile,eb->e_mf_xbpmf_1d); pr(logFile," kcal/mol\n");
														pr(logFile,"%s(2) XBPMF Total 2D HB Potential     = ",prefixString); print1000(logFile,eb->e_mf_xbpmf_2d_hb); pr(logFile," kcal/mol\n");
														pr(logFile,"%s(3) XBPMF Total 2D XB Potential     = ",prefixString); print1000(logFile,eb->e_mf_xbpmf_2d_xb); pr(logFile," kcal/mol\n");
														pr(logFile,"%s(4) XBPMF Outside Grid Penalty      = ",prefixString); print1000(logFile,eb->e_mf_outside_grid_penalty); pr(logFile," kcal/mol\n");
												}

												if(xbpmf_scoring==0){
														pr( logFile, "%s(2) Final Total Internal Energy     = ", prefixString); print1000(logFile, eb->e_intra); pr( logFile, " kcal/mol\n");
														if (B_have_flexible_residues) {
																pr( logFile, "%s    Internal Energy Ligand          = ", prefixString); print1000(logFile, eb->e_intra_lig ); pr( logFile, " kcal/mol\n");
																//pr( logFile, "%s    Internal Energy Receptor        = ", prefixString); print1000(logFile, eb->e_intra_rec ); pr( logFile, " kcal/mol\n");
																pr( logFile, "%s    Internal Moving-Fixed Receptor  = ", prefixString); print1000(logFile, eb->e_intra_moving_fixed_rec ); pr( logFile, " kcal/mol\n");
																pr( logFile, "%s    Internal Moving-Moving Receptor = ", prefixString); print1000(logFile, eb->e_intra_moving_moving_rec ); pr( logFile, " kcal/mol\n");
														}

														pr( logFile, "%s(3) Torsional Free Energy           = ", prefixString); print1000(logFile, eb->e_torsFreeEnergy); pr( logFile, " kcal/mol\n");
												}

												switch(ad4_unbound_model){
														// in AutoDock 4.2, the default unbound model is "unbound is same as bound"
														case Unbound_Default:
														case Unbound_Same_As_Bound:
														default:
																if(xbpmf_scoring==0)
																		pr( logFile, "%s(4) Unbound System's Energy  [=(2)] = ", prefixString); 
																break;
														case User:
														case Extended:
														case Compact:
																if(xbpmf_scoring==0)
																		pr( logFile, "%s(4) Unbound System's Energy         = ", prefixString); 
																break;
												}
												if(xbpmf_scoring==0){
														print1000(logFile, eb->e_unbound_internal_FE); pr( logFile, " kcal/mol\n");
												}

												pr( logFile, "%s\n", prefixString);
												pr( logFile, "%s\n", prefixString);
										}

										void M_print_rem( FILE *outFile,int Rank,int NumMem,int Run,Real ref_rms)
										{
												fprintf( outFile, "MODEL     %4d\n", Run );
												fprintf( outFile, "USER    Run = %d\n", Run );
												fprintf( outFile, "USER    Cluster Rank = %d\n", Rank );
												fprintf( outFile, "USER    Number of conformations in this cluster = %d\n", NumMem );
												fprintf( outFile, "USER  \n");
												fprintf( outFile, "USER    RMSD from reference structure       = %.3f A\n", ref_rms );
												fprintf( outFile, "USER  \n");
										}

										void M_update_binding_energy_breakdown( EnergyBreakdown * eb, Unbound_Model ad4_unbound_model )
										{
												// total intermolecular energy = (1) + (4)
												eb->e_inter     = eb->e_inter_moving_fixed + eb->e_inter_moving_moving;

												// total intramolecular energy = (3) + (2) + (5)
												eb->e_intra     = eb->e_intra_moving_moving_lig + eb->e_intra_moving_fixed_rec + eb->e_intra_moving_moving_rec;

												// ligand intramolecular energy = (3)
												eb->e_intra_lig = eb->e_intra_moving_moving_lig;

												// receptor intramolecular energy = (2) + (5)
												eb->e_intra_rec = eb->e_intra_moving_fixed_rec + eb->e_intra_moving_moving_rec;

												// Set the internal energy of the unbound state
												switch (ad4_unbound_model) {
														// in AutoDock 4.2, the default unbound model is "unbound is same as bound"
														case Unbound_Default:
														case Unbound_Same_As_Bound:
														default:
																// Update the unbound internal energy, setting it to the current internal energy
																eb->e_unbound_internal_FE = eb->e_intra_lig;  // current internal energy of the ligand unbound state
																eb->e_intra_moving_moving_rec = 0;  // internal energy of the rec moving atoms
																eb->e_intra_moving_fixed_rec = 0;   // moving rec v. grids
																eb->e_intra   = eb->e_intra_moving_moving_lig + eb->e_intra_moving_fixed_rec + eb->e_intra_moving_moving_rec;
																eb->e_inter   = eb->e_inter_moving_fixed ;
																break;
														case User:
														case Extended:
														case Compact:
																// The unbound internal energy has already been set in 
																// initialise_energy_breakdown() to the value passed in unbound_internal_FE
																// There is no need to update here.
																break;
												}

												// estimated free energy upon binding
												eb->deltaG = eb->e_inter + eb->e_intra + eb->e_torsFreeEnergy - eb->e_unbound_internal_FE;
										}

										void M_initialise_binding_energy_breakdown( EnergyBreakdown * eb,
														Real torsFreeEnergy, 
														Real unbound_internal_FE ,
														Unbound_Model ad4_unbound_model)
										{
												eb->e_inter_moving_fixed = 0.0;      // (1)  // trilinterp( 0, true_ligand_atoms, ...)
												eb->e_mf_outside_grid_penalty = 0.0;
												eb->e_mf_xbpmf_1d = 0.0;
												eb->e_mf_xbpmf_2d_hb = 0.0;
												eb->e_mf_xbpmf_2d_xb = 0.0;

												eb->e_intra_moving_fixed_rec = 0.0;  // (2)  // trilinterp( true_ligand_atoms, natom, ...)
												eb->e_mfr_outside_grid_penalty = 0.0;
												eb->e_mfr_xbpmf_1d = 0.0;
												eb->e_mfr_xbpmf_2d_hb = 0.0;
												eb->e_mfr_xbpmf_2d_xb = 0.0;   

												eb->e_intra_moving_moving_lig = 0.0; // (3)  // eintcal( 0, Nnb_array[0], ...)             // nb_group_energy[INTRA_LIGAND]
												eb->e_inter_moving_moving = 0.0;     // (4)  // eintcal( Nnb_array[0], Nnb_array[1], ...)  // nb_group_energy[INTER]
												eb->e_intra_moving_moving_rec = 0.0; // (5)  // eintcal( Nnb_array[1], Nnb_array[2], ...)  // nb_group_energy[INTRA_RECEPTOR]

												eb->e_inter = 0.0;                   // total    intermolecular energy = (1) + (4)
												eb->e_intra = 0.0;                   // total    intramolecular energy = (3) + (2) + (5)
												eb->e_intra_lig = 0.0;               // ligand   intramolecular energy = (3)
												eb->e_intra_rec = 0.0;               // receptor intramolecular energy = (2) + (5)

												eb->e_torsFreeEnergy = torsFreeEnergy; // empirical torsional free energy penalty

												// Set the internal energy of the unbound state
												switch (ad4_unbound_model) {
														// in AutoDock 4.2, the default unbound model is "unbound is same as bound"
														case Unbound_Same_As_Bound:
														default:
																// Update the unbound internal energy, setting it to the current internal energy
																eb->e_unbound_internal_FE = eb->e_intra_lig;  // current internal energy of the ligand unbound state
																break;
														case User:
														case Extended:
														case Compact:
																// Set the unbound internal energy to the value passed in unbound_internal_FE
																eb->e_unbound_internal_FE = unbound_internal_FE;  // supplied internal energy of the ligand unbound state
																break;
												}

												eb->deltaG = 0.0;                    // estimated change in free energy upon binding
										}

										EnergyBreakdown M_calculateBindingEnergies(
														int                  natom,                     // input  number of atoms
														int                  ntor,                      // input  number of torsions
														Real                 unbound_internal_FE,       // input  pre-calculated internal energy of unbound state
														Real                 torsFreeEnergy,            // input  constant times number of freely-rotatable bonds
														Boole                B_have_flexible_residues,  // input  boolean whether we have flexible residues in protein

														// trilinterp
														const Real           tcoord[MAX_ATOMS][SPACE],  // input  coordinates of atoms to be trilinearly-interpolated
														CONST_FLOAT          charge[MAX_ATOMS],         // input  partial atomic charges
														CONST_FLOAT          abs_charge[MAX_ATOMS],     // input  absolute magnitude of partial charges
														CONST_INT            type[MAX_ATOMS],           // input  atom type of each atom
														MapType map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS], 
														GridMapSetInfo       *info,                     // input  info->lo[X],info->lo[Y],info->lo[Z],    minimum coordinates in x,y,z
														int                  B_outside,                 // input  boolean whether some atoms are outside grid box
														int                  ignore_inter[MAX_ATOMS],   // input  array of booleans, says to ignore computation intermolecular energies per atom
														Real                 elec[MAX_ATOMS],           // output if not NULL - electrostatic energies, atom by atom
														Real                 emap[MAX_ATOMS],           // output if not NULL - intermolecular energies
														Real                 *p_elec_total,             // output if not NULL - total electrostatic energy
														Real                 *p_emap_total,             // output if not NULL - total intermolecular energy

														// eintcal
														NonbondParam * const         nonbondlist,       // input  list of nonbonds
														const EnergyTables   *ptr_ad_energy_tables,     // input  pointer to AutoDock intermolecular, dielectric, solvation lookup tables
														const int            Nnb,                       // input  total number of nonbonds
														const Boole          B_calcIntElec,             // input  boolean whether we must calculate internal electrostatics
														const Boole          B_include_1_4_interactions,// input  boolean whether to include 1,4 interactions as non-bonds
														const Real           scale_1_4,                 // input  scaling factor for 1,4 interactions, if included
														const Real           qsp_abs_charge[MAX_ATOMS], // input  q-solvation parameters
														const Boole          B_use_non_bond_cutoff,     // input  boolean whether to use a nonbond distance cutoff
														Unbound_Model ad4_unbound_model,
														/**********************************
														// YTLIU_EDIT 2013.01.26
														 **********************************/
														Real &xb_empirical_vdw,
														Real &xb_empirical_es,
														Real &ad_vdw,
														Real &ad_es,
														Real &ad_desolv,
														// Real xb_vdw_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
														// Real xb_es_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
														// Real xb_desolv_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
														/*--------------------------------------------------*/
														/*acceleration: 2013.05.23 by ytliu@mail.shcnc.ac.cn*/
														/*--------------------------------------------------*/
														Real xb_vdw_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
														Real xb_es_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
														Real xb_desolv_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
														XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES],
														Boole halogen_found,
														Real xbempirical_recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
														int xbempirical_ligand_xbdonor[MAX_ATOMS][2],
														int xbempirical_receptor_acceptor_index[MAX_RECEPTOR_ATOMS]
																)
																{
																		EnergyBreakdown eb;

																		M_initialise_binding_energy_breakdown( &eb, torsFreeEnergy, unbound_internal_FE , ad4_unbound_model);

																		// computing trilinear-interpolated energies from atom = 0 to atom < true_ligand_atoms
																		// gives the intermolecular energy between the ligand and the protein
																		eb.e_inter_moving_fixed = L_trilinterp( 0, true_ligand_atoms, tcoord, charge, abs_charge, type, map, 
																						info, B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID, 
																						ignore_inter, elec, emap,
																						p_elec_total, p_emap_total,xb_empirical_vdw, xb_empirical_es,
																						ad_vdw, ad_es, ad_desolv, xb_vdw_profile, xb_es_profile,
																						xb_desolv_profile, xbempirical_parms, halogen_found,
																						xbempirical_recep_crdpdb,
																						xbempirical_ligand_xbdonor,
																						xbempirical_receptor_acceptor_index);

																		eb.e_mf_xb_empirical_vdw = xb_empirical_vdw;
																		eb.e_mf_xb_empirical_es = xb_empirical_es;
																		eb.e_mf_ad_vdw = ad_vdw;
																		eb.e_mf_ad_es = ad_es;
																		eb.e_mf_ad_desolv = ad_desolv;

																		if (B_have_flexible_residues) {
																				// computing trilinear-interpolated energies from atom = true_ligand_atoms to atom < true_ligand_atoms
																				// gives the intramolecular energy within the protein
																				// we can ignore the elec_total and emap_total breakdown here
																				eb.e_intra_moving_fixed_rec = L_trilinterp( true_ligand_atoms, natom, tcoord, charge, abs_charge, type, map, 
																								info, B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID, 
																								ignore_inter, elec, emap,
																								NULL, NULL,xb_empirical_vdw, xb_empirical_es,
																								ad_vdw, ad_es, ad_desolv, xb_vdw_profile, xb_es_profile,
																								xb_desolv_profile, xbempirical_parms, halogen_found,
																								xbempirical_recep_crdpdb,
																								xbempirical_ligand_xbdonor,
																								xbempirical_receptor_acceptor_index);

																				eb.e_mfr_xb_empirical_vdw = xb_empirical_vdw;
																				eb.e_mfr_xb_empirical_es = xb_empirical_es;
																				eb.e_mfr_ad_vdw = ad_vdw;
																				eb.e_mfr_ad_es = ad_es;
																				eb.e_mfr_ad_desolv = ad_desolv;
																		}

																		if (ntor > 0) {
																				// computing all the nonbond interaction energies fills nb_group_energy[3] array
																				// with intramolecular energy of ligand, intermolecular energy, and intramolecular energy of receptor
																				(void) L_eintcal( nonbondlist, ptr_ad_energy_tables, tcoord, Nnb, B_calcIntElec, B_include_1_4_interactions, scale_1_4, qsp_abs_charge, B_use_non_bond_cutoff, B_have_flexible_residues ) ;

																				eb.e_intra_moving_moving_lig = nb_group_energy[INTRA_LIGAND];
																				eb.e_inter_moving_moving = nb_group_energy[INTER];
																				eb.e_intra_moving_moving_rec = nb_group_energy[INTRA_RECEPTOR];
																		}

																		// update the totals in the energy breakdown structure
																		M_update_binding_energy_breakdown( &eb, ad4_unbound_model );

																		return eb;
																} // calculateBindingEnergies()

										int M_cluster_analysis( Real clus_rms_tol, 
														int cluster[MAX_RUNS][MAX_RUNS], 
														int num_in_clus[MAX_RUNS], 
														int isort[MAX_RUNS], 
														int nconf, 
														int natom, 
														int type[MAX_ATOMS],
														Real crd[MAX_RUNS][MAX_ATOMS][SPACE], 
														Real crdpdb[MAX_ATOMS][SPACE], 
														Real sml_center[SPACE], 
														Real clu_rms[MAX_RUNS][MAX_RUNS], 
														Boole B_symmetry_flag,
														Real ref_crds[MAX_ATOMS][SPACE],
														int ref_natoms,
														Real ref_rms[MAX_RUNS])
										{
												/* __________________________________________________________________________
												   | Cluster Analysis                                                         |
												   |__________________________________________________________________________|
												   |  If conformations are within clus_rms_tol, scored as the same.           |
												   |  Compares atoms with same type, not atom name, to find propellers.       |
												   |__________________________________________________________________________|*/

												register int compare = 0,
												i = 0;

												int          nClusters = 1,
															 thisconf = 0,
															 new_conf = FALSE;

												Real rms = 0.;

												if (ref_natoms == -1) {
														// No reference coordinates were defined, 
														//
														// Assume the Input Ligand PDBQT file is the reference structure
														// we must un-center the original PDBQT coordinates, 

														for (i = 0;  i < natom;  i++) {
																ref_crds[i][0] = sml_center[0] + crdpdb[i][0];
																ref_crds[i][1] = sml_center[1] + crdpdb[i][1];
																ref_crds[i][2] = sml_center[2] + crdpdb[i][2];
														}/*i*/
												}

												/* Assign the index of the lowest energy to 0,0 in "cluster" */

												thisconf = cluster[0][0] = isort[0]; 

												/* Set number in 0-th cluster to 1 */
												/* Also initialize total number of clusters to 1 */

												num_in_clus[0] = nClusters = 1;         
												clu_rms[0][0]  = M_getrms(crd[thisconf], ref_crds,B_symmetry_flag, natom, type);

												/* Go through *all* conformations... */
												for ( i=0; i<nconf; i++) {

														/* Calculate the RMSD to the reference structure: */
														ref_rms[i] = M_getrms(crd[i], ref_crds, B_symmetry_flag, natom, type);
												}

												/* Go through all conformations *except* 0-th... */
												for ( i=1; i<nconf; i++) {        

														/* "thisconf" is the index of the energy-sorted i-th conformation: */
														thisconf = isort[i];

														/* Assume this is a new conformation until proven otherwise... */
														new_conf = TRUE;

														for ( compare=0; compare<nClusters; compare++ ) {

																rms = M_getrms(crd[thisconf], crd[cluster[compare][0]],B_symmetry_flag, natom, type);

																/* Check rms; if greater than tolerance, */
																if ( rms > clus_rms_tol ) {

																		continue; /* to compare next conformation, */

																} else {

																		/* Otherwise, add this conformation to the current cluster, */
																		cluster[compare][ num_in_clus[compare] ] = thisconf;
																		clu_rms[compare][ num_in_clus[compare] ] = rms;
																		num_in_clus[compare]++;
																		new_conf = FALSE;
																		break; /* Go on to next i iteration... */
																}
														} /* next comparison... */

														if (new_conf) {

																/* Start a new cluster...  */
																cluster[ nClusters ][0] = thisconf;
																clu_rms[ nClusters ][0] = M_getrms(crd[thisconf], ref_crds,B_symmetry_flag, natom, type);
																num_in_clus[ nClusters ] = 1;

																/* Increment the number of clusters... */
																nClusters++;

														} /* endif */

												} /* next i... */

												return nClusters;
										}

										Real M_getrms ( Real Crd[MAX_ATOMS][SPACE],Real CrdRef[MAX_ATOMS][SPACE], Boole B_symmetry_flag,int natom,int type[MAX_ATOMS] )
										{
												double sqrSum, sqrMin, dc[SPACE];
												register int i, j, xyz;

												sqrSum = 0.;

												if (B_symmetry_flag) {
														for (i = 0;  i < natom;  i++) {
																sqrMin = BIG;
																for (j = 0;  j < natom;  j++) {                
																		if (type[i] == type[j]) {
																				for (xyz = 0;  xyz < SPACE;  xyz++) {
																						dc[xyz]= Crd[i][xyz] - CrdRef[j][xyz];
																				} /* xyz */
																				sqrMin = min( sqhypotenuse(dc[X], dc[Y], dc[Z]), sqrMin );
																		}
																} /*  next j  */
																sqrSum += sqrMin;
														} /*  next i  */
												} else {
														for (i = 0;  i < natom;  i++) {
																for (xyz = 0;  xyz < SPACE;  xyz++) {
																		dc[xyz]= Crd[i][xyz] - CrdRef[i][xyz];
																} /* xyz */
																sqrSum += sqhypotenuse( dc[X], dc[Y], dc[Z] );
														} /*  next i  */
												}

												return ( sqrt( sqrSum / (double)natom )  );
										}

										void M_sort_enrg( Real econf[MAX_RUNS],int isort[MAX_RUNS],int nconf )
										{
												M_quicksort( econf, isort, 0, nconf-1 );
										}

										int M_getpdbcrds( char *rms_ref_crds_FN,Real ref_crds[MAX_ATOMS][SPACE] )
										{
												int ii=0;
												int natoms=0;
												char line[LINE_LEN];
												char str[4][WORDLEN];
												char rec5[5];
												FILE *rms_ref_FilePtr;

												//if ( !openfile( rms_ref_crds_FN, "r", &rms_ref_FilePtr )) {
												if((rms_ref_FilePtr=fopen(rms_ref_crds_FN,"r"))!=NULL)
												{
														fprintf( logFile, "%s: ERROR!  Sorry, could not open file \"%s\" for reading.\n", programname,  rms_ref_crds_FN );
														return -1;
												}

												pr (logFile, "\nRMS Reference Coordinates from \"%s\":-\n\n", rms_ref_crds_FN);

												while ( fgets(line, LINE_LEN, rms_ref_FilePtr) != NULL ) {

														for (ii = 0; ii < 4; ii++) {
																rec5[ii] = (char)tolower( (int)line[ii] );
														}
														if (equal(rec5,"atom",4) || equal(rec5,"heta",4)) {

																if (natoms < MAX_ATOMS) {
																		sscanf( &line[30], "%s %s %s", str[X], str[Y], str[Z] );
																		ref_crds[natoms][X] = atof( str[X] );
																		ref_crds[natoms][Y] = atof( str[Y] );
																		ref_crds[natoms][Z] = atof( str[Z] );
																		pr (logFile, "Atom %5d,  x,y,z = %8.3f %8.3f %8.3f\n", natoms+1, ref_crds[natoms][X], ref_crds[natoms][Y], ref_crds[natoms][Z]);
																} else {
																		fprintf( logFile, "%s: ERROR!  Sorry, too many atoms in file \"%s\"\n", programname,  rms_ref_crds_FN );
																		return -1;
																}
																++natoms;
														} /* End if "atom" or "heta" */

												} /* End while there's a line to read... */

												/* Close the reference coordinates file... */
												(void) fclose(rms_ref_FilePtr);

												return natoms;
										}

										void M_analysis( int   Nnb, 
														char  atomstuff[MAX_ATOMS][MAX_CHARS], 
														Real charge[MAX_ATOMS], 
														Real abs_charge[MAX_ATOMS], 
														Real qsp_abs_charge[MAX_ATOMS], 
														Boole B_calcIntElec,
														Real clus_rms_tol, 
														Real crdpdb[MAX_ATOMS][SPACE], 

														const EnergyTables *ptr_ad_energy_tables,

														Real  map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS], 
														Real  econf[MAX_RUNS], 
														int   irunmax, 
														int   natom, 
														NonbondParam *nonbondlist, 
														int   nconf, 
														int   ntor, 
														State hist[MAX_RUNS], 
														char  *smFileName, 
														Real  sml_center[SPACE],
														Boole B_symmetry_flag, 
														int   tlist[MAX_TORS][MAX_ATOMS], 
														int   type[MAX_ATOMS], 
														Real  vt[MAX_TORS][SPACE],
														char  *FN_rms_ref_crds,
														Real  torsFreeEnergy,
														Boole B_write_all_clusmem,
														int   ligand_is_inhibitor,
														int   outlev,
														int   ignore_inter[MAX_ATOMS],
														const Boole   B_include_1_4_interactions,
														const Real scale_1_4,
														const Real unbound_internal_FE,

														GridMapSetInfo *info,
														Boole B_use_non_bond_cutoff,
														Boole B_have_flexible_residues,
														Boole B_rms_atoms_ligand_only,
														Unbound_Model ad4_unbound_model,
														/**********************************
														// YTLIU_EDIT 2013.01.26
														 **********************************/
														Real &xb_empirical_vdw,
														Real &xb_empirical_es,
														Real &ad_vdw,
														Real &ad_es,
														Real &ad_desolv,
														// Real xb_vdw_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
														// Real xb_es_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
														// Real xb_desolv_profile[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES][MAX_DIST][2],
														/*--------------------------------------------------*/
														/*acceleration: 2013.05.23 by ytliu@mail.shcnc.ac.cn*/
														/*--------------------------------------------------*/
														Real xb_vdw_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
														Real xb_es_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
														Real xb_desolv_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8],
														XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES],
														Boole halogen_found,
														Real xbempirical_recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN],
														int xbempirical_ligand_xbdonor[MAX_ATOMS][2],
														int xbempirical_receptor_acceptor_index[MAX_RECEPTOR_ATOMS])
														{
																/* register int   imol = 0; */
																char  filename[PATH_MAX];
																static char  label[MAX_CHARS];

																static Real clu_rms[MAX_RUNS][MAX_RUNS];
																static Real crdSave[MAX_RUNS][MAX_ATOMS][SPACE];
																static Real crd[MAX_ATOMS][SPACE];
																static Real elec[MAX_ATOMS];
																static Real elec_total;
																static Real emap[MAX_ATOMS];
																static Real emap_total;
																// Real lo[3];
																static Real ref_crds[MAX_ATOMS][SPACE];
																static Real ref_rms[MAX_RUNS];
																Real torDeg = 0.;
																Real modtorDeg = 0.;
																Real MaxValue = 99.99;

																int   c = 0;
																int   c1 = 0;
																static int   cluster[MAX_RUNS][MAX_RUNS];
																int   i1=1;
																int   indpf = 0;
																static int   isort[MAX_RUNS];
																int   ncluster = 1; int   num_in_clu[MAX_RUNS];
																int   off[VECLENMAX];
																int   ref_natoms = -1;
																int   veclen = 0;
																int   kmax = 0;
																int   n_rms_atoms = 0;

																register int   i = 0;
																register int   j = 0;
																register int   k = 0;
																register int   t = 0;

																State save;

#pragma omp threadprivate(label, clu_rms, crdSave, crd, elec, elec_total, ref_crds, ref_rms, cluster, isort)


																//    pr( logFile, "\n\t\tCLUSTER ANALYSIS OF CONFORMATIONS\n\t\t_________________________________\n\nNumber of conformations = %d\n", nconf );

																// Initialise these arrays
																for (j = 0; j < MAX_RUNS; j++) {
																		num_in_clu[j] = 0;
																		isort[j] = j;
																		for (i = 0; i < MAX_RUNS; i++) {
																				cluster[j][i] = 0;
																		}
																}

																// Set the number of atoms to cluster on
																pr( logFile, "\n");
																if (B_rms_atoms_ligand_only == TRUE) {
																		// use only the ligand atoms for clustering
																		n_rms_atoms = true_ligand_atoms;
																		//        pr( logFile, "RMSD cluster analysis will be performed using the ligand atoms only (%d / %d total atoms).\n", n_rms_atoms, natom);
																} else {
																		// use all the moving atoms in the receptor plus the ligand atoms for clustering
																		n_rms_atoms = natom;
																		//        pr( logFile, "RMSD cluster analysis will be performed using all the moving atoms in the receptor\n plus the ligand atoms (%d / %d total atoms).\n", n_rms_atoms, natom);
																}

																// Read in reference coordinates...
																if (strncmp(FN_rms_ref_crds,"unspecified filename",20) != 0) {
																		if ((ref_natoms = M_getpdbcrds( FN_rms_ref_crds, ref_crds)) == -1) {
																				//            fprintf( logFile, "%s: Problems while reading the ligand reference coordinates file \"%s\".\n", programname, FN_rms_ref_crds);
																				//            fprintf( logFile, "%s: Will attempt to use the input ligand PDBQT coordinates as reference instead.\n", programname);
																		} else if (ref_natoms != natom) {
																				// intention is to compare the number of reference atoms with the number of atoms we are comparing
																				// if receptor is flexible, natom will include both the receptor and ligand atoms, but if the
																				// receptor is rigid, natom will be equal to true_ligand_atoms.
																				pr( logFile, "%s: ERROR!  Wrong number of atoms in reference structure.\n", programname);
																				pr( logFile, "%s:         The reference structure should consist of only the ligand atoms.\n", programname);
																				pr( logFile, "%s:         Input ligand PDBQT structure has %d atoms, but reference structure has %d atoms.\n\n", programname, true_ligand_atoms, ref_natoms);
																				ref_natoms = -1;
																		}
																}

																// Generate coordinates for each final transformation,
																for ( k=0; k<nconf; k++ ) {

																		/* fprintf( logFile, "\n\nState hist[%d].\n", k); */
																		//        if (outlev > -1) {
																		//            printState( logFile, hist[k], 2 );
																		//        }

																		/* fprintf( logFile, "\nCopying state %d.\n", k); */
																		L_Add_copyState( &save, hist[k] );

																		/* fprintf( logFile, "Converting state %d to coordinates.\n", k); */
																		L_cnv_state_to_coords( save, vt, tlist, ntor, crdpdb, crd, natom);

																		/* fprintf( logFile, "Saving coordinates of state %d.\n", k); */

																		/* Save coordinates in crdSave array...  */
																		(void)memcpy(crdSave[k], crd, natom*3*sizeof(Real));
																} /*k*/

																flushLog;

																// Sort conformations by energy and perform cluster analysis,
																if (nconf > 1) {
																		M_sort_enrg( econf, isort, nconf );

																		// NOTE:  We are clustering on only the ligand atoms, regardless
																		// of flexibility in the receptor sidechains...
																		ncluster = M_cluster_analysis( clus_rms_tol, cluster, num_in_clu, isort, 
																						nconf, n_rms_atoms, type, crdSave, crdpdb, 
																						sml_center, clu_rms, B_symmetry_flag,
																						ref_crds, ref_natoms, ref_rms);

																		//        pr( logFile, "\nOutputting structurally similar clusters, ranked in order of increasing energy.\n" );
																		flushLog;

																} else {
																		pr( logFile, "\nSorry!  Unable to perform cluster analysis, because not enough conformations were generated.\n\n\n" );

																		ncluster = 1;
																		ref_rms[0] = M_getrms( crd, ref_crds, B_symmetry_flag, n_rms_atoms, type);
																		clu_rms[0][0] = 0.;
																		num_in_clu[0] = 1;
																		cluster[0][0] = 0;
																}
																//    flushLog;

																// For each cluster, i
																////////////////////////////////////////////
																///xbzhang edit 2014.5.10
																///print first one of max cluster
																////////////////////////////////////////////
																for (i = 0;  i < 1;  i++) {
																		i1 = i + 1;

																		// c = cluster[i][0];
																		if (B_write_all_clusmem) {
																				kmax = num_in_clu[i];
																		} else {
																				kmax = 1;	/* write lowest-energy only */
																		}

																		// For each member, k, of this cluster
																		for (k = 0;  k < 1;  k++) {
																				c = cluster[i][k];
																				c1 = c + 1;

																				(void)memcpy(crd, crdSave[c], natom*3*sizeof(Real));

																				Boole B_outside=FALSE;
																				register int ia=0;
																				for (ia=0; (ia<natom)&&(!B_outside); ia++) {
																						B_outside = is_out_grid_info(crd[ia][0], crd[ia][1], crd[ia][2]);
																				}

																				EnergyBreakdown eb;

																				eb = M_calculateBindingEnergies( natom, ntor, unbound_internal_FE, torsFreeEnergy, B_have_flexible_residues,
																								crd, charge, abs_charge, type, map, info, B_outside?SOME_ATOMS_OUTSIDE_GRID:ALL_ATOMS_INSIDE_GRID,
																								ignore_inter, elec, emap, &elec_total, &emap_total,
																								nonbondlist, ptr_ad_energy_tables, Nnb, B_calcIntElec,
																								B_include_1_4_interactions, scale_1_4, qsp_abs_charge, B_use_non_bond_cutoff, ad4_unbound_model,xb_empirical_vdw, xb_empirical_es,
																								ad_vdw, ad_es, ad_desolv, xb_vdw_profile, xb_es_profile,
																								xb_desolv_profile, xbempirical_parms, halogen_found,
																								xbempirical_recep_crdpdb,
																								xbempirical_ligand_xbdonor,
																								xbempirical_receptor_acceptor_index );

																				M_print_rem( logFile, i1, num_in_clu[i], c1, ref_rms[c]);

																				M_printEnergies( &eb, "USER    ", ligand_is_inhibitor, emap_total, elec_total, B_have_flexible_residues, ad4_unbound_model);

																				pr( logFile, "USER  \n");
																				pr( logFile, "USER    DPF = %s\n", dock_param_fn);
																				pr( logFile, "USER    NEWDPF move\t%s\n", smFileName );
																				pr( logFile, "USER    NEWDPF about\t%f %f %f\n", sml_center[X],sml_center[Y],sml_center[Z]);
																				pr( logFile, "USER    NEWDPF tran0\t%f %f %f\n", hist[c].T.x, hist[c].T.y, hist[c].T.z );
																				pr( logFile, "USER    NEWDPF axisangle0\t%f %f %f %f\n", hist[c].Q.nx, hist[c].Q.ny, hist[c].Q.nz, RadiansToDegrees(hist[c].Q.ang) );
																				pr( logFile, "USER    NEWDPF quaternion0\t%f %f %f %f\n", hist[c].Q.x, hist[c].Q.y, hist[c].Q.z, hist[c].Q.w );
																				if (ntor > 0) {
																						// Deprecated in AutoDock 4 // pr( logFile, "USER    NEWDPF ndihe\t%d\n", hist[c].ntor );
																						pr( logFile, "USER    NEWDPF dihe0\t" );
																						flushLog;
																						for ( t = 0;  t < hist[c].ntor;  t++ ) {
																								torDeg = RadiansToDegrees(hist[c].tor[t]);
																								modtorDeg = ModDeg(torDeg);
																								pr( logFile, "%.2f ", WrpDeg(modtorDeg) );
																						}/*t*/
																						pr( logFile, "\n" );
																				}/*if*/
																				pr( logFile, "USER  \n");
																				flushLog;

																				if (outlev > -11) {
																						if (keepresnum > 0) {
																								// Log File PDBQ coordinates [
																								pr( logFile, "USER                              x       y       z    vdW   Elec        q     RMS \n" );
																								// TODO output the ROOT, ENDROOT, BRANCH, ENDBRANCH, TORS records...
																								for (j = 0;  j < natom;  j++) {
																										M_print_PDBQ_atom_resstr( logFile, "", j, atomstuff[j],  crd, 
																														min(emap[j], MaxValue), min(elec[j], MaxValue), charge[j],"");
																										pr(logFile," %6.3f\n", ref_rms[c]); 
																								}
																								//]
																						} else {
																								// Log File PDBQ coordinates [
																								// TODO output the ROOT, ENDROOT, BRANCH, ENDBRANCH, TORS records...
																								pr( logFile, "USER                 Rank         x       y       z    vdW   Elec        q     RMS \n");
																								for (j = 0;  j < natom;  j++) {
																										M_print_PDBQ_atom_resnum( logFile, "", j, atomstuff[j],  i1, crd, 
																														min(emap[j], MaxValue), min(elec[j], MaxValue), charge[j],"");
																										pr(logFile," %6.3f\n", ref_rms[c]); 
																								}/*j*/
																								//]
																						}/*if*/
																				}
																				pr( logFile, "TER\n" );
																				pr( logFile, "ENDMDL\n" );
																				// End of outputting coordinates of this "MODEL"...
#ifdef EINTCALPRINT
																				// Print detailed breakdown of internal energies of all non-bonds
																				(void) eintcalPrint(nonbondlist, ptr_ad_energy_tables, crd, Nnb, B_calcIntElec, B_include_1_4_interactions, scale_1_4, qsp_abs_charge, B_use_non_bond_cutoff, B_have_flexible_residues);
#endif
																				flushLog;
																		} /*k*/
																} /*i   (Next cluster.) */
																//    pr( logFile, "\n\n" );

																// AVS Field file [
																off[0]=5;
																off[1]=6;
																off[2]=7;
																off[3]=8;
																off[4]=9;
																off[5]=10;
																if (keepresnum > 0) {
																		off[6]=11;
																		veclen = 7;
																		strcpy( label, "x y z vdW Elec q RMS\0" );
																} else {
																		off[6]=4;
																		off[7]=11;
																		veclen = 8;
																		strcpy( label, "x y z vdW Elec q Rank RMS\0" );
																}
																indpf = strindex( dock_param_fn, ".dpf" );
																strncpy( filename, dock_param_fn, (size_t)indpf );
																filename[ indpf ] = '\0';
																strcat( filename, ".dlg.pdb\0" );

																//    print_avsfld( logFile, veclen, natom, ncluster, off, 12, label, filename );
																//]
														}

										void M_printdate( FILE *fp, int flag )
										{
												time_t tn; /* tn = "time_now" */
												char *StringTimeDate;
												struct tm *ts;

												tn = time( &tn );

												ts = localtime( &tn );

												if (flag==1) {
														fprintf(fp, "%d:%02d %02d\" %s, %02d/%02d/%4d\n", 
																		( (ts->tm_hour >  12) ? (ts->tm_hour-12) : ts->tm_hour ), ts->tm_min, ts->tm_sec,
																		( (ts->tm_hour >= 12) ? "p.m." : "a.m." ),
																		(ts->tm_mon + 1), ts->tm_mday, 1900+ts->tm_year );
												} else if (flag==2) {
														StringTimeDate = ctime( &tn );
														fprintf(fp, "%s", StringTimeDate);
												} else {
														fprintf(fp, "%d:%02d %02d\" %s\n", 
																		( (ts->tm_hour >  12) ? (ts->tm_hour-12) : ts->tm_hour ), ts->tm_min, ts->tm_sec,
																		( (ts->tm_hour >= 12) ? "pm" : "am" ) );
												}
										}

#endif

#define MAX_RANKS 1024

										typedef struct
										{
												int ranks[MAX_RANKS];
												int size;
										} MY_GROUP;

										//------------------------------- PSO -Work Variables declaration 

										// State Structure Variable DECLARATION
										State sNew[S_max];
										int D; //search space dimension 
										int nb_eval; // Current number of Swarm evaluations
										int eval_max = 0; //Max number of Swarm iterations
										int S ; // Swarm size
										int S_factor=30; // Swarm size
										double xmin[D_max], xmax[D_max]; // Intervals defining the search space
										double Vmin[D_max], Vmax[D_max]; // Intervals defining the search space

										__declspec(target(mic))L_Global_Search		*L_GlobalSearchMethod=NULL;
										__declspec(target(mic))L_Genetic_Algorithm	*L_GA=NULL;
										__declspec(target(mic))L_Local_Search		*L_LocalSearchMethod=NULL;
										__declspec(target(mic))L_Solis_Wets1		*L_SW=NULL;
										__declspec(target(mic))L_Pseudo_Solis_Wets1	*L_PSW=NULL;
										__declspec(target(mic))L_Pattern_Search		*L_PS=NULL;
#pragma omp threadprivate(L_GlobalSearchMethod,L_GA,L_LocalSearchMethod,L_SW,L_PSW,L_PS)

										// pkcoff: the main for mpi is now solely the mpi driver
#ifdef AUTODOCK_MPI

										int main (int argc, char ** argv)
										{
												time_t totalTimeBegin,totalTimeEnd;
												long time_duration;
												totalTimeBegin=time(NULL);

												// verify params
												if (argc != 12) 
												{
														fprintf(stderr,"MPDOCKxb: incorrect number of parameters, parameters should be: docking_list_file docking_base_directory status_directory scoring_function_type number_of_MPI_comm seed_type map_file_usage sleeptime threadNum ProcessOnNodes dpffile\n");
														exit(-1);
												}

												strcpy(dockingDirectoryBaseName,argv[2]);

												int scoringFuction = XB_EMPIRCAL;

												// determine map file usage
												if (strcmp(argv[4],"xb_empirical") == 0)
														scoringFuction = XB_EMPIRCAL;
												else if (strcmp(argv[4],"xb_pmf") == 0)
														scoringFuction = XB_PMF;
												else 
												{
														fprintf(stderr,"MPDOCKxb: scoring fuction usage unrecognized - should be one of these values: xb_empirical or xb_pmf.\n");
														exit(-1);
												}

												// set seed and map reuse options
												int seedType = DEFAULT_SEED;

												// determine seed type
												if (strcmp(argv[6],"same_seed") == 0)
														seedType = SAME_SEED;
												else if (strcmp(argv[6],"default_seed") == 0)
														seedType = DEFAULT_SEED;
												else if (strcmp(argv[6],"unique_node_seed") == 0)
														seedType = UNIQUE_NODE_SEED;
												else 
												{
														fprintf(stderr,"MPDOCKxb: seed type unrecognized - should be one of these values: same_seed, default_seed, or unique_node_seed.\n");
														exit(-1);
												}

												int mapUsageType = RELOAD_MAPS;

												// determine map file usage
												if (strcmp(argv[7],"reload_maps") == 0)
														mapUsageType = RELOAD_MAPS;
												else if (strcmp(argv[7],"reuse_maps") == 0)
														mapUsageType = REUSE_MAPS;
												else 
												{
														fprintf(stderr,"MPDOCKxb: map file usage unrecognized - should be one of these values: reload_maps or reuse_maps.\n");
														exit(-1);
												}
												/*
												   D3DOCKxb4 docklist /vol6/home/liuxin/chengqian/MICD3DOCKxb/ Tests xb_empirical 4 default_seed reuse_maps
												   */
												// mpi required vars
												int mpirank, mpisize, mpirc;
												int ctrlTag = 1;
												int computerTag = 2;
												int endTag = 2;
												MPI_Status mpistatus;

												//xbzhang designed 2014.2
												int firstLoopJobs=INT_MAX;
												int contrlSize= atoi(argv[5]);
												int computerNum=0;

												int groupID;
												FILE *dockingListFile;
												//    int threadErr;
#ifdef PERF_PROFILING
												char *dockTimeStatusFileName;
												FILE *dockTimeStatusFile;
												//    char stateTime[9];
#endif

												MY_GROUP group;
												char hostnm[MAX_CHARS];

#ifdef MPI_DEBUG
												char output[80];
#endif
												list<struct dockinfo> ctrlThread;
												//xbzhang designed end

												// the number of slaves that have returned, used to determine when all the work is done and we can exit
												int slaveReturns = 0;

												// buffer for reading docking list file
												char line[LINE_LEN];


												// initialize mpi
												//int provided;
												mpirc=MPI_Init(&argc, (char ***) &argv);
												//  mpirc = MPI_Init_thread(&argc, (char ***) &argv,MPI_THREAD_MULTIPLE,&provided);
												if (mpirc != MPI_SUCCESS)
												{
														fprintf(stderr,"MPI cannot be initialized. Terminating.\n");
														MPI_Abort(MPI_COMM_WORLD, mpirc);
												}
												mpirc = MPI_Comm_size(MPI_COMM_WORLD, &mpisize);
												mpirc = MPI_Comm_rank(MPI_COMM_WORLD, &mpirank);

#ifdef MPI_DEBUG
												printf("There are %d nodes, I am rank %d\n",mpisize,mpirank);
#endif
#ifdef PERF_PROFILING
												char TimeStatusName[20];
												sprintf(TimeStatusName,"TimeOfRank%d",mpirank);
												dockTimeStatusFileName = (char *) malloc((strlen(argv[3])+strlen(TimeStatusName)+ 1) * sizeof(char));
												strcpy(dockTimeStatusFileName,argv[3]);
												strcat(dockTimeStatusFileName,TimeStatusName);

												(void) strcpy(hostnm, "unknown host");
												gethostname( hostnm, sizeof hostnm );

												if ( (dockTimeStatusFile = fopen(dockTimeStatusFileName, "w")) == NULL ) {
														fprintf(stderr, "\nMPDOCKxb master: can't open %s\n", dockTimeStatusFileName);
														exit(-1);
												}
												pr(dockTimeStatusFile,"Rank begin at %s at ",hostnm); //xbzhang designed 2014.3.10

												M_printdate( dockTimeStatusFile, 1 );
												(void) fflush(dockTimeStatusFile);
#endif

												if(mpirank==0)
												{
														if ( (dockingListFile = fopen(argv[1], "r+")) == NULL ) 
														{
																fprintf(stderr, "\nMPDOCKxb master: can't find or open docking list file %s\n", argv[1]);
																exit(-1);
														}
														//        contrlSize=sqrt(mpisize);
														fpos_t pos;
														fgetpos(dockingListFile,&pos);
														while(( fgets(line, LINE_LEN, dockingListFile) != NULL)) //xbzhang designed 2014.4.1
														{
																if(strlen(line) > 0 && !strncmp(line,"#",1))
																{
																		if(strstr(line,"number_of_first_loop_jobs:"))
																		{
																				sscanf(line,"#number_of_first_loop_jobs: %d",&firstLoopJobs);
																				computerNum=mpisize-contrlSize;
																				//                    firstLoopJobs=numJob*0.7;
																				firstLoopJobs=firstLoopJobs>computerNum?firstLoopJobs:computerNum;
#ifdef MPI_DEBUG
																				printf("first loop jobs is %d\n",firstLoopJobs);
#endif
																		}
																}
																else
																{
																		fsetpos(dockingListFile,&pos);
																		break;
																}
																fgetpos(dockingListFile,&pos);
														}
#ifdef MPI_DEBUG
														printf("second contrl: %d\n",contrlSize);
#endif

												}

												if(mpirank<contrlSize)
												{
														groupID=mpirank;
														group.size=0;
														for(int i = groupID;i<mpisize;i+=contrlSize)
																group.ranks[group.size++]=i;
												}
												else
												{
														groupID=mpirank%contrlSize;
#ifdef MPI_DEBUG
														//        printf("My rank is %d, my group ID is %d\n",mpirank,groupID);
#endif

														group.ranks[0]=groupID;

														group.size=1;
												}

#ifdef PERF_PROFILING
												pr(dockTimeStatusFile,"Comm and group created at "); //xbzhang designed 2014.3.10

												M_printdate( dockTimeStatusFile, 1 );
												(void) fflush(dockTimeStatusFile);
#endif

												//xbzhang designed end
												FILE *dockSubmittedStatusFile;
												FILE *dockPerformanceFile;
												FILE *secondPerformanceFile;
												FILE *dockErrorStatusFile;
												FILE *secondErrorStatusFile;
												FILE *dockSuccessStatusFile;
												FILE *secondSuccessStatusFile;
												FILE *dockRunningStatusFile = NULL;

												char *dockSubmittedStatusFileName, *dockPerformanceFileName, *dockSuccessStatusFileName, *dockErrorStatusFileName, *dockRunningStatusFileName;
												char *secondSubmittedStatusFileName, *secondPerformanceFileName, *secondSuccessStatusFileName, *secondErrorStatusFileName, *secondRunningStatusFileName;
												const char dockSubmittedStatusFileNameBase[] = "submitted_dockings";
												const char dockPerformanceFileNameBase[] = "docking_performance.csv";
												const char dockErrorStatusFileNameBase[] = "failed_dockings";
												const char dockSuccessStatusFileNameBase[] = "successful_dockings";
												const char dockRunningStatusFileNameBase[] = "running_dockings";

												int secondDockingCounter = 0;
												int DockingCounter = 0;
												int ctrlEndedCounter = 0;
												int dockListFilePos;
												int SleepTime=atoi(argv[8]);
												MaxNumThreads=atoi(argv[9]);
												NpOnNodes=atoi(argv[10]);
												strcpy(M_dpfname,argv[11]);

												if (mpirank == 0) // master node
												{ 
#ifdef MPI_DEBUG
														//      printf("docking List file name = %s\n",argv[1]);
#endif /* DEBUG */
														//////////////////////////////////////////////////
														/// open the docking list and all the status files
														//////////////////////////////////////////////////
														dockSubmittedStatusFileName = (char *) malloc((strlen(argv[3])+strlen(dockSubmittedStatusFileNameBase)+ 1) * sizeof(char));
														strcpy(dockSubmittedStatusFileName,argv[3]);
														strcat(dockSubmittedStatusFileName,dockSubmittedStatusFileNameBase);

														if ( (dockSubmittedStatusFile = fopen(dockSubmittedStatusFileName, "w")) == NULL ) 
														{
																fprintf(stderr, "\nMPDOCKxb master: can't open %s\n", dockSubmittedStatusFileName);
																exit(-1);
														}

														dockSuccessStatusFileName = (char *) malloc((strlen(argv[3])+strlen(dockSuccessStatusFileNameBase) + 1) * sizeof(char));
														strcpy(dockSuccessStatusFileName,argv[3]);
														strcat(dockSuccessStatusFileName,dockSuccessStatusFileNameBase);

														if ( (dockSuccessStatusFile = fopen(dockSuccessStatusFileName, "w")) == NULL ) 
														{
																fprintf(stderr, "\nMPDOCKxb master: can't open %s\n", dockSuccessStatusFileName);
																exit(-1);
														}

														dockErrorStatusFileName = (char *) malloc((strlen(argv[3])+strlen(dockErrorStatusFileNameBase) + 1) * sizeof(char));
														strcpy(dockErrorStatusFileName,argv[3]);
														strcat(dockErrorStatusFileName,dockErrorStatusFileNameBase);

														if ( (dockErrorStatusFile = fopen(dockErrorStatusFileName, "w")) == NULL ) 
														{
																fprintf(stderr, "\nMPDOCKxb master: can't open %s\n", dockErrorStatusFileName);
																exit(-1);
														}

														dockRunningStatusFileName = (char *) malloc((strlen(argv[3])+strlen(dockRunningStatusFileNameBase) + 1) * sizeof(char));
														strcpy(dockRunningStatusFileName,argv[3]);
														strcat(dockRunningStatusFileName,dockRunningStatusFileNameBase);

#ifdef PERF_PROFILING
														dockPerformanceFileName = (char *) malloc((strlen(argv[3])+strlen(dockPerformanceFileNameBase) + 1) * sizeof(char));
														strcpy(dockPerformanceFileName,argv[3]);
														strcat(dockPerformanceFileName,dockPerformanceFileNameBase);

														if ( (dockPerformanceFile = fopen(dockPerformanceFileName, "w")) == NULL ) {
																fprintf(stderr, "\nMPDOCKxb master: can't open %s\n", dockPerformanceFileName);
																exit(-1);
														}

														// print out the column names in the performance file
														pr(dockPerformanceFile,"Base Name,Contrl node,Computer node,Master Send Date,Master Send Time,Control Send Time,Control Recv Time,Control Send-Recv Duration (Sec),Slave Send - Control Recv Delta (MPI Time) (Sec), Slave Recv Time,Slave Main Start Time,First FLD File Load Start Time,Last FLD File Load End Time,First Map File Load Start Time,Last Map File Load End Time,First Ligand File Load Start Time,Last Ligand File Load End Time,LGA Setup Start Time,LGA Start Time,LGA End Time,Analysis Start Time,Analysis End Time,Post Slave Main Cleanup Time,Slave Main End Time,Slave Send Time,Slave Main Duration (Sec),FLD File Load Total Duration (Sec),FLD File Load Number,FLD File Load Min Duration (Sec),FLD File Load Avg Duration (Sec),FLD File Load Max Duration (Sec),Map File Load Total Duration (Sec),Map File Load Number,Map File Load Min Duration (Sec),Map File Load Avg Duration (Sec),Map File Load Max Duration (Sec),Ligand File Load Total Duration (Sec),LGA Overall Duration (Sec),Number LGA Runs,LGA Run Comp Min Duration (Sec),LGA Run Comp Avg Duration (Sec),LGA Run Comp Max Duration (Sec),LGA Run IO Min Duration (Sec),LGA Run IO Avg Duration (Sec),LGA Run IO Max Duration (Sec),Analysis Duration (Sec)\n");
														(void) fflush(dockPerformanceFile);

														pr(dockTimeStatusFile,"First loop send %d jobs at ",firstLoopJobs); //xbzhang designed 2014.3.10

														M_printdate( dockTimeStatusFile, 1 );
														(void) fflush(dockTimeStatusFile);
#endif
														//////////////////////////////////////////////////
														int secondDockInfoCount=0;
														// to begin with, iterate through the docking list for mpisize iterations to send off the first batch of slaves
														//    while(((dockingCounter+1) < mpisize) && ( fgets(line, LINE_LEN, dockingListFile) != NULL))
														while((DockingCounter<firstLoopJobs) && ( fgets(line, LINE_LEN, dockingListFile) != NULL)) //xbzhang designed 2014.3.10
														{
																if (strlen(line) > 0) 
																{
																		// remove eol
																		if (line[strlen(line)-1] == '\n')	line[strlen(line)-1] = '\0';
#ifdef MPI_DEBUG
																		//      printf("Master first loop: Processing docking list entry: %s\n",line);
#endif
																		char jobname[80];
																		sscanf(line,"%s",jobname);


																		//xbzhang designed 2014.3.10
																		masterDockInfo.dockID=DockingCounter;
																		masterDockInfo.ctrlrank=masterDockInfo.dockID%contrlSize;

																		//      masterDockInfo.slaverank = dockingCounter +1;
																		masterDockInfo.endJobSubmit=0;
																		//xbzhang designed end

																		strcpy(masterDockInfo.baseName,jobname);

#ifdef MPI_DEBUG
																		//      printf("Master first loop: about to send dir %s and basename %s\n",dockingDirectoryBaseName,masterDockInfo.baseName);
#endif
																		masterDockInfo.jobNext=0;
																		masterDockInfo.endSlave = 0;
																		DockingCounter++;

#ifdef PERF_PROFILING

																		return_current_date(masterDockInfo.masterMainSendDate);
																		return_current_time(masterDockInfo.masterMainSendTime);
																		time(&masterDockInfo.masterMainSendTime_t);

#endif

																		if(masterDockInfo.ctrlrank!=0)
																		{
																				mpirc = MPI_Send(&masterDockInfo, sizeof(dockinfo), MPI_BYTE, masterDockInfo.ctrlrank, ctrlTag, MPI_COMM_WORLD);  //xbzhang designed 2014.3.10
																				pr(dockSubmittedStatusFile,"%s submitted to second %d at ", masterDockInfo.baseName,masterDockInfo.ctrlrank); //xbzhang designed 2014.3.10

																				M_printdate( dockSubmittedStatusFile, 1 );
																				(void) fflush(dockSubmittedStatusFile);
																		}
																		else
																		{
																				if(secondDockInfoCount<group.size-1)
																				{
																						masterDockInfo.slaverank=group.ranks[secondDockInfoCount+1];
#ifdef PERF_PROFILING

																						return_current_time(masterDockInfo.secondMainSendTime);
																						time(&masterDockInfo.secondMainSendTime_t);

																						pr(dockTimeStatusFile,"job %s recieve and sent at ",masterDockInfo.baseName); //xbzhang designed 2014.3.10

																						M_printdate( dockTimeStatusFile, 1 );
																						(void) fflush(dockTimeStatusFile);
#endif
																						mpirc=MPI_Send(&masterDockInfo, sizeof(dockinfo), MPI_BYTE, masterDockInfo.slaverank, computerTag, MPI_COMM_WORLD);
#ifdef MPI_DEBUG
																						printf("second %d: sent to slave %d, mpirc is %d\n",mpirank,secondDockInfo.slaverank,mpirc);//xbzhang designed 2014.3.10
#endif /* DEBUG */
																						pr(dockSubmittedStatusFile,"%s submitted to node %d by second %d at ", masterDockInfo.baseName,masterDockInfo.slaverank,mpirank); //xbzhang designed 2014.3.10

																						M_printdate( dockSubmittedStatusFile, 1 );
																						(void) fflush(dockSubmittedStatusFile);

																						secondDockingCounter++;
																				}
																				else
																				{
																						ctrlThread.push_back(masterDockInfo);
																				}
																				secondDockInfoCount++;
																		}

#ifdef PERF_PROFILING
																		pr(dockTimeStatusFile,"Job %s sented at ",masterDockInfo.baseName); //xbzhang designed 2014.3.10

																		M_printdate( dockTimeStatusFile, 1 );
																		(void) fflush(dockTimeStatusFile);
#endif
#ifdef MPI_DEBUG
																		//      printf("Master first loop: sent to slave %d, mpirc is %d\n",masterDockInfo.ctrlrank,mpirc);//xbzhang designed 2014.3.10
#endif /* DEBUG */
																}
														}
														//xbzhang designed 2014.3.10
														masterDockInfo.endJobSubmit=1;
														dockListFilePos = ftell(dockingListFile);
														masterDockInfo.dockListFilePos=dockListFilePos;
														for (int i=1;i<contrlSize;i++)
														{
																//printf("mpi_send from %d to %d\n",mpirank,i+1);
																mpirc = MPI_Send(&masterDockInfo, sizeof(dockinfo), MPI_BYTE,i, ctrlTag, MPI_COMM_WORLD);
																//        pr(dockSubmittedStatusFile,"Jobs to second %d is submitted at ", i+1); //xbzhang designed 2014.3.10

																//        printdate( dockSubmittedStatusFile, 1 );
																//        (void) fflush(dockSubmittedStatusFile);
														}
#ifdef PERF_PROFILING
														pr(dockTimeStatusFile,"First loop %d jobs sented at ",firstLoopJobs); //xbzhang designed 2014.3.10

														M_printdate( dockTimeStatusFile, 1 );
														(void) fflush(dockTimeStatusFile);
#endif
														//xbzhang designed end
												}
												else if(mpirank<contrlSize)//xbzhang designed 2014.3.10
												{
														char secondStatusName[20];
														sprintf(secondStatusName,"_second%d",mpirank);
														dockSubmittedStatusFileName = (char *) malloc((strlen(argv[3])+strlen(dockSubmittedStatusFileNameBase)+strlen(secondStatusName) + 1) * sizeof(char));
														strcpy(dockSubmittedStatusFileName,argv[3]);
														strcat(dockSubmittedStatusFileName,dockSubmittedStatusFileNameBase);
														strcat(dockSubmittedStatusFileName,secondStatusName);

														if ( (dockSubmittedStatusFile = fopen(dockSubmittedStatusFileName, "w")) == NULL ) {
																fprintf(stderr, "\nMPDOCKxb master: can't open %s\n", dockSubmittedStatusFileName);
																exit(-1);
														}

														dockSuccessStatusFileName = (char *) malloc((strlen(argv[3])+strlen(dockSuccessStatusFileNameBase)+strlen(secondStatusName) + 1) * sizeof(char));
														strcpy(dockSuccessStatusFileName,argv[3]);
														strcat(dockSuccessStatusFileName,dockSuccessStatusFileNameBase);
														strcat(dockSuccessStatusFileName,secondStatusName);

														if ( (dockSuccessStatusFile = fopen(dockSuccessStatusFileName, "w")) == NULL ) {
																fprintf(stderr, "\nMPDOCKxb master: can't open %s\n", dockSuccessStatusFileName);
																exit(-1);
														}

														dockErrorStatusFileName = (char *) malloc((strlen(argv[3])+strlen(dockErrorStatusFileNameBase)+strlen(secondStatusName) + 1) * sizeof(char));
														strcpy(dockErrorStatusFileName,argv[3]);
														strcat(dockErrorStatusFileName,dockErrorStatusFileNameBase);
														strcat(dockErrorStatusFileName,secondStatusName);

														if ( (dockErrorStatusFile = fopen(dockErrorStatusFileName, "w")) == NULL ) {
																fprintf(stderr, "\nMPDOCKxb master: can't open %s\n", dockErrorStatusFileName);
																exit(-1);
														}
														if((dockingListFile = fopen(argv[1],"r"))==NULL)
														{
																fprintf(stderr,"MPDOCKxb:can not open file %s\n",argv[1]);
																exit(-1);
														}

#ifdef PERF_PROFILING
														dockPerformanceFileName = (char *) malloc((strlen(argv[3])+strlen(dockPerformanceFileNameBase) +strlen(secondStatusName) + 1) * sizeof(char));
														strcpy(dockPerformanceFileName,argv[3]);
														strcat(dockPerformanceFileName,dockPerformanceFileNameBase);
														strcat(dockPerformanceFileName,secondStatusName);

														if ( (dockPerformanceFile = fopen(dockPerformanceFileName, "w")) == NULL ) {
																fprintf(stderr, "\nMPDOCKxb master: can't open %s\n", dockPerformanceFileName);
																exit(-1);
														}

#endif
														int secondDockInfoCount=0;
														int endJobSubmit=0;
#ifdef MPI_DEBUG
														printf("in second %d, waiting\n",mpirank);
#endif
														//  groupID=mpirank%contrlSize;

#ifdef PERF_PROFILING
														pr(dockTimeStatusFile,"Second jobs first loop recieve and send begin at "); //xbzhang designed 2014.3.10

														M_printdate( dockTimeStatusFile, 1 );
														(void) fflush(dockTimeStatusFile);
#endif

														while(!endJobSubmit)
														{
																mpirc = MPI_Recv(&secondDockInfo, sizeof(dockinfo), MPI_BYTE, 0, ctrlTag, MPI_COMM_WORLD, &mpistatus);
																if(secondDockInfo.endJobSubmit==1)
																{
																		endJobSubmit=1;
																		dockListFilePos=secondDockInfo.dockListFilePos;
																		fseek(dockingListFile,dockListFilePos,SEEK_SET);
																}
																else
																{
#ifdef MPI_DEBUG
																		printf("in second %d, processing dock %s\n",mpirank,secondDockInfo.baseName);
#endif
																		if(secondDockInfoCount<group.size-1)
																		{
																				secondDockInfo.slaverank=group.ranks[secondDockInfoCount+1];
#ifdef PERF_PROFILING

																				return_current_time(secondDockInfo.secondMainSendTime);
																				time(&secondDockInfo.secondMainSendTime_t);

																				pr(dockTimeStatusFile,"job %s recieve and sent at ",secondDockInfo.baseName); //xbzhang designed 2014.3.10

																				M_printdate( dockTimeStatusFile, 1 );
																				(void) fflush(dockTimeStatusFile);
#endif

																				mpirc=MPI_Send(&secondDockInfo, sizeof(dockinfo), MPI_BYTE, secondDockInfo.slaverank, computerTag, MPI_COMM_WORLD);
#ifdef MPI_DEBUG
																				printf("second %d: sent to slave %d, mpirc is %d\n",mpirank,secondDockInfo.slaverank,mpirc);//xbzhang designed 2014.3.10
#endif /* DEBUG */
																				pr(dockSubmittedStatusFile,"%s submitted to node %d by second %d at ", secondDockInfo.baseName,secondDockInfo.slaverank,mpirank); //xbzhang designed 2014.3.10

																				M_printdate( dockSubmittedStatusFile, 1 );
																				(void) fflush(dockSubmittedStatusFile);
																				secondDockingCounter++;
																		}
																		else
																		{
																				ctrlThread.push_back(secondDockInfo);
																		}
																		secondDockInfoCount++;
																}
														}

#ifdef MPI_DEBUG
														printf("Second %d: receive all first loop jobs\n",mpirank);
#endif
#ifdef PERF_PROFILING
														pr(dockTimeStatusFile,"Second jobs first loop recieve and send end at "); //xbzhang designed 2014.3.10

														M_printdate( dockTimeStatusFile, 1 );
														(void) fflush(dockTimeStatusFile);
#endif
												}
												else //xbzhang designed end
												{ // slave node
#ifdef MPI_DEBUG
														printf("in slave %d, waiting\n",mpirank);
#endif
														// pkcoff: change to support unduplicated file loading
														if (mapUsageType == REUSE_MAPS) 
														{
																info = (GridMapSetInfo *) malloc( sizeof(GridMapSetInfo) );
																if(scoringFuction==XB_EMPIRCAL)
																{
																		xbEmpiricalMapInfo=(xbempirical_map_info *) malloc( sizeof(xbempirical_map_info) );
																		(void) initializeXBEmpiricalParms(xbEmpiricalMapInfo->xbempirical_parms);
																}
																else if(scoringFuction==XB_PMF)
																		xbPmfMapInfo=(xbpmf_map_info *) malloc( sizeof(xbpmf_map_info) );
														}
														int endSlave = 0;
														int TaskNum=0;
														while (!endSlave) 
														{ 
																// keep waiting for send from master until the master sends an end
																TaskNum++;
																mpirc = MPI_Recv(&slaveDockInfo, sizeof(dockinfo), MPI_BYTE, group.ranks[0], computerTag, MPI_COMM_WORLD, &mpistatus);

#ifdef BGQ_NODE_VERIFICATION
																Personality_t p;
																Kernel_GetPersonality(&p, sizeof(Personality_t));
																int row = BG_UCI_GET_ROW(p.Kernel_Config.UCI);
																int column = BG_UCI_GET_COLUMN(p.Kernel_Config.UCI);
																int midplane = BG_UCI_GET_MIDPLANE(p.Kernel_Config.UCI);
																int nodeBoard = BG_UCI_GET_NODE_BOARD(p.Kernel_Config.UCI);
																int computeCard = BG_UCI_GET_COMPUTE_CARD(p.Kernel_Config.UCI);
																int core = Kernel_ProcessorCoreID();
																int hwtid = Kernel_ProcessorThreadID();

																sprintf(slaveDockInfo.bgqCoordinates,"R%x%x-M%x-N%02d-J%02d-C%02d-T%02d", row, column,midplane,nodeBoard,computeCard,core,hwtid);
#endif

#ifdef PERF_PROFILING
																return_current_time(slaveDockInfo.slaveMainRecvTime);
																time (&slaveDockInfo.slaveMainRecvTime_t);

#endif

																int slave_main_rc;

																// if the master set the endSlave to 1, then don't do anything and exit
																if (slaveDockInfo.endSlave > 0 ) 
																{
																		endSlave = 1;
																		//i want to free the memory on mic,but offload code do not allow me to do that
																		//so i must delete this code...
																		/*
																		   if(MIC_or_CPU=RUN_ON_MIC)
																		   {
																		   char *mpi_slave_argv[6];
																		   for (int i=0;i<6;i++)
																		   mpi_slave_argv[i] = (char *) malloc(300*sizeof(char));
																		   slaveDockInfo.dockingSuccess=-1;
																		   try 
																		   {
																		   M_MIC_STATUS=M_MIC_END;
																		   slaveDockInfo.dockingSuccess = mpi_slave_main(6,mpi_slave_argv,mpirank,seedType,mapUsageType,"");
																		   } 
																		   catch (SlaveException *se) 
																		   {
																		   if (se->slaveRC == 0)
																		   slaveDockInfo.dockingSuccess = -1;
																		   else
																		   slaveDockInfo.dockingSuccess = se->slaveRC;
																		   free(se);
																		   }
																		   for (int i=0;i<5;i++)
																		   free(mpi_slave_argv[i]);
																		   }
																		   */
																}
																else 
																{ // there is work to do

#ifdef MPI_DEBUG
																		printf("in slave %d, receive %s from %d\n",mpirank,slaveDockInfo.baseName,mpistatus.MPI_SOURCE);
																		//       printf("in slave %d, processing dock %s\n",mpirank,slaveDockInfo.baseName);
#endif /* DEBUG */
																		// create the argument list that the original serial main expected from the dockinfo structure that was sent from the main
#ifdef PERF_PROFILING
																		pr(dockTimeStatusFile,"job %s recieve at ",slaveDockInfo.baseName); //xbzhang designed 2014.3.10

																		M_printdate( dockTimeStatusFile, 1 );
																		(void) fflush(dockTimeStatusFile);
#endif

																		if(TaskNum==1)//designed by chengqian, let the computeProgress sleep for 15s
																		{
																				sleep(SleepTime*(mpirank/5000));
																		}
																		char *mpi_slave_argv[6];
																		for (int i=0;i<6;i++)
																				mpi_slave_argv[i] = (char *) malloc(300*sizeof(char));

																		strcpy (mpi_slave_argv[0],"MPDOCKxb");
																		if(scoringFuction==XB_EMPIRCAL)
																				strcpy (mpi_slave_argv[1],"-X");
																		else if (scoringFuction==XB_PMF)
																				strcpy (mpi_slave_argv[1],"-x");
																		strcpy (mpi_slave_argv[2],"-p");
																		//strcpy (mpi_slave_argv[3],slaveDockInfo.baseName);
																		//strcat(mpi_slave_argv[3],".dpf");
																		strcpy(mpi_slave_argv[3],M_dpfname);
																		strcpy (mpi_slave_argv[4],"-l");
																		strcpy(mpi_slave_argv[5],argv[2]);
																		strcat(mpi_slave_argv[5],slaveDockInfo.baseName);
																		strcat(mpi_slave_argv[5],"/");
																		strcat(mpi_slave_argv[5],slaveDockInfo.baseName);
																		strcat(mpi_slave_argv[5],".dlg");
																		strcpy(dlgName,mpi_slave_argv[5]);
																		char dockingDirectoryName[FILENAME_MAX];
																		strcpy(dockingDirectoryName,dockingDirectoryBaseName);
																		strcat(dockingDirectoryName,slaveDockInfo.baseName);

#ifdef MPI_DEBUG
																		printf("in slave %d, about to chdir to  ---%s---\n",mpirank,dockingDirectoryName);
#endif /* DEBUG */

																		// change to the diretory for the ligand to be docked
																		//int num_of_devices=_Offload_number_of_devices();
																		//for(int im=0;im<num_of_devices;im++)
																		//{
																		//#pragma offload target(mic:im)
																		//{}
																		//}
																		/*
																		   int chdir_rc;
																		   chdir_rc = chdir(dockingDirectoryName);

																		   if (chdir_rc != 0) 
																		   {
																		   printf("change dir %s failed with %d errno is %d\n",dockingDirectoryName,chdir_rc,errno);
																		   perror("failed chdir");
																		   }
																		   */
																		/*
#ifdef MPI_DEBUG

size_t size = 100;
char *buffer = (char *) malloc (size);
if (getcwd (buffer, size) == buffer) {
printf("in slave %d, successfully changed dir to %s, getcwd is now %s\n",mpirank,dockingDirectoryName,buffer);
}
else {
printf("chdir failed, buffer is %s\n",buffer);
}
free (buffer);

printf("in slave %d, after chdir to  %s with rc %d\n",mpirank,dockingDirectoryName,chdir_rc);
#endif 
*/

																		// call the original serial main which is now a function
																		// put a try-catch around this to return to the master on exit

																		//    printf("%s is mpi_slave_main(5,%s %s,%d,%d,%d) in slave %d\n",slaveDockInfo.baseName,mpi_slave_argv[2],mpi_slave_argv[4],mpirank,seedType,mapUsageType,mpirank);//xbzhang debug
#ifdef PERF_PROFILING
																		pr(dockTimeStatusFile,"job %s begin at ",slaveDockInfo.baseName); //xbzhang designed 2014.3.10

																		M_printdate( dockTimeStatusFile, 1 );
																		(void) fflush(dockTimeStatusFile);
#endif
																		slaveDockInfo.dockingSuccess=-1;
																		try 
{
		slaveDockInfo.dockingSuccess = mpi_slave_main(6,mpi_slave_argv,mpirank,seedType,mapUsageType,\
						dockingDirectoryName);
} 
catch (SEFather sef)//(SlaveException *se) 
{
		if ((sef.se)->slaveRC == 0)
				slaveDockInfo.dockingSuccess = -1;
		else
				slaveDockInfo.dockingSuccess = (sef.se)->slaveRC;
}

#ifdef MPI_DEBUG
printf("in slave %d, returned from mpi_slave_main\n",mpirank);
#endif /* DEBUG */

for (int i=0;i<5;i++)
free(mpi_slave_argv[i]);

// send the status of the docking back to the master

#ifdef PERF_PROFILING
return_current_time(slaveDockInfo.slaveMainSendTime);
time (&slaveDockInfo.slaveMainSendTime_t);

#endif

//      mpirc = MPI_Send(&slaveDockInfo, sizeof(dockinfo), MPI_BYTE, 0, mpitag, MPI_COMM_WORLD);
//  mpirc = MPI_Send(&slaveDockInfo, sizeof(dockinfo), MPI_BYTE, 0, computerTag, computerComm); //xbzhang designed 2014.2.12
//        printf("mpi_send from %d to %d\n",mpirank,group.ranks[0]);
mpirc = MPI_Send(&slaveDockInfo, sizeof(dockinfo), MPI_BYTE, group.ranks[0], computerTag, MPI_COMM_WORLD); //xbzhang designed 2014.2.12
#ifdef MPI_DEBUG
printf("in slave %d, %s is %s, sent back to second %d\n",mpirank,slaveDockInfo.baseName,slaveDockInfo.dockingSuccess==0?"successful":"failed",slaveDockInfo.ctrlrank);
#endif /* DEBUG */
#ifdef PERF_PROFILING
pr(dockTimeStatusFile,"job %s end at ",slaveDockInfo.baseName); //xbzhang designed 2014.3.10

M_printdate( dockTimeStatusFile, 1 );
(void) fflush(dockTimeStatusFile);
#endif
}
}
if (mapUsageType == REUSE_MAPS) 
{
		free(info);
		if(scoringFuction==XB_EMPIRCAL)
				free(xbEmpiricalMapInfo);
		else if(scoringFuction==XB_PMF)
				free(xbPmfMapInfo);
}
#ifdef MPI_DEBUG
printf("Slave %d is end.\n",mpirank);
#endif
#ifdef PERF_PROFILING
pr(dockTimeStatusFile,"Slave job end at "); //xbzhang designed 2014.3.10

M_printdate( dockTimeStatusFile, 1 );
(void) fflush(dockTimeStatusFile);
#endif
}

//xbzhang designed 2014.3.12
if (mpirank<contrlSize) 
{ 
		// second node
#ifdef MPI_DEBUG
		printf("Second %d: waiting to receive slave responses\n",mpirank);
#endif
		int nojobnext=0;
		while (!nojobnext) 
		{
				while(!ctrlThread.empty()) 
				{
						secondDockInfo = ctrlThread.front();

#ifdef MPI_DEBUG
						printf("Second %d: waiting for chance to submit %s\n",mpirank,secondDockInfo.baseName);
#endif

						mpirc = MPI_Recv(&slaveDockInfo, sizeof(dockinfo), MPI_BYTE,  MPI_ANY_SOURCE, computerTag, MPI_COMM_WORLD, &mpistatus); //xbzhang desigen 2014.3.19
#ifdef MPI_DEBUG
						printf("Second %d: recieve return from %d, %s is end\n",mpirank,mpistatus.MPI_SOURCE,slaveDockInfo.baseName);
#endif
#ifdef PERF_PROFILING
						pr(dockTimeStatusFile,"job %s end recieve at ",slaveDockInfo.baseName); //xbzhang designed 2014.3.10

						M_printdate( dockTimeStatusFile, 1 );
						(void) fflush(dockTimeStatusFile);
#endif
#ifdef PERF_PROFILING
						return_current_time(slaveDockInfo.masterMainRecvTime);
						time(&slaveDockInfo.masterMainRecvTime_t);

#endif

						if(mpistatus.MPI_SOURCE<contrlSize)
						{
								dockListFilePos=slaveDockInfo.dockListFilePos;
								fseek(dockingListFile,dockListFilePos,SEEK_SET);
						}
						else
						{
								if (slaveDockInfo.dockingSuccess == 0) 
								{ // slave success

										// code for generating the blue gene Q location coordinates for use in node computational verification added to the submitted file
#ifdef BGQ_NODE_VERIFICATION

										pr(dockSuccessStatusFile,"%s completed successfully on node %d with coordinates %s at ", slaveDockInfo.baseName,slaveDockInfo.slaverank, slaveDockInfo.bgqCoordinates);
#else
										pr(dockSuccessStatusFile,"%s completed successfully on node %d on second %d at ", slaveDockInfo.baseName, slaveDockInfo.slaverank, mpirank);
#endif
										M_printdate( dockSuccessStatusFile, 1 );
										(void) fflush(dockSuccessStatusFile);
#ifdef PERF_PROFILING
										// Write out performance profiling info

										pr(dockPerformanceFile,"%s,%d,%d,%s,%s,%s,%s,%.0lf,%.0lf,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%.0lf,%.3lf,%d,%.3lf,%.3lf,%.3lf,%.3lf,%d,%.3lf,%.3lf,%.3lf,%.3lf,%.0lf,%d,%.0lf,%.0lf,%.0lf,%.3lf,%.3lf,%.3lf,%.3lf\n", slaveDockInfo.baseName,slaveDockInfo.ctrlrank,slaveDockInfo.slaverank, slaveDockInfo.masterMainSendDate, slaveDockInfo.masterMainSendTime, slaveDockInfo.secondMainSendTime, slaveDockInfo.masterMainRecvTime, difftime(slaveDockInfo.masterMainRecvTime_t, slaveDockInfo.secondMainSendTime_t),difftime(slaveDockInfo.masterMainRecvTime_t, slaveDockInfo.slaveMainSendTime_t), slaveDockInfo.slaveMainRecvTime, slaveDockInfo.slaveMainStartTime, slaveDockInfo.FldFileStartTime, slaveDockInfo.FldFileEndTime, slaveDockInfo.MapFileStartTime, slaveDockInfo.MapFileEndTime, slaveDockInfo.LigandFileStartTime, slaveDockInfo.LigandFileEndTime, slaveDockInfo.LGASetupStartTime, slaveDockInfo.LGAStartTime, slaveDockInfo.LGAEndTime, slaveDockInfo.analysisStartTime, slaveDockInfo.analysisEndTime, slaveDockInfo.SlaveMainPostLGATime,slaveDockInfo.slaveMainEndTime,slaveDockInfo.slaveMainSendTime, difftime(slaveDockInfo.slaveMainEndTime_t, slaveDockInfo.slaveMainStartTime_t), slaveDockInfo.FldFileTotalDuration, slaveDockInfo.FldFileNumber, (double)slaveDockInfo.FldFileMinDuration, (slaveDockInfo.FldFileNumber > 0 ? (double)(slaveDockInfo.FldFileTotalDuration/slaveDockInfo.FldFileNumber) : 0), (double)slaveDockInfo.FldFileMaxDuration, (double)slaveDockInfo.MapFileTotalDuration, slaveDockInfo.MapFileNumber, (double)slaveDockInfo.MapFileMinDuration, (slaveDockInfo.MapFileNumber > 0 ? (double)(slaveDockInfo.MapFileTotalDuration/slaveDockInfo.MapFileNumber) : 0), (double)slaveDockInfo.MapFileMaxDuration,  slaveDockInfo.LigandFileTotalDuration, difftime(slaveDockInfo.LGAEndTime_t, slaveDockInfo.LGAStartTime_t),slaveDockInfo.LGAIters, slaveDockInfo.LGAMinRuntime, (slaveDockInfo.LGAIters > 0 ? (slaveDockInfo.LGATotalRuntime/slaveDockInfo.LGAIters) : 0), slaveDockInfo.LGAMaxRuntime, (double) slaveDockInfo.LGAMinRuntimeIO, (slaveDockInfo.LGAItersIO > 0 ? (double) (slaveDockInfo.LGATotalRuntimeIO/slaveDockInfo.LGAItersIO) : 0), (double) slaveDockInfo.LGAMaxRuntimeIO, (double)slaveDockInfo.analysisDuration);

										(void) fflush(dockPerformanceFile);

#endif
								}
								else 
								{ // slave failure

#ifdef BGQ_NODE_VERIFICATION

										pr(dockErrorStatusFile,"%s failed on node %d with coordinates %s - look in stderr for the details, at ", slaveDockInfo.baseName,slaveDockInfo.slaverank, slaveDockInfo.bgqCoordinates);
#else

										pr(dockErrorStatusFile,"%s failed on node %d - look in stderr for the details, on second %d at ", slaveDockInfo.baseName,slaveDockInfo.slaverank,mpirank);
#endif

										M_printdate( dockErrorStatusFile, 1 );
										(void) fflush(dockErrorStatusFile);
								}

#ifdef MPI_DEBUG
								printf("second %d: slave %d returned for docking %s with rc %d\n", mpirank,slaveDockInfo.slaverank, slaveDockInfo.baseName, slaveDockInfo.dockingSuccess);
#endif
								slaveReturns++;

								// prepare to send more work to the same slave
								secondDockInfo.slaverank = slaveDockInfo.slaverank;
#ifdef MPI_DEBUG
								printf("second %d: about to send dir %s and basename %s\n",mpirank,dockingDirectoryBaseName,secondDockInfo.baseName);
#endif

								secondDockInfo.endSlave = 0;

								secondDockingCounter++;

#ifdef PERF_PROFILING
								pr(dockTimeStatusFile,"job %s sent at ",secondDockInfo.baseName); //xbzhang designed 2014.3.10

								M_printdate( dockTimeStatusFile, 1 );
								(void) fflush(dockTimeStatusFile);
#endif
#ifdef PERF_PROFILING

								return_current_time(secondDockInfo.secondMainSendTime);
								time(&secondDockInfo.secondMainSendTime_t);

#endif

								mpirc = MPI_Send(&secondDockInfo, sizeof(dockinfo), MPI_BYTE, secondDockInfo.slaverank, computerTag, MPI_COMM_WORLD);

								pr(dockSubmittedStatusFile,"%s submitted to node %d by second %d at ", secondDockInfo.baseName,slaveDockInfo.slaverank,mpirank);
								M_printdate( dockSubmittedStatusFile, 1 );
								(void) fflush(dockSubmittedStatusFile);

#ifdef MPI_DEBUG
								printf("Second %d: sent to slave %d, mpirc is %d\n",mpirank,slaveDockInfo.slaverank,mpirc);
#endif
								ctrlThread.pop_front();

#ifdef MPI_DEBUG
								//      printf("Second %d: there are %d jobs\n",mpirank,ctrlThread.size());
#endif
						}
				}

				int jobNext = group.size*0.5;
				int i=0;
				while(i<jobNext)
				{
						if(fgets(line,100,dockingListFile) != NULL)
						{
								char jobname[80];
								sscanf(line,"%s",jobname);
								dockListFilePos=ftell(dockingListFile);

								strcpy(secondDockInfo.baseName,jobname);
								secondDockInfo.dockID=DockingCounter+1;
								secondDockInfo.ctrlrank=mpirank;
								secondDockInfo.endSlave=0;
								secondDockInfo.jobNext=0;
#ifdef PERF_PROFILING

								return_current_date(secondDockInfo.masterMainSendDate);
								return_current_time(secondDockInfo.masterMainSendTime);
								time(&secondDockInfo.masterMainSendTime_t);

#endif
								ctrlThread.push_back(secondDockInfo);

						}
						else
						{
								nojobnext=1;
								break;
						}
						i++;
				}
				dockListFilePos=ftell(dockingListFile);
				secondDockInfo.dockListFilePos=dockListFilePos;
				for(int i=0;i<contrlSize;i++)
				{
						if(i!=mpirank)
								mpirc = MPI_Send(&secondDockInfo, sizeof(dockinfo), MPI_BYTE, i, computerTag, MPI_COMM_WORLD);
				}
#ifdef PERF_PROFILING
				pr(dockTimeStatusFile,"new jobs recieve at "); //xbzhang designed 2014.3.10

				M_printdate( dockTimeStatusFile, 1 );
				(void) fflush(dockTimeStatusFile);
#endif
		}
		// wait for remaing slaves to return to master
		while (slaveReturns < secondDockingCounter) 
		{
#ifdef MPI_DEBUG
				printf("Second %d: waiting for another remaining slave to return\n",mpirank);
#endif
				mpirc = MPI_Recv(&slaveDockInfo, sizeof(dockinfo), MPI_BYTE,  MPI_ANY_SOURCE, computerTag, MPI_COMM_WORLD, &mpistatus);
#ifdef PERF_PROFILING
				return_current_time(slaveDockInfo.masterMainRecvTime);
				time(&slaveDockInfo.masterMainRecvTime_t);
#endif
#ifdef PERF_PROFILING
				pr(dockTimeStatusFile,"job %s end recieve at ",slaveDockInfo.baseName); //xbzhang designed 2014.3.10

				M_printdate( dockTimeStatusFile, 1 );
				(void) fflush(dockTimeStatusFile);
#endif
				if (slaveDockInfo.dockingSuccess == 0) { // success
#ifdef BGQ_NODE_VERIFICATION
						pr(dockSuccessStatusFile,"%s completed successfully on node %d with coordinates %s at ", slaveDockInfo.baseName,slaveDockInfo.slaverank, slaveDockInfo.bgqCoordinates);
#else
						pr(dockSuccessStatusFile,"%s completed successfully on node %d on second %d at ", slaveDockInfo.baseName,slaveDockInfo.slaverank,mpirank);
#endif

						M_printdate( dockSuccessStatusFile, 1 );
						(void) fflush(dockSuccessStatusFile);
#ifdef PERF_PROFILING
						// Write out performance profiling info
						pr(dockPerformanceFile,"%s,%d,%d,%s,%s,%s,%s,%.0lf,%.0lf,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%.0lf,%.3lf,%d,%.3lf,%.3lf,%.3lf,%.3lf,%d,%.3lf,%.3lf,%.3lf,%.3lf,%.0lf,%d,%.0lf,%.0lf,%.0lf,%.3lf,%.3lf,%.3lf,%.3lf\n", slaveDockInfo.baseName,slaveDockInfo.ctrlrank,slaveDockInfo.slaverank, slaveDockInfo.masterMainSendDate, slaveDockInfo.masterMainSendTime, slaveDockInfo.secondMainSendTime, slaveDockInfo.masterMainRecvTime, difftime(slaveDockInfo.masterMainRecvTime_t, slaveDockInfo.secondMainSendTime_t),difftime(slaveDockInfo.masterMainRecvTime_t, slaveDockInfo.slaveMainSendTime_t), slaveDockInfo.slaveMainRecvTime, slaveDockInfo.slaveMainStartTime, slaveDockInfo.FldFileStartTime, slaveDockInfo.FldFileEndTime, slaveDockInfo.MapFileStartTime, slaveDockInfo.MapFileEndTime, slaveDockInfo.LigandFileStartTime, slaveDockInfo.LigandFileEndTime, slaveDockInfo.LGASetupStartTime, slaveDockInfo.LGAStartTime, slaveDockInfo.LGAEndTime, slaveDockInfo.analysisStartTime, slaveDockInfo.analysisEndTime, slaveDockInfo.SlaveMainPostLGATime,slaveDockInfo.slaveMainEndTime,slaveDockInfo.slaveMainSendTime, difftime(slaveDockInfo.slaveMainEndTime_t, slaveDockInfo.slaveMainStartTime_t), slaveDockInfo.FldFileTotalDuration, slaveDockInfo.FldFileNumber, (double)slaveDockInfo.FldFileMinDuration, (slaveDockInfo.FldFileNumber > 0 ? (double)(slaveDockInfo.FldFileTotalDuration/slaveDockInfo.FldFileNumber) : 0), (double)slaveDockInfo.FldFileMaxDuration, (double)slaveDockInfo.MapFileTotalDuration, slaveDockInfo.MapFileNumber, (double)slaveDockInfo.MapFileMinDuration, (slaveDockInfo.MapFileNumber > 0 ? (double)(slaveDockInfo.MapFileTotalDuration/slaveDockInfo.MapFileNumber) : 0), (double)slaveDockInfo.MapFileMaxDuration,  slaveDockInfo.LigandFileTotalDuration, difftime(slaveDockInfo.LGAEndTime_t, slaveDockInfo.LGAStartTime_t),slaveDockInfo.LGAIters, slaveDockInfo.LGAMinRuntime, (slaveDockInfo.LGAIters > 0 ? (slaveDockInfo.LGATotalRuntime/slaveDockInfo.LGAIters) : 0), slaveDockInfo.LGAMaxRuntime, (double) slaveDockInfo.LGAMinRuntimeIO, (slaveDockInfo.LGAItersIO > 0 ? (double) (slaveDockInfo.LGATotalRuntimeIO/slaveDockInfo.LGAItersIO) : 0), (double) slaveDockInfo.LGAMaxRuntimeIO, (double)slaveDockInfo.analysisDuration);

						(void) fflush(dockPerformanceFile);
#endif
				}
				else 
				{

						pr(dockErrorStatusFile,"%s failed on node %d, look in stderr for the details, on second %d at ", slaveDockInfo.baseName,slaveDockInfo.slaverank,mpirank);
						M_printdate( dockErrorStatusFile, 1 );
						(void) fflush(dockErrorStatusFile);
				}
#ifdef MPI_DEBUG
				printf("second %d: slave %d returned for docking %s with rc %d\n",mpirank,slaveDockInfo.slaverank, slaveDockInfo.baseName, slaveDockInfo.dockingSuccess);
#endif
				slaveReturns++;
		}

#ifdef MPI_DEBUG
		printf("second %d: all slaves have returned\n",mpirank);
#endif

		// end all slaves
		for (int i=1;i<group.size;i++) 
		{
				secondDockInfo.endSlave = 1;
				mpirc = MPI_Send(&secondDockInfo, sizeof(dockinfo), MPI_BYTE, group.ranks[i], computerTag, MPI_COMM_WORLD);
				pr(dockSubmittedStatusFile,"second %d: stopping node %d at ", mpirank, group.ranks[i]);
				M_printdate( dockSubmittedStatusFile, 1 );
				(void) fflush(dockSubmittedStatusFile);
		}
		pr(dockSubmittedStatusFile,"Jobs on second %d is finished at ", mpirank); //xbzhang designed 2014.3.10

		M_printdate( dockSubmittedStatusFile, 1 );
		(void) fflush(dockSubmittedStatusFile);

		pr(dockSubmittedStatusFile,"second %d is end at ", mpirank); //xbzhang designed 2014.3.10

		M_printdate( dockSubmittedStatusFile, 1 );
		(void) fflush(dockSubmittedStatusFile);
		int close_rc;
		if ( close_rc = fclose(dockSubmittedStatusFile) != 0 ) {
				fprintf(stderr, "\nMPDOCKxb master: can't close %s\n", dockSubmittedStatusFileName);
				//           exit(-1);
		}

		if ( close_rc = fclose(dockErrorStatusFile) != 0 ) {
				fprintf(stderr, "\nMPDOCKxb master: can't close %s\n", dockErrorStatusFileName);
				//           exit(-1);
		}

		if ( close_rc = fclose(dockSuccessStatusFile) != 0 ) {
				fprintf(stderr, "\nMPDOCKxb master: can't close %s\n", dockSuccessStatusFileName);
				//           exit(-1);
		}

#ifdef MPI_DEBUG
		printf("second %d is end.\n",mpirank);
#endif
#ifdef PERF_PROFILING
		pr(dockTimeStatusFile,"Second job end at "); //xbzhang designed 2014.3.10

		M_printdate( dockTimeStatusFile, 1 );
		(void) fflush(dockTimeStatusFile);
#endif
} //second end
mpirc=MPI_Barrier(MPI_COMM_WORLD);

#ifdef PERF_PROFILING
pr(dockTimeStatusFile,"Rank %d finished at ",mpirank); //xbzhang designed 2014.3.10

M_printdate( dockTimeStatusFile, 1 );
(void) fflush(dockTimeStatusFile);
int close_rc;
if ( close_rc = fclose(dockTimeStatusFile) != 0 ) {
		fprintf(stderr, "\nMPDOCKxb master: can't close %s\n", dockTimeStatusFileName);
		//      exit(-1);
}
#endif

mpirc = MPI_Finalize();
totalTimeEnd=time(NULL);
time_duration=totalTimeEnd-totalTimeBegin;
printf("Total time of D3DOCKxb:%d\n",time_duration);
return 0;
}

#endif

#ifdef AUTODOCK_MPI
int mpi_slave_main(int argc, char ** argv,int mpirank, int seedtype, int mapusagetype,char*dockingDirectoryName)
#else
int main (int argc, char ** argv)
#endif
{
		int mic_no=0;
		MIC_or_CPU=RUN_ON_CPU;
#ifdef AUTODOCK_MPI
		int layer=mpirank%NpOnNodes;
		if(layer==0) MIC_or_CPU=RUN_ON_CPU;
		else if(layer==1)
		{ 
				MIC_or_CPU=RUN_ON_MIC;
				mic_no=0;
		}
		else if(layer==2)
		{
				MIC_or_CPU=RUN_ON_MIC;
				mic_no=1;
		}
		else if(layer==3)
		{
				MIC_or_CPU=RUN_ON_MIC;
				mic_no=1;
		}
		else if(layer==4)
		{
				MIC_or_CPU=RUN_ON_MIC;
				mic_no=1;
		}
		else MIC_or_CPU=RUN_ON_CPU;
		int num_of_mic;
		num_of_mic=_Offload_number_of_devices();
		if(mic_no>=num_of_mic) MIC_or_CPU=RUN_ON_CPU;
#endif
		//    printf("slave %d: job %s began\n",mpirank,argv[2]);
		char HName[64];
		gethostname(HName,64);
		//	printf("mpirank %d\t\thostname:%s\n",mpirank,HName);
#ifdef PERF_PROFILING

		return_current_time(slaveDockInfo.slaveMainStartTime);
		time (&slaveDockInfo.slaveMainStartTime_t);

		Real serialCurrentDuration;
		time_t serialStartTime_t,serialEndTime_t;

		struct tms tms_serialStart;
		struct tms tms_serialEnd;

		Clock  serialStartClock;
		Clock  serialEndClock;

		slaveDockInfo.LGAMaxRuntime = 0.0;
		slaveDockInfo.LGAMinRuntime = -1.0;
		slaveDockInfo.LGAIters = 0;
		slaveDockInfo.LGATotalRuntime =0.0;

		slaveDockInfo.LGAMaxRuntimeIO = 0.0;
		slaveDockInfo.LGAMinRuntimeIO = -1.0;
		slaveDockInfo.LGAItersIO = 0;
		slaveDockInfo.LGATotalRuntimeIO =0.0;

		slaveDockInfo.firstFldFileFound = 0;
		slaveDockInfo.FldFileMaxDuration = 0.0;
		slaveDockInfo.FldFileMinDuration = -1.0;
		slaveDockInfo.FldFileNumber = 0;
		slaveDockInfo.FldFileTotalDuration = 0.0;

		slaveDockInfo.firstMapFileFound = 0;
		slaveDockInfo.MapFileMaxDuration = 0.0;
		slaveDockInfo.MapFileMinDuration = -1.0;
		slaveDockInfo.MapFileNumber = 0;
		slaveDockInfo.MapFileTotalDuration = 0.0;

		slaveDockInfo.firstLigandFileFound = 0;
		slaveDockInfo.LigandFileTotalDuration = 0.0;

		slaveDockInfo.analysisDuration = 0.0;

#endif



#ifndef AUTODOCK_MPI
		// int seedtype = DEFAULT_SEED;
		int seedtype = SAME_SEED;
		int mpirank = 0;
		int mapusagetype = RELOAD_MAPS;
#endif

		int LS_Type=-1;
		Real T_xb1,T_xb2,T_ad1,T_ad2,T_ad3;
		Real T_crdpdb[MAX_ATOMS][SPACE];
		Real T_crdreo[MAX_ATOMS][SPACE];
		Real T_crd[MAX_ATOMS][SPACE];
		Real T_vt[MAX_TORS][SPACE];
		Quat T_q_reorient;
		Molecule T_ligand;
		Real T_eintra,T_einter,T_FE;

		// pkcoff: change to support unduplicated file loading
		//GridMapSetInfo *info;  // this information is from the AVS field file
		int newMapsToAddIndex = 0;
		int atomTypeMapIndex = 0;
		int num_maps_iterated = 0;


		int xbempirical_donor_index;
		int xbempirical_acceptor_index;

		int xbempirical_ligand_xbdonor[MAX_ATOMS][2];	// ligand halogen bond donor link atom serial - 1
		__declspec(target(mic))static Real xb_empirical_vdw = 0.;
		__declspec(target(mic))static Real xb_empirical_es = 0.;
		__declspec(target(mic))static Real ad_vdw = 0.;
		__declspec(target(mic))static Real ad_es = 0.;
		__declspec(target(mic))static Real ad_desolv = 0.;
#pragma omp threadprivate(ad_vdw, ad_es, ad_desolv,xb_empirical_vdw,xb_empirical_es)
		//static L_Local_Search *L_LocalSearchMethod;

		//#pragma omp threadprivate(L_GlobalSearchMethod)

		int xbpmf_ligand_hb_donorH_ids[MAX_ATOMS][5];
		int xbpmf_ligand_xb_donorX_id[MAX_ATOMS];
		int xbpmf_ligand_at_index[MAX_ATOMS];
		//int xbpmf_receptor_at_index[MAX_RECEPTOR_ATOMS];
		int xbpmf_ligand_hb_acceptor[MAX_ATOMS];
		int xbpmf_ligand_hb_donor[MAX_ATOMS];
		int xbpmf_ligand_xb_donor[MAX_ATOMS];
		int xbpmf_receptor_hb_acceptor[MAX_RECEPTOR_ATOMS];

		// double *map;  // Use this with malloc...
		char atomstuff[MAX_ATOMS][MAX_CHARS];

		//   MAX_ATOMS
		//

		char pdbaname[MAX_ATOMS][5];
		__declspec(target(mic))static Real crdpdb[MAX_ATOMS][SPACE];  // original PDB coordinates from input
		__declspec(target(mic))static Real crdreo[MAX_ATOMS][SPACE];  // reoriented coordinates
		__declspec(target(mic))static Real crd[MAX_ATOMS][SPACE];     // current coordinates
		Real charge[MAX_ATOMS];
		Real abs_charge[MAX_ATOMS];
		Real qsp_abs_charge[MAX_ATOMS];
		Real elec[MAX_ATOMS];
		Real emap[MAX_ATOMS];
		int type[MAX_ATOMS];
		int bond_index[MAX_ATOMS];
		int ignore_inter[MAX_ATOMS];
		Atom atoms[MAX_ATOMS];
		/*

*/


		//   MAX_TORS
		//
		int  tlist[MAX_TORS][MAX_ATOMS];
		__declspec(target(mic))static Real vt[MAX_TORS][SPACE];
		Real F_TorConRange[MAX_TORS][MAX_TOR_CON][2];
		unsigned short  US_TorE[MAX_TORS];
		Boole B_isTorConstrained[MAX_TORS];
		int N_con[MAX_TORS];
		unsigned short US_torProfile[MAX_TORS][NTORDIVS];
		__declspec(target(mic))static Quat q_reorient;
		__declspec(target(mic))static Molecule ligand;        /* ligand */

#pragma omp threadprivate(crd, crdreo, vt, crdpdb, q_reorient, ligand)

		//   MAX_NONBONDS
		//
		NonbondParam *nonbondlist = new NonbondParam[MAX_NONBONDS];
		//   LINE_LEN
		//
		char error_message[LINE_LEN];
		char message[LINE_LEN];
		char line[LINE_LEN];
		char torfmt[LINE_LEN];
		char param[2][LINE_LEN];
		char rms_atoms_cmd[LINE_LEN];
		char c_mode_str[LINE_LEN];
		char confsampler_type[LINE_LEN];
		char autodock_parameter_version[LINE_LEN]; //eg 4.1.1

		// filename max length is taken from system include file
		char FN_parameter_library[PATH_MAX];
		char FN_ligand[PATH_MAX];
		char FN_flexres[PATH_MAX];
		char FN_rms_ref_crds[PATH_MAX];
		char FN_clus[PATH_MAX];
		char FN_watch[PATH_MAX];
		char dummy_FN_ligand[PATH_MAX];
		char FN_pop_file[PATH_MAX];
		char FN_trj[PATH_MAX];
		//char FN_gdfld[PATH_MAX]  // now part of the GridMapSetInfo structure;
		//char FN_gpf[PATH_MAX];  // now part of the GridMapSetInfo structure
		//char FN_receptor[PATH_MAX];// now part of the GridMapSetInfo structure

		//   MAX_CHARS
		char hostnm[MAX_CHARS];

		//   MAX_RECORDS
		//
		char PDBQT_record[MAX_RECORDS][LINE_LEN];

		//   SPACE
		//
		Real lig_center[SPACE];
		//Real map_center[SPACE];

		//   MAX_RUNS
		//
		__declspec(target(mic))Real econf[MAX_RUNS];  // this is the list of energies printed in the histogram in "analysis"
		__declspec(target(mic))State sHist[MAX_RUNS];  /* qtnHist[MAX_RUNS][QUAT],torHist[MAX_RUNS][MAX_TORS];*/
		State sUnbound; // State of the unbound ligand's conformation
		State sUnbound_ext; // State of the unbound ligand's conformation after extended-conformation search
		//// UNCOMMENT if using Step 2 in unbound calculation ---> State sUnbound_ls; // State of the unbound ligand's conformation after a local search
		State sUnbound_ad; // State of the unbound ligand's conformation after an AutoDock search

		char out_acc_rej = '?';
		__declspec(target(mic))char timeSeedIsSet[2];
		char selminpar = 'm';
		char S_contype[8];

		//   MAX_ATOM_TYPES
		//
		char *ligand_atom_type_ptrs[MAX_ATOM_TYPES]; /* array of ptrs used to parse input line of atom type names */
		ParameterEntry parameterArray[MAX_ATOM_TYPES]; // input  nonbond and desolvation parameters
		static ParameterEntry * foundParameter;

		Real cA;
		Real cB;
		Real cA_unbound = 392586.8;  // repulsive
		Real cB_unbound = 0.0; // attractive
		Real epsij;
		Real F_A;
		Real F_Aova;
		Real F_tor;
		Real F_torPref;
		Real F_torHWdth;
		Real Rij;
		Real sqlower;
		Real squpper;
		Real tmpconst;

		// Distance-dependence in Desolvation Term
		const double sigma = 3.6L;
		const double qsolpar = 0.01097L;

		// ELECSCALE converts between CGS units and SI units;
		// see, e.g. p 254, "Molecular Modeling and Simulation", by Tamar Schlick, Springer.
		//
		// Units of ELECSCALE are (Kcal/mol ) * (Angstrom / esu^2)
		// and this allows us to use distances in  Angstroms and charges in esu...
		const Real ELECSCALE = 332.06363;

		// const Real ELECSCALE = 83.0159075;   this ELECSCALE (corresponding to eps(r) = 1/4r) gives -7.13 kcal/mol for 1pgp Tests/test_autodock4.py

		// i
		double Ri, epsi, Ri_hb, epsi_hb;
		hbond_type hbondi;

		// j
		double Rj, epsj, Rj_hb, epsj_hb;
		hbond_type hbondj;

		Real scale_1_4 = 0.5;
		Real c=0.0;
		Real clus_rms_tol = 0.0;
		Real e0max = BIG;

		/***************
		//YTLIU_NOTE
		 ***************/
		__declspec(target(mic))static Real eintra = 0.0;  // sum of intramolecular energy for the ligand plus that of the protein
		__declspec(target(mic))static Real einter = 0.0; // intermolecular energy between the ligand and the protein
		Real etotal = 0.0;

		Real AD3_FE_coeff_estat   = 1.000;
		Real qtwFac = 1.0;
		Real qtwStep0 = DegreesToRadians( 5.0 );
		Real qtwStepFinal = DegreesToRadians( 0.5 );
		Real maxrad = -1.0;
		Real r2sum=0.0;
		// Real RJ = 8.31441;     // in J/K/mol, Gas Constant, Atkins Phys.Chem., 2/e
		// Real Rcal = 1.9871917; // in cal/K/mol, Gas Constant, RJ/4.184
		// Real T0K = 273.15;        // 0 degrees Celsius, in K
		Real RTreduc = 1.0;
		// Real spacing = 0.0;// now part of the GridMapSetInfo structure
		Real RT0 = 616.0;
		Real RTFac = 0.95;

		/***************
		//YTLIU_NOTE
		 ***************/
		Real torsdoffac = 0.3113;
		Real torsFreeEnergy = 0.0;

		Real torFac = 1.0;
		Real torStep0 = DegreesToRadians( 5.0 );
		Real torStepFinal = DegreesToRadians( 1.0 );
		Real trnFac = 1.0;
		Real trnStep0 = 0.2;
		Real trnStepFinal = 0.2;
		Real WallEnergy = 1.0e8; /* Energy barrier beyond walls of gridmaps. */
		//  The GA Stuff
		Real m_rate = 0.02;
		Real c_rate = 0.80;
		Real alpha = 0;
		Real beta = 1;
		Real search_freq = 0.06;
		__declspec(target(mic))static Real unbound_internal_FE = 0.0;
		Real unbound_ext_internal_FE = 0.0;
		Real unbound_ad_internal_FE = 0.0;

#pragma omp threadprivate(eintra, einter, unbound_internal_FE)

		/***************
		//YTLIU_NOTE
		 ***************/
		Real emap_total = 0.;
		Real elec_total = 0.;
		Real charge_total = 0.;
		Real etot = 0.;

		//  The LS Stuff
		Real rho = 1.0;
		Real lb_rho = 0.01;

		Real psw_trans_scale = 1.0;//1 angstrom
		Real psw_rot_scale = 0.05;  //about 3 degrees, we think
		Real psw_tors_scale = 0.1; //about 6 degrees

		Unbound_Model ad4_unbound_model = Unbound_Default;
		//NOT Same_As_Bound so user can specify in dpf

		EnergyBreakdown eb;

		M_initialise_energy_breakdown(&eb, 0, 0);

		unsigned int outputEveryNgens = 100;

		Boole B_atom_types_found = FALSE;
		Boole B_isGaussTorCon = FALSE;
		Boole B_constrain_dist;
		Boole B_either = FALSE;
		Boole B_calcIntElec = FALSE;
		Boole B_calcIntElec_saved = FALSE;
		Boole B_write_trj = FALSE;
		Boole B_watch = FALSE;
		Boole B_acconly = FALSE;
		Boole B_cluster_mode = FALSE;
		Boole B_havemap = FALSE;
		Boole B_havenbp = FALSE;
		Boole B_haveCharges;
		Boole B_linear_schedule = FALSE;
		Boole B_qtwReduc = FALSE;
		Boole B_selectmin = FALSE;
		Boole B_symmetry_flag = TRUE;
		Boole B_tempChange = TRUE;
		Boole B_torReduc = FALSE;
		Boole B_trnReduc = FALSE;
		Boole B_write_all_clusmem = FALSE;
		Boole B_ShowTorE = FALSE;
		Boole B_RandomTran0 = FALSE;
		Boole B_RandomQuat0 = FALSE;
		Boole B_RandomDihe0 = FALSE;
		Boole B_CalcTrnRF = FALSE;
		Boole B_CalcQtwRF = FALSE;
		Boole B_CalcTorRF = FALSE;
		Boole B_charMap = FALSE;
		Boole B_include_1_4_interactions = FALSE;  // This was the default behaviour in previous AutoDock versions (1 to 3).
		Boole B_found_move_keyword = FALSE;
		Boole B_found_ligand_types = FALSE;
		Boole B_found_autodock_parameter_version = FALSE;
		Boole B_use_non_bond_cutoff = TRUE;
		Boole B_have_flexible_residues = FALSE;  // if the receptor has flexible residues, this will be set to TRUE
		Boole B_rms_atoms_ligand_only = TRUE;  // cluster on the ligand atoms only
		Boole B_reorient_random = FALSE; // if true, create a new random orientation before docking
		int atm1=0;
		int atm2=0;
		int a1=0;
		int a2=0;
		int atomC1;
		int atomC2;
		int dpf_keyword = -1;
		//int gridpts1[SPACE];  // now part of the GridMapSetInfo structure
		//int gridpts[SPACE];  // now part of the GridMapSetInfo structure
		int n_heavy_atoms_in_ligand = 0;
		int ncycles = -1;
		int iCon=0;
		int indcom = 0;
		int ligand_is_inhibitor = 1;
		int ltorfmt = 4;
		int nruns = 0;
		int nstepmax = -1;
		int naccmax = 0;
		int natom = 0;
		int nconf = 0;
		int ncycm1 = 1;
		int ndihed = 0;
		int nlig = 0;
		int nres = 0;
		int nmol = 0;
		int Nnb = 0;
		int nrejmax = 0;
		int ntor = 0;
		int ntor1 = 1;
		int ntor_ligand = 0;
		int ntorsdof = 0;

		static Boole xbPmfMapAlreadyLoaded = FALSE;
		static Boole xbPmfReceptorAlreadLoaded = FALSE;
		static Boole xbPmfParmsAlreadLoaded = FALSE;

		static Boole xbEmpiricalParmsAlreadLoaded = FALSE;
		static Boole xbEmpiricalReceptorAlreadLoaded = FALSE;
		static Boole xbEmpiricalVDWProfileAlreadLoaded = FALSE;
		static Boole xbEmpiricalESProfileAlreadLoaded = FALSE;
		static Boole xbEmpiricalDesolvProfileAlreadLoaded = FALSE;

		Boole mapFileAlreadyLoaded = FALSE;
		char FileName[PATH_MAX];

		static int num_maps = 0;
		int num_atom_types = 0;
		int nval = 0;
		int outlev = -1;
		int retval = 0;
		int trj_end_cyc = 0;
		int trj_begin_cyc = 0;
		int trj_freq = 0;
		int xA = 12;
		int xB = 6;
		int xA_unbound = 12;
		int xB_unbound = 6;
		int I_tor;
		int I_torBarrier;
		int MaxRetries = 1000; /* Default maximum number of retries for ligand init. */
		int OutputEveryNTests = 1000;
		int NumLocalTests = 10;
		int maxTests = 10000;
		int parameter_library_found = 0;
		/* int beg; */
		/* int end; */
		/* int imol = 0; */
		int outside = FALSE;
		int atoms_outside = FALSE;
		// unsigned int min_evals_unbound =  250000;
		unsigned int max_evals_unbound = 1000000;
		int saved_sInit_ntor = 0;
		int confsampler_samples = 0;

		unsigned short US_energy;
		unsigned short US_tD;
		unsigned short US_torBarrier = TORBARMAX;
		unsigned short US_min = TORBARMAX;

		register int i = 0;
		__declspec(target(mic))register int j = 0;
		register int k = 0;
		/**********************
		// YTLIU_EDIT 2013.01.04
		 **********************/
		register int m = 0;
		//register int n = 0;

		register int xyz = 0;
		static int j1 = 1;
#pragma omp threadprivate(j1)

		State sInit;            /* Real qtn0[QUAT], tor0[MAX_TORS]; */



		static Real F_A_from;
		static Real F_A_to;
		static Real F_lnH;
		static Real F_W;
		static Real F_hW;
		static FourByteLong clktck = 0;

#ifndef VERSION
		static char* version_num = "4.2.2";
#else
		static char* version_num = VERSION;
#endif

		struct tms tms_jobStart;
		struct tms tms_gaStart;
		struct tms tms_gaEnd;
		struct tms tms_psoStartClock;
		struct tms tms_psoEndClock;

		Clock  jobStart;
		Clock  gaStart;
		Clock  gaEnd;

		/***************
		//YTLIU_NOTE
		 ***************/
		EnergyTables *ad_energy_tables;  // Holds vdw+Hb, desolvation & dielectric lookup tables
		EnergyTables *unbound_energy_tables;  // Use for computing unbound energy & conformation

		Statistics map_stats;
		/******************************
		// YTLIU_EDIT 2013.01.25
		 ******************************/
		Statistics profile_stats;

		//  The GA Stuff
		__declspec(target(mic))static FourByteLong seed[2];
		__declspec(target(mic))static time_t time_seed;
#pragma omp threadprivate(seed, time_seed)
		unsigned int pop_size = 200;
		unsigned int num_generations = 0;  //  Don't terminate on the basis of number of generations
		unsigned int num_evals = 250000;
		unsigned int num_evals_unbound = num_evals;
		unsigned int max_its = 300;
		unsigned int max_succ = 4;
		unsigned int max_fail = 4;
		int window_size = 10;
		int low = 0;
		int high = 100;
		int elitism = 1;


		// For Branch Crossover Mode
		int end_of_branch[MAX_TORS];

		Selection_Mode s_mode = Proportional;
		Real linear_ranking_selection_probability_ratio = 2.0;
		Xover_Mode c_mode = TwoPt;  //  can be: OnePt, TwoPt, Uniform or Arithmetic
		Worst_Mode w_mode = AverageOfN;
		EvalMode e_mode = Normal_Eval;

		//---------PSO Variable Declaration
		// Local Variables
		//

		// Confidence Coefficients
		//double w = 0 ; // First confidence coefficient
		//double w_start = 0.9 ; // First confidence coefficient-Start
		//double w_end = 0.4 ; // First confidence coefficient-End
		double c1 = 0; // second confidence coefficient
		double c2 = 0; // second confidence coefficient
		int K ; // Max number of particles informed by a given one
		int n_exec, n_exec_max; //Nbs of executions

		//Boole B_notinbox; //For checking in Grid Box
		// SSM-PSO
		//double mc = 0.3; // momentum constant for SSM-PSO

		Clock  psoStartClock;
		Clock  psoEndClock;

		time_t ProgStart,ProgEnd,MICStart,MICEnd;
		long Progduration,MICduration;

		XBLigand xbligand;
		int xbligand_natom = 0;
		Real xbligand_crdpdb[MAX_ATOMS][NTRN];
		Real xbligand_charge[MAX_ATOMS];
		Boole xbligand_B_haveCharges;
		char xbligand_pdbaname[MAX_ATOMS][5];
		Atom xbligand_atoms[MAX_ATOMS];
		int xbligand_pmf_at_index[XBPMF_AT_NUM];
		int xbligand_pmf_at_num = 0;
		Progduration=MICduration=0;
		ProgStart=time(NULL);
		//omp_set_num_threads(15);
		//double stacksize=omp_get_stacksize();
		/*
		   if(MIC_or_CPU==RUN_ON_MIC)
		   {
		   if(M_MIC_STATUS==M_MIC_END)
		   {
#pragma offload target(mic:mic_no)\
in(nruns)\
nocopy(L_GlobalSearchMethod,L_GA								)\
nocopy(L_LocalSearchMethod,L_SW,rho_ptr,lb_rho_ptr,j,L_PSW,L_PS	)\
nocopy(T_crd:length(MAX_ATOMS*SPACE)	M_FREE)\
nocopy(T_crdreo:length(MAX_ATOMS*SPACE)	M_FREE)\
nocopy(T_crdpdb:length(MAX_ATOMS*SPACE)	M_FREE)\
nocopy(T_vt:length(MAX_TORS*SPACE)		M_FREE)\
nocopy(param:length(2*LINE_LEN)			M_FREE)\
nocopy(seed:length(2)					M_FREE)\
nocopy(timeSeedIsSet:length(2)			M_FREE)\
nocopy(Nnb_array:length(3) 				M_FREE)\
nocopy(nb_group_energy:length(3) 		M_FREE)\
nocopy(crd:length(MAX_ATOMS*SPACE)		M_FREE)\
nocopy(crdreo:length(MAX_ATOMS*SPACE)	M_FREE)\
nocopy(crdpdb:length(MAX_ATOMS*SPACE)	M_FREE)\
nocopy(vt:length(MAX_TORS*SPACE)		M_FREE)\
nocopy(map:length(MAX_GRID_PTS*MAX_GRID_PTS*MAX_GRID_PTS*MAX_MAPS)		M_FREE)\
nocopy(US_torProfile:length(MAX_TORS*NTORDIVS)			M_FREE)\
nocopy(tlist:length(MAX_TORS*MAX_ATOMS)					M_FREE)\
nocopy(xbpmf_ligand_hb_donorH_ids:length(MAX_ATOMS*5)	M_FREE)\
nocopy(xbempirical_ligand_xbdonor:length(MAX_ATOMS*2)	M_FREE)\
nocopy(line:length(LINE_LEN) 						M_FREE)\
nocopy(charge,abs_charge:length(MAX_ATOMS)			M_FREE)\
nocopy(qsp_abs_charge:length(MAX_ATOMS) 			M_FREE)\
nocopy(emap:length(MAX_ATOMS)						M_FREE)\
nocopy(type:length(MAX_ATOMS)						M_FREE)\
nocopy(elec:length(MAX_ATOMS) 						M_FREE)\
nocopy(ignore_inter:length(MAX_ATOMS) 				M_FREE)\
nocopy(nonbondlist:length(MAX_NONBONDS) 			M_FREE)\
nocopy(ad_energy_tables:length(1) 					M_FREE)\
nocopy(B_isTorConstrained:length(MAX_TORS)			M_FREE)\
nocopy(US_TorE:length(MAX_TORS) 					M_FREE)\
nocopy(info:length(1) 								M_FREE)\
nocopy(L_evaluate:length(MIC_MAX_NUM_THREADS) 		M_FREE)\
nocopy(xbEmpiricalMapInfo:length(1) 				M_FREE)\
nocopy(xbpmf_ligand_xb_donorX_id:length(MAX_ATOMS)	M_FREE)\
nocopy(xbpmf_ligand_at_index:length(MAX_ATOMS)		M_FREE)\
nocopy(xbpmf_ligand_hb_acceptor:length(MAX_ATOMS)	M_FREE)\
nocopy(xbpmf_ligand_hb_donor:length(MAX_ATOMS)		M_FREE)\
nocopy(xbpmf_ligand_xb_donor:length(MAX_ATOMS) 		M_FREE)\
nocopy(xbpmf_receptor_hb_acceptor:length(MAX_RECEPTOR_ATOMS) 	M_FREE)\
nocopy(atomstuff:length(MAX_ATOMS*MAX_CHARS)					M_FREE)\
nocopy(parameterArray:length(MAX_ATOM_TYPES)					M_FREE)\
nocopy(FN_pop_file:length(FILENAME_MAX)							M_FREE)\
nocopy(end_of_branch:length(MAX_TORS)							M_FREE)\
nocopy(econf:length(MAX_RUNS) 									M_FREE)\
nocopy(sHist:length(MAX_RUNS)									M_FREE)
{
#pragma omp parallel num_threads(nruns)
{
if(L_GlobalSearchMethod!=NULL) delete L_GlobalSearchMethod;
if(L_LocalSearchMethod!=NULL)	delete L_LocalSearchMethod;
}
}
}		
return 0;
}

*/
		omp_set_num_threads(24);
#pragma omp parallel num_threads(MaxNumThreads)
{
		threadID = omp_get_thread_num();
		//printf("CPU:threadID=%d\n",threadID);
		//fflush(0);
}

/***************
//YTLIU_NOTE
 ***************/
if (mapusagetype == RELOAD_MAPS) {

		info = (GridMapSetInfo *) malloc( sizeof(GridMapSetInfo) );
}

ad_energy_tables = (EnergyTables *) malloc( sizeof(EnergyTables) );
unbound_energy_tables = (EnergyTables *) malloc( sizeof(EnergyTables) );

// Create a coordinate at the origin:
Coord origin;
origin.x = 0.;
origin.y = 0.;
origin.z = 0.;

//______________________________________________________________________________
/*
 ** Get the time at the start of the run...
 */

jobStart = times( &tms_jobStart );

//_____________________________________________________________________________
/*
 ** Boinc initialization
 */
#ifdef BOINC
int flags = 0;
int rc;
flags =
BOINC_DIAG_DUMPCALLSTACKENABLED |
BOINC_DIAG_HEAPCHECKENABLED |
BOINC_DIAG_REDIRECTSTDERR |
BOINC_DIAG_REDIRECTSTDOUT ;
boinc_init_diagnostics(flags);

#ifdef BOINCCOMPOUND
BOINC_OPTIONS options;
options.main_program = false;
options.check_heartbeat = false; // monitor does check heartbeat
options.handle_trickle_ups = false;
options.handle_trickle_downs = false;
options.handle_process_control = false;
options.send_status_msgs = true;// only the worker programs (i.e. model) sends status msgs
options.direct_process_action = true;// monitor handles suspend/quit, but app/model doesn't
// Initialisation of Boinc
rc =  boinc_init_options(options); //return 0 for success
if( rc ){
		fprintf(stderr,"BOINC_ERROR: boinc_init_options() failed \n");
		slaveExit(rc);
}

#else
// All BOINC applications must initialize the BOINC interface:
rc = boinc_init();
if (rc){
		fprintf(stderr, "BOINC_ERROR: boinc_init() failed.\n");
		slaveExit(rc);
}
#endif
#endif


//______________________________________________________________________________
/*
 ** Parse the arguments in the command line...
 */
//for(int i_tmp=0;i_tmp<_Offload_number_of_devices();i_tmp++)
//{
//	#pragma offload_transfer target(mic:i_tmp)
//	{}
//}
// change to the diretory for the ligand to be docked
// 13758 //int num_of_devices=_Offload_number_of_devices();
// 13759 //for(int im=0;im<num_of_devices;im++)
// 13760 //{
// 13761 //#pragma offload target(mic:im)
// 13762 //{}
// 13763 //}
//
#ifdef AUTODOCK_MPI
//char*G_dockingDirectoryName="/vol6/home/liuxin/chengqian/MPD3DOCK_old/1gj6/";
//strcpy();
//int chdir_rc = chdir(dockingDirectoryName);
//if(chdir_rc!=0)
//{
//	printf("Failed to change directory to %s\n",dockingDirectoryName);
//	slaveExit(-1);
//}
#endif
/***************
//YTLIU_NOTE
 ***************/
if ( M_setflags(argc,argv,version_num) == -1) {
		slaveExit(-1);
} /* END PROGRAM */

/****************************
// YTLIU_EDIT 2013.01.08
 ****************************/
//if(xbpmf_scoring || xb_empirical_scoring)
M_banner();

/*****************************
// YTLIU_EDIT 2013.01.25
 *****************************/
if(xb_empirical_scoring){
		if(mapusagetype == RELOAD_MAPS)
		{
				xbEmpiricalMapInfo = (xbempirical_map_info *) malloc( sizeof(xbempirical_map_info) );
				(void) initializeXBEmpiricalParms(xbEmpiricalMapInfo->xbempirical_parms);
		}
}
if(xbpmf_scoring)
{
		if(mapusagetype == RELOAD_MAPS)
				xbPmfMapInfo = (xbpmf_map_info *) malloc( sizeof(xbpmf_map_info) );
}


/****************************
// YTLIU_EDIT 2012.12.30
 ****************************/
//Receptor recep;		  /* receptor */
//int recep_natom = 0;
//int recep_acceptor_natom = 0;
//Real recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN];
//Real recep_acceptor_crdpdb[MAX_RECEPTOR_ATOMS][NTRN];
//char recep_acceptor_atomtype[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1];
//Real recep_charge[MAX_RECEPTOR_ATOMS];
//Boole recep_B_haveCharges;
//char recep_pdbaname[MAX_RECEPTOR_ATOMS][5];
//Atom recep_atoms[MAX_RECEPTOR_ATOMS];

//#pragma omp threadprivate (xbligand)
//Real xbpmf_1d_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM];
//Real xbpmf_2d_hb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM];
//Real xbpmf_2d_xb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM];

//______________________________________________________________________________
/*
 ** Initialize torsion arrays and constants.
 */
//if the job is over,then we must free the memory on mic

//

(void) strcpy( torfmt, "%*s" ); /* len(torfmt) is 3 chars */

for (j = 0;  j < MAX_ATOMS;  j++ ) {
		type[j] = 0;
		ignore_inter[j] = 0;
}

for (i = 0; i  < MAX_TORS;  i++ ) {
		for (j = 0;  j < MAX_ATOMS;  j++ ) {
				tlist[i][j] = 0;
		}
}

for (i = 0; i  < MAX_TORS;  i++ ) {
		B_isTorConstrained[i] = 0;
		US_torProfile[i][0] = 0;
		N_con[i] = 0;
}

M_initialiseState( &sInit );
M_initialiseState( &(ligand.S) );

M_initialiseQuat( &q_reorient );

F_W      =  360.0 / NTORDIVS;
F_hW     =  F_W  / 2.0;
F_A_from = -360.0 + F_hW;
F_A_to   =  360.0 + F_hW;
#ifdef MPIING
printf("Line 9761\n");
#endif
for (k = 0; k < MAX_RUNS; k++) {
		for (i = 0; i  < MAX_TORS;  i++ ) {
				sHist[k].tor[i] = 0.0;
		}
}
#ifdef MPIING
printf("Line 9769\n");
#endif
for (i = 0; i < MAX_TORS;  i++ ) {
		if ( (ltorfmt += 4) > LINE_LEN ) {
				prStr( error_message, "%s:  ERROR: MAX_TORS = %d torsions declared in \"constants.h\";\n\t LINE_LEN = %d, Therefore you must change \"LINE_LEN\" to exceed %d...\n", programname, MAX_TORS, LINE_LEN, 4+4*MAX_TORS );
				//stop( error_message );
				slaveExit( -1 );
		} else {
				(void) strcat( torfmt, " %lf" );  /* add on 4 chars  for each new torsion... */
		}
} /* len(torfmt) is 3+4*MAX_TORS chars */
#ifdef MPIING
printf("Line 9781\n");
#endif
for (j = 0; j < MAX_NONBONDS; j++) {
		nonbondlist[j].a1 = nonbondlist[j].a2 = 0;
}
#ifdef MPIING
printf("Line 9787\n");
#endif
for (j = 0; j < MAX_RUNS; j++) {
		econf[j] = 0.0;
}
#ifdef MPIING
printf("Line 9791\n");
#endif
B_constrain_dist = B_haveCharges = FALSE;
ntor1 = ntor = atomC1 = atomC2 = 0;
sqlower = squpper = 0.0;

timeSeedIsSet[0] = 'F';
timeSeedIsSet[1] = 'F';

if (clktck == 0) {        /* fetch clock ticks per second first time */
		if ( (clktck = sysconf(_SC_CLK_TCK)) < (FourByteLong)0L) {
				//stop("\"sysconf(_SC_CLK_TCK)\" command failed in \"main.c\"\n");
				slaveExit( -1 );
		} else {
				idct = (Real)1.0 / (Real)clktck;
				if (debug) {
						pr(logFile, "N.B. debug is on and set to %d\n\n", debug);
						pr(logFile, "\n\nFYI:  Number of clock ticks per second = %d\n", (int)clktck);
						pr(logFile, "FYI:  Elapsed time per clock tick = %.3e milli-seconds\n\n\n\n", idct * 1000. );
				}
		}
}
#ifdef MPIING
printf("Line 9814\n");
#endif
(void) strcpy(FN_rms_ref_crds,"unspecified filename\0");


//______________________________________________________________________________
/*
 ** log(x): compute the natural (base e) logarithm of x,
 */

F_lnH = ((Real)log(0.5));

//______________________________________________________________________________
/*
 ** Determine output level before we ouput anything.
 ** We must parse the entire DPF -- silently -- for any outlev settings
 ** or flexible residues file specification
 */

while( fgets(line, LINE_LEN, parFile) != NULL ) { /* PARSING-DPF parFile */
		dpf_keyword = M_parse_dpf_line( line );

		switch( dpf_keyword ) {
				case DPF_OUTLEV:
						/*
						 **  outlev
						 **  Output level,
						 */
						retval = sscanf( line, "%*s %d", &outlev );
						switch ( outlev ) {
								case -1:
										outputEveryNgens = (unsigned int) OUTLEV0_GENS;
										break;
								case 0:
										outputEveryNgens = (unsigned int) OUTLEV0_GENS;
										break;
								case 1:
										outputEveryNgens = (unsigned int) OUTLEV1_GENS;
										break;
								case 2:
								default:
										outputEveryNgens = (unsigned int) OUTLEV2_GENS;
										break;
						}
						break;

				case DPF_FLEXRES:
						// The DPF specifies a flexible residues file
						// -- set a flag
						// -- get the filename
						B_have_flexible_residues = TRUE;
						(void) sscanf( line, "%*s %s", FN_flexres );
						break;

				default:
						break;
		} // switch( dpf_keyword )
} // while

// Rewind DPF, so we can resume normal parsing
(void) rewind( parFile );

//______________________________________________________________________________
/*
 ** Output banner...
 */

/*****************************
// YTLIU_EDIT 2013.01.08
 *****************************/
//if(xbpmf_scoring==0 && xb_empirical_scoring==0)
//    banner( version_num.c_str() );

//(void) fprintf(logFile, "                           $Revision: 1.114 $\n\n");
//(void) fprintf(logFile, "                   Compiled on %s at %s\n\n\n", __DATE__, __TIME__);


//______________________________________________________________________________
/*
 ** Print the time and date when the log file was created...
 */

//pr( logFile, "This file was created at:\t\t\t" );
//printdate( logFile, 1 );

(void) strcpy(hostnm, "unknown host");

if (gethostname( hostnm, sizeof hostnm ) == 0) {
		//    pr( logFile, "                   using:\t\t\t\"%s\"\n", hostnm );
}

//______________________________________________________________________________
//
// Read in default parameters
//
M_setup_parameter_library(outlev, "default Unbound_Same_As_Bound", Unbound_Same_As_Bound);

//
// Compute the look-up table for the distance-dependent dielectric function
//
//(void) fprintf(logFile, "\n\nPreparing Energy Tables for Bound Calculation:\n\n");
M_setup_distdepdiel(outlev, ad_energy_tables);
//(void) fprintf(logFile, "Preparing Energy Tables for Unbound Calculation:\n\n");
M_setup_distdepdiel(outlev, unbound_energy_tables);


//______________________________________________________________________________
/*
 ** Start reading in the DPF parameter/run-control file,
 */

while( fgets(line, LINE_LEN, parFile) != NULL ) { /* PARSING-DPF parFile */
		// "line" is a string containing the current line of the input DPF.

		dpf_keyword = M_parse_dpf_line( line );

		switch( dpf_keyword ) {
				case -1:
						sprintf( error_message,
										"DPF> %s\n%s: ERROR: Unrecognized keyword in docking parameter file.\n",
										line, programname );
						//stop( error_message );

						break;

				case DPF_NULL:
				case DPF_COMMENT:
						//            pr( logFile, "DPF> %s", line );
						//            (void) fflush(logFile);
						break;

				default:
						//            pr( logFile, "\n\nDPF> %s\n", line );
						indcom = strindex( line, "#" );
						if (indcom != -1) {
								line[ indcom ] = '\0'; /* Truncate "line" at the comment */
						}
						//            (void) fflush(logFile);
						break;
		} /* switch */

		switch( dpf_keyword ) {

				//______________________________________________________________________________

				case DPF_NULL:
				case DPF_COMMENT:
						break;

						//______________________________________________________________________________

				case DPF_PARAMETER_VERSION:
						/*
						 ** autodock_parameter_version string
						 **
						 **
						 **
						 ** initial implementation ignores value of string
						 */

						B_found_autodock_parameter_version = 1==sscanf( line, "%*s %s", autodock_parameter_version );
						//        pr( logFile, "\n\tAutodock parameter version %s.\n", autodock_parameter_version );
						//        (void) fflush(logFile);

						break;

						/*____________________________________________________________________________*/

				case DPF_OUTLEV:
						/*
						 **  outlev
						 **  Output level,
						 */
						retval = sscanf( line, "%*s %d", &outlev );
						switch ( outlev ) {
								case -1:
										//            pr( logFile, "Output Level = -1.  ONLY STATE VARIABLES OUTPUT, NO COORDINATES.\n" );
										outputEveryNgens = (unsigned int) OUTLEV0_GENS;
										break;
								case 0:
										//            pr( logFile, "Output Level = 0.\n" );
										outputEveryNgens = (unsigned int) OUTLEV0_GENS;
										break;
								case 1:
										//            pr( logFile, "Output Level = 1.  MINIMUM OUTPUT DURING DOCKING.\n" );
										outputEveryNgens = (unsigned int) OUTLEV1_GENS;
										break;
								case 2:
								default:
										//            pr( logFile, "Output Level = 2.  FULL OUTPUT DURING DOCKING.\n" );
										outputEveryNgens = (unsigned int) OUTLEV2_GENS;
										break;
						}
						//        if(outputEveryNgens>0) pr( logFile, "\n\tOutput population statistics every %u generations.\n", outputEveryNgens );
						//        else pr( logFile, "\n\tNever output generation-based population statistics.\n");
						//        (void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/

				case DPF_PARAMETER_LIBRARY:
						/*
						 ** parameter_file AD4_parameters.dat
						 **  or
						 ** parameter_library AD4_parameters.dat
						 **
						 ** initial implementation based on hsearch was suggested by Mike Pique
						 */

						parameter_library_found = sscanf( line, "%*s %s", FN_parameter_library );
						//        (void) fflush(logFile);

						M_read_parameter_library(FN_parameter_library, outlev);

						break;

						/*____________________________________________________________________________*/
#ifdef USE_DPF_INCLUDE_1_4_INTERACTIONS
				case DPF_INCLUDE_1_4_INTERACTIONS:
						/*
						 * include_1_4_interactions 0.5
						 *
						 * Set the Boolean variable, B_include_1_4_interactions, to TRUE.
						 *
						 * NOTE:  You must use this command _before_ the "move ligand.pdbqt"
						 *        command, since "include_1_4_interactions" affects how the Ligand
						 *        PDBQT specified by the "move" command will be interpreted.
						 */
						if (B_found_move_keyword == TRUE) {
								// If we have found the move keyword already, warn the user
								// that this command ("include_1_4_interactions 0.5") should have
								// been given before this!
								pr(logFile, "\nWARNING:  This command will be ignored.\n\nYou must put this command _before_ the \"move ligand.pdbqt\" command, since this command affects how the PDBQT file will be interpreted.\n\n");
						}
						(void) sscanf( line, "%*s " FDFMT, &scale_1_4 );
						B_include_1_4_interactions = TRUE;
						print_1_4_message(logFile, B_include_1_4_interactions, scale_1_4);
						break;
#endif
						//______________________________________________________________________________

				case DPF_INTELEC:
						/*
						 **  intelec
						 **  Calculate internal electrostatic energies...
						 */
						B_calcIntElec = TRUE;
						//        if (outlev >= 0) {
						//            pr( logFile, "Electrostatic energies will be calculated for all non-bonds between moving atoms.\n\n");
						//        }
						retval = sscanf( line, "%*s " FDFMT, &AD3_FE_coeff_estat );
						if (retval == 1) 
						{
								//            if (outlev >= 0) {
								//                pr(logFile, "NOTE!  Internal electrostatics will NOT be scaled by the factor specified by this command,  %.4f -- the coefficient set by this command is ignored in AutoDock 4;\n", AD3_FE_coeff_estat);
								//                pr(logFile, "       the coefficient that will actually be used should be set in the parameter library file.\n");
								//                pr(logFile, "       The coefficient for the electrostatic energy term is %.4f", AD4.coeff_estat);
								//                if (parameter_library_found == 1) {
								//                    pr( logFile, " as specified in parameter library \"%s\".\n", FN_parameter_library );
								//                } else {
								//                    pr( logFile, ", the factory default value.\n");
								//                }
								//            }
						} 
						else 
						{
								AD3_FE_coeff_estat = 1.0;
						}

						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_SEED:
						/*
						 **  seed
						 **  Set the random-number gerator's seed value,
						 */
						retval = (int)sscanf( line, "%*s %s %s", param[0], param[1]);
						timeSeedIsSet[0] = 'F';
						timeSeedIsSet[1] = 'F';
						//        pr(logFile, "%d seed%c found.\n", retval, ((retval==1)? ' ' : 's'));
						for (j=0; j<retval; j++) {
								for (i=0; i<(int)strlen(param[j]); i++) {
										param[j][i] = (char)tolower( (int)param[j][i] );
								}
								//            pr(logFile, "argument \"%s\" found\n", param[j]);
						}
#ifdef MIC_DEBUG        
						printf("param[0]=%s\tparam[1]=%s\n",param[0],param[1]);
						printf("retval=%d\n",retval);
#endif		
						//fflush(0);
#pragma omp parallel num_threads(MaxNumThreads)
						{
								if ((retval==2) || (retval==1)) 
								{
										for (int i=0; i<retval ; i++ ) 
										{
												if (equal(param[i], "tim", 3)) 
												{
														timeSeedIsSet[i] = 'T';
														// set the seed based on the seed type
														if (seedtype == SAME_SEED) 
														{
																seed[i] = SAME_SEED_CONSTANT;
														}
														else if (seedtype == DEFAULT_SEED) 
														{ // the time seed needs to have the threadID added to it so that different threads get a different seed
																seed[i] = (FourByteLong)(time( &time_seed ) + threadID);
														}
														else if (seedtype == UNIQUE_NODE_SEED) 
														{ // the time seed needs to have the threadID added to it so that different threads get a different seed plus the mpirank times the most threads possible on BQG (320) to make sure the seed is unique across the nodes
																seed[i] = (FourByteLong)(time( &time_seed ) + threadID + (mpirank*320));
														}
														else 
														{
																fprintf(stderr,"seed type not set properly, exitting\n");
																slaveExit(-1);
														}
														seed_random(seed[i]);
												} 
												else if (equal(param[i], "pid", 3)) 
												{
														timeSeedIsSet[i] = 'F';
														if (seedtype == SAME_SEED) 
														{
																seed[i] = SAME_SEED_CONSTANT;
														}
														else 
														{
																seed[i] = getpid();
														}
														seed_random(seed[i]);
												} 
												else 
												{
														timeSeedIsSet[i] = 'F';
														seed[i] = atol(param[i]);
														seed_random(seed[i]);
												}
										}	/*i*/

										if (retval==2) 
										{
												L_setall(seed[0], seed[1]);
												L_initgn(-1);  // Reinitializes the state of the current random number generator
										}
								} 
								else 
								{
										pr(logFile, "Error encountered reading seeds!\n");
								}
						}

						(void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/

				case DPF_LIGAND_TYPES:
						/*
						 *  Read in the ligand atom type names, e.g.
						 *
						 *  ligand_types C HD OA P               # ligand atom type names
						 *
						 *  The order of the arguments is the index that will
						 *  be used for look up in the grid maps, "map_index".
						 */

						//  Use the function "parsetypes" to read in the atom types;
						//
						//  The array "ligand_atom_type_ptrs" is returned, having been filled with pointers
						//  to the beginning of each "atom type word" (not atom type characters);
						//  In AutoDock 4, an atom type can be either 1 or 2 characters long.
						//
						num_atom_types = M_parsetypes(line, ligand_atom_type_ptrs, MAX_ATOM_TYPES);
						if (num_atom_types<0){
								prStr( error_message, "%s:  ERROR! Too many atom types have been found: maximum is %d; we cannot continue !\n\n", programname, MAX_ATOM_TYPES );
								pr_2x( logFile, stderr, error_message );
								slaveExit(-1);
						}



						B_found_ligand_types = TRUE;

						// This is not necessary if we increment num_maps one-at-a-time as we read each atom map in
						// num_maps += num_atom_types;
						info->num_atom_types = num_atom_types;

						for (i=0; i<num_atom_types; i++) {
								strcpy(info->atom_type_name[i], ligand_atom_type_ptrs[i]);

								/*************************
								// YTLIU_EDIT 2013.01.25
								 *************************/
								if(xb_empirical_scoring){
										if( equal(ligand_atom_type_ptrs[i],"Cl",2) ||
														equal(ligand_atom_type_ptrs[i],"CL",2) ||
														equal(ligand_atom_type_ptrs[i],"Br",2) ||
														equal(ligand_atom_type_ptrs[i],"BR",2) ||
														equal(ligand_atom_type_ptrs[i],"I",1) ){
												halogen_found = TRUE;
										}
								}

#ifdef DEBUG
								(void) fprintf(logFile, "%d %s ->%s\n",i, ligand_atom_type_ptrs[i], info->atom_type_name[i]);
#endif
						}

						if (num_atom_types > 0) {
								B_atom_types_found = TRUE;
						} else {
								prStr( error_message, "%s:  ERROR! No atom types have been found; we cannot continue without this information!\n\n", programname );
								pr_2x( logFile, stderr, error_message );
								prStr( error_message, "%s:  ERROR! Are you trying to use an AutoDock 3 DPF with AutoDock 4?\n\n", programname );
								pr_2x( logFile, stderr, error_message );
								slaveExit(-1);
						}

						if (debug > 0) {
								for (i=0; i<num_atom_types; i++) {
										(void) fprintf(logFile, "info->atom_type_name[%d] = %s\n", i, info->atom_type_name[i] );
								}
						}

						// For all ligand atom types... set up the map_index
						// "ligand_types"

						for (i=0; i<num_atom_types; i++) {
								foundParameter = M_apm_find(info->atom_type_name[i]);
								if (foundParameter != NULL ) {
										// Not NULL means we have found this atom type's parameters.
										// Set the ParameterEntry's "map_index" member to the
										// 0-based index it had in the list of ligand types supplied in the DPF "types" line:
										foundParameter->map_index = i;
										parameterArray[i] = *(foundParameter);
								} else {
										// We could not find this parameter -- return error here
										prStr( error_message,"%s: ERROR:  Unknown ligand atom type \"%s\"; add parameters for it to the parameter library first!\n", programname, info->atom_type_name[i]);
										pr_2x( logFile, stderr, error_message );
										if (parameter_library_found == 1) {
												prStr( error_message,"%s:         Edit the parameter library file \"%s\" and try again.\n", programname, FN_parameter_library );
												pr_2x( logFile, stderr, error_message );
										}
										slaveExit(-1);
								} // if / else apm_find
						} // for i

						// Calculate the internal energy table
						/**************************************
						// YTLIU_NOTE
						// Calculate the internal energy of the ligand
						 **************************************/
						// loop over atom types, i, from 1 to number of atom types
						for (i=0; i<num_atom_types; i++) {

								//  Find internal energy parameters, i.e.  epsilon and r-equilibrium values...
								//  Lennard-Jones and Hydrogen Bond Potentials

								Ri = parameterArray[i].Rij;
								epsi = parameterArray[i].epsij;
								Ri_hb = parameterArray[i].Rij_hb;
								epsi_hb = parameterArray[i].epsij_hb;
								hbondi = parameterArray[i].hbond;

								// loop over atom types, j, from i to number of atom types
								for (j=i; j<num_atom_types; j++) {

										//  Find internal energy parameters, i.e.  epsilon and r-equilibrium values...
										//  Lennard-Jones and Hydrogen Bond Potentials

										Rj = parameterArray[j].Rij;
										epsj = parameterArray[j].epsij;
										Rj_hb = parameterArray[j].Rij_hb;
										epsj_hb = parameterArray[j].epsij_hb;
										hbondj = parameterArray[j].hbond;

										// we need to determine the correct xA and xB exponents
										xA = 12; // for both LJ, 12-6 and HB, 12-10, xA is 12
										xB =  6; // assume we have LJ, 12-6

										if ( ((hbondi == DS) || (hbondi == D1)) && ((hbondj == AS) || (hbondj == A1) || (hbondj == A2)) ) {
												// i is a donor and j is an acceptor.
												// i is a hydrogen, j is a heteroatom
												// we need to calculate the arithmetic mean of Ri_hb and Rj_hb  // not in this Universe...  :-(
												//Rij = arithmetic_mean(Ri_hb, Rj_hb);// not in this Universe...  :-(
												Rij = Rj_hb;
												// we need to calculate the geometric mean of epsi_hb and epsj_hb  // not in this Universe...  :-(
												//epsij = geometric_mean(epsi_hb, epsj_hb);// not in this Universe...  :-(
												epsij = epsj_hb;
												xB = 10;
										} else if ( ((hbondi == AS) || (hbondi == A1) || (hbondi == A2)) && ((hbondj == DS) || (hbondj == D1))) {
												// i is an acceptor and j is a donor.
												// i is a heteroatom, j is a hydrogen
												// we need to calculate the arithmetic mean of Ri_hb and Rj_hb// not in this Universe...  :-(
												//Rij = arithmetic_mean(Ri_hb, Rj_hb);// not in this Universe...  :-(
												Rij = Ri_hb;
												// we need to calculate the geometric mean of epsi_hb and epsj_hb// not in this Universe...  :-(
												//epsij = geometric_mean(epsi_hb, epsj_hb);// not in this Universe...  :-(
												epsij = epsi_hb;
												xB = 10;
										} else {
												// we need to calculate the arithmetic mean of Ri and Rj
												Rij = arithmetic_mean(Ri, Rj);
												// we need to calculate the geometric mean of epsi and epsj
												epsij = geometric_mean(epsi, epsj);
										}

										/* Check that the Rij is reasonable */
										if ((Rij < RIJ_MIN) || (Rij > RIJ_MAX)) {
												(void) fprintf( logFile,
																"WARNING: pairwise distance, Rij, %.2f, is not a very reasonable value for the equilibrium separation of two atoms! (%.2f Angstroms <= Rij <= %.2f Angstroms)\n\n", Rij, RIJ_MIN, RIJ_MAX);
												(void) fprintf( logFile, "Perhaps you meant to use \"intnbp_coeffs\" instead of \"intnbp_r_eps\"?\n\n");
												/* gmm commented out for dave goodsell, mutable atoms
												 * slaveExit(-1); */
										}
										/* Check that the epsij is reasonable */
										if ((epsij < EPSIJ_MIN) || (epsij > EPSIJ_MAX)) {
												(void) fprintf( logFile,
																"WARNING: well-depth, epsilon_ij, %.2f, is not a very reasonable value for the equilibrium potential energy of two atoms! (%.2f kcal/mol <= epsilon_ij <= %.2f kcal/mol)\n\n", epsij, EPSIJ_MIN, EPSIJ_MAX);
												(void) fprintf( logFile, "Perhaps you meant to use \"intnbp_coeffs\" instead of \"intnbp_r_eps\"?\n\n");
												/* gmm commented out for dave goodsell, mutable atoms
												 * slaveExit(-1); */
										}
										/* Defend against division by zero... */
										if (xA != xB) {
												cA = (tmpconst = epsij / (Real)(xA - xB)) * pow( (double)Rij, (double)xA ) * (Real)xB;
												cB = tmpconst * pow( (double)Rij, (double)xB ) * (Real)xA;
												//                    pr(logFile, "\nCalculating internal non-bonded interaction energies for docking calculation;\n");
												M_intnbtable( &B_havenbp, a1, a2, info, cA, cB, xA, xB, AD4.coeff_desolv, sigma, ad_energy_tables, BOUND_CALCULATION );
												//                    pr(logFile, "\nCalculating internal non-bonded interaction energies for unbound conformation calculation;\n");
												M_intnbtable( &B_havenbp, a1, a2, info, cA_unbound, cB_unbound, xA_unbound, xB_unbound, AD4.coeff_desolv, sigma, unbound_energy_tables, UNBOUND_CALCULATION );
												// Increment the atom type numbers, a1 and a2, for the internal non-bond table
												a2++;
												if (a2 >= info->num_atom_types) {
														a1++;
														a2 = a1;
												}

										} else {
												pr(logFile,"WARNING: Exponents must be different, to avoid division by zero!\n\tAborting...\n");
												slaveExit(-1);
										}
										(void) fflush(logFile);

								} // for j
						} // for i
						break;

						//______________________________________________________________________________

						/******************************
						// YTLIU_EDIT 2013.01.25
						 ******************************/
				case DPF_XBEMPIRICAL_RECEPTOR:
						if(xb_empirical_scoring && halogen_found){
								if(mapusagetype == REUSE_MAPS)
										if(xbEmpiricalReceptorAlreadLoaded)
												break;

								(void) sscanf(line, "%*s %s", xbempirical_receptor_fn);
								xbEmpiricalMapInfo->xbempirical_recep = M_readReceptorPDBQT(
												&(xbEmpiricalMapInfo->xbempirical_recep_natom),xbEmpiricalMapInfo->xbempirical_recep_crdpdb,xbEmpiricalMapInfo->xbempirical_recep_charge,
												&(xbEmpiricalMapInfo->xbempirical_recep_B_haveCharges),xbEmpiricalMapInfo->xbempirical_recep_pdbaname,
												xbempirical_receptor_fn,jobStart,tms_jobStart,B_include_1_4_interactions,
												xbEmpiricalMapInfo->xbempirical_recep_atoms);
								//        (void) pr(logFile,"number of receptor atoms: %d\n\n",xbEmpiricalMapInfo->xbempirical_recep_natom);
								for(i=0; i<xbEmpiricalMapInfo->xbempirical_recep_natom; i++)
								{
										xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index[i] = -1;
										if( equal(xbEmpiricalMapInfo->xbempirical_recep.atomtype[i],"OA",2) ||
														equal(xbEmpiricalMapInfo->xbempirical_recep.atomtype[i],"NA",2) ||
														equal(xbEmpiricalMapInfo->xbempirical_recep.atomtype[i],"SA",2) ||
														equal(xbEmpiricalMapInfo->xbempirical_recep.atomtype[i],"OS",2) ||
														equal(xbEmpiricalMapInfo->xbempirical_recep.atomtype[i],"NS",2) ){
												xbempirical_acceptor_index = M_lookupXBPMFATindex(xbEmpiricalMapInfo->xbempirical_recep.atomtype[i]);
												xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index[i] = xbempirical_acceptor_index - OA;
										}
								}
								xbEmpiricalReceptorAlreadLoaded=TRUE;
								xbempirical_receptor_in = TRUE;
						}
						break;

				case DPF_XBEMPIRICAL_PARM:
						if(xb_empirical_scoring && halogen_found){
								if(mapusagetype == REUSE_MAPS)
										if(xbEmpiricalParmsAlreadLoaded)
												break;
								(void) sscanf(line, "%*s %s", xbempirical_parm_fn);

								if(setupXBEmpiricalParms(xbempirical_parm_fn, xbEmpiricalMapInfo->xbempirical_parms)){
										xbEmpiricalParmsAlreadLoaded=TRUE;
										//                        (void) fprintf(logFile, "\nset up halogen bonding empirical scoring function parameters\n\n");
								}
								else{
										(void) fprintf(logFile, "\nfailed in setting up halogen bonding empirical scoring function parameters\n");
										(void) fprintf(logFile, "\nreinitialize halogen bonding empirical scoring function parameters\n\n");
										initializeXBEmpiricalParms(xbEmpiricalMapInfo->xbempirical_parms);
								}
						}
						break;

						/*******************************
						// YTLIU_EDIT 2013.01.16
						 *******************************/
#ifdef USE_DPF_XBPMF_RECEPTOR
				case DPF_XBPMF_RECEPTOR:
						if(mapusagetype == REUSE_MAPS)
						{
								if(xbPmfReceptorAlreadLoaded)
										break;
						}
						xbdock_receptor_in=TRUE;
						(void) sscanf(line, "%*s %s", xbdock_receptor_fn);
						xbPmfMapInfo->recep = readReceptorPDBQT(
										&(xbPmfMapInfo->recep_natom),xbPmfMapInfo->recep_crdpdb,xbPmfMapInfo->recep_charge,&(xbPmfMapInfo->recep_B_haveCharges),
										xbPmfMapInfo->recep_pdbaname,xbdock_receptor_fn,jobStart,tms_jobStart,
										B_include_1_4_interactions,xbPmfMapInfo->recep_atoms);
						/////////////error xbzhang
						//    (void) pr(logFile,"number of receptor atoms: %d\n\n",xbPmfMapInfo->recep_natom);
						xbPmfMapInfo->recep_acceptor_natom=0;
						for(i=0; i<xbPmfMapInfo->recep_natom; i++)
						{
								int rat_accep_index = lookupXBPMFATindex(xbPmfMapInfo->recep.atomtype[i]);
								if(rat_accep_index==OC || rat_accep_index==OA || rat_accep_index==OD || rat_accep_index==NA || rat_accep_index==ND || rat_accep_index==N0 || rat_accep_index==SA){
										xbPmfMapInfo->recep_acceptor_crdpdb[xbPmfMapInfo->recep_acceptor_natom][X]=xbPmfMapInfo->recep_crdpdb[i][X];
										xbPmfMapInfo->recep_acceptor_crdpdb[xbPmfMapInfo->recep_acceptor_natom][Y]=xbPmfMapInfo->recep_crdpdb[i][Y];
										xbPmfMapInfo->recep_acceptor_crdpdb[xbPmfMapInfo->recep_acceptor_natom][Z]=xbPmfMapInfo->recep_crdpdb[i][Z];
										strcpy(xbPmfMapInfo->recep_acceptor_atomtype[xbPmfMapInfo->recep_acceptor_natom],xbPmfMapInfo->recep.atomtype[i]);
										xbPmfMapInfo->recep_acceptor_natom++;
								}
						}
						xbPmfReceptorAlreadLoaded=TRUE;
						break;
#endif
#ifdef USE_DPF_XBPMF_LIGAND
				case DPF_XBPMF_LIGAND:
						xbdock_ligand_in=TRUE;
						(void) sscanf(line, "%*s %s", xbdock_ligand_fn);
						xbligand = readXBLigandPDBQT(
										&xbligand_natom,xbligand_crdpdb,xbligand_charge,
										&xbligand_B_haveCharges,xbligand_pdbaname,
										xbdock_ligand_fn,jobStart,tms_jobStart,
										B_include_1_4_interactions,xbligand_atoms);
						(void) pr(logFile,"number of ligand atoms: %d\n\n",xbligand_natom);
						for(i=0; i<xbligand_natom; i++)
						{
								(void) pr(logFile,"Atom %d;XBPMF Atom Type %s\n",(i+1),xbligand.atomtype[i]);
						}
						(void) fprintf(logFile,"\n\n");

						for(i=0; i<XBPMF_AT_NUM; i++)
								xbligand_pmf_at_index[i]=0;
						for(i=0; i<xbligand_natom; i++)
						{
								int xblat_index=lookupXBPMFATindex(xbligand.atomtype[i]);
								if(xbligand_pmf_at_index[xblat_index]==0)
								{
										xbligand_pmf_at_num++;
										xbligand_pmf_at_index[xblat_index]=1;
								}
						}
						break;
#endif
				case DPF_XBPMF_1D:
						xbpmf_1d_parm=TRUE;
						sscanf(line, "%*s %s", xbpmf_1d_fn);
						break;

				case DPF_XBPMF_HB:
						xbpmf_hb_parm=TRUE;
						sscanf(line, "%*s %s", xbpmf_hb_fn);
						break;
#ifdef USE_DPF_XBPMF_XB
				case DPF_XBPMF_XB:
						xbpmf_xb_parm=TRUE;
						sscanf(line, "%*s %s", xbpmf_xb_fn);
						if(xbpmf_scoring)
						{
								if(mapusagetype==RELOAD_MAPS)
										xbPmfParmsAlreadLoaded=FALSE;
								if(!xbPmfParmsAlreadLoaded)
								{
										//            (void) fprintf(logFile, "\n      ________________________________________________________________\n\n");
										//                (void) fprintf(logFile, "                  SETTING UP XBPMF ATOM TYPER LIBRARY\n");
										//                (void) fprintf(logFile, "      ________________________________________________________________\n\n\n");
										if(xbpmf_1d_parm && xbpmf_hb_parm && xbpmf_xb_parm)
										{
												//                (void) fprintf(logFile, "XBPMF 1d parameter file: %s\n",xbpmf_1d_fn);
												//                (void) fprintf(logFile, "XBPMF hydrogen bonding parameter file: %s\n",xbpmf_hb_fn);
												//                (void) fprintf(logFile, "XBPMF halogen bonding parameter file: %s\n\n",xbpmf_xb_fn);
												for(i=0; i<XBPMF_AT_NUM; i++)
												{
														for(j=0; j<XBPMF_AT_NUM; j++)
														{
																for(k=0; k<XBPMF_SHELL_NUM; k++)
																{
																		xbPmfMapInfo->xbpmf_1d_pw_parms[i][j][k] = 0.0;
																		for(m=0; m<XBPMF_BIN_NUM; m++)
																		{
																				xbPmfMapInfo->xbpmf_2d_hb_pw_parms[i][j][k][m] = 0.0;
																				xbPmfMapInfo->xbpmf_2d_xb_pw_parms[i][j][k][m] = 0.0;
																		}
																}
														}
												}

												//error xbzhang
												if(readXBPMFPairwiseParms(xbpmf_1d_fn, xbpmf_hb_fn, xbpmf_xb_fn, xbPmfMapInfo->xbpmf_1d_pw_parms, xbPmfMapInfo->xbpmf_2d_hb_pw_parms, xbPmfMapInfo->xbpmf_2d_xb_pw_parms, jobStart, tms_jobStart))
												{
														//                        pr( logFile, "XBPMF atom type pairwise parameters have been successfully read in!\n\n");
												}
												else
												{
														pr( logFile, "ERROR: Failed in reading in XBPMF atom type pairwise parameters!\n\n");
														slaveExit(-1);
												}
										}
										else
										{
												if(!xbpmf_1d_parm)
														pr(logFile,"XBPMF 1d paramter file not found!\n");
												if(!xbpmf_hb_parm)
														pr(logFile,"XBPMF hydrogen bonding parameter file not found!\n");
												if(!xbpmf_xb_parm)
														pr(logFile,"XBPMF halogen bonding parameters file not found!\n\n");
												slaveExit(-1);
										}
										int grat_index;
										for(i=0; i < xbPmfMapInfo->recep_natom; i++)
										{
												grat_index = lookupXBPMFATindex(xbPmfMapInfo->recep.atomtype[i]);
												xbPmfMapInfo->xbpmf_receptor_at_index[i] = grat_index;
												if(grat_index==OC || grat_index==OA || grat_index==OD || grat_index==NA || grat_index==ND || grat_index==N0 || grat_index==SA)
														xbpmf_receptor_hb_acceptor[i]=1;
												else
														xbpmf_receptor_hb_acceptor[i]=0;
										}
										xbPmfParmsAlreadLoaded=TRUE;
								}

								if(xbdock_ligand_in && xbdock_receptor_in)
								{
										int glat_index, gn_index, gn;

										for(i=0; i < xbligand_natom; i++)
										{
												glat_index=lookupXBPMFATindex(xbligand.atomtype[i]);
												xbpmf_ligand_at_index[i] = glat_index;
												if(glat_index==NC || glat_index==ND || glat_index==OD || glat_index==SD)
														xbpmf_ligand_hb_donor[i]=1;
												else if(glat_index==Cl || glat_index==Br || glat_index==I)
														xbpmf_ligand_xb_donor[i]=1;

												if(glat_index==OC || glat_index==OA || glat_index==OD || glat_index==NA || glat_index==ND || glat_index==N0 || glat_index==SA)
														xbpmf_ligand_hb_acceptor[i]=1;

												if(xbpmf_ligand_hb_donor[i]==0 && xbpmf_ligand_xb_donor[i]==0)
														continue;

												for(j=0; j < xbPmfMapInfo->recep_natom; j++)
												{
														if(xbpmf_receptor_hb_acceptor[j])
														{
																Boole ghb_flag = FALSE;
																Boole gxb_flag = FALSE;
																if(xbpmf_ligand_hb_donor[i])
																{
																		int gfrom=(0>(i-20)?0:(i-20));
																		int gto=((xbligand_natom-1)>(i+20)?(i+20):(xbligand_natom-1));
																		int hb_num=0;
																		for(gn=gfrom; gn<=gto; gn++)
																		{
																				if(gn==i)
																						continue;
																				gn_index=xbpmf_ligand_at_index[gn];
																				if(gn_index==HL)
																				{
																						Real gndist=hypotenuse((xbligand_crdpdb[i][X]-xbligand_crdpdb[gn][X]),(xbligand_crdpdb[i][Y]-xbligand_crdpdb[gn][Y]),(xbligand_crdpdb[i][Z]-xbligand_crdpdb[gn][Z]));
																						if(gndist<1.3)
																						{
																								ghb_flag = TRUE;
																								xbpmf_ligand_hb_donorH_ids[i][hb_num]=gn;
																								hb_num++;
																						}
																				}
																		}
																		if(ghb_flag)
																		{
																				xbPmfMapInfo->xbpmf_hb_label[i][j]=hb_num;
																				continue;
																		}
																		//				xbpmf_1d_label[i][j]=1;
																}
																else if(xbpmf_ligand_xb_donor[i])
																{
																		int gfrom=(0>(i-20)?0:(i-20));
																		int gto=((xbligand_natom-1)>(i+20)?(i+20):(xbligand_natom-1));
																		for(gn=gfrom; gn<=gto; gn++)
																		{
																				if(gn==i)
																						continue;
																				gn_index=xbpmf_ligand_at_index[gn];
																				if(gn_index!=HL)
																				{
																						Real gndist=hypotenuse((xbligand_crdpdb[i][X]-xbligand_crdpdb[gn][X]),(xbligand_crdpdb[i][Y]-xbligand_crdpdb[gn][Y]),(xbligand_crdpdb[i][Z]-xbligand_crdpdb[gn][Z]));
																						if(gndist<1.9)
																						{
																								gxb_flag = TRUE;
																								xbpmf_ligand_xb_donorX_id[i]=gn;
																								break;
																						}
																				}
																		}
																		if(gxb_flag)
																		{
																				xbPmfMapInfo->xbpmf_xb_label[i][j]=1;
																				continue;
																		}
																		//                                xbpmf_1d_label[i][j]=1;
																}
														}
												}
										}
								}

						}
						break;
#endif
						//______________________________________________________________________________

				case DPF_FLD:
						/*
						 ** fld
						 ** GRID_DATA_FILE
						 ** Read the (AVS-format) grid data file, .fld
						 */
						// TO DO: add outlev
#ifdef PERF_PROFILING


						if (slaveDockInfo.firstFldFileFound == 0) {
								return_current_time(slaveDockInfo.FldFileStartTime);
								slaveDockInfo.FldFileMaxDuration = 0.0;
								slaveDockInfo.FldFileMinDuration = -1.0;
								slaveDockInfo.FldFileNumber=0;
								slaveDockInfo.FldFileTotalDuration=0.0;

								slaveDockInfo.firstFldFileFound = 1;
						}

						slaveDockInfo.FldFileNumber++;

						serialStartClock = (Real) times(&tms_serialStart);


#endif
						if (mapusagetype == RELOAD_MAPS)
								num_maps = 0;
						if (num_maps == 0) { // pkcoff: code to enable unduplicated file loading - only load the grid info the first time
								// TO DO: add outlev
								M_readfield( info, line, jobStart, tms_jobStart );
								(void) fflush(logFile);
						}

#ifdef PERF_PROFILING

						return_current_time(slaveDockInfo.FldFileEndTime);
						serialEndClock = (Real) times(&tms_serialEnd);

						serialCurrentDuration = (Real) (serialEndClock-serialStartClock) * idct;


						if (slaveDockInfo.FldFileMaxDuration < serialCurrentDuration)
								slaveDockInfo.FldFileMaxDuration = serialCurrentDuration;
						if ((slaveDockInfo.FldFileMinDuration > serialCurrentDuration) || (slaveDockInfo.FldFileMinDuration == -1.0))
								slaveDockInfo.FldFileMinDuration = serialCurrentDuration;
						slaveDockInfo.FldFileTotalDuration += serialCurrentDuration;

#endif
						break;

						//______________________________________________________________________________

				case DPF_MAP:
						/*
						 ** map
						 ** ATOMIC AFFINITY, ELECTROSTATIC POTENTIAL OR DESOLVATION ENERGY GRID MAP
						 ** Read in active site grid map...
						 */
#ifdef PERF_PROFILING


						if (slaveDockInfo.firstMapFileFound == 0) {
								return_current_time(slaveDockInfo.MapFileStartTime);
								slaveDockInfo.firstMapFileFound = 1;
						}


						serialStartClock = (Real) times(&tms_serialStart);


#endif
						B_charMap = FALSE;
						if (B_atom_types_found == TRUE) {
								// Read in the AutoGrid atomic affinity map
								// map_index could be incremented here if we had the atom_type stored in each map...
								mapFileAlreadyLoaded = FALSE;
								//            xbPmfMapAlreadyLoaded = FALSE;
								if(xbpmf_scoring)
								{
										/*
										   if(mapusagetype == RELOAD_MAPS)
										   {
										   map_stats = readxbpmfmap(line, outlev, jobStart, tms_jobStart, B_charMap, &B_havemap, num_maps, info, xbPmfMapInfo->xbpmf_1d_map, xbPmfMapInfo->xbpmf_hb_map, 'a' );
										   }
										   else if(mapusagetype == REUSE_MAPS)
										   {
										   if(!xbPmfMapAlreadyLoaded)
										   {
										   map_stats = readxbpmfmap(line, outlev, jobStart, tms_jobStart, B_charMap, &B_havemap, num_maps, info, xbPmfMapInfo->xbpmf_1d_map, xbPmfMapInfo->xbpmf_hb_map, 'a' );
										   xbPmfMapAlreadyLoaded=TRUE;
										   }
										   }
										   */
								}
								else
								{
										if (mapusagetype == REUSE_MAPS) 
										{
												(void) sscanf( line, "%*s %s", FileName );

												for (int i=0;(i<num_maps && !mapFileAlreadyLoaded);i++) 
												{
														if (strcmp(loadedMapFileNames[i],FileName) == 0)
																mapFileAlreadyLoaded = TRUE;
												}
										}
										//     printf("mapFileAlreadyLoaded is %d\n",mapFileAlreadyLoaded);

										if ((mapusagetype == REUSE_MAPS) && !mapFileAlreadyLoaded) 
										{
												strcpy(loadedMapFileNames[num_maps],FileName);
												strcpy(atomTypeMap[num_maps],info->atom_type_name[num_maps_iterated]);
										}

										num_maps_iterated++;
								}
								if (!mapFileAlreadyLoaded) 
								{
										map_stats = M_readmap( line, outlev, jobStart, tms_jobStart, B_charMap, &B_havemap, num_maps, info, map, 'a',mapFileAlreadyLoaded, mapusagetype );
										//                pr(logFile, "Min= %.3lf Mean= %.3lf Max= %.3lf\n\n",
										//                    map_stats.minimum, map_stats.mean, map_stats.maximum);
								}

								if (!mapFileAlreadyLoaded) 
								{
										num_maps++;
								}
						} 
						else 
						{
								prStr( error_message, "%s:  ERROR! No atom types have been found; we cannot continue without this information!\n\n", programname );
								pr_2x( logFile, stderr, error_message );
								prStr( error_message, "%s:  ERROR! Are you trying to use an AutoDock 3 DPF with AutoDock 4?\n\n", programname );
								pr_2x( logFile, stderr, error_message );
								slaveExit(-1);
						}
						(void) fflush(logFile);
#ifdef PERF_PROFILING

						return_current_time(slaveDockInfo.MapFileEndTime);
						serialEndClock = (Real) times(&tms_serialEnd);

						serialCurrentDuration = (Real) (serialEndClock-serialStartClock) * idct;

						if (!mapFileAlreadyLoaded)
								slaveDockInfo.MapFileNumber++;
						if (slaveDockInfo.MapFileMaxDuration < serialCurrentDuration)
								slaveDockInfo.MapFileMaxDuration = serialCurrentDuration;
						if ((slaveDockInfo.MapFileMinDuration > serialCurrentDuration) || (slaveDockInfo.MapFileMinDuration == -1.0))
								slaveDockInfo.MapFileMinDuration = serialCurrentDuration;
						slaveDockInfo.MapFileTotalDuration += serialCurrentDuration;

#endif
						break;
						//______________________________________________________________________________
						/***************************
						// YTLIU_EDIT 2013.01.25
						 ***************************/
				case DPF_XBVDWPROFILE:
						if(xb_empirical_scoring && halogen_found){
								if(mapusagetype==REUSE_MAPS)
										if(xbEmpiricalVDWProfileAlreadLoaded)
												break;
								profile_stats = M_readxbempiricalprofile(line,outlev,jobStart,tms_jobStart,info,xbEmpiricalMapInfo->xb_vdw_profile,'v');
								//        pr(logFile, "Min= %.3lf Mean= %.3lf Max= %.3lf\n\n",
								//                    profile_stats.minimum, profile_stats.mean, profile_stats.maximum);
								xbEmpiricalVDWProfileAlreadLoaded=TRUE;
						}
						break;

				case DPF_XBESPROFILE:
						if(xb_empirical_scoring && halogen_found){
								if(mapusagetype==REUSE_MAPS)
										if(xbEmpiricalESProfileAlreadLoaded)
												break;
								profile_stats = M_readxbempiricalprofile(line,outlev,jobStart,tms_jobStart,info,xbEmpiricalMapInfo->xb_es_profile,'e');
								//            pr(logFile, "Min= %.3lf Mean= %.3lf Max= %.3lf\n\n",
								//                    profile_stats.minimum, profile_stats.mean, profile_stats.maximum);
								xbEmpiricalESProfileAlreadLoaded=TRUE;
						}
						break;

				case DPF_XBDESOLVPROFILE:
						if(xb_empirical_scoring && halogen_found){
								if(mapusagetype==REUSE_MAPS)
										if(xbEmpiricalDesolvProfileAlreadLoaded)
												break;
								profile_stats = M_readxbempiricalprofile(line,outlev,jobStart,tms_jobStart,info,xbEmpiricalMapInfo->xb_desolv_profile,'d');
								//            pr(logFile, "Min= %.3lf Mean= %.3lf Max= %.3lf\n\n",
								//                    profile_stats.minimum, profile_stats.mean, profile_stats.maximum);
								xbEmpiricalDesolvProfileAlreadLoaded=TRUE;
						}
						break;

						//______________________________________________________________________________

				case DPF_ELECMAP:
						/*
						 *  elecmap file.e.map
						 */
						//        map_stats = readmap( line, outlev, jobStart, tms_jobStart, B_charMap, &B_havemap, num_maps, info, map, 'e' );
						//        pr(logFile, "Min= %.3lf Mean= %.3lf Max= %.3lf\n\n",
						//                map_stats.minimum, map_stats.mean, map_stats.maximum);
						//        ElecMap = num_maps;
						//        B_found_elecmap = TRUE;
						//        num_maps++;
						//        (void) fflush(logFile);

#ifdef PERF_PROFILING


						if (slaveDockInfo.firstMapFileFound == 0) {
								return_current_time(slaveDockInfo.MapFileStartTime);
								slaveDockInfo.firstMapFileFound = 1;
						}


						serialStartClock = (Real) times(&tms_serialStart);


#endif

						mapFileAlreadyLoaded = FALSE;
						if (mapusagetype == REUSE_MAPS) {
								(void) sscanf( line, "%*s %s", FileName );
								// printf("elecmap filename is %s\n",FileName);

								for (int i=0;(i<num_maps && !mapFileAlreadyLoaded);i++) {

										// printf("FileName is %s and loadedMapFileNames[%d] is %s\n",FileName,i,loadedMapFileNames[i]);

										if (strcmp(loadedMapFileNames[i],FileName) == 0)
												mapFileAlreadyLoaded = TRUE;
								}
						}
						if ((mapusagetype == REUSE_MAPS) && !mapFileAlreadyLoaded) {
								strcpy(loadedMapFileNames[num_maps],FileName);
								strcpy(atomTypeMap[num_maps],"e");
						}

						if (!mapFileAlreadyLoaded) {
								map_stats = M_readmap( line, outlev, jobStart, tms_jobStart, B_charMap, &B_havemap, num_maps, info, map, 'e', mapFileAlreadyLoaded, mapusagetype );
								//              pr(logFile, "Min= %.3lf Mean= %.3lf Max= %.3lf\n\n",
								//                map_stats.minimum, map_stats.mean, map_stats.maximum);
								ElecMap = num_maps;
						}

						B_found_elecmap = TRUE;
						if (!mapFileAlreadyLoaded) {
								num_maps++;
						}
						//        (void) fflush(logFile);

#ifdef PERF_PROFILING

						return_current_time(slaveDockInfo.MapFileEndTime);
						serialEndClock = (Real) times(&tms_serialEnd);

						serialCurrentDuration = (Real) (serialEndClock-serialStartClock) * idct;

						if (!mapFileAlreadyLoaded)
								slaveDockInfo.MapFileNumber++;
						if (slaveDockInfo.MapFileMaxDuration < serialCurrentDuration)
								slaveDockInfo.MapFileMaxDuration = serialCurrentDuration;
						if ((slaveDockInfo.MapFileMinDuration > serialCurrentDuration) || (slaveDockInfo.MapFileMinDuration == -1.0))
								slaveDockInfo.MapFileMinDuration = serialCurrentDuration;
						slaveDockInfo.MapFileTotalDuration += serialCurrentDuration;

#endif
						break;

						//______________________________________________________________________________

				case DPF_DESOLVMAP:
						/*
						 *  desolvmap file.d.map
						 */
						//        map_stats = readmap( line, outlev, jobStart, tms_jobStart, B_charMap, &B_havemap, num_maps, info, map, 'd' );
						//        pr(logFile, "Min= %.3lf Mean= %.3lf Max= %.3lf\n\n",
						//                map_stats.minimum, map_stats.mean, map_stats.maximum);
						//        DesolvMap = num_maps;
						//        B_found_desolvmap = TRUE;
						//        num_maps++;
						//        (void) fflush(logFile);
#ifdef PERF_PROFILING


						if (slaveDockInfo.firstMapFileFound == 0) {
								return_current_time(slaveDockInfo.MapFileStartTime);
								slaveDockInfo.firstMapFileFound = 1;
						}


						serialStartClock = (Real) times(&tms_serialStart);


#endif

						mapFileAlreadyLoaded = FALSE;
						if (mapusagetype == REUSE_MAPS) {
								(void) sscanf( line, "%*s %s", FileName );
								// printf("disolvmap filename is %s\n",FileName);

								for (int i=0;(i<num_maps && !mapFileAlreadyLoaded);i++) {

										// printf("FileName is %s and loadedMapFileNames[%d] is %s\n",FileName,i,loadedMapFileNames[i]);

										if (strcmp(loadedMapFileNames[i],FileName) == 0)
												mapFileAlreadyLoaded = TRUE;
								}
						}
						// printf("mapFileAlreadyLoaded is %d\n",mapFileAlreadyLoaded);

						if ((mapusagetype == REUSE_MAPS) && !mapFileAlreadyLoaded) {
								strcpy(loadedMapFileNames[num_maps],FileName);
								strcpy(atomTypeMap[num_maps],"d");
						}
						if (!mapFileAlreadyLoaded) {

								map_stats = M_readmap( line, outlev, jobStart, tms_jobStart, B_charMap, &B_havemap, num_maps, info, map, 'd', mapFileAlreadyLoaded, mapusagetype );
								//              pr(logFile, "Min= %.3lf Mean= %.3lf Max= %.3lf\n\n",
								//                map_stats.minimum, map_stats.mean, map_stats.maximum);
								DesolvMap = num_maps;
						}
						B_found_desolvmap = TRUE;
						if (!mapFileAlreadyLoaded) {
								num_maps++;
						}
						//        (void) fflush(logFile);

#ifdef PERF_PROFILING

						return_current_time(slaveDockInfo.MapFileEndTime);
						serialEndClock = (Real) times(&tms_serialEnd);

						serialCurrentDuration = (Real) (serialEndClock-serialStartClock) * idct;

						if (!mapFileAlreadyLoaded)
								slaveDockInfo.MapFileNumber++;
						if (slaveDockInfo.MapFileMaxDuration < serialCurrentDuration)
								slaveDockInfo.MapFileMaxDuration = serialCurrentDuration;
						if ((slaveDockInfo.MapFileMinDuration > serialCurrentDuration) || (slaveDockInfo.MapFileMinDuration == -1.0))
								slaveDockInfo.MapFileMinDuration = serialCurrentDuration;
						slaveDockInfo.MapFileTotalDuration += serialCurrentDuration;

#endif
						break;

						//______________________________________________________________________________

				case DPF_CHARMAP:
						/*
						 ** charmap
						 ** ATOMIC AFFINITY, ELECTROSTATIC POTENTIAL OR DESOLVATION ENERGY GRID MAP
						 ** Read in active site grid map...
						 */

#ifdef PERF_PROFILING


						if (slaveDockInfo.firstMapFileFound == 0) {
								return_current_time(slaveDockInfo.MapFileStartTime);
								slaveDockInfo.firstMapFileFound = 1;
						}


						serialStartClock = (Real) times(&tms_serialStart);

#endif

						B_charMap = TRUE;
						if (B_atom_types_found == TRUE) {
								// map_index could be incremented here if we had the atom_type stored in each map...

								mapFileAlreadyLoaded = FALSE;
								if (mapusagetype == REUSE_MAPS) {
										(void) sscanf( line, "%*s %s", FileName );

										for (int i=0;(i<num_maps && !mapFileAlreadyLoaded);i++) {

												// printf("FileName is %s and loadedMapFileNames[%d] is %s\n",FileName,i,loadedMapFileNames[i]);

												if (strcmp(loadedMapFileNames[i],FileName) == 0)
														mapFileAlreadyLoaded = TRUE;
										}
								}
								// printf("mapFileAlreadyLoaded is %d\n",mapFileAlreadyLoaded);

								if ((mapusagetype == REUSE_MAPS) && !mapFileAlreadyLoaded) {
										strcpy(loadedMapFileNames[num_maps],FileName);
										strcpy(atomTypeMap[num_maps],"c");
								}

								if (!mapFileAlreadyLoaded) {

										map_stats = M_readmap( line, outlev, jobStart, tms_jobStart, B_charMap, &B_havemap, num_maps, info, map, 'c', mapFileAlreadyLoaded, mapusagetype );
										//            pr(logFile, "Min= %.3lf Mean= %.3lf Max= %.3lf\n\n",
										//                    map_stats.minimum, map_stats.mean, map_stats.maximum);
								}

								if (!mapFileAlreadyLoaded) {
										num_maps++;
								}
						} else {
								prStr( error_message, "%s:  msg 3 ERROR! No atom types have been found; we cannot continue without this information!\n\n", programname );
								pr_2x( logFile, stderr, error_message );
								prStr( error_message, "%s:  ERROR! Are you trying to use an AutoDock 3 DPF with AutoDock 4?\n\n", programname );
								pr_2x( logFile, stderr, error_message );
								slaveExit(-1);
						}
						//        (void) fflush(logFile);

#ifdef PERF_PROFILING

						return_current_time(slaveDockInfo.MapFileEndTime);
						serialEndClock = (Real) times(&tms_serialEnd);

						serialCurrentDuration = (Real) (serialEndClock-serialStartClock) * idct;

						if (!mapFileAlreadyLoaded)
								slaveDockInfo.MapFileNumber++;

						if (slaveDockInfo.MapFileMaxDuration < serialCurrentDuration)
								slaveDockInfo.MapFileMaxDuration = serialCurrentDuration;
						if ((slaveDockInfo.MapFileMinDuration > serialCurrentDuration) || (slaveDockInfo.MapFileMinDuration == -1.0))
								slaveDockInfo.MapFileMinDuration = serialCurrentDuration;
						slaveDockInfo.MapFileTotalDuration += serialCurrentDuration;

#endif
						break;

						//______________________________________________________________________________

				case DPF_MOVE:
						/*
						 ** move ligand_file.pdbqt
						 ** Specify the movable ligand,
						 */
						//
						// Initialisations that must be done before reading in a new ligand...
						//
#ifdef PERF_PROFILING


						if (slaveDockInfo.firstLigandFileFound == 0) {
								return_current_time(slaveDockInfo.LigandFileStartTime);
								slaveDockInfo.LigandFileTotalDuration=0.0;

								slaveDockInfo.firstLigandFileFound = 1;
						}


						serialStartClock = (Real) times(&tms_serialStart);

						// write out the map to a file
						/*
						   {

						   FILE *mapOutputFile = NULL;
						   char mapOutputFileName[FILENAME_MAX];

						   strcpy(mapOutputFileName,"mapOutputFile");
						   strcat(mapOutputFileName,slaveDockInfo.LigandFileStartTime);

						   if ( (mapOutputFile = ad_fopen(mapOutputFileName, "w")) == NULL ) {
						   fprintf(stderr, "\nautodock4 master: can't open %s\n", mapOutputFileName);
						   exit(-1);
						   }

						   for (int i=0;i<MAX_GRID_PTS;i++) {
						   for (int j=0;j<MAX_GRID_PTS;j++) {
						   for (int k=0;k<MAX_GRID_PTS;k++) {
						   for (int m=0;m<MAX_MAPS;m++) {
						   pr(mapOutputFile,"%.3lf\n", map[i][j][k][m]);
						   }
						   }
						   }
						   }
						   }
						   */

#endif
						/************************
						// YTLIU_EDIT 2013.01.16
						 ************************/

						if(xbpmf_scoring==0)
						{
								if (num_maps != num_atom_types + NUM_NON_VDW_MAPS) { //  dsolv map and elec map
										prStr(error_message, "\n\nMISSING MAP ERROR:\nnumber of maps %d does not match number expected for %d ligand types. \nUnable to continue.\n", num_maps, num_atom_types);
										//stop(error_message);
										slaveExit(-1);
								}
						}
						// pkcoff: change to support unduplicated map file loading
						// this check is only valid if we are always reloading maps
						if (mapusagetype == RELOAD_MAPS) {
								if (num_maps != num_atom_types + NUM_NON_VDW_MAPS) { //  dsolv map and elec map
										pr_2x( logFile, stderr, error_message );
										prStr(error_message, "\n\nMISSING MAP ERROR:\nnumber of maps %d does not match number expected for %d ligand types. \nUnable to continue.\n", num_maps, num_atom_types);
										//stop(error_message);
										slaveExit(-1);
								}
						}
						else {
								// reorder the map to what this iteration expected normally

								char printAtomBuffer[1024];
								char printAtomBufferOutputToFile[4096];
								sprintf(printAtomBufferOutputToFile,"Ligand %s on node %d - ligand info types: ",slaveDockInfo.baseName,slaveDockInfo.slaverank);

								for (int i=0;i<info->num_atom_types;i++) 
								{
										sprintf(printAtomBuffer,"[%s] ",info->atom_type_name[i]);
										strcat(printAtomBufferOutputToFile,printAtomBuffer);
								}

								strcat(printAtomBufferOutputToFile," -- atom types before map shuffle: ");
								for (int i=0;i<num_maps;i++) 
								{
										sprintf(printAtomBuffer,"[%s] ",atomTypeMap[i]);
										strcat(printAtomBufferOutputToFile,printAtomBuffer);
								}
								// clear out the atomTypeMapCopy
								strcpy(atomTypeMapCopy,"");
								strcpy(loadedMapFileNamesCopy,"");

								int newMapIter = 0;
								for (newMapIter=0; newMapIter<info->num_atom_types; newMapIter++) {
										if (strcmp(atomTypeMap[newMapIter],info->atom_type_name[newMapIter]) == 0) { // row can stay the same

										}
										else { // swap the atomTypeMap[newMapIter] entry with the one that matches the info->atom_type_name
												Boole mapAtomTypeFound = FALSE;
												int typeAtomIndex = 0;
												for (int k=0;(k<num_maps && !mapAtomTypeFound);k++) {
														if (strcmp(atomTypeMap[k],info->atom_type_name[newMapIter]) == 0) {
																mapAtomTypeFound = TRUE;
																typeAtomIndex = k;
														}
												}

												if (!mapAtomTypeFound) {
														fprintf(stderr,"REUSE_MAPS issue - atom type for position %d in the ligand not found in global atom map\n",
																		typeAtomIndex);
														slaveExit(-1);
												}
												else {
														// swap the rows

														// save off the newMapIter row
														for (int j=0;j<MAX_GRID_PTS;j++)
																for (int k=0;k<MAX_GRID_PTS;k++)
																		for (int m=0;m<MAX_GRID_PTS;m++)
																				mapCopyOneRow[j][k][m] = map[j][k][m][newMapIter];
														strcpy(atomTypeMapCopy, atomTypeMap[newMapIter]);
														strcpy(loadedMapFileNamesCopy, loadedMapFileNames[newMapIter]);

														// copy down the typeAtomIndex row
														for (int j=0;j<MAX_GRID_PTS;j++)
																for (int k=0;k<MAX_GRID_PTS;k++)
																		for (int m=0;m<MAX_GRID_PTS;m++)
																				map[j][k][m][newMapIter] = map[j][k][m][typeAtomIndex];
														strcpy(atomTypeMap[newMapIter], atomTypeMap[typeAtomIndex]);
														strcpy(loadedMapFileNames[newMapIter], loadedMapFileNames[typeAtomIndex]);

														// copy the saved newMapIter row into the typeAtomIndex row
														for (int j=0;j<MAX_GRID_PTS;j++)
																for (int k=0;k<MAX_GRID_PTS;k++)
																		for (int m=0;m<MAX_GRID_PTS;m++)
																				map[j][k][m][typeAtomIndex] = mapCopyOneRow[j][k][m];
														strcpy(atomTypeMap[typeAtomIndex],atomTypeMapCopy);
														strcpy(loadedMapFileNames[typeAtomIndex],loadedMapFileNamesCopy);

														// if we moved the electrostatic or desolvation maps then reset the offset
														if (strcmp(atomTypeMap[typeAtomIndex],"e") == 0)
																ElecMap = typeAtomIndex;
														if (strcmp(atomTypeMap[typeAtomIndex],"d") == 0)
																DesolvMap = typeAtomIndex;
												} // else
										} // else
								} // for
								strcat(printAtomBufferOutputToFile," -- atom types after map shuffle: ");
								for (int i=0;i<num_maps;i++) 
								{
										sprintf(printAtomBuffer,"[%s] ",atomTypeMap[i]);
										strcat(printAtomBufferOutputToFile,printAtomBuffer);
								}
								// printf("%s\n",printAtomBufferOutputToFile);

						}
						nconf = 0;
						for (k = 0; k < MAX_RUNS; k++) {
								for (i = 0; i  < MAX_TORS;  i++ ) {
										sHist[k].tor[i] = 0.0;
								}
								econf[k] = 0.0;
						}
						for (j = 0;  j < MAX_ATOMS;  j++ ) {
								type[j] = 0;
								ignore_inter[j] = 0;
						}
						for (i = 0; i  < MAX_TORS;  i++ ) {
								for (j = 0;  j < MAX_ATOMS;  j++ ) {
										tlist[i][j] = 0;
								}
								B_isTorConstrained[i] = 0;
								US_torProfile[i][0] = 0;
								N_con[i] = 0;
						}
						for (j = 0; j < MAX_NONBONDS; j++) {
								nonbondlist[j].a1 = nonbondlist[j].a2 = 0;
						}

#pragma omp parallel num_threads(MaxNumThreads)
						{
								for (int j=0; j<3; j++) {       
										Nnb_array[j] = 0;
										nb_group_energy[j] = 0.0;
								}
								//printf("CPU:Parallel 3...\n");
								//fflush(0);
						}
						M_initialiseState( &sInit );
						M_initialiseState( &(ligand.S) );
						M_initialiseQuat( &q_reorient );
						B_constrain_dist = B_haveCharges = FALSE;
						ntor1 = ntor = atomC1 = atomC2 = 0;
						ntor_ligand = 0;
						ntorsdof = 0;
						sqlower = squpper = 0.0;
						strcpy( FN_pop_file, "");  // means don't print pop_file
						Nnb = 0;
						ligand_is_inhibitor = 1;
						M_initialise_energy_breakdown(&eb, 0, 0);
						//
						// end of initialization
						//

						// this is the DPF_MOVE section...
						B_found_move_keyword = TRUE;
						B_found_about_keyword = FALSE; //set false by 'move' true by 'about'

						//        print_1_4_message(logFile, B_include_1_4_interactions, scale_1_4);

						natom=0;
						ligand = M_readPDBQT( line,
										num_atom_types,
										&natom,
										crdpdb, crdreo, charge, &B_haveCharges,
										type, bond_index,
										pdbaname, FN_ligand, FN_flexres, B_have_flexible_residues, atomstuff, &n_heavy_atoms_in_ligand,
										&B_constrain_dist, &atomC1, &atomC2,
										&sqlower, &squpper,
										&ntor1, &ntor, &ntor_ligand,
										tlist, vt,
										&Nnb, nonbondlist,
										jobStart, tms_jobStart, hostnm, &ntorsdof, outlev,
										ignore_inter,
										B_include_1_4_interactions,
										atoms, PDBQT_record, end_of_branch );

						// pre-calculate some values we will need later in computing the desolvation energy
						//
						for (i=0; i<natom; i++) {
								abs_charge[i] = fabs(charge[i]);
								qsp_abs_charge[i] = qsolpar * abs_charge[i];

								/**************************
								// YTLIU_EDIT 2013.01.25
								 **************************/
								if(xb_empirical_scoring && halogen_found){
										xbempirical_ligand_xbdonor[i][0] = -1;
										xbempirical_ligand_xbdonor[i][1] = -1;
										//		xbempirical_ligand_donor_index[i] = -1;

										if( equal(atoms[i].type_string,"Cl",2) ||
														equal(atoms[i].type_string,"CL",2) ||
														equal(atoms[i].type_string,"Br",2) ||
														equal(atoms[i].type_string,"BR",2) ||
														equal(atoms[i].type_string,"I",1) ){
												xbempirical_donor_index = M_lookupXBPMFMAPATindex(atoms[i].type_string);
												xbempirical_donor_index -= Cl;
												//		    xbempirical_ligand_donor_index[i] = xbempirical_donor_index;
												xbempirical_ligand_xbdonor[i][0] = xbempirical_donor_index;

												int xfrom, xto;
												xfrom=(0>(i-20)?0:(i-20));
												xto=((natom-1)>(i+20)?(i+20):(natom-1));
												Real min_xdist = 100.0;
												int min_index = -1;
												for(j=xfrom; j<=xto; j++){
														if(j==i)
																continue;
														Real xdist = hypotenuse((crdpdb[i][X]-crdpdb[j][X]),(crdpdb[i][Y]-crdpdb[j][Y]),(crdpdb[i][Z]-crdpdb[j][Z]));
														if(xdist<min_xdist){
																min_xdist=xdist;
																min_index=j;
														}
												}
												xbempirical_ligand_xbdonor[i][1] = min_index;
												if(xbempirical_ligand_xbdonor[i][1] == -1){
														pr(logFile, "No bonded atom found for atom %d:%s in ligand", i+1,atoms[i].type_string);
														xbempirical_ligand_xbdonor[i][0] = -1;
												}
										}
								}

						}
						torsFreeEnergy = (Real)ntorsdof * AD4.coeff_tors;


						if (!B_haveCharges) 
						{
								pr( logFile, "%s: WARNING! No partial atomic charges have been supplied yet.\n\n",programname);
						}
						else 
						{
								if (Nnb > 0){	
										if (outlev >= 0) 
										{
												for (i = 0;  i < Nnb;  i++) 
												{
														atm1 = nonbondlist[i].a1;
														atm2 = nonbondlist[i].a2;
														int t1 = nonbondlist[i].t1;
														int t2 = nonbondlist[i].t2;
														nonbondlist[i].desolv =
																( parameterArray[t2].vol * (parameterArray[t1].solpar + qsp_abs_charge[atm1])+ parameterArray[t1].vol * (parameterArray[t2].solpar + qsp_abs_charge[atm2]) );

														nonbondlist[i].q1q2 = charge[atm1] * charge[atm2];	
														nonbondlist[i].q1q2 *= ELECSCALE * AD4.coeff_estat;
												}
										} // if outlev > 0
								} // if NNb > 0
						} // else
						sInit.ntor = ligand.S.ntor;
						++nmol;
						++nlig;

						//        (void) fflush(logFile);
#ifdef PERF_PROFILING

						return_current_time(slaveDockInfo.LigandFileEndTime);
						serialEndClock = (Real) times(&tms_serialEnd);

						serialCurrentDuration = (Real) (serialEndClock-serialStartClock) * idct;

						slaveDockInfo.LigandFileTotalDuration += serialCurrentDuration;

#endif
						break;

						/*____________________________________________________________________________*/

				case DPF_FLEXRES:

						break;


#ifdef USING_COLINY
						/*____________________________________________________________________________*/

				case DPF_COLINY:
						{
								//ostdiostream fstr(logFile);
								//ostdiostream fstr(logFile->_file);
								//CommonIO::set_streams(&fstr,&fstr,&cin);

								struct tms tms_colinyStart;
								struct tms tms_colinyEnd;

								Clock  colinyStart;
								Clock  colinyEnd;

								int coliny_seed;
								char algname[LINE_LEN];
								char nruns_str[LINE_LEN];
								(void) sscanf(line, "%*s %s %d", algname, &nruns);
								(void) sscanf(line, "%*s %s %s", algname, nruns_str);

								if (strcmp(algname,"help")==0) {
										std::vector<double> initvec;
										coliny_init(algname, "", 0);
										prStr(error_message, "%s:  ERROR:  no optimizer type specified.", programname);
										//stop(error_message);
										slaveExit(-1);
								}
								else if (strcmp(nruns_str,"help")==0) {
										std::vector<double> initvec;
										coliny_init(algname, nruns_str, 0);
										prStr(error_message, "%s:  ERROR:  no optimizer type specified.", programname);
										//stop(error_message);
										slaveExit(-1);
								}


								if (nruns>MAX_RUNS) {
										prStr(error_message, "%s:  ERROR:  %d runs requested, but only dimensioned for %d.\nChange \"MAX_RUNS\" in \"constants.h\".", programname, nruns, MAX_RUNS);
										//stop(error_message);
										slaveExit(-1);
								}
								exit_if_missing_elecmap_desolvmap_about("coliny");

								if(xbpmf_scoring)
										evaluate.setup( crd, charge, abs_charge, qsp_abs_charge, type, natom,
														map, elec, emap, nonbondlist, ad_energy_tables,
														Nnb, B_calcIntElec, B_isGaussTorCon, B_isTorConstrained, B_ShowTorE,
														US_TorE, US_torProfile,
														vt, tlist,
														crdpdb, crdreo, sInit, ligand, ignore_inter, B_include_1_4_interactions, scale_1_4,
														unbound_internal_FE, info,
														B_use_non_bond_cutoff, B_have_flexible_residues, xbpmf_1d_pw_parms,
														xbpmf_2d_hb_pw_parms,
														xbpmf_2d_xb_pw_parms,
														recep_natom,
														recep_crdpdb,
														recep.atomtype,
														xbligand.atomtype,
														xbpmf_1d_map,
														xbpmf_hb_map,
														recep_acceptor_natom,
														recep_acceptor_crdpdb,
														recep_acceptor_atomtype,xbpmf_hb_label,xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
								else
										evaluate.setup( crd, charge, abs_charge, qsp_abs_charge, type, natom,
														map, elec, emap, nonbondlist, ad_energy_tables,
														Nnb, B_calcIntElec, B_isGaussTorCon, B_isTorConstrained, B_ShowTorE,
														US_TorE, US_torProfile,
														vt, tlist,
														crdpdb, crdreo, sInit, ligand, ignore_inter, B_include_1_4_interactions, scale_1_4,
														unbound_internal_FE, info,
														B_use_non_bond_cutoff, B_have_flexible_residues,
														xb_empirical_vdw, xb_empirical_es,
														ad_vdw, ad_es, ad_desolv, xb_vdw_profile, xb_es_profile,
														xb_desolv_profile, xbempirical_parms, halogen_found,
														xbempirical_recep_crdpdb,
														xbempirical_ligand_xbdonor,
														xbempirical_receptor_acceptor_index);

								evaluate.compute_intermol_energy(TRUE);

								char domain[1024];
								// NOTE: Coliny enforces the bound constraints, but since the
								// torsion angles are periodic, we simply prevent the optimizer
								// from going too far.
								if (sInit.ntor > 0) {
										sprintf(domain,"[%f,%f] [%f,%f] [%f,%f] [-1000.0,1000.0]^3 [-3.1416,3.1416] [-3.1416,3.1416]^%d",(double)info->lo[X], (double)info->hi[X], (double)info->lo[Y], (double)info->hi[Y], (double)info->lo[Z], (double)info->hi[Z], sInit.ntor);
										//sprintf(domain,"[%f,%f] [%f,%f] [%f,%f] [-1.0,1.1]^3 [-6.2832,12.5664] [-6.2832,12.5664]^%d",(double)info->lo[X], (double)info->hi[X], (double)info->lo[Y], (double)info->hi[Y], (double)info->lo[Z], (double)info->hi[Z], sInit.ntor);
								} else {
										sprintf(domain,"[%f,%f] [%f,%f] [%f,%f] [-1000.0,1000.0]^3 [-3.1416,3.1416]",(double)info->lo[X], (double)info->hi[X], (double)info->lo[Y], (double)info->hi[Y], (double)info->lo[Z], (double)info->hi[Z]);
								}
								pr(logFile, "Number of Coliny %s dockings = %d run%c\n", algname, nruns, (nruns>1)?'s':' ');
								pr(logFile, "Search Domain: %s\n", domain);

								//
								// COLINY-SPECIFIC LOGIC - BEGIN
								//

								try {

										std::vector<double> initvec, finalpt;
										// set up initial point
										initvec.resize(7+sInit.ntor);
										initvec[0] = sInit.T.x;
										initvec[1] = sInit.T.y;
										initvec[2] = sInit.T.z;
										/*
										 * axis-angle (nx,ny,nz,ang) suffers from bias
										 initvec[3] = sInit.Q.nx;
										 initvec[4] = sInit.Q.ny;
										 initvec[5] = sInit.Q.nz;
										 initvec[6] = DegreesToRadians( sInit.Q.ang );
										 */
										sInit.Q = convertRotToQuat( sInit.Q );
										initvec[3] = sInit.Q.x;
										initvec[4] = sInit.Q.y;
										initvec[5] = sInit.Q.z;
										initvec[6] = sInit.Q.w;
										for (j=0; j < sInit.ntor ; j++) {
												initvec[j+7] = DegreesToRadians(sInit.tor[j]);
										}
										coliny_init(algname, domain, sInit.ntor+7);

										for (j=0; j<nruns; j++) {
												fprintf( logFile, "\n\n\tBEGINNING Coliny %s DOCKING\n",algname);
												pr(logFile, "\nDoing %s run:  %d/%d.\n", algname, j+1, nruns);

												//coliny uses a single seed
												coliny_seed = seed[0]+seed[1]+j;
												pr(logFile, "Seed: %d [%ld+%ld+%d]\n", coliny_seed, seed[0], seed[1], j);
												//pr(logFile, "Seeds:  %ld %ld\n", seed[0], seed[1]);
												(void) fflush(logFile);

												colinyStart = times(&tms_colinyStart);

												finalpt.resize( initvec.size() );
												int neval, niters;
												coliny_minimize( coliny_seed, initvec, finalpt, neval, niters );
												//fstr.flush();

												make_state_from_rep( (double *)&(finalpt[0]), int(finalpt.size()), &sHist[nconf]);

												pr(logFile, "\nTotal Num Evals: %d\n", neval);
												printState(logFile, sHist[nconf], 2);

												colinyEnd = times(&tms_colinyEnd);
												pr(logFile, "Time taken for this %s run:\n", algname);
												M_timesyshms(colinyEnd-colinyStart, &tms_colinyStart, &tms_colinyEnd);
												pr(logFile, "\n");

												pr(logFile, "Total number of Energy Evaluations: %d\n", (int)evaluate.evals() );
												//pr(logFile, "Total number of Iterations:        %d\n", (int)niters);

												pr(logFile, "\nFinal docked state:\n");
												pr( logFile, UnderLine );
												pr( logFile, "\n\n\tFINAL Coliny %s DOCKED STATE\n",algname );
												pr( logFile,     "\t____________________________________\n\n\n" );
												(void) fflush(logFile);

												if(xbpmf_scoring)
														writePDBQT(j, seed, FN_ligand, dock_param_fn, lig_center,
																		sHist[nconf], ntor, &eintra, &einter, natom, atomstuff,
																		crd, emap, elec,
																		charge, abs_charge, qsp_abs_charge,
																		ligand_is_inhibitor,
																		torsFreeEnergy,
																		vt, tlist, crdpdb, nonbondlist,
																		ad_energy_tables,
																		type, Nnb, B_calcIntElec,
																		map,
																		outlev,
																		ignore_inter,
																		B_include_1_4_interactions, scale_1_4, parameterArray,
																		unbound_internal_FE,info, DOCKED, PDBQT_record,
																		B_use_non_bond_cutoff, B_have_flexible_residues, ad4_unbound_model,
																		xbpmf_1d_pw_parms,xbpmf_2d_hb_pw_parms,xbpmf_2d_xb_pw_parms,
																		recep_natom,recep_crdpdb,recep.atomtype,xbligand.atomtype,
																		xbpmf_1d_map,xbpmf_hb_map,recep_acceptor_natom,
																		recep_acceptor_crdpdb,recep_acceptor_atomtype,xbpmf_hb_label,xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
												else
														writePDBQT( j, seed, FN_ligand, dock_param_fn, lig_center,
																		sHist[nconf], ntor, &eintra, &einter, natom, atomstuff,
																		crd, emap, elec,
																		charge, abs_charge, qsp_abs_charge,
																		ligand_is_inhibitor,
																		torsFreeEnergy,
																		vt, tlist, crdpdb, nonbondlist,
																		ad_energy_tables,
																		type, Nnb, B_calcIntElec,
																		map,
																		outlev,
																		ignore_inter,
																		B_include_1_4_interactions, scale_1_4, parameterArray, unbound_internal_FE,
																		info, DOCKED, PDBQT_record, B_use_non_bond_cutoff, B_have_flexible_residues, ad4_unbound_model,
																		xb_empirical_vdw, xb_empirical_es,
																		ad_vdw, ad_es, ad_desolv, xb_vdw_profile, xb_es_profile,
																		xb_desolv_profile, xbempirical_parms, halogen_found,
																		xbempirical_recep_crdpdb,
																		xbempirical_ligand_xbdonor,
																		xbempirical_receptor_acceptor_index);

												// See also "calculateEnergies.cc", switch(ad4_unbound_model)
												if (ad4_unbound_model == Unbound_Same_As_Bound) {
														// Update the unbound internal energy, setting it to the current internal energy
														unbound_internal_FE = eintra;
												}
												econf[nconf] = eintra + einter + torsFreeEnergy - unbound_internal_FE;
												evaluate.reset();

												++nconf;

										} // Next run
										if(write_stateFile){
												fprintf(stateFile,"\t</runs>\n");
												(void) fflush(stateFile);
										}
										(void) fflush(logFile);
								}
								catch (std::exception& err) {
										(void)fprintf(logFile, "Caught Exception: %s\n", err.what());
										slaveExit(1);
								}

						}
						break;
#endif


						//______________________________________________________________________________

				case DPF_ABOUT:
						/*
						 **  about
						 **  Rotation center for current ligand,
						 */
						(void) sscanf( line, "%*s " FDFMT3, &lig_center[X], &lig_center[Y], &lig_center[Z]);
						//        pr( logFile, "Small molecule center of rotation =\t" );
						//        pr( logFile, "(%+.3f, %+.3f, %+.3f)\n\n", lig_center[X], lig_center[Y], lig_center[Z]);
						B_found_about_keyword = TRUE; //set false by 'move' true by 'about'
						/*
						 **  Center the ligand,
						 */
						if ( nmol == 0 ) {
								pr( logFile, "Must specify a ligand PDBQT file, using the \"move\" command.\n");
						} else {
								//            if (outlev >= 0) {
								//                pr( logFile, "Translating small molecule by:\t" );
								//                pr( logFile, "(%+.3f, %+.3f, %+.3f)\n\n", -lig_center[X], -lig_center[Y], -lig_center[Z]);
								//            }
								/*
								 **  Zero-out on central point...
								 */
								maxrad = -1.0;
								for ( i=0; i<true_ligand_atoms; i++ ) { /*new, gmm, 6-23-1998*/
										r2sum=0.0;
										for (xyz = 0;  xyz < SPACE;  xyz++) {
												c = crd[i][xyz] = (crdpdb[i][xyz] -= lig_center[xyz]);
												r2sum += c*c;
										} /* xyz */
										maxrad = maxrad>sqrt(r2sum)?maxrad:sqrt(r2sum);
								} /* i */
								//            if (outlev >= 0) {
								//                pr( logFile, "Furthest ligand atom from \"about\" center is %.3f Angstroms (maxrad).\n\n",maxrad);
								//            }
						}
						//        (void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/
#ifdef USE_DPF_REORIENT
				case DPF_REORIENT:
						/*
						 *  reorient random
						 *      # applies a random rotation to the input ligand
						 * -OR-
						 *  reorient standard
						 *      # moves the ligand such that
						 *      # the first three atoms lie parallel to the xy-plane, and
						 *      # the first two atoms lie parallel to the x-axis
						 * -OR-
						 *  reorient <axis-x> <axis-y> <axis-z> <angle>
						 *      # applies the specified rotation to the input ligand
						 */
						(void) sscanf( line, "%*s %s", param[0] );
						{ // Parse the reorient command
								for (i=0; i<6; i++) {
										param[0][i] = (char)tolower( (int)param[0][i] );
								}
								if (equal(param[0],"random",6)) {
										// reorient random
										B_reorient_random = TRUE; // create a new random orientation before docking

										L_create_random_orientation( &q_reorient );

								} else if (equal(param[0],"standard",8)) {
										{ // reorient standard
												B_reorient_random = FALSE; // do not create a new random orientation before docking

												if (true_ligand_atoms >= 3 ) {
														// Move the ligand such that
														// the first three atoms lie parallel to the xy-plane, and
														// the first two atoms lie parallel to the x-axis
														Vector vec_01,     // vector between ligand atoms 0 and 1
															   vec_12,     // vector between ligand atoms 1 and 2
															   vec_normal, // vector perpendicular to plane of vec_01 and vec_12
															   vec_x_axis, // vector along the X-axis
															   vec_z_axis, // vector along the Z-axis
															   vec_reorient_axis; // vector describing the axis about which to reorient
														// Set the X and Z axes:
														vec_x_axis[X] = 1.;
														vec_x_axis[Y] = 0.;
														vec_x_axis[Z] = 0.;
														vec_z_axis[X] = 0.;
														vec_z_axis[Y] = 0.;
														vec_z_axis[Z] = 1.;
														for (xyz = 0;  xyz < SPACE;  xyz++) {
																vec_01[xyz] = (double)( crdpdb[1][xyz] - crdpdb[0][xyz] );
																vec_12[xyz] = (double)( crdpdb[2][xyz] - crdpdb[1][xyz] );
														}
														// Compute the normal to vec_01 and vec_12
														Cross_product( vec_normal, vec_01, vec_12 );
														Print_vector( logFile, "vec_01", vec_01 );
														Print_vector( logFile, "vec_12", vec_12 );
														Print_vector( logFile, "vec_normal", vec_normal );
														Print_vector( logFile, "vec_z_axis", vec_z_axis );
														// Compute the angle between vec_01 and vec_12
														double angle_012 = 0.;
														angle_012 = Angle_between( vec_01, vec_12 );
														pr( logFile, "Angle between vectors 01 and 12 = %.2f degrees\n", RadiansToDegrees( angle_012 ) );
														if ( ( fabs(angle_012) < APPROX_ZERO ) || ( ( fabs(angle_012) > (PI - APPROX_ZERO) ) && ( fabs(angle_012) < (PI + APPROX_ZERO) ) ) ) {
																// angle is too small or "too linear" to align the molecule into the xy-plane
																pr( logFile, "%s:  WARNING!  The angle between the first three atoms is not suitable (%6.3f degrees) to align them with the xy-plane.\n", programname, RadiansToDegrees( angle_012 ) );
														} else {
																// Calculate angle between vec_normal and the z-axis
																double angle_n1z = 0.;  // Angle between vec_normal and the z-axis
																angle_n1z = Angle_between( vec_normal, vec_z_axis );
																pr( logFile, "Angle between vec_normal and vec_z_axis = %.2f degrees\n", RadiansToDegrees( angle_n1z ) );
																//
																// We need to rotate the molecule about the normal to vec_normal and vec_z_axis
																Cross_product( vec_reorient_axis, vec_normal, vec_z_axis );
																//
																// Set the rotation axis for reorientation
																q_reorient.nx = vec_reorient_axis[X];
																q_reorient.ny = vec_reorient_axis[Y];
																q_reorient.nz = vec_reorient_axis[Z];
																//
																// Normalise the vector defining the axis of rotation:
																q_reorient = normRot( q_reorient );
																//
																// Set the angle for reorientation of the first 3 atoms
																// into the xy-plane
																q_reorient.ang = -angle_n1z;
																//
																// Convert the rotation-about-axis components (nx,ny,nz,ang)
																// to a rotation-quaternion (x,y,z,w):
																q_reorient = convertRotToQuat( q_reorient );

																// Rotate ligand into the xy-plane...
																// qtransform( origin, q_reorient, crdreo, true_ligand_atoms );
																L_qtransform( origin, q_reorient, crdpdb, true_ligand_atoms );

																// Compute the updated vec_01, the vector between atom 0 and atom 1,
																// since the preceding "qtransform" changed the coordinates.
																for (xyz = 0;  xyz < SPACE;  xyz++) {
																		// vec_01[xyz] = (double)( crdreo[1][xyz] - crdreo[0][xyz] );
																		vec_01[xyz] = (double)( crdpdb[1][xyz] - crdpdb[0][xyz] );
																}
																//
																// Compute the angle between vec_01 and the x-axis:
																double angle_01x = 0.;
																angle_01x = Angle_between( vec_01, vec_x_axis );
																//
																pr( logFile, "Angle between vector 01 and the x-axis = %.2f degrees\n", RadiansToDegrees( angle_01x ) );
																//
																// The rotation axis to rotate the first two atoms, 0 and 1,
																// to be parallel to the x-axis, will be
																// perpendicular to the xy-plane, i.e. the z-axis,
																// since the molecule's first 3 atoms are now in the xy-plane.
																q_reorient.nx = vec_z_axis[X];
																q_reorient.ny = vec_z_axis[Y];
																q_reorient.nz = vec_z_axis[Z];
																//
																// Set the rotation angle:
																q_reorient.ang = angle_01x;
																//
																// Build the quaternion from the axis-angle rotation values:
																q_reorient = convertRotToQuat( q_reorient );
														} // angle_012 is appropriate to align into xy-plane

												} else {
														prStr( error_message, "%s: ERROR! Insufficient atoms in the ligand.  There must be at least three atoms in the ligand to use this command.\n", programname );
														//stop( error_message );
														slaveExit( -1 );
												}
										} // reorient standard
								} else {
										{ // reorient <nx> <ny> <nz> <angle>
												B_reorient_random = FALSE; // do not create a new random orientation before docking

												// Read the specified initial orientation for the ligand
												retval = (int)sscanf( line,"%*s %lf %lf %lf %lf", &(q_reorient.nx), &(q_reorient.ny), &(q_reorient.nz), &(q_reorient.ang) );
												if ( retval == 4 ) {
														// Normalise the vector defining the axis of rotation:
														q_reorient = normRot( q_reorient );
														// Make sure angle is in radians, and ranges from -PI to PI
														q_reorient.ang = DegreesToRadians( q_reorient.ang ); // convert from degrees to radians
														q_reorient.ang = ModRad( q_reorient.ang ); // wrap to range (0, 2*PI) using modulo 2*PI
														q_reorient.ang = WrpRad( q_reorient.ang ); // wrap to range (-PI, PI)
														pr( logFile, "After normalising the vector, and converting the angle to radians, the axis-angle rotation becomes ((%.3f, %.3f, %.3f), %.2f radians)\n",
																		q_reorient.nx, q_reorient.ny, q_reorient.ny, q_reorient.ang);
														// Convert the rotation-about-axis components (nx,ny,nz,ang)
														// to a rotation-quaternion (x,y,z,w):
														q_reorient = convertRotToQuat( q_reorient );
												} else {
														prStr( error_message, "%s: ERROR! Please specify the vector and rotation angle using four real numbers.\n", programname );
														//stop( error_message );
														slaveExit( -1 );
												}
										} // reorient <nx> <ny> <nz> <angle>
								} // endif
						} // end parsing reorient command line

						// reorient( logFile, true_ligand_atoms, atomstuff, crdreo, charge, type,
						reorient( logFile, true_ligand_atoms, atomstuff, crdpdb, charge, type,
										parameterArray, q_reorient, origin, ntor, tlist, vt, &ligand, debug );

						(void) fflush(logFile);
						break;
#endif

						//______________________________________________________________________________

				case DPF_TRAN0:
						/*
						 **  tran0
						 **  Initial_translation,
						 */
						(void) sscanf( line, "%*s %s", param[0]);
						for (i=0; i<6; i++) {
								param[0][i] = (char)tolower( (int)param[0][i] );
						}
						if (equal(param[0],"random",6)) {
								B_RandomTran0 = TRUE;
								ligand.S.T.x = sInit.T.x = random_range( info->lo[X], info->hi[X] );
								ligand.S.T.y = sInit.T.y = random_range( info->lo[Y], info->hi[Y] );
								ligand.S.T.z = sInit.T.z = random_range( info->lo[Z], info->hi[Z] );
						} else {
								B_RandomTran0 = FALSE;
								(void) sscanf( line,"%*s %lf %lf %lf", &(sInit.T.x), &(sInit.T.y), &(sInit.T.z));
								ligand.S.T.x = sInit.T.x;
								ligand.S.T.y = sInit.T.y;
								ligand.S.T.z = sInit.T.z;
						}
						//        if (outlev >= 0) {
						//            pr( logFile, "Initial translation =\t\t\t(%.3f, %.3f, %.3f) Angstroms\n", sInit.T.x, sInit.T.y, sInit.T.z );
						//        }
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_QUAT0:
				case DPF_AXISANGLE0:
				case DPF_QUATERNION0:
						/*
						 * Handles both axisangle0 and quaternion0
						 *
						 *  axisangle0 1. 0. 0. 0.
						 *  axisangle0 random
						 *  ( quat0 <--- deprecated )
						 *  Initial_quaternion, specified as an axis and angle
						 *
						 *  quaternion0 0. 0. 0. 1.
						 *  quaternion0 random
						 *  Initial_quaternion, specified as the four components (qx, qy, qz, qw)
						 */
						{
								// Local Block...
								double a, b, c, d;
								(void) sscanf( line, "%*s %s", param[0]);
								for (i=0; i<6; i++) {
										param[0][i] = (char)tolower( (int)param[0][i] );
								}
								if (equal(param[0],"random",6)) {
										// Make a random initial quaternion,
										// and set the boolean B_RandomQuat0 to true,
										// so we can generate random quaternions in population-based methods.
										B_RandomQuat0 = TRUE;
										L_create_random_orientation( &(sInit.Q) );
								} else {
										// Read in the user-defined axis-angle values for the initial quaternion
										// and set the boolean B_RandomQuat0 to false,
										/*////chengqian delete it
										  B_RandomQuat0 = FALSE;
										  (void) sscanf( line, "%*s %lf %lf %lf %lf", &a, &b, &c, &d);
										  sInit.Q = (dpf_keyword == DPF_QUATERNION0) ?
										  M_quatComponentsToQuat(a,b,c,d) :
										  M_axisDegreeToQuat(a,b,c,d);
										  */
								}
								ligand.S.Q = sInit.Q;
						}
						break;

						//______________________________________________________________________________

				case DPF_NDIHE:
						/*
						 **  ndihe
						 **  Number of dihedral angles to be specified by "dihe0"
						 */
						(void) sscanf( line, "%*s %d", &ndihed );
						if ( nmol == 0 ) {
								//            if (outlev >= 0) {
								//                pr( logFile, "Must specify a ligand PDBQT file, using the \"move\" command.\n");
								//            }
						} else {
								//            if (outlev >= 0) {
								//                pr( logFile, "%s: WARNING!  The \"ndihe\" command is no longer supported.  The number of torsions in the PDBQT file(s) is the number that will be used (i.e. %d)\n", programname, ntor);
								//            }
								if ( ndihed != ntor ) {
										pr( logFile, "%s: WARNING!  You requested %d torsions, but I found %d in PDBQT-file specifications.\n", programname, ndihed, ntor );
								} /* if */
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_DIHE0:
						/*
						 **  dihe0
						 **  Initial dihedral angles, input in degrees,
						 */
						(void) sscanf( line, "%*s %s", param[0]);
						for (i=0; i<6; i++) {
								param[0][i] = (char)tolower( (int)param[0][i] );
						}
						if (equal(param[0],"random",6)) {
								B_RandomDihe0 = TRUE;
								sInit.ntor = nval = ntor;
								for ( i=0; i<nval; i++ ) {
										sInit.tor[i] = random_range( -180.0, 180.0 );
								}
						} else {
								B_RandomDihe0 = FALSE;
								retval = (int)sscanf( line, torfmt, TOR_ARG_LIST );
								if (retval == 0) {
										pr( logFile, "WARNING!  AutoDock could not read any torsions!\n" );
								} else if (retval == EOF) {
										pr( logFile, "WARNING!  End of file encountered while reading dihe0 line\n");
								} else if (retval < ntor) {
										pr( logFile, "WARNING!  Only %d initial torsion angles were detected on input line.\n",retval);
										pr( logFile, "WARNING!  I am sorry, the number of torsions detected in the PDBQT files was %d torsions.\n", ntor);
								} else {
										//                if (outlev >= 0) {
										//                    pr( logFile, "%d initial torsion angles were detected on input line.\n", retval );
										//                }
								}
								nval = retval;
						}
						if (nval != ntor) {
								pr( logFile, "%s: WARNING!  The number of torsions specified (%d) does not match the number found in the PDBQT file (i.e. %d)\n", programname, nval, ntor);
						}
						for ( i=0; i<nval; i++ ) {
								//            if (outlev >= 0) {
								//                pr( logFile, "\tInitial torsion %2d = %7.2f deg\n", (i+1), sInit.tor[i] ); /* sInit.tor is in degrees */
								//                /* Convert sInit.tor[i] into radians */
								//            }
								ligand.S.tor[i] = sInit.tor[i] = DegreesToRadians( sInit.tor[i] ); /* sInit.tor is now in radians  Added:05-01-95 */
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_TSTEP:
						/*
						 **  tstep
						 **  Translation_step,
						 */
						retval = (int)sscanf( line, "%*s " FDFMT2, &trnStep0, &trnStepFinal );
						if (retval == 0) {
								pr( logFile, "WARNING!  AutoDock could not read any arguments!\n" );
						} else if (retval == EOF) {
								pr( logFile, "WARNING!  End of file encountered!\n");
						} else if (retval > 0) {
								//            pr( logFile, "Initial cycle, maximum translation step = +/- %-.1f Angstroms\n", trnStep0);
						}
						if (retval == 2) {
								B_CalcTrnRF = TRUE;
								//            if (outlev >= 0) {
								//                pr( logFile, "Final cycle,   maximum translation step = +/- %-.1f Angstroms\n", trnStepFinal);
								//                pr( logFile, "Reduction factor will be calculated when number of cycles has been read in.\n");
								//            }
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_QSTEP:
						/*
						 **  qstep
						 **  Quaternion_step,
						 */
						retval = (int)sscanf( line, "%*s " FDFMT2, &qtwStep0, &qtwStepFinal );
						if (retval == 0) {
								pr( logFile, "WARNING!  AutoDock could not read any arguments!\n" );
						} else if (retval == EOF) {
								pr( logFile, "WARNING!  End of file encountered!\n");
						} else if (retval > 0) {
								//            if (outlev >= 0) {
								//                pr( logFile, "Initial cycle, maximum quaternion angle step = +/- %-.1f deg\n", qtwStep0);
								//            }
								/* convert to radians */
								qtwStep0 = DegreesToRadians( qtwStep0 );
						}
						if (retval == 2) {
								B_CalcQtwRF = TRUE;
								//            if (outlev >= 0) {
								//                pr( logFile, "Final cycle,   maximum quaternion angle step = +/- %-.1f deg\n", qtwStepFinal);
								//                pr( logFile, "Reduction factor will be calculated when number of cycles has been read in.\n");
								//            }
								/* convert to radians */
								qtwStepFinal = DegreesToRadians( qtwStepFinal );
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_DSTEP:
						/*
						 **  dstep
						 **  Torsion_step,
						 */
						retval = (int)sscanf( line, "%*s " FDFMT2, &torStep0, &torStepFinal );
						if (retval == 0) {
								pr( logFile, "WARNING!  AutoDock could not read any arguments!\n" );
						} else if (retval == EOF) {
								pr( logFile, "WARNING!  End of file encountered!\n");
						} else if (retval > 0) {
								if (outlev >= 0) {
										//                pr( logFile, "Initial cycle, maximum torsion angle step = +/- %-.1f deg\n", torStep0);
								}
								/* convert to radians */
								torStep0 = DegreesToRadians( torStep0 );
						}
						if (retval == 2) {
								B_CalcTorRF = TRUE;
								//            if (outlev >= 0) {
								//                pr( logFile, "Final cycle,   maximum torsion angle step = +/- %-.1f deg\n", torStepFinal);
								//                pr( logFile, "Reduction factor will be calculated when number of cycles has been read in.\n");
								//            }
								/* convert to radians */
								torStepFinal = DegreesToRadians( torStepFinal );
						}
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_TRNRF:
						/*
						 **  trnrf
						 **  Translation reduction factor,
						 */
						(void) sscanf( line, "%*s " FDFMT, &trnFac );
						if (outlev >= 0) {
								pr( logFile, "Reduction factor for translations =\t%-.3f /cycle\n", trnFac );
						}
						B_trnReduc = (trnFac != 1.);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_QUARF:
						/*
						 **  quarf
						 **  Quaternion reduction factor,
						 */
						(void) sscanf( line, "%*s " FDFMT, &qtwFac );
						if (outlev >= 0) {
								pr( logFile, "Reduction factor for quaternion angle =\t%-.3f /cycle\n", qtwFac );
						}
						B_qtwReduc = (qtwFac != 1.);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_DIHRF:
						/*
						 **  dihrf
						 **  Torsion reduction factor,
						 */
						(void) sscanf( line, "%*s " FDFMT, &torFac );
						if (outlev >= 0) {
								pr( logFile, "Reduction factor for torsion angles =\t%-.3f /cycle\n", torFac );
						}
						B_torReduc = (torFac != 1.);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_FLEX:
						/*
						 **  flex
						 **  Flexible side-chains, cannot translate:
						 */
						nmol++;
						nres++;
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_INTNBP_REQM_EPS:
				case DPF_INTNBP_COEFFS:
						/*
						 **  intnbp_r_eps
						 **  Read internal energy parameters:
						 **  Lennard-Jones and Hydrogen Bond Potentials,
						 **  DPF_INTNBP_REQM_EPS: Using epsilon and r-equilibrium values...
						 **  DPF_INTNBP_COEFFS: Using coefficients...
						 */
						(void) sscanf( line, "%*s " FDFMT2 " %d %d %s %s", &Rij, &epsij, &xA, &xB, param[0], param[1] );
						if ( dpf_keyword == DPF_INTNBP_REQM_EPS ) {
								/* check that the Rij is reasonable */
								/* SF ...but only if there are no G-atoms. */        /* SF RING CLOSURE */

								if ((Rij <= 2.0 ) && (epsij >= EPSIJ_MAX )) {    /* RING CLOSURE */
										(void) fprintf( logFile, "Ring closure distance potential found for atom type %s :\n    Equilibrium distance   = %.2f Angstroms \n    Equilibrium potential  = %.6f Kcal/mol\n    Pseudo-LJ coefficients = %d-%d \n\n", param[1] , Rij, epsij, xA, xB); /* SF RING CLOSURE */
								}   /* SF RING CLOSURE */
								else { /* SF RING CLOSURE */

										if ((Rij < RIJ_MIN) || (Rij > RIJ_MAX)) {
												(void) fprintf( logFile,
																"WARNING: pairwise distance, Rij, %.2f, is not a very reasonable value for the equilibrium separation of two atoms! (%.2f Angstroms <= Rij <= %.2f Angstroms)\n\n", Rij, RIJ_MIN, RIJ_MAX);
												(void) fprintf( logFile, "Perhaps you meant to use \"intnbp_coeffs\" instead of \"intnbp_r_eps\"?\n\n");
												/* GMM COMMENTED OUT FOR DAVE GOODSELL, MUTABLE ATOMS
												 * slaveExit(-1); */
										}
										/* check that the epsij is reasonable */
										if ((epsij < EPSIJ_MIN) || (epsij > EPSIJ_MAX)) {
												(void) fprintf( logFile,
																"WARNING: well-depth, epsilon_ij, %.2f, is not a very reasonable value for the equilibrium potential energy of two atoms! (%.2f kcal/mol <= epsilon_ij <= %.2f kcal/mol)\n\n", epsij, EPSIJ_MIN, EPSIJ_MAX);
												(void) fprintf( logFile, "Perhaps you meant to use \"intnbp_coeffs\" instead of \"intnbp_r_eps\"? \n\n");
												/* GMM COMMENTED OUT FOR DAVE GOODSELL, MUTABLE ATOMS
												 * slaveExit(-1); */
										}
								} /* RING CLOSURE */

						}

						/* Defend against division by zero... */
						if (xA != xB) {
								if ( dpf_keyword == DPF_INTNBP_REQM_EPS ) {
										// Calculate the coefficients from Rij and epsij
										cA = (tmpconst = epsij / (Real)(xA - xB)) * pow( (double)Rij, (double)xA ) * (Real)xB;
										cB = tmpconst * pow( (double)Rij, (double)xB ) * (Real)xA;
								} else {
										cA = Rij;
										cB = epsij;
								}

								int a[2]; /* atom types of this interaction pair */
								for (int i=0;i<2;i++) {
										foundParameter = M_apm_find(param[i]);
										if ( NULL == foundParameter ) {
												prStr( error_message,"%s: ERROR:  Unknown ligand atom type \"%s\"; add parameters for it to the parameter library first!\n", programname, param[i]);
												slaveExit(-1);
										}
										else a[i] = foundParameter->map_index;
								}
								pr(logFile, "\nCalculating internal non-bonded interaction energies for docking calculation;\n");
								M_intnbtable( &B_havenbp, a[0], a[1], info, cA, cB, xA, xB, AD4.coeff_desolv, sigma, ad_energy_tables, BOUND_CALCULATION );
								// pr(logFile, "\nCalculating internal non-bonded interaction energies for unbound conformation calculation;\n");
								//intnbtable( &B_havenbp, a[0], a[1], info, cA_unbound, cB_unbound, xA_unbound, xB_unbound, AD4.coeff_desolv, sigma, unbound_energy_tables, UNBOUND_CALCULATION );
						} else {
								pr(logFile,"WARNING: Exponents must be different, to avoid division by zero!\n\tAborting...\n");
								slaveExit(-1);
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________


				case DPF_UNBOUND_INTNBP_COEFFS:
						/*
						 **  unbound_intnbp_coeffs
						 **  Read internal energy parameters for unbound extended state calculation:
						 */
						(void) sscanf( line, "%*s " FDFMT2 " %d %d", &cA_unbound, &cB_unbound, &xA_unbound, &xB_unbound );

						//        pr(logFile, "\nSetting the internal non-bonded interaction energy parameters for the\nunbound docking calculation, E = %.1f / r^%d - %.1f / r^%d\n\n", cA_unbound, xA_unbound, cB_unbound, xB_unbound);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_RT0:
						/*
						 **  rt0
						 **  Initial Temperature,
						 */
						(void) sscanf( line, "%*s " FDFMT, &RT0 );
						if (RT0 <= 0.) {
								pr( logFile, "\nWARNING!  Negative temperatures not allowed! Will default to RT = 616 cal mol.\n" );
								RT0 = 616.0;
						}
						if (outlev >= 0) {
								pr( logFile, "\n\t\tTEMPERATURE SCHEDULE INFORMATION\n" );
								pr( logFile, "\t\t________________________________\n\n" );
								pr( logFile, "               -1 -1                 -1 -1\n" );
								pr( logFile, "R = %5.3f J mol  K    = %5.3f cal mol  K  \n\n", RJ, Rcal );
								pr( logFile, "                                        -1\n" );
								pr( logFile, "Initial R*Temperature = %8.2f cal mol\n", RT0 );
								pr( logFile, "      (=> Temperature = %8.2f K\n", RT0/Rcal );
								pr( logFile, "                   or = %8.2f C)\n\n", RT0/Rcal - T0K );
						}
						break;

						//______________________________________________________________________________

				case DPF_RTRF:
						/*
						 **  rtrf
						 **  Temperature reduction factor,
						 */
						(void) sscanf( line, "%*s " FDFMT, &RTFac);
						if (outlev >= 0) {
								pr( logFile, "R*Temperature reduction factor = %8.2f\t/cycle\n", RTFac );
						}
						if (RTFac >= 1.) {
								//stop("Cooling is impossible with a reduction\n\tfactor greater than or equal to 1.0!" );
								slaveExit( -1 );
						} else if (RTFac == 0.0 ) {
								//stop("Cooling is impossible with a ZERO reduction factor!" );
								slaveExit( -1 );
						} else if (RTFac < 0.0 ) {
								//stop("Cooling is impossible with a NEGATIVE reduction factor!" );
								slaveExit( -1 );
						}
						(void) fflush(logFile);
						B_tempChange = ( RTFac != 1.0 );
						break;

						//______________________________________________________________________________

				case DPF_RUNS:
						/*
						 **  runs
						 **  Number of docking runs,
						 */
						(void) sscanf( line, "%*s %d", &nruns );
						if ( nruns > MAX_RUNS ) {
								prStr( error_message, "%s:  ERROR: %d runs were requested, but AutoDock is only dimensioned for %d.\nChange \"MAX_RUNS\" in \"constants.h\".", programname, nruns, MAX_RUNS);
								//stop( error_message );
								slaveExit( -1 );
						}
						pr( logFile, "Number of runs =\t\t\t\t%8d run%c\n", nruns, (nruns > 1)?'s':' ');
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_CYCLES:
						/*
						 **  cycles
						 **  Number of constant temperature SA cycles,
						 */
						(void) sscanf( line, "%*s %d", &ncycles );
						if (ncycles < 0) {
								pr( logFile, "WARNING!  Negative number of cycles found!  Using default value.\n");
								ncycles = 50;
						}
						pr( logFile, "Maximum number of cycles =\t\t\t%8d cycles\n\n", ncycles);
						if (B_linear_schedule) {
								RTreduc = RT0 / ncycles;
								if (outlev >= 0) {
										pr( logFile, "\nA linear temperature reduction schedule was requested...\n" );
										pr( logFile, "Annealing temperature will be reduced by %.3f cal mol per cycle.\n\n", RTreduc );
								}
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_ACCS:
						/*
						 **  accs
						 **  Maximum number of steps accepted,
						 */
						(void) sscanf( line, "%*s %d", &naccmax );
						if (naccmax < 0) {
								naccmax = 100;
								pr( logFile, "WARNING!  Negative number of accepted moves found!  Using default value.\n");
						}
						if (outlev >= 0) {
								pr( logFile, "Maximum number accepted per cycle =\t\t%8d steps\n", naccmax);
						}
						if (nrejmax != 0) {
								nstepmax = naccmax + nrejmax;
								if (outlev >= 0) {
										pr( logFile, "                                           \t_________\n" );
										pr( logFile, "Maximum possible number of steps per cycle =\t%8d\tsteps\n\n", nstepmax);
								}
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_REJS:
						/*
						 **  rejs
						 **  Maximum number of steps rejected,
						 */
						(void) sscanf( line, "%*s %d", &nrejmax );
						if (nrejmax < 0) {
								nrejmax = 100;
								pr( logFile, "WARNING!  Negative number of rejected moves found!  Using default value.\n");
						}
						if (outlev >= 0) {
								pr( logFile, "Maximum number rejected per cycle =\t\t%8d steps\n", nrejmax);
						}
						if (naccmax != 0) {
								nstepmax = naccmax + nrejmax;
								if (outlev >= 0) {
										pr( logFile, "                                           \t_________\n" );
										pr( logFile, "Maximum possible number of steps per cycle =\t%8d steps\n\n", nstepmax);
								}
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_SELECT:
						/*
						 **  select
						 **  Select either minimum or last state from previous cycle,
						 */
						(void) sscanf( line, "%*s %c", &selminpar );
						B_selectmin = (selminpar == 'm');
						if ( B_selectmin ) {
								if (outlev >= 0) {
										pr( logFile, "%s will begin each new cycle\nwith the state of minimum energy from the previous annealing cycle.\n", programname);
								}
						} else {
								if (outlev >= 0) {
										pr( logFile, "%s will begin each new cycle\nwith the last state from the previous annealing cycle.\n", programname);
								}
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_RMSTOL:
						/*
						 **  rmstol
						 **  Cluster tolerance,
						 */
						(void) sscanf( line, "%*s " FDFMT, &clus_rms_tol);
						//        if (outlev >= 0) {
						//            pr( logFile, "Maximum RMS tolerance for conformational cluster analysis = %.2f Angstroms\n", clus_rms_tol);
						//        }
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_RMSREF:
						/*
						 **  rmsref
						 **  RMS Reference Coordinates:
						 */
						(void) sscanf( line, "%*s %s", FN_rms_ref_crds);
						if (outlev >= 0) {
								pr( logFile, "RMS reference coordinates will taken from \"%s\"\n", FN_rms_ref_crds );
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_RMSATOMS:
						/*
						 **  rmsatoms ligand_only
						 **  rmsatoms all
						 **
						 **  Set the atoms to compute the RMSD values for cluster analysis
						 **  either "ligand_only" (the default) or "all" moving atoms (ligand + receptor)
						 */
						retval = sscanf( line, "%*s %s", rms_atoms_cmd);
						if (retval != 1) {
								pr( logFile, "%s:  ERROR: please specify an argument (either \"ligand_only\" or \"all\").  By default, only the ligand atoms will be used for the cluster analysis.\n", programname );
								B_rms_atoms_ligand_only = TRUE;  // cluster on the ligand atoms only
						} else {
								if ( strncmp( rms_atoms_cmd, "ligand_only", 11 ) == 0 ) {
										if (outlev >= 0) {
												pr( logFile, "RMS clustering will be performed on the ligand atoms only.\n" );
										}
										B_rms_atoms_ligand_only = TRUE;  // cluster on the ligand atoms only
								} else if ( strncmp( rms_atoms_cmd, "all", 3 ) == 0 ) {
										if (outlev >= 0) {
												pr( logFile, "RMS clustering will be performed on the moving atoms of the receptor plus all the ligand atoms.\n" );
										}
										B_rms_atoms_ligand_only = FALSE;  // cluster on the ligand atoms plus moving receptor atoms
								} else {
										if (outlev >= 0) {
												pr( logFile, "RMS clustering will be performed on the ligand atoms only.\n" );
										}
										B_rms_atoms_ligand_only = TRUE;  // cluster on the ligand atoms only
								}
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_TRJFRQ:
						/*
						 **  trjfrq
						 **  Trajectory frequency,
						 */
						(void) sscanf( line, "%*s %d", &trj_freq);
						B_write_trj = (trj_freq > 0);
						if (outlev >= 0) {
								pr( logFile, UnderLine );
								pr( logFile, "\t\tTRAJECTORY INFORMATION\n" );
								pr( logFile, "\t\t______________________\n\n\n" );
						}
						if (B_write_trj) {
								if (outlev >= 0) {
										pr( logFile, "Output frequency for trajectory frames =\tevery %d step%s\n", trj_freq, (trj_freq > 1)?"s.":"." );
								}
						} else {
								if (outlev >= 0) {
										pr( logFile, "No trajectory of states will be written.\n\n" );
										pr( logFile, "Subsequent \"trjbeg\", \"trjend\", \"trjout\" and \"trjsel\" parameters will be ignored.\n\n" );
								}
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_TRJBEG:
						/*
						 **  trjbeg
						 **  Trajectory begin cycle,
						 */
						(void) sscanf( line, "%*s %d", &trj_begin_cyc );
						if (outlev >= 0) {
								pr( logFile, "Begin outputting trajectory of states at cycle:\t%d\n", trj_begin_cyc );
						}
						if (trj_begin_cyc < 0) {
								trj_begin_cyc = 0;
						} else if (trj_begin_cyc > ncycles) {
								trj_begin_cyc = trj_end_cyc = ncycles;
						}
						--trj_begin_cyc;
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_TRJEND:
						/*
						 **  trjend
						 **  Trajectory end cycle,
						 */
						(void) sscanf( line, "%*s %d", &trj_end_cyc );
						if (outlev >= 0) {
								pr( logFile, "Cease outputting trajectory of states at cycle:\t%d\n", trj_end_cyc );
						}
						if (trj_end_cyc > ncycles) {
								trj_end_cyc = ncycles;
						} else if (trj_end_cyc < 0) {
								trj_end_cyc = 1;
						}
						--trj_end_cyc;
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_TRJOUT:
						/*
						 **  trjout
						 **  Trajectory file,
						 */
						(void) sscanf( line, "%*s %s", FN_trj );
						if (outlev >= 0) {
								pr( logFile, "\nWrite trajectory of state variables to file: \"%s\"\n", FN_trj);
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_TRJSEL:
						/*
						 **  trjsel
						 **  Trajectory select,
						 */
						(void) sscanf( line, "%*s %c", &out_acc_rej );
						B_acconly = (out_acc_rej == 'A');
						B_either  = (out_acc_rej == 'E');
						if (B_acconly) {
								if (outlev >= 0) {
										pr( logFile, "Output *accepted* states only.\n" );
								}
						} else if (B_either) {
								if (outlev >= 0) {
										pr( logFile, "Output *either* accepted or rejected states.\n" );
								}
						} else {
								pr( logFile, "WARNING: Missing or unknown accepted/rejected output flag.\n" );
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_EXTNRG:
						/*
						 **  extnrg
						 **  Wall Energy,
						 */
						(void) sscanf( line, "%*s " FDFMT, &WallEnergy );
						//        if (outlev >= 0) {
						//            pr( logFile, "External grid energy (beyond grid map walls) = %.2f\n\n", WallEnergy );
						//        }
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________
#ifdef USE_DPF_CLUSTER
				case DPF_CLUSTER:
						/*
						 **  cluster
						 **  Cluster mode,
						 */
						(void) sscanf( line, "%*s %s", FN_clus );
						B_cluster_mode = TRUE;
						if (!B_found_about_keyword){
								prStr(error_message, "%s:  ERROR:  no \"about\" command has been specified!\n", programname);
								//stop(error_message);
								slaveExit(-1);
						}
						if (outlev >= 0) {
								pr( logFile, "Cluster mode is now set.\n\n" );
						}
						clmode( num_atom_types, clus_rms_tol,
										hostnm, jobStart, tms_jobStart,
										B_write_all_clusmem, FN_clus, crdpdb, lig_center,
										B_symmetry_flag, FN_rms_ref_crds );
						(void) fflush(logFile);
						break;
#endif
						//______________________________________________________________________________

				case DPF_CLUSALL:
						/*
						 ** write_all_clusmem
						 ** Write all cluster members...
						 */
						B_write_all_clusmem = TRUE;
						if (outlev >= 0) {
								pr( logFile, "All members of each cluster will be written out after the clustering histogram.\n(This is instead of outputting just the lowest energy member in each.)\n\n" );
						}
						break;

						//______________________________________________________________________________

				case DPF_RMSNOSYM:
						/*
						 **  rmsnosym
						 **  Calculate RMS values in the normal way,
						 **  ignoring any atom-type equivalences...
						 */
						B_symmetry_flag = FALSE;
						if (outlev >= 0) {
								pr( logFile, "Symmetry will be ignored in RMS calculations.\n\n" );
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_SCHEDLIN:
						/*
						 **  linear_schedule
						 **  Use a linear (arithmetic) temperature
						 **  reduction schedule.  This is necessary for
						 **  more accurate entropy estimations...
						 */
						B_linear_schedule = TRUE;
						if (outlev >= 0) {
								pr( logFile, "A linear temperature reduction schedule will be used...\n\n" );
						}
						if (ncycles == -1) {
								pr( logFile, "\nWARNING!  Please specify the number of cycles first!\n\n" );
						} else {
								RTreduc = RT0 / ncycles;
								if (outlev >= 0) {
										pr( logFile, "Annealing temperature will be reduced by %.3f cal mol per cycle.\n\n", RTreduc );
								}
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_WATCH:
						/*
						 **  watch
						 **  for watching a job's progress PDBQT file in AVS,
						 */
						(void) sscanf( line, "%*s %s", FN_watch);
						if (B_write_trj) {
								pr(logFile,"\nAutoDock will create the watch-file \"%s\", for real-time monitoring of runs.\n\n", FN_watch);
								pr(logFile,"\nThe watch-file will be updated every %d moves, in accordance with the trajectory parameters..\n\n", trj_freq);
								B_watch = TRUE;
						} else {
								pr(logFile,"\nYou must set \"trjfrq\" to be greater than zero. No watch-file will be created.\n\n");
								B_watch = FALSE;
						}
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_GAUSSTORCON:
				case DPF_HARDTORCON:
						/*
						 ** "gausstorcon" Add Gaussian torsion contraints,
						 ** "hardtorcon"  Add Hard torsion contraints,
						 */
						(void) sscanf( line, "%*s %d " FDFMT2, &I_tor, &F_torPref, &F_torHWdth);
						if (I_tor <= 0) {
								pr( logFile, "\nTorsion IDs less than 1 (%d) are not allowed!\n\n", I_tor);
						} else if (I_tor > ntor) {
								pr( logFile, "\nRequested torsion ID (%d) is larger than the number of torsions found (%d)!\n\n", I_tor, ntor);
						} else { /* torsion-ID accepted */
								--I_tor;    /* Because humans start at 1, and C at 0... */
								if ( B_isTorConstrained[I_tor] == 0 ) {

										if (dpf_keyword ==  DPF_GAUSSTORCON) {
												B_isGaussTorCon = TRUE;
												B_isTorConstrained[I_tor] = 1;
												/*
												 ** Initialize... Torsion Energy Profile...
												 ** Set energies at every torsion division
												 ** to the user-defined (maximum) barrier energy,
												 */
												for (US_tD = 0;  US_tD < NTORDIVS;  US_tD++) {
														US_torProfile[I_tor][US_tD] = US_torBarrier;
												}
										} else {
												/*
												 ** DPF_HARDTORCON
												 */
												B_isTorConstrained[I_tor] = 2;
										}
								}
								if (dpf_keyword ==  DPF_GAUSSTORCON) {
										(void) strcpy( S_contype, " half-" );
								} else {
										(void) strcpy( S_contype, " " );
								}
								/*
								 ** F_torPref ranges from -180.0 to +180.0 degrees...
								 */
								F_torPref = WrpDeg(ModDeg(F_torPref));
								if (F_torHWdth < 0.) {
										pr(logFile,"\nI'm sorry, negative%swidths (%.1f) are not allowed. I will use the default (%.1f) instead.\n\n", S_contype, F_torHWdth, DEFHWDTH);
										F_torHWdth = DEFHWDTH;
								} else if (F_torHWdth > 90.) {
										pr(logFile,"\nI'm sorry, your requested%swidth (%.1f) is too large. I will use the default (%.1f) instead.\n\n", S_contype, F_torHWdth, DEFHWDTH);
										F_torHWdth = DEFHWDTH;
								}
								pr( logFile, "For torsion %d, Adding a constrained-torsion zone centered on %.1f degrees;\n%swidth = %.1f degrees.\n\n", 1+I_tor, F_torPref, S_contype, F_torHWdth);

								if (dpf_keyword == DPF_GAUSSTORCON) {
										/*
										 ** Calculate the torsion energy profile;
										 ** combine this with previous profile without
										 ** losing any information.
										 */
										for (F_A = F_A_from;  F_A <= F_A_to;  F_A += F_W) {
												F_Aova = (F_A - F_torPref) / F_torHWdth;
												US_energy = (unsigned short) (((Real)US_torBarrier) * (1.0 - exp(F_lnH * F_Aova*F_Aova)));
												/*
												 ** if F_A(<-180.or>180), wrap to -180to180,
												 */
												F_tor = WrpDeg(ModDeg(F_A));
												/*
												 ** Convert from F_tor to US_tD
												 */
												US_tD = (unsigned short) ((F_tor - F_hW + 180.)/F_W);
												US_torProfile[I_tor][US_tD] =US_energy<US_torProfile[I_tor][US_tD]?US_energy:US_torProfile[I_tor][US_tD]; 
										}/* for F_A */
										/*
										 ** Ensure that the lowest point(s) in the profile are
										 ** zero...
										 */
										US_min = TORBARMAX;
										for (US_tD = 0;  US_tD < NTORDIVS;  US_tD++) {
												US_min = US_min<US_torProfile[I_tor][US_tD]?US_min:US_torProfile[I_tor][US_tD];
										}
										for (US_tD = 0;  US_tD < NTORDIVS;  US_tD++) {
												US_torProfile[I_tor][US_tD] -= US_min;
										}
								} else { /*DPF_HARDTORCON*/

										iCon = N_con[I_tor] + 1;
										if (iCon < MAX_TOR_CON) {
												F_TorConRange[I_tor][N_con[I_tor]][LOWER] = F_torPref - 0.5* F_torHWdth;
												F_TorConRange[I_tor][N_con[I_tor]][UPPER] = F_torPref + 0.5* F_torHWdth;
												N_con[I_tor] = iCon;
										} else {
												pr(logFile,"\n\n I'm sorry, you can only have %d (=MAX_TOR_CON) torsion constraints.\nIf you need more, change the \"#define MAX_TOR_CON\" line in \"constants.h\".\n\n",MAX_TOR_CON);
										}/* Still room to add another constraint. */
								} /*DPF_HARDTORCON*/
						}/* torsion-ID accepted */
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_BARRIER:
						/*
						 **  barrier
						 **  Define torsion-barrier energy...
						 */
						(void) sscanf( line, "%*s %d", &I_torBarrier);
						US_torBarrier = (unsigned short)I_torBarrier;
						US_torBarrier = US_torBarrier<TORBARMAX?US_torBarrier:TORBARMAX;
						pr(logFile,"\nTorsion barrier energy is set to %uhd\n\n", US_torBarrier);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_SHOWTORPEN:
						/*
						 **  showtorpen
						 **  Show torsion's penalty energy.
						 */
						B_ShowTorE = TRUE;
						pr(logFile,"\nConstrained torsion penalty energies will be stored during docking, and output after each run\n\n");
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_E0MAX:
						/*
						 **  e0max
						 **  Set maximum initial energy,
						 */
						retval = sscanf( line, "%*s " FDFMT " %d", &e0max, &MaxRetries );
						//        if (retval == 0) {
						//            pr( logFile, "Could not read any arguments!\n" );
						//        } else if (retval == EOF) {
						//            pr( logFile, "End of file encountered!\n");
						//        } else if (retval == 1) {
						//            pr(logFile,"Using the default maximum number of retries for initialization, %d retries.\n\n", MaxRetries);
						//        } else if (retval == 2) {
						//            pr(logFile,"Using user-specified maximum number of retries for initialization, %d retries.\n\n", MaxRetries);
						//        }
						if (e0max < 0.) {
								e0max = 1000.0;
						}
						//        pr(logFile,"\nIf the initial energy is greater than e0max, %.3f,\nthen a new, random initial state will be created.\n\n",e0max);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

						/*****************************
						//YTLIU_NOTE
						 *****************************/
#ifdef USE_SIMANNEAL		
				case DPF_SIMANNEAL:
						/*
						 ** simanneal
						 */
						/*
						 ** Calculate reduction factor based on initial and final step values,
						 ** and number of cycles...
						 */
						ncycm1 = ncycles - 1;
						if (ncycm1 < 0) {
								ncycm1 = 1;
						}
						if (B_CalcTrnRF) {
								trnFac = RedFac(trnStep0, trnStepFinal, ncycm1);
								pr( logFile, "Calculated reduction factor for translations     = %-.3f /cycle\n", trnFac);
								B_trnReduc = (trnFac != 1.);
						}
						if (B_CalcQtwRF) {
								qtwFac = RedFac(qtwStep0, qtwStepFinal, ncycm1);
								pr( logFile, "Calculated reduction factor for quaternion angle = %-.3f /cycle\n", qtwFac );
								B_qtwReduc = (qtwFac != 1.);
						}
						if (B_CalcTorRF) {
								torFac    = RedFac(torStep0, torStepFinal, ncycm1);
								pr( logFile, "Calculated reduction factor for torsion angles   = %-.3f /cycle\n", torFac );
								B_torReduc = (torFac != 1.);
						}
						pr(logFile, "\n");
						/*
						 ** Number of ligands read in...
						 */
						if (nlig > 0) {
								pr( logFile, "\nTotal number of ligands read in by the DPF \"move\" command = %d\n\n", nlig );
						}
						if (nres > 0) {
								pr( logFile, "\nTotal number of residues read in by the DPF \"flex\" command = %d\n\n", nres );
						}
						pr(logFile, "\n");

						if (!B_found_about_keyword){
								prStr(error_message, "%s:  ERROR:  no \"about\" command has been specified!\n", programname);
								//stop(error_message);
								slaveExit(-1);
						}

						if (B_havenbp) {
								nbe( info, ad_energy_tables, num_atom_types );
						}
						if (B_cluster_mode) {
								clmode( num_atom_types, clus_rms_tol,
												hostnm, jobStart, tms_jobStart,
												B_write_all_clusmem, FN_clus, crdpdb, lig_center,
												B_symmetry_flag, FN_rms_ref_crds );
						}
						for (j = 0; j < MAX_RUNS; j++) {
								econf[j] = torsFreeEnergy;
						}
						if (ad4_unbound_model==Unbound_Default) ad4_unbound_model = Unbound_Same_As_Bound;
						pr(logFile, "Unbound model to be used is %s.\n", report_parameter_library());
						/* ___________________________________________________________________
						 **
						 ** Begin the automated docking simulation,
						 ** ___________________________________________________________________
						 */
						/****************************
						// YTLIU_EDIT 2013.01.04
						 ****************************/
						if(xbpmf_scoring)
								simanneal( &nconf, Nnb, WallEnergy, atomstuff, charge, abs_charge, qsp_abs_charge, B_calcIntElec,
												crd, crdpdb, dock_param_fn,
												ad_energy_tables,
												econf, B_either,
												elec, emap,
												ncycles, nruns, jobStart,
												map,
												naccmax, natom, nonbondlist, nrejmax, ntor1, ntor, outlev,
												sInit, sHist,   qtwFac, B_qtwReduc, qtwStep0,
												B_selectmin, FN_ligand, lig_center, RT0, B_tempChange, RTFac,
												tms_jobStart, tlist, torFac, B_torReduc, torStep0,
												FN_trj, trj_end_cyc, trj_begin_cyc, trj_freq, trnFac,
												B_trnReduc, trnStep0, type, vt, B_write_trj,
												B_constrain_dist, atomC1, atomC2, sqlower, squpper,
												B_linear_schedule, RTreduc,
												/*maxrad,*/
												B_watch, FN_watch,
												B_isGaussTorCon, US_torProfile, B_isTorConstrained,
												B_ShowTorE, US_TorE, F_TorConRange, N_con,
												B_RandomTran0, B_RandomQuat0, B_RandomDihe0,
												e0max, torsFreeEnergy, MaxRetries, ligand_is_inhibitor,
												ignore_inter,
												B_include_1_4_interactions, scale_1_4,
												parameterArray, unbound_internal_FE,
												info, B_use_non_bond_cutoff,
												B_have_flexible_residues,
												PDBQT_record,
												ad4_unbound_model,
												xbPmfMapInfo->xbpmf_1d_pw_parms,
												xbPmfMapInfo->xbpmf_2d_hb_pw_parms,
												xbPmfMapInfo->xbpmf_2d_xb_pw_parms,
												xbPmfMapInfo->recep_natom,
												xbPmfMapInfo->recep_crdpdb,
												xbPmfMapInfo->recep.atomtype,
												xbligand.atomtype,
												xbPmfMapInfo->xbpmf_1d_map,
												xbPmfMapInfo->xbpmf_hb_map,
												xbPmfMapInfo->recep_acceptor_natom,
												xbPmfMapInfo->recep_acceptor_crdpdb,
												xbPmfMapInfo->recep_acceptor_atomtype,xbPmfMapInfo->xbpmf_hb_label,xbPmfMapInfo->xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbPmfMapInfo->xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor
														);
						//                ;  //error xbzhang
						else
								simanneal( &nconf, Nnb, WallEnergy, atomstuff, charge, abs_charge, qsp_abs_charge, B_calcIntElec,
												crd, crdpdb, dock_param_fn,
												ad_energy_tables,
												econf, B_either,
												elec, emap,
												ncycles, nruns, jobStart,
												map,
												naccmax, natom, nonbondlist, nrejmax, ntor1, ntor, outlev,
												sInit, sHist,   qtwFac, B_qtwReduc, qtwStep0,
												B_selectmin, FN_ligand, lig_center, RT0, B_tempChange, RTFac,
												tms_jobStart, tlist, torFac, B_torReduc, torStep0,
												FN_trj, trj_end_cyc, trj_begin_cyc, trj_freq, trnFac,
												B_trnReduc, trnStep0, type, vt, B_write_trj,
												B_constrain_dist, atomC1, atomC2, sqlower, squpper,
												B_linear_schedule, RTreduc,
												/*maxrad,*/
												B_watch, FN_watch,
												B_isGaussTorCon, US_torProfile, B_isTorConstrained,
												B_ShowTorE, US_TorE, F_TorConRange, N_con,
												B_RandomTran0, B_RandomQuat0, B_RandomDihe0,
												e0max, torsFreeEnergy, MaxRetries, ligand_is_inhibitor,
												ignore_inter,
												B_include_1_4_interactions, scale_1_4,
												parameterArray, unbound_internal_FE,
												info, B_use_non_bond_cutoff,
												B_have_flexible_residues,
												PDBQT_record,
												ad4_unbound_model,
												xb_empirical_vdw, xb_empirical_es,
												ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
												xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
												xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
												xbempirical_ligand_xbdonor,
												xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index
														);

						(void) fflush(logFile);
						break;
#endif
						//______________________________________________________________________________

						/*****************************
						//YTLIU_NOTE
						 *****************************/
				case DPF_SET_GA:


						//(void) fflush(logFile);
						break;
						//______________________________________________________________________________

				case DPF_SET_SW1:
						LS_Type=0;
						break;
						//______________________________________________________________________________

				case DPF_SET_PSW1:
						LS_Type=1;
						//(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case DPF_SET_PATTERN:
						LS_Type=2;
						break;

						//______________________________________________________________________________

				case DPF_GALS:
						(void) fflush( logFile );
						//printf("begin dpf_gals\n");

#ifdef PERF_PROFILING
						return_current_time(slaveDockInfo.LGASetupStartTime);

#endif
						/*
						 ** Genetic Algorithm-Local search,  a.k.a. Lamarckian Genetic Algorithm
						 */
						(void) sscanf( line, "%*s %d",&nruns );
						//printf("B_found_elecmap=%d,B_found_desolvmap=%d,B_found_about_keyword=%d\n",\
						B_found_elecmap,B_found_desolvmap,B_found_about_keyword);
						nruns=10;
						MICStart=time(NULL);

						if(MIC_or_CPU==RUN_ON_CPU)//then for statement will run on cpu.16 cores or 24 cores
						{
								printf("Now we compute on CPU ...\n");
#pragma omp parallel private(j) num_threads(MaxNumThreads)
								{
										if (L_GlobalSearchMethod != NULL) 
										{
												//printf("Deleting the previous settings for the Genetic Algorithm.\n");
												delete L_GlobalSearchMethod;
												L_GlobalSearchMethod = NULL;
										}
										L_GlobalSearchMethod = new L_Genetic_Algorithm(e_mode, s_mode, c_mode, w_mode, elitism, c_rate, m_rate,
														window_size, num_generations, outputEveryNgens );
										((L_Genetic_Algorithm *)L_GlobalSearchMethod)->mutation_values( low, high, alpha, beta, trnStep0, qtwStep0, torStep0  );
										((L_Genetic_Algorithm *)L_GlobalSearchMethod)->initialize(pop_size, 7+sInit.ntor);
										if (s_mode==LinearRanking)
										{
												(void)((L_Genetic_Algorithm *)L_GlobalSearchMethod)->set_linear_ranking_selection_probability_ratio(linear_ranking_selection_probability_ratio);
										}
										if (L_LocalSearchMethod != NULL) 
										{			
												//pr("Deleting the previous settings for the local search Solis-Wets algorithm (SW1 object).\n");
												delete L_LocalSearchMethod;
												L_LocalSearchMethod = NULL;
										}
										if(LS_Type==0)
										{
												L_LocalSearchMethod = new L_Solis_Wets1(7+sInit.ntor, max_its, max_succ, max_fail, rho, lb_rho, 2.0, 0.5, search_freq);
												




L_LocalSearchMethod->SearchType=1;
										}
										else if(LS_Type==1)
										{
												//  Allocate space for the variable rho's
												rho_ptr = new Real[7+sInit.ntor];
												lb_rho_ptr = new Real[7+sInit.ntor];
												for (j=0; j<3; j++) 
												{
														// j=0,1,2
														rho_ptr[j] = rho * psw_trans_scale;// formerly trnStep0;
														lb_rho_ptr[j] = lb_rho * psw_trans_scale; //once trnStepFinal;
												}

												//  Initialize the rho's corresponding to the quaterion
												for (; j<7; j++) 
												{
														// j=3,4,5,6
														rho_ptr[j] = rho * psw_rot_scale;// formerly qtwStep0;
														lb_rho_ptr[j] = lb_rho * psw_rot_scale; //once qtwStepFinal;
												}

												//  Initialize the rho's corresponding to the torsions
												for (; j<7+sInit.ntor; j++) 
												{
														// j=7,...
														rho_ptr[j] = rho * psw_tors_scale;// formerly torStep0;
														lb_rho_ptr[j] = lb_rho * psw_tors_scale;//formerly torStepFinal;
												}

												L_LocalSearchMethod = new L_Pseudo_Solis_Wets1(7+sInit.ntor, max_its, max_succ, max_fail, 2.0, 0.5, search_freq, rho_ptr, lb_rho_ptr);
												L_LocalSearchMethod->SearchType=2;
										}
										else if(LS_Type==2)
										{
												L_LocalSearchMethod = new L_Pattern_Search(7+sInit.ntor, max_succ, rho, lb_rho, 2.0, 0.5, search_freq);
												L_LocalSearchMethod->SearchType=3;
										}
										else
										{
												printf("Error:local search method is invalid...\n");
												slaveExit(-1);
										}

								}
#pragma omp parallel copyin(crd, crdreo, vt, crdpdb, q_reorient,\
				ligand,xb_empirical_vdw, xb_empirical_es, ad_vdw, ad_es, ad_desolv) num_threads(MaxNumThreads)
								{
										if ( nruns > MAX_RUNS ) 
										{
												prStr( error_message, "%s:  ERROR: %d runs requested, but only dimensioned for %d.\nChange \"MAX_RUNS\" in \"constants.h\".", programname, nruns, MAX_RUNS);
												printf("%s\n", error_message );
												slaveExit( -1 );
										} 
										else if ((L_GlobalSearchMethod==NULL)||(L_LocalSearchMethod==NULL)) 
										{
												prStr(error_message, "%s:  ERROR:  You must use \"set_ga\" to allocate both Global Optimization object AND Local Optimization object.\n", programname);
												printf("%s\n", error_message );
												slaveExit(-1);
										}
										exit_if_missing_elecmap_desolvmap_about("gals");
										if (ad4_unbound_model==Unbound_Default) ad4_unbound_model = Unbound_Same_As_Bound;
										if(xbpmf_scoring)
										{
												L_evaluate[threadID].setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
																elec, emap, nonbondlist, ad_energy_tables, Nnb,
																B_calcIntElec, B_isGaussTorCon, B_isTorConstrained,
																B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
																ignore_inter,
																B_include_1_4_interactions, scale_1_4,
																unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues,
																xbPmfMapInfo->xbpmf_1d_pw_parms,
																xbPmfMapInfo->xbpmf_2d_hb_pw_parms,
																xbPmfMapInfo->xbpmf_2d_xb_pw_parms,
																xbPmfMapInfo->recep_natom,
																xbPmfMapInfo->recep_crdpdb,
																xbPmfMapInfo->recep.atomtype,
																xbligand.atomtype,
																xbPmfMapInfo->xbpmf_1d_map,
																xbPmfMapInfo->xbpmf_hb_map,
																xbPmfMapInfo->recep_acceptor_natom,
																xbPmfMapInfo->recep_acceptor_crdpdb,
																xbPmfMapInfo->recep_acceptor_atomtype,xbPmfMapInfo->xbpmf_hb_label,xbPmfMapInfo->xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbPmfMapInfo->xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
										}
										else
										{
												L_evaluate[threadID].setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
																elec, emap, nonbondlist, ad_energy_tables, Nnb,
																B_calcIntElec, B_isGaussTorCon, B_isTorConstrained,
																B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
																ignore_inter,
																B_include_1_4_interactions, scale_1_4,
																unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues,
																xb_empirical_vdw, xb_empirical_es,
																ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
																xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
																xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
																xbempirical_ligand_xbdonor,
																xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);
										}
										//parameterArray, unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues);

										L_evaluate[threadID].compute_intermol_energy(TRUE);
								}

								int nconf_bb=nconf;
#pragma omp parallel for copyin(crd, crdreo, vt, crdpdb, q_reorient,\
				ligand, eintra, einter,unbound_internal_FE) num_threads(MaxNumThreads) schedule(dynamic)
								for (j=0; j<nruns; j++) 
								{
										if (B_reorient_random == TRUE) 
										{
												// create a new random orientation before docking
												L_create_random_orientation( &q_reorient );
												// reorient the ligand
												L_reorient(true_ligand_atoms, atomstuff, crdpdb, charge, type,
																parameterArray, q_reorient, origin, ntor, tlist, vt, &ligand, debug );
												// update the evaluate object
												L_evaluate[threadID].update_crds( crdpdb, vt );
										}

										//  Can get rid of the following line
										((L_Genetic_Algorithm *)L_GlobalSearchMethod)->initialize(pop_size, 7+sInit.ntor);
										State stmp;
										stmp= L_call_glss( L_GlobalSearchMethod, L_LocalSearchMethod,
														sInit,
														num_evals, pop_size,
														outlev,
														outputEveryNgens, &ligand,
														B_RandomTran0, B_RandomQuat0, B_RandomDihe0,
														info, FN_pop_file, end_of_branch );
										sHist[nconf_bb+j]=stmp;
										// See also "calculateEnergies.cc", switch(ad4_unbound_model)
										if (ad4_unbound_model == Unbound_Same_As_Bound) 
										{
												// Update the unbound internal energy, setting it to the current internal energy
												unbound_internal_FE = eintra;
										}
										econf[nconf_bb+j] = eintra + einter + torsFreeEnergy - unbound_internal_FE;	
								} // Next LGA run

								nconf=nconf_bb+nruns;
								printf("Compute End...\n");	  
						}
						else//then for statement will run on MIC ,nruns threads
						{
								printf("Now we compute on MIC ...\n");
								//eintra, einter,unbound_internal_FE
								T_xb1=xb_empirical_vdw;
								T_xb2=xb_empirical_es;
								T_ad1=ad_vdw;
								T_ad2=ad_es;
								T_ad3=ad_desolv;
								T_eintra=eintra;
								T_einter=einter;
								T_FE=unbound_internal_FE;
								memcpy(T_crdpdb,crdpdb,sizeof(Real)*MAX_ATOMS*SPACE);
								memcpy(T_crdreo,crdreo,sizeof(Real)*MAX_ATOMS*SPACE);
								memcpy(T_crd,crd,sizeof(Real)*MAX_ATOMS*SPACE);
								memcpy(T_vt,vt,sizeof(Real)*MAX_TORS*SPACE);
								memcpy(&T_q_reorient,&q_reorient,sizeof(Quat));
								memcpy(&T_ligand,&ligand,sizeof(Molecule));
								//printf("param[0]=%s\tparam[1]=%s\n",param[0],param[1]);
								//printf("retval=%d\n",retval);
								strcpy(param[0],"pid");
								//int nconf_before=nconf;
								if(M_MIC_STATUS==M_MIC_BEGIN)
								{
										#pragma offload target(mic:mic_no)\
										in(T_xb1,T_xb2,T_ad1,T_ad2,T_ad3,T_ligand,T_q_reorient,T_eintra,T_einter,T_FE)\
												in(T_crd:length(MAX_ATOMS*SPACE)	M_ALLOC)\
												in(T_crdreo:length(MAX_ATOMS*SPACE)	M_ALLOC)\
												in(T_crdpdb:length(MAX_ATOMS*SPACE)	M_ALLOC)\
												in(T_vt:length(MAX_TORS*SPACE)		M_ALLOC)\
												nocopy(threadID							   )\
												in(LS_Type,B_found_elecmap,B_found_desolvmap,B_found_about_keyword)\
												in(nruns,ad4_unbound_model					)\
												in(retval,mpirank,seedtype					)\
												nocopy(time_seed							)\
												in(param:length(2*LINE_LEN)			M_ALLOC)\
												nocopy(seed:length(2)				M_ALLOC)\
												nocopy(timeSeedIsSet:length(2)		M_ALLOC)\
												nocopy(Nnb_array:length(3) 			M_ALLOC)\
												nocopy(nb_group_energy:length(3) 	M_ALLOC)\
												nocopy(L_GlobalSearchMethod,L_GA		   )\
												nocopy(L_LocalSearchMethod,L_SW,rho_ptr,lb_rho_ptr,L_PSW,L_PS)\
												in(B_isGaussTorCon,B_ShowTorE			   )\
												in(B_include_1_4_interactions, scale_1_4   )\
												in(B_use_non_bond_cutoff, B_have_flexible_residues)\
												in(unbound_internal_FE						)\
												in(xb_empirical_es,ad_vdw,ad_es,ad_desolv,natom,B_calcIntElec,xb_empirical_vdw)\
												in(q_reorient,ligand,sInit					)\
												in(crd:length(MAX_ATOMS*SPACE)		M_ALLOC)\
												in(crdreo:length(MAX_ATOMS*SPACE)	M_ALLOC)\
												in(crdpdb:length(MAX_ATOMS*SPACE)	M_ALLOC)\
												in(vt:length(MAX_TORS*SPACE)		M_ALLOC)\
												in(map:length(MAX_GRID_PTS*MAX_GRID_PTS*MAX_GRID_PTS*MAX_MAPS)		M_ALLOC)\
												in(US_torProfile:length(MAX_TORS*NTORDIVS)			M_ALLOC)\
												in(tlist:length(MAX_TORS*MAX_ATOMS)					M_ALLOC)\
												in(xbpmf_ligand_hb_donorH_ids:length(MAX_ATOMS*5)	M_ALLOC)\
												in(xbempirical_ligand_xbdonor:length(MAX_ATOMS*2)	M_ALLOC)\
												nocopy(line:length(LINE_LEN) 					M_ALLOC)\
												in(charge,abs_charge:length(MAX_ATOMS)			M_ALLOC)\
												in(qsp_abs_charge:length(MAX_ATOMS) 			M_ALLOC)\
												in(emap:length(MAX_ATOMS)						M_ALLOC)\
												in(type:length(MAX_ATOMS)						M_ALLOC)\
												in(elec:length(MAX_ATOMS) 						M_ALLOC)\
												in(ignore_inter:length(MAX_ATOMS) 				M_ALLOC)\
												in(nonbondlist:length(MAX_NONBONDS) 			M_FREE)\
												in(ad_energy_tables:length(1) 				M_FREE)\
												in(B_isTorConstrained:length(MAX_TORS)			M_ALLOC)\
												in(US_TorE:length(MAX_TORS) 					M_ALLOC)\
												in(info:length(1) 					M_FREE)\
												in(L_evaluate:length(MIC_MAX_NUM_THREADS) 		M_ALLOC)\
												in(xbEmpiricalMapInfo:length(1) 			M_FREE)\
												in(xbpmf_ligand_xb_donorX_id:length(MAX_ATOMS)	M_ALLOC)\
												in(xbpmf_ligand_at_index:length(MAX_ATOMS)		M_ALLOC)\
												in(xbpmf_ligand_hb_acceptor:length(MAX_ATOMS)	M_ALLOC)\
												in(xbpmf_ligand_hb_donor:length(MAX_ATOMS)		M_ALLOC)\
												in(xbpmf_ligand_xb_donor:length(MAX_ATOMS) 		M_ALLOC)\
												in(xbpmf_receptor_hb_acceptor:length(MAX_RECEPTOR_ATOMS)   M_ALLOC)\
												in(origin,B_reorient_random,debug								  )\
												in(ntor															  )\
												in(num_evals, pop_size,outputEveryNgens							  )\
												in(outlev														  )\
												in(B_RandomTran0, B_RandomQuat0, B_RandomDihe0					  )\
												in(eintra,einter												  )\
												in(torsFreeEnergy												  )\
												inout(nconf														  )\
												in(atomstuff:length(MAX_ATOMS*MAX_CHARS)					M_ALLOC)\
												in(parameterArray:length(MAX_ATOM_TYPES)					M_ALLOC)\
												in(FN_pop_file:length(FILENAME_MAX)							M_ALLOC)\
												in(end_of_branch:length(MAX_TORS)							M_ALLOC)\
												out(econf:length(MAX_RUNS) 									M_ALLOC)\
												out(sHist:length(MAX_RUNS)									M_ALLOC)\
												in(xbpmf_scoring,true_ligand_atoms,AD4,sel_prop_count,global_ntor	  )\
												in(ElecMap,DesolvMap,halogen_found									  )\
												in(Nnb)
												{
														//						printf("Hello, I am on mic%d\n",_Offload_get_device_number());

#pragma omp parallel num_threads(nruns)
														{
																threadID=omp_get_thread_num();
																if ((retval==2) || (retval==1)) 
																{
																		for (int i=0; i<retval ; i++ ) 
																		{
																				if (equal(param[i], "tim", 3)) 
																				{
																						timeSeedIsSet[i] = 'T';
																						// set the seed based on the seed type
																						if (seedtype == SAME_SEED) 
																						{
																								seed[i] = SAME_SEED_CONSTANT;
																						}
																						else if (seedtype == DEFAULT_SEED) 
																						{ // the time seed needs to have the threadID added to it so that different threads get a different seed
																								seed[i] = (FourByteLong)(time( &time_seed ) + threadID);
																						}
																						else if (seedtype == UNIQUE_NODE_SEED) 
																						{ // the time seed needs to have the threadID added to it so that different threads get a different seed plus the mpirank times the most threads possible on BQG (320) to make sure the seed is unique across the nodes
																								seed[i] = (FourByteLong)(time( &time_seed ) + threadID + (mpirank*320));
																						}
																						else 
																						{
																								//fprintf(stderr,"seed type not set properly, exitting\n");
																								slaveExit(-1);
																						}
																						L_setall( seed[i], seed[i] ); 
																						L_initgn(-1);
																				} 
																				else if (equal(param[i], "pid", 3)) 
																				{
																						timeSeedIsSet[i] = 'F';
																						if (seedtype == SAME_SEED) 
																						{
																								seed[i] = SAME_SEED_CONSTANT;
																						}
																						else 
																						{
																								seed[i] = getpid();
																						}
																						L_setall( seed[i], seed[i] ); 
																						L_initgn(-1);
																				} 
																				else 
																				{
																						timeSeedIsSet[i] = 'F';
																						seed[i] = atol(param[i]);
																						L_setall( seed[i], seed[i] ); 
																						L_initgn(-1);
																				}
																		}
																		if (retval==2) 
																		{
																				L_setall(seed[0], seed[1]);
																				L_initgn(-1);  // Reinitializes the state of the current random number generator
																		}
																} 
																else 
																{
																		//pr(logFile, "Error encountered reading seeds!\n");
																}
																//if(threadID==1)
																//{
																//	printf("parallel 1...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
																for (int j=0; j<3; j++) {          
																		Nnb_array[j] = 0;
																		nb_group_energy[0] = 0.0;
																}
																//if(threadID==2)
																//{
																//	printf("parallel 2...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
																if(L_GlobalSearchMethod != NULL) 
																{
																		delete L_GlobalSearchMethod;
																		L_GlobalSearchMethod = NULL;
																}
																L_GA = new L_Genetic_Algorithm(e_mode, s_mode, c_mode, w_mode, elitism, c_rate, m_rate,
																				window_size, num_generations, outputEveryNgens );
																L_GlobalSearchMethod=L_GA;
																(dynamic_cast<L_Genetic_Algorithm*>(L_GlobalSearchMethod))->mutation_values( low, high, alpha, beta,\
																				trnStep0, qtwStep0, torStep0  );
																(dynamic_cast<L_Genetic_Algorithm*>(L_GlobalSearchMethod))->initialize(pop_size, 7+sInit.ntor);

																if (s_mode==LinearRanking){
																		(dynamic_cast<L_Genetic_Algorithm*>(L_GlobalSearchMethod))->set_linear_ranking_selection_probability_ratio(linear_ranking_selection_probability_ratio);
																}
																//if(threadID==3)
																//{
																//	printf("parallel 3...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
																if(L_LocalSearchMethod != NULL) 
																{
																		delete L_LocalSearchMethod;
																		L_LocalSearchMethod = NULL;
																}
																if(LS_Type==0)
																{
																		L_SW = new L_Solis_Wets1(7+sInit.ntor, max_its, max_succ, max_fail, rho, lb_rho, 2.0, 0.5, search_freq);
																		L_LocalSearchMethod = L_SW;
																		L_LocalSearchMethod->SearchType=1;
																}
																else if(LS_Type==1)
																{
																		rho_ptr = new Real[7+sInit.ntor];
																		lb_rho_ptr = new Real[7+sInit.ntor];
																		int j;
																		for (j=0; j<3; j++) {
																				// j=0,1,2
																				rho_ptr[j] = rho * psw_trans_scale;// formerly trnStep0;
																				lb_rho_ptr[j] = lb_rho * psw_trans_scale; //once trnStepFinal;
																		}

																		//  Initialize the rho's corresponding to the quaterion
																		for (; j<7; j++) {
																				// j=3,4,5,6
																				rho_ptr[j] = rho * psw_rot_scale;// formerly qtwStep0;
																				lb_rho_ptr[j] = lb_rho * psw_rot_scale; //once qtwStepFinal;
																		}

																		//  Initialize the rho's corresponding to the torsions
																		for (; j<7+sInit.ntor; j++) {
																				// j=7,...
																				rho_ptr[j] = rho * psw_tors_scale;// formerly torStep0;
																				lb_rho_ptr[j] = lb_rho * psw_tors_scale;//formerly torStepFinal;
																		}

																		L_PSW = new L_Pseudo_Solis_Wets1(7+sInit.ntor, max_its, max_succ, max_fail, 2.0, 0.5, search_freq, rho_ptr, lb_rho_ptr);
																		L_LocalSearchMethod=L_PSW;
																		L_LocalSearchMethod->SearchType=2;
																}
																else if(LS_Type==2)
																{
																		L_PS = new L_Pattern_Search(7+sInit.ntor, max_succ, rho, lb_rho, 2.0, 0.5, search_freq);
																		L_LocalSearchMethod=L_PS;
																		dynamic_cast<L_Local_Search*>(L_LocalSearchMethod)->SearchType=3;
																}
																else
																{
																		printf("Sorry!LocalSearchMethod is unavailible...\n");
																		fflush(0);
																		slaveExit(-1);
																}
																//if(threadID==4)
																//{
																//	printf("Parallel 4...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
																xb_empirical_vdw=T_xb1;
																xb_empirical_es=T_xb2;
																ad_vdw=T_ad1;
																ad_es=T_ad2;
																ad_desolv=T_ad3;
																memcpy(crdpdb,T_crdpdb,sizeof(Real)*MAX_ATOMS*SPACE);
																memcpy(crdreo,T_crdreo,sizeof(Real)*MAX_ATOMS*SPACE);
																memcpy(crd,T_crd,sizeof(Real)*MAX_ATOMS*SPACE);
																memcpy(vt,T_vt,sizeof(Real)*MAX_TORS*SPACE);
																memcpy(&q_reorient,&T_q_reorient,sizeof(Quat));
																memcpy(&ligand,&T_ligand,sizeof(Molecule));
																if( nruns > MAX_RUNS ) 
																{
																		//fprintf(stderr, "%s:  ERROR: %d runs requested, but only dimensioned for %d.\nChange \"MAX_RUNS\" in \"constants.h\".", programname, nruns, MAX_RUNS);
																		slaveExit( -1 );
																} 
																else if ((L_GlobalSearchMethod==NULL)||(L_LocalSearchMethod==NULL)) 
																{
																		//fprintf(stderr, "%s:  ERROR:  You must use \"set_ga\" to allocate both Global Optimization object AND Local Optimization object.\n", programname);
																		slaveExit(-1);
																}
																exit_if_missing_elecmap_desolvmap_about("gals");
																if (ad4_unbound_model==Unbound_Default) 
																		ad4_unbound_model = Unbound_Same_As_Bound;
																L_evaluate[threadID].setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
																				elec, emap, nonbondlist, ad_energy_tables, Nnb,
																				B_calcIntElec, B_isGaussTorCon, B_isTorConstrained,
																				B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
																				ignore_inter,
																				B_include_1_4_interactions, scale_1_4,
																				unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues,
																				xb_empirical_vdw, xb_empirical_es,
																				ad_vdw, ad_es, ad_desolv, 
																				xbEmpiricalMapInfo->xb_vdw_profile, 
																				xbEmpiricalMapInfo->xb_es_profile,
																				xbEmpiricalMapInfo->xb_desolv_profile, 
																				xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
																				xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
																				xbempirical_ligand_xbdonor,
																				xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);
																L_evaluate[threadID].compute_intermol_energy(TRUE);
																//if(threadID==5)
																//{
																//	printf("Parallel 5...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
														}
														int count_for=0;
														int nconf_b=nconf;
#pragma omp parallel for private(count_for) num_threads(nruns)
														for (int j=0; j<nruns; j++) 
														{
																if(count_for==0)
																{
																		eintra=T_eintra;
																		einter=T_einter;
																		unbound_internal_FE=T_FE;
																		memcpy(crdpdb,T_crdpdb,sizeof(Real)*MAX_ATOMS*SPACE);
																		memcpy(crdreo,T_crdreo,sizeof(Real)*MAX_ATOMS*SPACE);
																		memcpy(crd,T_crd,sizeof(Real)*MAX_ATOMS*SPACE);
																		memcpy(vt,T_vt,sizeof(Real)*MAX_TORS*SPACE);
																		memcpy(&q_reorient,&T_q_reorient,sizeof(Quat));
																		memcpy(&ligand,&T_ligand,sizeof(Molecule));
																}
																count_for++;            
																//printf("\n\n\tBEGINNING LAMARCKIAN GENETIC ALGORITHM DOCKING\n");
																//fflush(0);
																if (B_reorient_random == TRUE) 
																{
																		// create a new random orientation before docking
																		L_create_random_orientation( &q_reorient );
																		// reorient the ligand
																		L_reorient(true_ligand_atoms, atomstuff, crdpdb, charge, type,parameterArray,
																						q_reorient, origin, ntor, tlist, vt, &ligand, debug );
																		// update the evaluate object
																		L_evaluate[threadID].update_crds( crdpdb, vt );
																}

																((L_Genetic_Algorithm *)L_GlobalSearchMethod)->initialize(pop_size, 7+sInit.ntor);
																State s_tmp;

																s_tmp = L_call_glss( L_GlobalSearchMethod, L_LocalSearchMethod,sInit,num_evals, pop_size,
																				outlev,outputEveryNgens, &ligand,B_RandomTran0, B_RandomQuat0, 
																				B_RandomDihe0,info, FN_pop_file, end_of_branch );
																sHist[nconf_b+j]=s_tmp;
																if (ad4_unbound_model == Unbound_Same_As_Bound) 
																{
																		unbound_internal_FE = eintra;
																}
																econf[nconf_b+j] = eintra + einter + torsFreeEnergy - unbound_internal_FE;
																//printf("Thread %d nconf = %d\n",threadID,nconf);
																//fflush(0);
														}
														nconf=nconf_b+nruns;
														//ShowConfMIC(econf,nconf_b,nconf);
												}
										M_MIC_STATUS=M_MIC_ING;
								}
								else if(M_MIC_STATUS==M_MIC_ING)
								{
										#pragma offload target(mic:mic_no)\
										in(T_xb1,T_xb2,T_ad1,T_ad2,T_ad3,T_ligand,T_q_reorient,T_eintra,T_einter,T_FE)\
												in(T_crd:length(MAX_ATOMS*SPACE)	M_USE)\
												in(T_crdreo:length(MAX_ATOMS*SPACE)	M_USE)\
												in(T_crdpdb:length(MAX_ATOMS*SPACE)	M_USE)\
												in(T_vt:length(MAX_TORS*SPACE)		M_USE)\
												nocopy(threadID							)\
												in(LS_Type,B_found_elecmap,B_found_desolvmap,B_found_about_keyword)\
												in(nruns,ad4_unbound_model					)\
												in(retval,mpirank,seedtype					)\
												nocopy(time_seed							)\
												in(param:length(2*LINE_LEN)			M_USE)\
												nocopy(seed:length(2)				M_USE)\
												nocopy(timeSeedIsSet:length(2)		M_USE)\
												nocopy(Nnb_array:length(3) 			M_USE)\
												nocopy(nb_group_energy:length(3) 	M_USE)\
												nocopy(L_GlobalSearchMethod,L_GA								)\
												nocopy(L_LocalSearchMethod,L_SW,rho_ptr,lb_rho_ptr,L_PSW,L_PS )\
												in(B_isGaussTorCon,B_ShowTorE									)\
												in(B_include_1_4_interactions, scale_1_4						)\
												in(B_use_non_bond_cutoff, B_have_flexible_residues				)\
												in(unbound_internal_FE											)\
												in(xb_empirical_es,ad_vdw,ad_es,ad_desolv,natom,B_calcIntElec,xb_empirical_vdw)\
												in(q_reorient,ligand,sInit					)\
												in(crd:length(MAX_ATOMS*SPACE)		M_USE)\
												in(crdreo:length(MAX_ATOMS*SPACE)	M_USE)\
												in(crdpdb:length(MAX_ATOMS*SPACE)	M_USE)\
												in(vt:length(MAX_TORS*SPACE)		M_USE)\
												in(map:length(MAX_GRID_PTS*MAX_GRID_PTS*MAX_GRID_PTS*MAX_MAPS)		M_USE)\
												in(US_torProfile:length(MAX_TORS*NTORDIVS)	M_USE)\
												in(tlist:length(MAX_TORS*MAX_ATOMS)			M_USE)\
												in(xbpmf_ligand_hb_donorH_ids:length(MAX_ATOMS*5)	M_USE)\
												in(xbempirical_ligand_xbdonor:length(MAX_ATOMS*2)	M_USE)\
												nocopy(line:length(LINE_LEN) 					M_USE)\
												in(charge,abs_charge:length(MAX_ATOMS)			M_USE)\
												in(qsp_abs_charge:length(MAX_ATOMS) 			M_USE)\
												in(emap:length(MAX_ATOMS)						M_USE)\
												in(type:length(MAX_ATOMS)						M_USE)\
												in(elec:length(MAX_ATOMS) 						M_USE)\
												in(ignore_inter:length(MAX_ATOMS) 				M_USE)\
												in(nonbondlist:length(MAX_NONBONDS) 			M_FREE)\
												in(ad_energy_tables:length(1) 				M_FREE)\
												in(B_isTorConstrained:length(MAX_TORS)			M_USE)\
												in(US_TorE:length(MAX_TORS) 					M_USE)\
												in(info:length(1) 					M_FREE)\
												in(L_evaluate:length(MIC_MAX_NUM_THREADS) 		M_USE)\
												in(xbEmpiricalMapInfo:length(1) 			M_FREE)\
												in(xbpmf_ligand_xb_donorX_id:length(MAX_ATOMS)	M_USE)\
												in(xbpmf_ligand_at_index:length(MAX_ATOMS)		M_USE)\
												in(xbpmf_ligand_hb_acceptor:length(MAX_ATOMS)	M_USE)\
												in(xbpmf_ligand_hb_donor:length(MAX_ATOMS)		M_USE)\
												in(xbpmf_ligand_xb_donor:length(MAX_ATOMS) 		M_USE)\
												in(xbpmf_receptor_hb_acceptor:length(MAX_RECEPTOR_ATOMS) 	M_USE)\
												in(origin,B_reorient_random,debug								  )\
												in(ntor															  )\
												in(num_evals, pop_size,outputEveryNgens							  )\
												in(outlev														  )\
												in(B_RandomTran0, B_RandomQuat0, B_RandomDihe0					  )\
												in(eintra,einter												  )\
												in(torsFreeEnergy												  )\
												inout(nconf														  )\
												in(atomstuff:length(MAX_ATOMS*MAX_CHARS)					M_USE)\
												in(parameterArray:length(MAX_ATOM_TYPES)					M_USE)\
												in(FN_pop_file:length(FILENAME_MAX)							M_USE)\
												in(end_of_branch:length(MAX_TORS)							M_USE)\
												out(econf:length(MAX_RUNS) 									M_USE)\
												out(sHist:length(MAX_RUNS)									M_USE)\
												in(xbpmf_scoring,true_ligand_atoms,AD4,sel_prop_count,global_ntor	  )\
												in(ElecMap,DesolvMap,halogen_found									  )\
												in(Nnb)
												{
#pragma omp parallel num_threads(nruns)
														{
																threadID=omp_get_thread_num();
																if ((retval==2) || (retval==1)) 
																{
																		for (int i=0; i<retval ; i++ ) 
																		{
																				if (equal(param[i], "tim", 3)) 
																				{
																						timeSeedIsSet[i] = 'T';
																						// set the seed based on the seed type
																						if (seedtype == SAME_SEED) 
																						{
																								seed[i] = SAME_SEED_CONSTANT;
																						}
																						else if (seedtype == DEFAULT_SEED) 
																						{ // the time seed needs to have the threadID added to it so that different threads get a different seed
																								seed[i] = (FourByteLong)(time( &time_seed ) + threadID);
																						}
																						else if (seedtype == UNIQUE_NODE_SEED) 
																						{ // the time seed needs to have the threadID added to it so that different threads get a different seed plus the mpirank times the most threads possible on BQG (320) to make sure the seed is unique across the nodes
																								seed[i] = (FourByteLong)(time( &time_seed ) + threadID + (mpirank*320));
																						}
																						else 
																						{
																								//fprintf(stderr,"seed type not set properly, exitting\n");
																								slaveExit(-1);
																						}
																						L_setall( seed[i], seed[i] ); 
																						L_initgn(-1);
																				} 
																				else if (equal(param[i], "pid", 3)) 
																				{
																						timeSeedIsSet[i] = 'F';
																						if (seedtype == SAME_SEED) 
																						{
																								seed[i] = SAME_SEED_CONSTANT;
																						}
																						else 
																						{
																								seed[i] = getpid();
																						}
																						L_setall( seed[i], seed[i] ); 
																						L_initgn(-1);
																				} 
																				else 
																				{
																						timeSeedIsSet[i] = 'F';
																						seed[i] = atol(param[i]);
																						L_setall( seed[i], seed[i] ); 
																						L_initgn(-1);
																				}
																		}
																		if (retval==2) 
																		{
																				L_setall(seed[0], seed[1]);
																				L_initgn(-1);  // Reinitializes the state of the current random number generator
																		}
																} 
																else 
																{
																		//pr(logFile, "Error encountered reading seeds!\n");
																}
																//if(threadID==1)
																//{
																//	printf("parallel 1...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
																//for (int j=0; j<3; j++) {          
																//	Nnb_array[j] = 0;
																//	nb_group_energy[j] = 0.0;
																//}
																for (int j=0; j<3; j++) {
																		Nnb_array[j] = 0;
																		nb_group_energy[0] = 0.0;
																}
																//if(threadID==2)
																//{
																//	printf("parallel 2...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
																if(L_GlobalSearchMethod != NULL) 
																{
																		delete L_GlobalSearchMethod;
																		L_GlobalSearchMethod = NULL;
																}
																L_GA = new L_Genetic_Algorithm(e_mode, s_mode, c_mode, w_mode, elitism, c_rate, m_rate,
																				window_size, num_generations, outputEveryNgens );
																L_GlobalSearchMethod=L_GA;
																(dynamic_cast<L_Genetic_Algorithm*>(L_GlobalSearchMethod))->mutation_values( low, high, alpha, beta,\
																				trnStep0, qtwStep0, torStep0  );
																(dynamic_cast<L_Genetic_Algorithm*>(L_GlobalSearchMethod))->initialize(pop_size, 7+sInit.ntor);

																if (s_mode==LinearRanking){
																		(dynamic_cast<L_Genetic_Algorithm*>(L_GlobalSearchMethod))->set_linear_ranking_selection_probability_ratio(linear_ranking_selection_probability_ratio);
																}
																//if(threadID==3)
																//{
																//	printf("parallel 3...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
																if(L_LocalSearchMethod != NULL) 
																{
																		delete L_LocalSearchMethod;
																		L_LocalSearchMethod = NULL;
																}
																if(LS_Type==0)
																{
																		L_SW = new L_Solis_Wets1(7+sInit.ntor, max_its, max_succ, max_fail, rho, lb_rho, 2.0, 0.5, search_freq);
																		L_LocalSearchMethod = L_SW;
																		L_LocalSearchMethod->SearchType=1;
																}
																else if(LS_Type==1)
																{
																		rho_ptr = new Real[7+sInit.ntor];
																		lb_rho_ptr = new Real[7+sInit.ntor];
																		int j;
																		for (j=0; j<3; j++) {
																				// j=0,1,2
																				rho_ptr[j] = rho * psw_trans_scale;// formerly trnStep0;
																				lb_rho_ptr[j] = lb_rho * psw_trans_scale; //once trnStepFinal;
																		}

																		//  Initialize the rho's corresponding to the quaterion
																		for (; j<7; j++) {
																				// j=3,4,5,6
																				rho_ptr[j] = rho * psw_rot_scale;// formerly qtwStep0;
																				lb_rho_ptr[j] = lb_rho * psw_rot_scale; //once qtwStepFinal;
																		}

																		//  Initialize the rho's corresponding to the torsions
																		for (; j<7+sInit.ntor; j++) {
																				// j=7,...
																				rho_ptr[j] = rho * psw_tors_scale;// formerly torStep0;
																				lb_rho_ptr[j] = lb_rho * psw_tors_scale;//formerly torStepFinal;
																		}

																		L_PSW = new L_Pseudo_Solis_Wets1(7+sInit.ntor, max_its, max_succ, max_fail, 2.0, 0.5, search_freq, rho_ptr, lb_rho_ptr);
																		L_LocalSearchMethod=L_PSW;
																		L_LocalSearchMethod->SearchType=2;
																}
																else if(LS_Type==2)
																{
																		L_PS = new L_Pattern_Search(7+sInit.ntor, max_succ, rho, lb_rho, 2.0, 0.5, search_freq);
																		L_LocalSearchMethod=L_PS;
																		dynamic_cast<L_Local_Search*>(L_LocalSearchMethod)->SearchType=3;
																}
																else
																{
																		printf("Sorry!LocalSearchMethod is unavailible...\n");
																		fflush(0);
																		slaveExit(-1);
																}
																//if(threadID==4)
																//{
																//	printf("Parallel 4...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
																xb_empirical_vdw=T_xb1;
																xb_empirical_es=T_xb2;
																ad_vdw=T_ad1;
																ad_es=T_ad2;
																ad_desolv=T_ad3;
																memcpy(crdpdb,T_crdpdb,sizeof(Real)*MAX_ATOMS*SPACE);
																memcpy(crdreo,T_crdreo,sizeof(Real)*MAX_ATOMS*SPACE);
																memcpy(crd,T_crd,sizeof(Real)*MAX_ATOMS*SPACE);
																memcpy(vt,T_vt,sizeof(Real)*MAX_TORS*SPACE);
																memcpy(&q_reorient,&T_q_reorient,sizeof(Quat));
																memcpy(&ligand,&T_ligand,sizeof(Molecule));
																if( nruns > MAX_RUNS ) 
																{
																		//fprintf(stderr, "%s:  ERROR: %d runs requested, but only dimensioned for %d.\nChange \"MAX_RUNS\" in \"constants.h\".", programname, nruns, MAX_RUNS);
																		slaveExit( -1 );
																} 
																else if ((L_GlobalSearchMethod==NULL)||(L_LocalSearchMethod==NULL)) 
																{
																		//fprintf(stderr, "%s:  ERROR:  You must use \"set_ga\" to allocate both Global Optimization object AND Local Optimization object.\n", programname);
																		slaveExit(-1);
																}
																exit_if_missing_elecmap_desolvmap_about("gals");
																if (ad4_unbound_model==Unbound_Default) 
																		ad4_unbound_model = Unbound_Same_As_Bound;
																L_evaluate[threadID].setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
																				elec, emap, nonbondlist, ad_energy_tables, Nnb,
																				B_calcIntElec, B_isGaussTorCon, B_isTorConstrained,
																				B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
																				ignore_inter,
																				B_include_1_4_interactions, scale_1_4,
																				unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues,
																				xb_empirical_vdw, xb_empirical_es,
																				ad_vdw, ad_es, ad_desolv, 
																				xbEmpiricalMapInfo->xb_vdw_profile, 
																				xbEmpiricalMapInfo->xb_es_profile,
																				xbEmpiricalMapInfo->xb_desolv_profile, 
																				xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
																				xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
																				xbempirical_ligand_xbdonor,
																				xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);
																L_evaluate[threadID].compute_intermol_energy(TRUE);
																//if(threadID==5)
																//{
																//	printf("Parallel 5...\n");
																//	fflush(0);
																//}
																/**************************************************************************************/
														}
														int count_for=0;
														int nconf_b=nconf;
#pragma omp parallel for private(count_for) num_threads(nruns)
														for (int j=0; j<nruns; j++) 
														{
																if(count_for==0)
																{
																		eintra=T_eintra;
																		einter=T_einter;
																		unbound_internal_FE=T_FE;
																		memcpy(crdpdb,T_crdpdb,sizeof(Real)*MAX_ATOMS*SPACE);
																		memcpy(crdreo,T_crdreo,sizeof(Real)*MAX_ATOMS*SPACE);
																		memcpy(crd,T_crd,sizeof(Real)*MAX_ATOMS*SPACE);
																		memcpy(vt,T_vt,sizeof(Real)*MAX_TORS*SPACE);
																		memcpy(&q_reorient,&T_q_reorient,sizeof(Quat));
																		memcpy(&ligand,&T_ligand,sizeof(Molecule));
																}
																count_for++;            
																//printf("\n\n\tBEGINNING LAMARCKIAN GENETIC ALGORITHM DOCKING\n");
																//fflush(0);
																if (B_reorient_random == TRUE) 
																{
																		// create a new random orientation before docking
																		L_create_random_orientation( &q_reorient );
																		// reorient the ligand
																		L_reorient(true_ligand_atoms, atomstuff, crdpdb, charge, type,parameterArray,
																						q_reorient, origin, ntor, tlist, vt, &ligand, debug );
																		// update the evaluate object
																		L_evaluate[threadID].update_crds( crdpdb, vt );
																}

																((L_Genetic_Algorithm *)L_GlobalSearchMethod)->initialize(pop_size, 7+sInit.ntor);
																State s_tmp;

																s_tmp = L_call_glss( L_GlobalSearchMethod, L_LocalSearchMethod,sInit,num_evals, pop_size,
																				outlev,outputEveryNgens, &ligand,B_RandomTran0, B_RandomQuat0, 
																				B_RandomDihe0,info, FN_pop_file, end_of_branch );
																sHist[nconf_b+j]=s_tmp;
																if (ad4_unbound_model == Unbound_Same_As_Bound) 
																{
																		unbound_internal_FE = eintra;
																}
																econf[nconf_b+j] = eintra + einter + torsFreeEnergy - unbound_internal_FE;
																//printf("Thread %d nconf = %d\n",threadID,nconf);
																//fflush(0);
														}
														nconf=nconf_b+nruns;
														//ShowConfMIC(econf,nconf_b,nconf);
												}
								}
								else
								{
										fprintf(stderr,"Error!invalid MIC status...\n");
										slaveExit(-1);
								}

								printf("Compute End...\n");
						}

						MICEnd=time(NULL);
						//printf("nruns=%d\n",nruns);
#ifdef PERF_PROFILING
						return_current_time(slaveDockInfo.LGAStartTime);
						time(&slaveDockInfo.LGAStartTime_t);

#endif

#ifdef PERF_PROFILING
						return_current_time(slaveDockInfo.LGAEndTime);
						time(&slaveDockInfo.LGAEndTime_t);

#endif
						if(write_stateFile)
						{
								fprintf(stateFile,"\t</runs>\n");
								(void) fflush(stateFile);
						}
						(void) fflush(logFile);
						break;
#ifdef USE_DPF_LS		
				case DPF_LS:
						// do_local_only
						(void) sscanf(line, "%*s %d", &nruns);

						if ( nruns > MAX_RUNS ) {

								prStr( error_message, "%s:  ERROR: %d runs requested, but only dimensioned for %d.\nChange \"MAX_RUNS\" in \"constants.h\".", programname, nruns, MAX_RUNS);
								//stop( error_message );
								slaveExit( -1 );

						} else if (LocalSearchMethod==NULL) {

								prStr(error_message, "%s:  ERROR:  You must use \"set_sw1\", \"set_psw1\" or \"set_pattern\" to create a Local Optimization object.\n", programname);
								//stop(error_message);
								slaveExit(-1);
						}
						exit_if_missing_elecmap_desolvmap_about("ls");
						pr( logFile, "Number of Local Search (LS) only dockings = %d run%c\n", nruns, (nruns > 1)?'s':' ');
						if (ad4_unbound_model==Unbound_Default) ad4_unbound_model = Unbound_Same_As_Bound;
						pr(logFile, "Unbound model to be used is %s.\n", report_parameter_library());
						evaluate[threadID].setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
										elec, emap,
										nonbondlist,
										ad_energy_tables,
										Nnb, B_calcIntElec, B_isGaussTorCon,B_isTorConstrained,
										B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
										ignore_inter,
										B_include_1_4_interactions, scale_1_4,
										unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues,xb_empirical_vdw, xb_empirical_es,
										ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
										xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
										xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
										xbempirical_ligand_xbdonor,
										xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);
						//parameterArray, unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues);

						evaluate[threadID].compute_intermol_energy(TRUE);

						if(write_stateFile){
								fprintf(stateFile,"\t<run_requested>%d</run_requested>\n",nruns);
								fprintf(stateFile,"\t<runs>\n");
						}

						for (j=0; j<nruns; j++) {

								(void) fprintf( logFile, "\n\n\tBEGINNING SOLIS & WETS LOCAL SEARCH DOCKING\n");
								pr( logFile, "\nRun:\t%d / %d\n", j+1, nruns );
								(void) fflush( logFile );

								pr(logFile, "Date:\t");
								printdate( logFile, 2 );
								(void) fflush( logFile );

								gaStart = times( &tms_gaStart );

								sHist[nconf] = call_ls(LocalSearchMethod, sInit, pop_size, &ligand);

								pr(logFile, "There were %lu Energy Evaluations.\n", evaluate[threadID].evals());

								gaEnd = times( &tms_gaEnd );
								pr( logFile, "Time taken for this Local Search (LS) run:\n");
								M_timesyshms( gaEnd - gaStart, &tms_gaStart, &tms_gaEnd );
								pr( logFile, "\n");
								(void) fflush( logFile );

								pr( logFile, "\n\n\tFINAL LOCAL SEARCH DOCKED STATE\n" );
								pr( logFile,     "\t_______________________________\n\n\n" );

								if(xbpmf_scoring)
										writePDBQT(j, seed, FN_ligand, dock_param_fn, lig_center,
														sHist[nconf], ntor, &eintra, &einter, natom, atomstuff,
														crd, emap, elec,
														charge, abs_charge, qsp_abs_charge,
														ligand_is_inhibitor,
														torsFreeEnergy,
														vt, tlist, crdpdb, nonbondlist,
														ad_energy_tables,
														type, Nnb, B_calcIntElec,
														map,
														outlev,
														ignore_inter,
														B_include_1_4_interactions, scale_1_4, parameterArray,
														unbound_internal_FE,info, DOCKED, PDBQT_record,
														B_use_non_bond_cutoff, B_have_flexible_residues, ad4_unbound_model,
														xbPmfMapInfo->xbpmf_1d_pw_parms,xbPmfMapInfo->xbpmf_2d_hb_pw_parms,xbPmfMapInfo->xbpmf_2d_xb_pw_parms,
														xbPmfMapInfo->recep_natom,xbPmfMapInfo->recep_crdpdb,xbPmfMapInfo->recep.atomtype,xbligand.atomtype,
														xbPmfMapInfo->xbpmf_1d_map,xbPmfMapInfo->xbpmf_hb_map,xbPmfMapInfo->recep_acceptor_natom,
														xbPmfMapInfo->recep_acceptor_crdpdb,xbPmfMapInfo->recep_acceptor_atomtype,xbPmfMapInfo->xbpmf_hb_label,xbPmfMapInfo->xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbPmfMapInfo->xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
								//                ; //error xbzhang
								else
										writePDBQT( j, seed, FN_ligand, dock_param_fn, lig_center,
														sHist[nconf], ntor, &eintra, &einter, natom, atomstuff,
														crd, emap, elec,
														charge, abs_charge, qsp_abs_charge,
														ligand_is_inhibitor,
														torsFreeEnergy,
														vt, tlist, crdpdb, nonbondlist,
														ad_energy_tables,
														type, Nnb, B_calcIntElec,
														map,
														outlev,
														ignore_inter,
														B_include_1_4_interactions, scale_1_4, parameterArray, unbound_internal_FE,
														info, DOCKED, PDBQT_record, B_use_non_bond_cutoff, B_have_flexible_residues, ad4_unbound_model,xb_empirical_vdw, xb_empirical_es,
														ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
														xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
														xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
														xbempirical_ligand_xbdonor,
														xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);

								// See also "calculateEnergies.cc", switch(ad4_unbound_model)
								if (ad4_unbound_model == Unbound_Same_As_Bound) {
										// Update the unbound internal energy, setting it to the current internal energy
										unbound_internal_FE = eintra;
								}
								econf[nconf] = eintra + einter + torsFreeEnergy - unbound_internal_FE;

								++nconf;

								pr( logFile, UnderLine );

						} // Next run
						if(write_stateFile){
								fprintf(stateFile,"\t</runs>\n");
								(void) fflush(stateFile);
						}
						(void) fflush(logFile);
						break;
#endif		
						//______________________________________________________________________________
#ifdef USE_DPF_GS		
				case DPF_GS:
						(void) sscanf(line, "%*s %d", &nruns);

						if (nruns>MAX_RUNS) {

								prStr(error_message, "%s:  ERROR:  %d runs requested, but only dimensioned for %d.\nChange \"MAX_RUNS\" in \"constants.h\".", programname, nruns, MAX_RUNS);
								//stop(error_message);
								slaveExit(-1);

						} else if (GlobalSearchMethod==NULL) {
								prStr(error_message, "%s:  ERROR:  You must use \"set_ga\" to allocate a Global Optimization object.\n", programname);
								//stop(error_message);
								slaveExit(-1);
						}

						exit_if_missing_elecmap_desolvmap_about("gs");

						pr(logFile, "Number of Genetic Algorithm (GA) only dockings = %d run%c\n", nruns, (nruns>1)?'s':' ');
						if (ad4_unbound_model==Unbound_Default) ad4_unbound_model = Unbound_Same_As_Bound;
						pr(logFile, "Unbound model to be used is %s.\n", report_parameter_library());


						evaluate[threadID].setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
										elec, emap,
										nonbondlist,
										ad_energy_tables,
										Nnb, B_calcIntElec, B_isGaussTorCon,B_isTorConstrained,
										B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
										ignore_inter,
										B_include_1_4_interactions, scale_1_4,
										unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues,xb_empirical_vdw, xb_empirical_es,
										ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
										xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
										xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
										xbempirical_ligand_xbdonor,
										xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);
						//parameterArray, unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues);

						evaluate[threadID].compute_intermol_energy(TRUE);

						if(write_stateFile){
								fprintf(stateFile,"\t<run_requested>%d</run_requested>\n",nruns);
								fprintf(stateFile,"\t<runs>\n");
						}
						for (j=0; j<nruns; j++) {

								fprintf( logFile, "\n\n\tBEGINNING GENETIC ALGORITHM DOCKING\n");
								pr(logFile, "\nDoing Genetic Algorithm run:  %d/%d.\n", j+1, nruns);
								(void) fflush( logFile );

								pr(logFile, "Date:\t");
								printdate( logFile, 2 );
								(void) fflush( logFile );

								gaStart = times(&tms_gaStart);

								sHist[nconf] = call_gs( GlobalSearchMethod, sInit, num_evals, pop_size,
												&ligand, outputEveryNgens, info, end_of_branch);

								pr(logFile, "\nFinal docked state:\n");
								printState(logFile, sHist[nconf], 2);

								gaEnd = times(&tms_gaEnd);
								pr(logFile, "Time taken for this Genetic Algorithm (GA) run:\n");
								M_timesyshms(gaEnd-gaStart, &tms_gaStart, &tms_gaEnd);
								pr(logFile, "\n");
								(void) fflush(logFile);

								pr(logFile, "Total number of Energy Evaluations: %lu\n", evaluate[threadID].evals() );
								pr(logFile, "Total number of Generations:        %u\n", ((Genetic_Algorithm *)GlobalSearchMethod)->num_generations());


								pr( logFile, "\n\n\tFINAL GENETIC ALGORITHM DOCKED STATE\n" );
								pr( logFile,     "\t____________________________________\n\n\n" );
								if(xbpmf_scoring)
										writePDBQT(j, seed, FN_ligand, dock_param_fn, lig_center,
														sHist[nconf], ntor, &eintra, &einter, natom, atomstuff,
														crd, emap, elec,
														charge, abs_charge, qsp_abs_charge,
														ligand_is_inhibitor,
														torsFreeEnergy,
														vt, tlist, crdpdb, nonbondlist,
														ad_energy_tables,
														type, Nnb, B_calcIntElec,
														map,
														outlev,
														ignore_inter,
														B_include_1_4_interactions, scale_1_4, parameterArray,
														unbound_internal_FE,info, DOCKED, PDBQT_record,
														B_use_non_bond_cutoff, B_have_flexible_residues, ad4_unbound_model,
														xbPmfMapInfo->xbpmf_1d_pw_parms,xbPmfMapInfo->xbpmf_2d_hb_pw_parms,xbPmfMapInfo->xbpmf_2d_xb_pw_parms,
														xbPmfMapInfo->recep_natom,xbPmfMapInfo->recep_crdpdb,xbPmfMapInfo->recep.atomtype,xbligand.atomtype,
														xbPmfMapInfo->xbpmf_1d_map,xbPmfMapInfo->xbpmf_hb_map,xbPmfMapInfo->recep_acceptor_natom,
														xbPmfMapInfo->recep_acceptor_crdpdb,xbPmfMapInfo->recep_acceptor_atomtype,xbPmfMapInfo->xbpmf_hb_label,xbPmfMapInfo->xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbPmfMapInfo->xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
								//                ; //error xbzhang
								else
										writePDBQT( j, seed, FN_ligand, dock_param_fn, lig_center,
														sHist[nconf], ntor, &eintra, &einter, natom, atomstuff,
														crd, emap, elec,
														charge, abs_charge, qsp_abs_charge,
														ligand_is_inhibitor,
														torsFreeEnergy,
														vt, tlist, crdpdb, nonbondlist,
														ad_energy_tables,
														type, Nnb, B_calcIntElec,
														map,
														outlev,
														ignore_inter,
														B_include_1_4_interactions, scale_1_4, parameterArray, unbound_internal_FE,
														info, DOCKED, PDBQT_record, B_use_non_bond_cutoff, B_have_flexible_residues, ad4_unbound_model,xb_empirical_vdw, xb_empirical_es,
														ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
														xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
														xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
														xbempirical_ligand_xbdonor,
														xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);

								// See also "calculateEnergies.cc", switch(ad4_unbound_model)
								if (ad4_unbound_model == Unbound_Same_As_Bound) {
										// Update the unbound internal energy, setting it to the current internal energy
										unbound_internal_FE = eintra;
								}
								econf[nconf] = eintra + einter + torsFreeEnergy - unbound_internal_FE;

								++nconf;

								pr( logFile, UnderLine );

						} // Next run
						if(write_stateFile){
								fprintf(stateFile,"\t</runs>\n");
								(void) fflush(stateFile);
						}
						(void) fflush(logFile);
						break;
#endif		
						//______________________________________________________________________________

				case GA_pop_size:
						(void) sscanf(line, "%*s %u", &pop_size);
						//       pr(logFile, "A population of %u individuals will be used\n", pop_size);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case GA_num_generations:
						(void) sscanf(line, "%*s %u", &num_generations);
						//       pr(logFile, "The GA will run for at most %u generations.\n", num_generations);
						//        (void) fflush(logFile);
						num_generations=27000;
						break;

						//______________________________________________________________________________

				case GA_num_evals:
						(void) sscanf(line, "%*s %u", &num_evals);
						num_evals=2500000;
						//       pr(logFile, "There will be at most %u function evaluations used.\n", num_evals);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case GA_window_size:
						(void) sscanf(line, "%*s %d", &window_size);
						//       pr(logFile, "The GA's selection window is %d generations.\n", window_size);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case GA_low:
						(void) sscanf(line, "%*s %d", &low);
						pr(logFile, "Setting low to %d.\n", low);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case GA_high:
						(void) sscanf(line, "%*s %d", &high);
						pr(logFile, "Setting high to %d.\n", high);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case GA_elitism:
						(void) sscanf(line, "%*s %d", &elitism);
						//       pr(logFile, "The %d best will be preserved each generation.\n", elitism);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case GA_mutation_rate:
						(void) sscanf(line, "%*s " FDFMT, &m_rate);
						//       pr(logFile, "The mutation rate is %f.\n", m_rate);
						//        (void) fflush(logFile);
						// if m_rate is out of range, make_table will fail
						if (m_rate < 0 || m_rate > 1) {
								prStr(error_message, "mutation rate must be within range 0 to 1 (inclusive).\n");
								//stop(error_message);
						}
						break;

						//______________________________________________________________________________

				case GA_crossover_rate:
						(void) sscanf(line, "%*s " FDFMT, &c_rate);
						//       pr(logFile, "The crossover rate is %f.\n", c_rate);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case GA_Cauchy_alpha:
						(void) sscanf(line, "%*s " FDFMT, &alpha);
						//       pr(logFile, "The alpha parameter (for the Cauchy distribution) is being set to %f.\n",
						//          alpha);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case GA_Cauchy_beta:
						(void) sscanf(line, "%*s " FDFMT, &beta);
						//       pr(logFile, "The beta parameter (for the Cauchy distribution) is being set to %f.\n",
						//          beta);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case SW_max_its:
						(void) sscanf(line, "%*s %u", &max_its);
						//       pr(logFile, "Solis & Wets algorithms will perform at most %u iterations.\n", max_its);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case SW_max_succ:
						(void) sscanf(line, "%*s %u", &max_succ);
						//       pr(logFile, "Solis & Wets algorithms expand rho every %u in a row successes.\n", max_succ);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case SW_max_fail:
						(void) sscanf(line, "%*s %u", &max_fail);
						//       pr(logFile, "Solis & Wets algorithms contract rho every %u in a row failures.\n", max_fail);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case SW_rho:
						(void) sscanf(line, "%*s " FDFMT, &rho);
						//       pr(logFile, "rho is set to %f.\n", rho);
						//        (void) fflush(logFile);
						break;


						//______________________________________________________________________________

				case SW_lb_rho:
						(void) sscanf(line, "%*s " FDFMT, &lb_rho);
						//        pr(logFile, "rho will never get smaller than %f.\n", lb_rho);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case PSW_TRANS_SCALE:
						(void) sscanf(line, "%*s " FDFMT, &psw_trans_scale);
						pr(logFile, "psw_trans_scale is set to %f.\n", psw_trans_scale);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case PSW_ROT_SCALE:
						(void) sscanf(line, "%*s " FDFMT, &psw_rot_scale);
						pr(logFile, "psw_rot_scale is set to %f.\n", psw_rot_scale);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case PSW_TORS_SCALE:
						(void) sscanf(line, "%*s " FDFMT, &psw_tors_scale);
						pr(logFile, "psw_tors_scale is set to %f.\n", psw_tors_scale);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________


				case LS_search_freq:
						(void) sscanf(line, "%*s " FDFMT, &search_freq);
						//        pr(logFile, "Local search will be performed with frequency %f.\n", search_freq);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case PSO_c1:
						(void) sscanf(line, "%*s %lf", &c1);
						//        pr(logFile, "PSO will be performed with the First Confidence Coefficient  (C1) %lf.\n", c1);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case PSO_c2:
						(void) sscanf(line, "%*s %lf", &c2);
						pr(logFile, "PSO will be performed with the Second Confidence Coefficient (C2) %lf.\n", c2);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case PSO_k:
						(void) sscanf(line, "%*s %d", &K);
						pr(logFile, "Max number of particles informed by a given one = %d.\n", K);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case PSO_swarm_moves:
						(void) sscanf(line, "%*s %d", &eval_max);
						pr(logFile, "There will be %d swarm Moves.\n", eval_max);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case PSO_swarm_size_factor:
						(void) sscanf(line, "%*s %d", &S_factor);
						pr(logFile, "There will be %d Swarm Size Factor.\n", S_factor);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________

				case PSO_n_exec:
						(void) sscanf(line, "%*s %d", &n_exec_max);
						pr(logFile, "Number of requested PSO runs = %d.\n", n_exec_max);
						(void) fflush(logFile);
						break;

						//______________________________________________________________________________
#ifdef USE_DPF_PSO_CONSTRICTION		
				case DPF_PSO_CONSTRICTION:

						/*
						 * PSO Work
						 */
						pr( logFile, "\nTotal number of torsions in the ligand = %d \n", ntor);
						D = 7 + ntor; //Dimension D
						pr( logFile, "\nTotal number of dimensions is equal to the number of Degrees of Freedom = %d \n", D);
						pr( logFile, "Number of requested PSO dockings = %d run%c\n", n_exec_max, (n_exec_max > 1)?'s':' ');
						//No. of Particles in the Swarm
						S = S_factor + (int) (2 * sqrt(D)); //S - Swarm Size (~somewhat analogous to pop_size)
						pr( logFile, "\nTotal number in swarm size = %d \n", S);

						//Checking the No. of Runs and No. of Particles
						if (n_exec_max > R_max ) //set to 1024 in constants.h
						{
								prStr( error_message, "ERROR: %d runs requested, but only dimensioned for %d.\nChange \"R_max\" in \"constants.h\".", nruns, R_max);
								//stop( error_message );
								slaveExit( -1 );
						} else if ( S  > S_max )
						{
								prStr( error_message, "ERROR: %d Particles initialised in Swarm, but only dimensioned for %d.\nChange \"S_max\" in \"constants.h\".", S, S_max);
								//stop( error_message );
								slaveExit( -1 );
						}

						if (outlev > 3) {
								pr( logFile, "\ncalling initialiseDimension: info->lo=%f %f %f , info->hi=%f %f %f,  \n", info->lo[0], info->lo[1], info->lo[2], info->hi[0], info->hi[1], info->hi[1]);
						};
						initialiseDimension(info, xmin, xmax, D);
						if (outlev > 3) {
								pr( logFile, "\nAFTER initDim trans: xmin=%f %f %f , xmax=%f %f %f,  \n", xmin[0], xmin[1], xmin[2], xmax[0], xmax[1], xmax[1]);
								pr( logFile, "\nAFTER initDim quat: xmin=%f %f %f %f, xmax=%f %f %f %f,  \n", xmin[3], xmin[4], xmin[5], xmin[6], xmax[3], xmax[4], xmax[5],xmax[6]);
						};

						evaluate[threadID].setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
										elec, emap, nonbondlist, ad_energy_tables, Nnb,
										B_calcIntElec, B_isGaussTorCon, B_isTorConstrained,
										B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
										ignore_inter, B_include_1_4_interactions, scale_1_4,
										unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues,xb_empirical_vdw, xb_empirical_es,
										ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
										xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
										xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
										xbempirical_ligand_xbdonor,
										xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);
						//parameterArray, unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues);

						evaluate[threadID].compute_intermol_energy(TRUE);

						//	//Initialise the Dimension of xmax, xmin using the function
						//initialiseDimension(xlo, xhi, ylo, yhi, zlo, zhi, xmin, xmax, D);


						//    evaluate.setup(crd, charge, type, natom, map, inv_spacing,
						//              elec, emap,
						//              xlo, xhi, ylo, yhi, zlo, zhi, nonbondlist, e_internal, Nnb,
						//              B_calcIntElec, q1q2, B_isGaussTorCon, B_isTorConstrained,
						//              B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, sInit, mol,
						//              B_template, template_energy, template_stddev);

						for (n_exec = 0; n_exec < n_exec_max; n_exec++)
						{
								j1 = n_exec + 1;
								(void) fprintf( logFile, "\n\n\tBEGINNING PARTICLE SWARM OPTIMIZATION\n");
								(void) fflush( logFile );
								pr(logFile, "\nRun:\t%d / %d\n", j1, n_exec_max );
								pr(logFile, "\nWorking with Constriction PSO\n");
								pr(logFile, "Date:\t");
								printdate( logFile, 2 );
								(void) fflush( logFile );
								psoStartClock = times(&tms_psoStartClock);
								// Reiterate output level...
								//pr(logFile, "Output level is set to %d.... about to invoke call_cpso:n_exec=%d, S=%d, D=%d,
								//   *xmin= %f, *xmax=%f, eval_max=%d, K=%f\n\n", outlev, n_exec, S, D, *xmin, *xmax, eval_max, K);
								//Start Particle Swarm Optimization Run
								//sHist[n_exec] = call_cpso(n_exec, sInit, S, D, xmin, xmax, eval_max, K, c1, c2, outlev,
								//					7+sInit.ntor, max_its, max_succ, max_fail, 2.0, 0.5, search_freq, rho_ptr, lb_rho_ptr);
								// swarmsize factor S is analogous to pop_size
								sHist[n_exec] = call_cpso(LocalSearchMethod, sInit, n_exec, S, D, xmin, xmax, eval_max, K, c1, c2, outlev);
								//Finished Particle Swarm Optimization Run
								psoEndClock = times(&tms_psoEndClock);
								pr(logFile, "\nRun completed. Time taken for this PSO run:\n");
								M_timesyshms(psoEndClock-psoStartClock, &tms_psoStartClock, &tms_psoEndClock);
								pr(logFile, "\n");
								printdate( logFile, 1 );
								(void) fflush(logFile);
								pr(logFile, "\nTotal number of Energy Evaluations: %lu\n", evaluate[threadID].evals() );
								pr(logFile, "Total number of Swarm moves 	  %d\n", eval_max);
								pr( logFile, "\n\n\tFINAL PARTICLE SWARM OPTIMIZATION (varCPSO-ls) DOCKED STATE\n" );
								pr( logFile,     "\t_________________________________________________________________\n\n\n" );
								//Printing the Run in PDBQ Format
								//		    writeStateOfPDBQ(n_exec , FN_ligand, dock_param_fn, lig_center,
								//        	            &(sHist[n_exec]), ntor, &eintra, &einter, natom, atomstuff,
								//                	    crd, emap, elec, charge,
								//	                    ligand_is_inhibitor,
								//        	            torsFreeEnergy,
								//                	    vt, tlist, crdpdb, nonbondlist, e_internal,
								//	                    type, Nnb, B_calcIntElec, q1q2,
								//        	            map, inv_spacing, xlo, ylo, zlo, xhi, yhi, zhi,
								//                	    B_template, template_energy, template_stddev,
								//	                    outlev);
								if(xbpmf_scoring)
										writePDBQT(n_exec, seed, FN_ligand, dock_param_fn, lig_center,
														sHist[nconf], ntor, &eintra, &einter, natom, atomstuff,
														crd, emap, elec,
														charge, abs_charge, qsp_abs_charge,
														ligand_is_inhibitor,
														torsFreeEnergy,
														vt, tlist, crdpdb, nonbondlist,
														ad_energy_tables,
														type, Nnb, B_calcIntElec,
														map,
														outlev,
														ignore_inter,
														B_include_1_4_interactions, scale_1_4, parameterArray,
														unbound_internal_FE,info, DOCKED, PDBQT_record,
														B_use_non_bond_cutoff, B_have_flexible_residues, ad4_unbound_model,
														xbPmfMapInfo->xbpmf_1d_pw_parms,xbPmfMapInfo->xbpmf_2d_hb_pw_parms,xbPmfMapInfo->xbpmf_2d_xb_pw_parms,
														xbPmfMapInfo->recep_natom,xbPmfMapInfo->recep_crdpdb,xbPmfMapInfo->recep.atomtype,xbligand.atomtype,
														xbPmfMapInfo->xbpmf_1d_map,xbPmfMapInfo->xbpmf_hb_map,xbPmfMapInfo->recep_acceptor_natom,
														xbPmfMapInfo->recep_acceptor_crdpdb,xbPmfMapInfo->recep_acceptor_atomtype,xbPmfMapInfo->xbpmf_hb_label,xbPmfMapInfo->xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbPmfMapInfo->xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
								//                ; //error xbzhang
								else
										writePDBQT( n_exec, seed,  FN_ligand, dock_param_fn, lig_center,
														sHist[nconf], ntor, &eintra, &einter, natom, atomstuff,
														crd, emap, elec, charge,
														abs_charge, qsp_abs_charge,
														ligand_is_inhibitor,
														torsFreeEnergy,
														vt, tlist, crdpdb, nonbondlist,
														ad_energy_tables,
														type, Nnb, B_calcIntElec, map,
														outlev, ignore_inter, B_include_1_4_interactions,
														scale_1_4, parameterArray, unbound_internal_FE,
														info, DOCKED, PDBQT_record, B_use_non_bond_cutoff, //@@info
														B_have_flexible_residues, ad4_unbound_model,
														xb_empirical_vdw, xb_empirical_es,
														ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
														xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
														xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
														xbempirical_ligand_xbdonor,
														xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);

								econf[nconf] = eintra + einter; // new2
								++nconf;
								pr( logFile, UnderLine );
						}
						/* PSO Work*/
						break;
#endif		
						////______________________________________________________________________________

				case DPF_ANALYSIS:
						/*
						 ** analysis
						 */
						/* _____________________________________________________________________
						 **
						 ** Perform Cluster analysis on results of docking,
						 ** _____________________________________________________________________
						 */
						/****************************
						// YTLIU_EDIT 2013.01.04
						 ****************************/
#ifdef PERF_PROFILING
						return_current_time(slaveDockInfo.analysisStartTime);
						serialStartClock = (Real) times(&tms_serialStart);

#endif
						if(xbpmf_scoring)
						{
								/*
								   analysis( Nnb, atomstuff, charge, abs_charge, qsp_abs_charge, B_calcIntElec, clus_rms_tol,
								   crdpdb, ad_energy_tables, map, econf, nruns,
								   natom, nonbondlist, nconf, ntor, sHist, FN_ligand,
								   lig_center, B_symmetry_flag, tlist, type, vt, FN_rms_ref_crds,
								   torsFreeEnergy, B_write_all_clusmem, ligand_is_inhibitor,
								   outlev,
								   ignore_inter, B_include_1_4_interactions, scale_1_4,
								   unbound_internal_FE,
								   info, B_use_non_bond_cutoff, B_have_flexible_residues,
								   B_rms_atoms_ligand_only, ad4_unbound_model,
								   xbPmfMapInfo->xbpmf_1d_pw_parms,
								   xbPmfMapInfo->xbpmf_2d_hb_pw_parms,
								   xbPmfMapInfo->xbpmf_2d_xb_pw_parms,
								   xbPmfMapInfo->recep_natom,
								   xbPmfMapInfo->recep_crdpdb,
								   xbPmfMapInfo->recep.atomtype,
								   xbligand.atomtype,
								   xbPmfMapInfo->xbpmf_1d_map,
								   xbPmfMapInfo->xbpmf_hb_map,
								   xbPmfMapInfo->recep_acceptor_natom,
								   xbPmfMapInfo->recep_acceptor_crdpdb,
								   xbPmfMapInfo->recep_acceptor_atomtype,xbPmfMapInfo->xbpmf_hb_label,xbPmfMapInfo->xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbPmfMapInfo->xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);

*/
						}
						else
								M_analysis( Nnb, atomstuff, charge, abs_charge, qsp_abs_charge, B_calcIntElec, clus_rms_tol,
												crdpdb, ad_energy_tables, map, econf, nruns,
												natom, nonbondlist, nconf, ntor, sHist, FN_ligand,
												lig_center, B_symmetry_flag, tlist, type, vt, FN_rms_ref_crds,
												torsFreeEnergy, B_write_all_clusmem, ligand_is_inhibitor,
												outlev,
												ignore_inter, B_include_1_4_interactions, scale_1_4,
												unbound_internal_FE,
												info, B_use_non_bond_cutoff, B_have_flexible_residues,
												B_rms_atoms_ligand_only, ad4_unbound_model,
												xb_empirical_vdw, xb_empirical_es,
												ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
												xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
												xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
												xbempirical_ligand_xbdonor,
												xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);

						(void) fflush(logFile);
#ifdef PERF_PROFILING
						return_current_time(slaveDockInfo.analysisEndTime);
						serialEndClock = (Real) times(&tms_serialEnd);

						serialCurrentDuration = (Real) (serialEndClock-serialStartClock) * idct;
						slaveDockInfo.analysisDuration += serialCurrentDuration;

#endif
						break;

						//______________________________________________________________________________

				case DPF_TORSDOF:
						/*
						 ** torsdof %d %f
						 */
						retval = sscanf( line, "%*s %d " FDFMT, &ntorsdof, &torsdoffac );
						if (retval == 2) {
								pr( logFile, "WARNING:  The torsional DOF coefficient is now read in from the parameter file; the value specified here (%.4lf) will be ignored.\n\n", (double)torsdoffac);
						}
						//        pr( logFile, "Number of torsional degrees of freedom = %d\n", ntorsdof);
						//        pr( logFile, "Free energy coefficient for torsional degrees of freedom = %.4f", AD4.coeff_tors);
						//        if (parameter_library_found == 1) {
						//            pr( logFile, " as specified in parameter library \"%s\".\n\n", FN_parameter_library );
						//        } else {
						//            pr( logFile, ", the factory default value.\n\n");
						//        }

						torsFreeEnergy = (Real)ntorsdof * AD4.coeff_tors;

						//        pr( logFile, "Estimated loss of torsional free energy upon binding = %+.4f kcal/mol\n\n", torsFreeEnergy);
						//        (void) fflush(logFile);
						break;

						//______________________________________________________________________________
#ifdef USE_DPF_INVESTIGATE		
				case DPF_INVESTIGATE:
						/*
						 ** Bin energies by RMSD from reference structure
						 **
						 ** investigate 100000 1000000 100
						 */
						(void) sscanf( line, "%*s %d %d %d", &OutputEveryNTests, &maxTests, &NumLocalTests );
						(void) fprintf( logFile, "OutputEveryNTests= %d\n", OutputEveryNTests);
						(void) fprintf( logFile, "maxTests= %d\n", maxTests );
						(void) fprintf( logFile, "NumLocalTests= %d\n\n", NumLocalTests );
						/****************************
						// YTLIU_EDIT 2013.01.04
						 ****************************/
						if(xbpmf_scoring)
						{
								//            (void) investigate( Nnb, charge, abs_charge, qsp_abs_charge, B_calcIntElec,
								//                            crd, crdpdb, ad_energy_tables,
								//                            maxTests,
								//                            map, natom, nonbondlist, ntor,
								//                            outlev, tlist, type, vt, B_isGaussTorCon, US_torProfile,
								//                            B_isTorConstrained, B_ShowTorE, US_TorE,
								//                            F_TorConRange, N_con, B_symmetry_flag, FN_rms_ref_crds,
								//                            OutputEveryNTests, NumLocalTests, trnStep0, torStep0,
								//                            ignore_inter,
								//                            B_include_1_4_interactions, scale_1_4,
								//                            unbound_internal_FE,
								//                            info, B_use_non_bond_cutoff, B_have_flexible_residues,
								//                xbpmf_1d_pw_parms,
								//                xbpmf_2d_hb_pw_parms,
								//                xbpmf_2d_xb_pw_parms,
								//                recep_natom,
								//                recep_crdpdb,
								//                recep.atomtype,
								//                xbligand.atomtype,
								//                xbpmf_1d_map,
								//                xbpmf_hb_map,
								//                recep_acceptor_natom,
								//                recep_acceptor_crdpdb,
								//                recep_acceptor_atomtype,xbpmf_hb_label,xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
								////////////error xbhzang
						}
						else
						{
								(void) investigate( Nnb, charge, abs_charge, qsp_abs_charge, B_calcIntElec,
												crd, crdpdb, ad_energy_tables,
												maxTests,
												map, natom, nonbondlist, ntor,
												outlev, tlist, type, vt, B_isGaussTorCon, US_torProfile,
												B_isTorConstrained, B_ShowTorE, US_TorE,
												F_TorConRange, N_con, B_symmetry_flag, FN_rms_ref_crds,
												OutputEveryNTests, NumLocalTests, trnStep0, torStep0,
												ignore_inter,
												B_include_1_4_interactions, scale_1_4,
												unbound_internal_FE,
												info, B_use_non_bond_cutoff, B_have_flexible_residues,
												xb_empirical_vdw, xb_empirical_es,
												ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
												xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
												xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
												xbempirical_ligand_xbdonor,
												xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index );
						}

						(void) fflush(logFile);
						break;
#endif		
						////______________________________________________________________________________
#ifdef USE_DPF_LIG_NOT_INHIB	
				case DPF_LIG_NOT_INHIB:
						/*
						 ** ligand_is_not_inhibitor
						 */
						ligand_is_inhibitor = 0;
						pr( logFile, "\nThis ligand is not an inhibitor, so dissociation constants (Kd) will be calculated, not inhibition constants (Ki).\n\n" );
						(void) fflush(logFile);
						break;
#endif		
						/*____________________________________________________________________________*/

				case DPF_UNBOUND_MODEL:
						/*
						 **  unbound_model { extended [energy <FLOAT>]| compact | bound }
						 **    extended is alias for "compute_unbound_extended" token
						 */
						char unbound_model_type[LINE_LEN];
						(void) sscanf( line, "%*s %s", unbound_model_type );

						if (equal( unbound_model_type, "bound", 5 )|| equal( unbound_model_type, "same_as_bound", 13 )
										|| equal( unbound_model_type, "unbound_same_as_bound", 21 )) 
						{
								if (ad4_unbound_model != Unbound_Same_As_Bound)  // default for Autodock 4.1
										M_setup_parameter_library(outlev, "Unbound_Same_As_Bound", Unbound_Same_As_Bound);
								ad4_unbound_model = Unbound_Same_As_Bound;
						} 
						else if (equal( unbound_model_type, "extended", 8 )) 
						{
								if (ad4_unbound_model != Unbound_Default) 
								{ //illegal to set extended after other
										pr( logFile, "%s:  ERROR:  Setting unbound model type twice: \"%s\" .\n",
														programname, unbound_model_type );
										//stop("");
								}
								if ( (1== sscanf( line, "%*s extended energy " FDFMT, &unbound_internal_FE )))
								{
										ad4_unbound_model = Extended;
										M_setup_parameter_library(outlev, "unbound_extended", ad4_unbound_model);
								}
								//else goto process_DPF_COMPUTE_UNBOUND_EXTENDED; // case DPF_COMPUTE_UNBOUND_EXTENDED below
						} 
						else if (equal( unbound_model_type, "compact", 6 )) {
								ad4_unbound_model = Compact;
						} 
						else 
						{
								// note that "User" is not acceptable in dpf file
								pr( logFile, "%s:  ERROR:  Unrecognized unbound model type \"%s\" .\n",
												programname, unbound_model_type );
								//stop("");
						}
						(void) fflush(logFile);
						break;
						/*____________________________________________________________________________*/

				case DPF_UNBOUND:
						/*
						 * unbound FLOAT
						 * unbound energy FLOAT
						 */
						if (ad4_unbound_model != Unbound_Default && ad4_unbound_model!= User) { //illegal to set user after other
								pr( logFile, "%s:  ERROR:  Setting unbound model type twice!\n",
												programname );
								//stop("");
						}
						if ((1!= sscanf( line, "%*s " FDFMT, &unbound_internal_FE ))
										&& (1!= sscanf( line, "%*s energy" FDFMT, &unbound_internal_FE ))){
								pr( logFile, "%s:  ERROR:  Non-numeric unbound model energy \"%s\" .\n",
												programname, line);
								//stop("");
						}
						pr(logFile, "The internal energy of the unbound state was set to %+.3lf kcal/mol\n", unbound_internal_FE);
						ad4_unbound_model = User;
						pr(logFile, "The unbound ligand energy model was set to User\n\n");
						(void) fflush(logFile);
						break;
#ifdef USE_COMPUTE_UNBOUND_EXTENDED
						/*____________________________________________________________________________*/
				case DPF_COMPUTE_UNBOUND_EXTENDED:
						/*
						 *  compute_unbound_extended
						 */
process_DPF_COMPUTE_UNBOUND_EXTENDED:
#ifdef PERF_PROFILING
						return_current_time(slaveDockInfo.UnboundExtendedStartTime);
						time(&slaveDockInfo.UnboundExtendedStartTime_t);

#endif
						if (ntor > 0) {
								(void) sprintf( message, "%s: WARNING: Using autodock4.0 unbound extended model in autodock4.2!\n", programname );
								print_2x( logFile, stderr, message );
								if (ad4_unbound_model != Unbound_Default) { //illegal to set extended after other
										pr( logFile, "%s:  ERROR:  Setting unbound model type twice!\n",
														programname );
										//stop("");
								}
								ad4_unbound_model = Extended;
								setup_parameter_library(outlev, "unbound_extended", ad4_unbound_model);

								//            pr(logFile, "Computing the energy of the unbound state of the ligand,\ngiven the torsion tree defined in the ligand file.\n\n");
								//            (void) fflush( logFile );

								// The initial goal is to obtain an extended conformation of the ligand.

								// Step 0 // {
								//
								// Set termination criteria for unbound calculations
								// -------------------------------------------------
								//
								// Set the maximum number of energy evaluations for finding the unbound conformation
								// if num_evals is less than this, then a shorter unbound docking will be performed
								max_evals_unbound = 1000000; // 1 million
								num_evals_unbound = num_evals > max_evals_unbound ?  max_evals_unbound :  num_evals;
								// end of Step 0 // }

								// Step 1 // {
								//
								// Run a hybrid global-local search using the unbound energy tables (set to be repulsive-only)
								// -------------------------------------------------------------------------------------------
								//
								//  *  Turn off the use of the non-bond cutoff
								//  *  Turn off internal electrostatics
								//  *  Turn off intermolecular energy calculations
								// TODO Do not translate or rotate the ligand in unbound searches
								//
								/*
								 *  Genetic Algorithm-Local search,  a.k.a.
								 *  Lamarckian Genetic Algorithm
								 */
								if ((GlobalSearchMethod==NULL)||(LocalSearchMethod==NULL)) {
										prStr(error_message, "%s:  ERROR:  You must use \"set_ga\" to allocate both Global Optimization object AND Local Optimization object.\n", programname);
										//stop(error_message);
										slaveExit(-1);
								}
								exit_if_missing_elecmap_desolvmap_about("compute_unbound_extended");

								//
								// Do not use a non-bond cutoff, this helps to produce the "most" extended conformation
								// especially with long inhibitors
								B_use_non_bond_cutoff = FALSE;
								//
								// Save the current value of B_calcIntElec, so we can restore it later.
								B_calcIntElec_saved = B_calcIntElec;
								//
								// Set the calculation of internal electrostatics to FALSE:
								// B_calcIntElec = FALSE;
								//
								// Assume the unbound state of the receptor is the same as the input coordinates from the
								// flexible residues file.  This means we must not change the rotatable bonds in the
								// flexible residues of the receptor during the unbound extended search.
								// We can turn off rotation of the flexres by setting ntor to ntor_ligand.
								// Save the current value of "ntor" in the "sInit" state variable, set it to number of torsions
								// in the ligand for the unbound extended search, then restore it afterwards.
								saved_sInit_ntor = sInit.ntor;
								sInit.ntor = ntor_ligand;
								//
								// Use the repulsive unbound energy tables, "unbound_energy_tables",
								// to drive the molecule into an extended conformation
								evaluate[threadID].setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
												elec, emap, nonbondlist, unbound_energy_tables, Nnb,
												B_calcIntElec, B_isGaussTorCon, B_isTorConstrained,
												B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
												ignore_inter,
												B_include_1_4_interactions, scale_1_4,
												unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues,xb_empirical_vdw, xb_empirical_es,
												ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
												xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
												xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
												xbempirical_ligand_xbdonor,
												xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);
								//parameterArray, unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues);
								//
								// Turn off computing the intermolecular energy, we will only consider the intramolecular energy
								// to determine the unbound state of the flexible molecule:
								evaluate[threadID].compute_intermol_energy(FALSE);
								//
								//            (void) fprintf( logFile, "\n\n\tBEGINNING COMPUTATION OF UNBOUND EXTENDED STATE USING LGA\n");
								//            (void) fprintf( logFile,     "\t_________________________________________________________\n\n\n");
								//            (void) fflush( logFile );
								//
								//            pr(logFile, "Date:\t");
								//            printdate( logFile, 2 );
								//            (void) fflush( logFile );
								gaStart = times( &tms_gaStart );
								//  Can get rid of the following line
								((Genetic_Algorithm *)GlobalSearchMethod)->initialize(pop_size, 7+sInit.ntor);
								//
								// Start Lamarckian GA run searching only torsions -- Unbound simulation
								// sUnbound_ext = call_glss_tors( GlobalSearchMethod, LocalSearchMethod,
								sUnbound_ext = call_glss( GlobalSearchMethod, LocalSearchMethod,
												sInit,
												num_evals_unbound, pop_size,
												outlev,
												outputEveryNgens, &ligand,
												// B_RandomDihe0, // use this line with call_glss_tors()
												B_RandomTran0, B_RandomQuat0, B_RandomDihe0,
												info, FN_pop_file, end_of_branch );
								// State of best individual at end of GA-LS run, sUnbound_ext, is returned.
								// Finished Lamarckian GA run
								gaEnd = times( &tms_gaEnd );
								//            pr( logFile, "\nFinished Lamarckian Genetic Algorithm (LGA), time taken:\n");
								//            timesyshms( gaEnd - gaStart, &tms_gaStart, &tms_gaEnd );
								//            pr( logFile, "\n");
								//            printdate( logFile, 1 );
								//            (void) fflush( logFile );
								//            pr(logFile, "\nTotal number of Energy Evaluations: %lu\n", evaluate.evals() );
								//            pr(logFile, "Total number of Generations:        %u\n", ((Genetic_Algorithm *)GlobalSearchMethod)->num_generations());
								// end of Step 1 // }

								// Step 2 // {
								//
								// Do a short local search using the standard internal energy tables
								// -----------------------------------------------------------------
								//
								// turn on internal electrostatics
								// but keep intermolecular energy calculations off
								//
								// Turn on calculation of internal electrostatics:
								//// B_calcIntElec = TRUE;
								//
								// Use the standard AutoDock energy tables to compute the internal energy
								// Use this value to set unbound_internal_FE
								//// evaluate.setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
								//// elec, emap, nonbondlist, ad_energy_tables, Nnb,
								//// B_calcIntElec, B_isGaussTorCon, B_isTorConstrained,
								//// B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
								//// ignore_inter,
								//// B_include_1_4_interactions, scale_1_4,
								//// unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues);
								//
								// --- Start Local Search ---
								//// pr( logFile, "\nPerforming local search using standard AutoDock scoring function\n" );
								//// pr( logFile, "\nUsing UnboundLocalSearchMethod = new Solis_Wets1(7+sInit.ntor, 300, 4, 4, 1., 0.01, 2., 0.5, 1.);\n\n" );
								// Create a local search object
								// * Use an initial rho value of 0.1 (default is set in DPF by "sw_rho 1.0")
								//   to ensure smaller, 'more local' steps.
								// * Use a search frequency of 1.0 (default is set in DPF by "ls_search_freq 0.06")
								//// unsigned int ls_pop_size = 150;
								// max_its = 300
								// max_succ = 4
								// max_fail = 4
								// rho = 1.
								// lb_rho = 0.01
								// expansion = 2.
								// contraction = 0.5
								// search_freq = 1.
								//// UnboundLocalSearchMethod = new Solis_Wets1(7+sInit.ntor, 300, 4, 4, 1., 0.01, 2., 0.5, 1.);
								// Perform a local search, using the standard AutoDock 4 scoring function
								//// sUnbound_ls = call_ls( UnboundLocalSearchMethod, sUnbound_ext, ls_pop_size, &ligand );
								//// // sUnbound_ext = sUnbound_ls; // if you want to update sUnbound_ext to be sUnbound_ls...
								// --- Finished Local Search ---
								// end of Step 2 // }

								// Step 3 // {
								//
								// Restore the AutoDock 4 force field for docking
								// ----------------------------------------------
								//
								// Remember to turn on the use of the non-bond cutoff
								B_use_non_bond_cutoff = TRUE;
								//
								// Restore the setting for calculation of internal electrostatics to the saved value:
								B_calcIntElec = B_calcIntElec_saved;
								//
								// Restore the number of torsions in the state variables "sInit" and "sUnbound_ext"
								sInit.ntor = saved_sInit_ntor;
								sUnbound_ext.ntor = saved_sInit_ntor;
								//
								// Use the standard AutoDock energy tables to compute the internal energy
								// Use this value to set unbound_internal_FE
								evaluate[threadID].setup( crd, charge, abs_charge, qsp_abs_charge, type, natom, map,
												elec, emap, nonbondlist, ad_energy_tables, Nnb,
												B_calcIntElec, B_isGaussTorCon, B_isTorConstrained,
												B_ShowTorE, US_TorE, US_torProfile, vt, tlist, crdpdb, crdreo, sInit, ligand,
												ignore_inter,
												B_include_1_4_interactions, scale_1_4,
												unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues,xb_empirical_vdw, xb_empirical_es,
												ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
												xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
												xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
												xbempirical_ligand_xbdonor,
												xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);
								//parameterArray, unbound_internal_FE, info, B_use_non_bond_cutoff, B_have_flexible_residues);
								// end of Step 3 // }

								// Step 4 // {
								//
								// Compute the energy of the unbound extended state
								// ------------------------------------------------
								//
								// Convert from unbound state to unbound coordinates
								cnv_state_to_coords( sUnbound_ext, vt, tlist, sUnbound_ext.ntor, crdpdb, crd, natom );
								//
								// Calculate the unbound internal energy using the standard AutoDock energy function
								(void) eintcalPrint(nonbondlist, ad_energy_tables, crd, Nnb, B_calcIntElec, B_include_1_4_interactions, scale_1_4, qsp_abs_charge, B_use_non_bond_cutoff, B_have_flexible_residues);
								//
								// eintcal() and eintcalPrint() set the values of the hideously-global nb_group_energy[]
								unbound_ext_internal_FE = nb_group_energy[INTRA_LIGAND] + nb_group_energy[INTRA_RECEPTOR];
								//
								//            pr(logFile, "\n\nThe internal energy of the unbound extended state was computed to be %+.3lf kcal/mol\n\n", unbound_ext_internal_FE);
								// end of Step 4 // }

								// Step 5 // {
								//
								// Decide whether to use extended or AutoDock state for unbound state
								// ------------------------------------------------------------------
								//
								if (unbound_ext_internal_FE > 0.0) {
										// Unbound extended state has an internal energy that is positive

										// Step 5.1 // {
										//
										// Repeat Step 1 with the standard AutoDock internal energy potentials
										//
										// Run a hybrid global-local search using the autodock energy tables
										// -----------------------------------------------------------------
										//
										//  *  Turn off the use of the non-bond cutoff
										//  *  Turn off internal electrostatics
										//  *  Turn off intermolecular energy calculations
										// TODO Do not translate or rotate the ligand in unbound searches
										//
										/*
										 *  Genetic Algorithm-Local search,  a.k.a.
										 *  Lamarckian Genetic Algorithm
										 */
										(void) fprintf( logFile, "\n\n\tBEGINNING COMPUTATION OF UNBOUND AUTODOCK STATE USING LGA\n");
										(void) fprintf( logFile,     "\t_________________________________________________________\n\n\n");
										(void) fflush( logFile );
										//
										pr(logFile, "Date:\t");
										printdate( logFile, 2 );
										(void) fflush( logFile );
										gaStart = times( &tms_gaStart );
										//  Can get rid of the following line
										((Genetic_Algorithm *)GlobalSearchMethod)->initialize(pop_size, 7+sInit.ntor);
										//
										// Start Lamarckian GA run searching only torsions -- Unbound simulation
										// sUnbound_ad = call_glss_tors( GlobalSearchMethod, LocalSearchMethod,
										sUnbound_ad = call_glss( GlobalSearchMethod, LocalSearchMethod,
														sInit,
														num_evals_unbound, pop_size,
														outlev,
														outputEveryNgens, &ligand,
														B_RandomTran0, B_RandomQuat0, B_RandomDihe0,
														info, FN_pop_file, end_of_branch );
										// State of best individual at end of GA-LS run, sUnbound_ad, is returned.
										// Finished Lamarckian GA run
										gaEnd = times( &tms_gaEnd );
										pr( logFile, "\nFinished Lamarckian Genetic Algorithm (LGA), time taken:\n");
										M_timesyshms( gaEnd - gaStart, &tms_gaStart, &tms_gaEnd );
										pr( logFile, "\n");
										printdate( logFile, 1 );
										(void) fflush( logFile );
										pr(logFile, "\nTotal number of Energy Evaluations: %lu\n", evaluate[threadID].evals() );
										pr(logFile, "Total number of Generations:        %u\n", ((Genetic_Algorithm *)GlobalSearchMethod)->num_generations());
										// Restore the number of torsions in the state variable "sUnbound_ad"
										sUnbound_ad.ntor = saved_sInit_ntor;
										// end of Step 5.1 // }

										// Step 5.2 // {
										//
										// Compute the energy of the unbound AutoDock state
										// ------------------------------------------------
										//
										// Convert from unbound state to unbound coordinates
										cnv_state_to_coords( sUnbound_ad, vt, tlist, sUnbound_ad.ntor, crdpdb, crd, natom );
										//
										// Calculate the unbound internal energy using the standard AutoDock energy function
										(void) eintcalPrint(nonbondlist, ad_energy_tables, crd, Nnb, B_calcIntElec, B_include_1_4_interactions, scale_1_4, qsp_abs_charge, B_use_non_bond_cutoff, B_have_flexible_residues);
										//
										// eintcal() and eintcalPrint() set the values of the hideously-global nb_group_energy[]
										unbound_ad_internal_FE = nb_group_energy[INTRA_LIGAND] + nb_group_energy[INTRA_RECEPTOR];
										//
										pr(logFile, "\n\nThe internal energy of the unbound AutoDock state was computed to be %+.3lf kcal/mol\n\n", unbound_ad_internal_FE);
										// end of Step 5.2 // }

										if (unbound_ad_internal_FE < unbound_ext_internal_FE) {
												pr(logFile, "NOTE:   The AutoDock internal energy of the \"extended\" state was higher\nNOTE:   than that of the state obtained by searching using the AutoDock internal\nNOTE:   energy potentials.\nNOTE:   The unbound state was set to the AutoDock optimum state, not the \"extended\" state.\n\n");
												unbound_internal_FE = unbound_ad_internal_FE;
												sUnbound = sUnbound_ad;
										} else {
												pr(logFile, "NOTE:   Although the AutoDock internal energy of the \"extended\" state was positive, it was lower\nNOTE:   than that of the state obtained by searching using the AutoDock internal\nNOTE:   energy potentials.\nNOTE:   The unbound state was set to the \"extended\" state.\n\n");
												unbound_internal_FE = unbound_ext_internal_FE;
												sUnbound = sUnbound_ext;
										}
								} else {
										// Unbound extended state has an internal energy that is negative
										unbound_internal_FE = unbound_ext_internal_FE;
										sUnbound = sUnbound_ext;
										pr(logFile, "NOTE:   The AutoDock internal energy of the \"extended\" state was negative.\n\nNOTE:   The unbound state was set to the \"extended\" state.\n\n");
								}
								//
								pr(logFile, "\n\nThe internal energy of the unbound state was set to %+.3lf kcal/mol\n\n", unbound_internal_FE);
								// end of Step 5 // }

								// Step 6 // {
								//
								// Convert from unbound state to unbound coordinates
								cnv_state_to_coords( sUnbound, vt, tlist, sUnbound.ntor, crdpdb, crd, natom );
								// end of Step 6 // }

								// Step 7 // {
								//
								// Output the coordinates of the unbound state
								pr( logFile, "\n\n\tFINAL UNBOUND STATE\n" );
								pr( logFile,     "\t___________________\n\n\n" );
								//
								if(xbpmf_scoring)
										writePDBQT(-1, seed, FN_ligand, dock_param_fn, lig_center,
														sUnbound, ntor, &eintra, &einter, natom, atomstuff,
														crd, emap, elec,
														charge, abs_charge, qsp_abs_charge,
														ligand_is_inhibitor,
														torsFreeEnergy,
														vt, tlist, crdpdb, nonbondlist,
														ad_energy_tables,
														type, Nnb, B_calcIntElec,
														map,
														outlev,
														ignore_inter,
														B_include_1_4_interactions, scale_1_4, parameterArray,
														unbound_internal_FE,info, DOCKED, PDBQT_record,
														B_use_non_bond_cutoff, B_have_flexible_residues, ad4_unbound_model,
														xbPmfMapInfo->xbpmf_1d_pw_parms,xbPmfMapInfo->xbpmf_2d_hb_pw_parms,xbPmfMapInfo->xbpmf_2d_xb_pw_parms,
														xbPmfMapInfo->recep_natom,xbPmfMapInfo->recep_crdpdb,xbPmfMapInfo->recep.atomtype,xbligand.atomtype,
														xbPmfMapInfo->xbpmf_1d_map,xbPmfMapInfo->xbpmf_hb_map,xbPmfMapInfo->recep_acceptor_natom,
														xbPmfMapInfo->recep_acceptor_crdpdb,xbPmfMapInfo->recep_acceptor_atomtype,xbPmfMapInfo->xbpmf_hb_label,xbPmfMapInfo->xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,xbPmfMapInfo->xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,xbpmf_receptor_hb_acceptor);
								//            ; //error xbzhang
								else
										writePDBQT( -1, seed,  FN_ligand, dock_param_fn, lig_center,
														sUnbound, ntor, &eintra, &einter, natom, atomstuff,
														crd, emap, elec,
														charge, abs_charge, qsp_abs_charge,
														ligand_is_inhibitor,
														torsFreeEnergy,
														vt, tlist, crdpdb, nonbondlist,
														ad_energy_tables,
														type, Nnb, B_calcIntElec,
														map,
														outlev,
														ignore_inter,
														B_include_1_4_interactions, scale_1_4, parameterArray, unbound_internal_FE,
														info, UNBOUND, PDBQT_record, B_use_non_bond_cutoff, B_have_flexible_residues, ad4_unbound_model,xb_empirical_vdw, xb_empirical_es,
														ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
														xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
														xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
														xbempirical_ligand_xbdonor,
														xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);
								// end of Step 7 // }

								// Step 8 // {
								//
								// Remember to reset the energy evaluator back to computing the intermolecular energy between
								// the flexible and the rigid molecules.
								evaluate[threadID].compute_intermol_energy(TRUE);
								// end of Step 8 // }

						} else {
								pr(logFile, "NOTE:  AutoDock cannot compute the energy of the unbound state, since the ligand is rigid.\n\n");
								pr(logFile, "NOTE:  Use the \"unbound energy\" command to set the energy of the unbound state, if known from a previous calculation where the ligand was treated as flexible.\n\n");
								unbound_internal_FE = 0.0L;
								ad4_unbound_model = User;
								pr(logFile, "\n\nThe internal energy of the unbound state was set to %+.3lf kcal/mol\n\n", unbound_internal_FE);
						}

						pr( logFile, UnderLine );
						(void) fflush(logFile);
#ifdef PERF_PROFILING
						return_current_time(slaveDockInfo.UnboundExtendedEndTime);
						time(&slaveDockInfo.UnboundExtendedEndTime_t);

#endif
						break;
#endif		
						/*____________________________________________________________________________*/
#ifdef USE_DPF_EPDB		
				case DPF_EPDB:
						/*
						 *  epdb
						 *
						 *  Computes the energy of the ligand specified by the "move lig.pdbqt" command.
						 *  Return the energy of the Small Molecule.
						 *  FN_ligand must be in   PDBQT-format;
						 *  flag can be:-
						 *  0 = NEW, or   PDBQT-71, and
						 *  1 = OLD, or   PDBQT-55 (old PDBq format).
						 */
						outside = FALSE;
						atoms_outside = FALSE;
						eintra = 0.0L;
						einter = 0.0L;
						etotal = 0.0L;

						pr(logFile, "WARNING This command, \"epdb\", currently computes the energy of the ligand specified by the \"move lig.pdbqt\" command.\n");
						retval = sscanf(line, "%*s %s", dummy_FN_ligand);
						if (retval >= 1) {
								pr(logFile, "WARNING  -- it will not read in the PDBQT file specified on the \"epdb\" command line.\n");
						}

						/*
						   (void) sscanf(line, "%*s %s", FN_ligand);
						   pr(logFile, "epdb %s\n\n", FN_ligand);
						   natom = 0;
						   print_1_4_message(logFile, B_include_1_4_interactions, scale_1_4);
						//
						ligand = ( line,
						num_atom_types,
						&natom,
						crdpdb, crdreo, charge, &B_haveCharges,
						type, bond_index,
						pdbaname, FN_ligand, FN_flexres, B_have_flexible_residues, atomstuff, &n_heavy_atoms_in_ligand,
						&B_constrain_dist, &atomC1, &atomC2,
						&sqlower, &squpper,
						&ntor1, &ntor, &ntor_ligand,
						tlist, vt,
						&Nnb, nonbondlist,
						jobStart, tms_jobStart, hostnm, &ntorsdof, outlev,
						ignore_inter,
						B_include_1_4_interactions,
						readPDBQTatoms, PDBQT_record, end_of_branch );

						//
						// pre-calculate some values we will need later in computing the desolvation energy
						//
						for (i=0; i<natom; i++) {
						abs_charge[i] = fabs(charge[i]);
						qsp_abs_charge[i] = qsolpar * abs_charge[i];
						}
						*/
						exit_if_missing_elecmap_desolvmap_about("epdb");

						// to restore the original coordinates, we must temporarily undo the centering transformation
						for ( i=0; i<true_ligand_atoms; i++ ) {
								for (xyz = 0;  xyz < SPACE;  xyz++) {
										crdpdb[i][xyz] += lig_center[xyz];
								}
						}
						// determine if any atoms are outside the grid box
						atoms_outside = FALSE;
						for (i=0; i<natom; i++) {
								outside = is_out_grid_info(crdpdb[i][X], crdpdb[i][Y], crdpdb[i][Z]);
								if (outside) {
										atoms_outside = TRUE;
										(void) sprintf( message, "%s: WARNING: Atom %d (%.3f, %.3f, %.3f) is outside the grid!\n", programname, i+1, crdpdb[i][X], crdpdb[i][Y], crdpdb[i][Z] );
										print_2x( logFile, stderr, message );
										outside = FALSE; /* Reset outside */
								}
						}
						pr(logFile, "Number of \"true\" ligand atoms:  %d\n", true_ligand_atoms);
						//
						for (i=0;i<natom;i++) {
								if (ignore_inter[i] == 1) {
										pr(logFile, "Special Boundary Conditions:\n");
										pr(logFile, "____________________________\n\n");
										pr(logFile, "AutoDock will ignore the following atoms in the input PDBQT file \nin intermolecular energy calculations:\n");
										pr(logFile, "\n(This is because these residue atoms are at the boundary between \nflexible and rigid, and since they cannot move \nthey will not affect the total energy.)\n\n");
										break;
								}
						}
						for (i=0;i<natom;i++) {
								if (ignore_inter[i] == 1) {
										pr(logFile, "Atom number %d:  %s\n", i+1, atomstuff[i] );
								}
						}
						pr(logFile, "\n");

						sInit.ntor = ligand.S.ntor;

						// save any currently-computed unbound internal FE
						//unbound_internal_FE_saved = unbound_internal_FE;
						//ad4_unbound_model_saved = ad4_unbound_model;
						//ad4_unbound_model = User;

						// Initialise to zero, since we may call "epdb" more than once in a single DPF
						// Set the unbound free energy -- assume it is zero, since this is a "single-point energy calculation"
						unbound_internal_FE = 0.0;

						// Calculate the internal energy
						if (ntor > 0) {
								(void) eintcalPrint(nonbondlist, ad_energy_tables, crdpdb, Nnb, B_calcIntElec, B_include_1_4_interactions, scale_1_4, qsp_abs_charge, B_use_non_bond_cutoff, B_have_flexible_residues);
						}

						pr(logFile, "Unbound model to be used is %s.\n", report_parameter_library());
						// calculate the energy breakdown for the input coordinates, "crdpdb"
						if(xbpmf_scoring)
								eb = calculateBindingEnergies( ntor, nonbondlist, ad_energy_tables, Nnb,
												B_calcIntElec, B_include_1_4_interactions, scale_1_4,
												qsp_abs_charge, B_use_non_bond_cutoff, natom,
												B_have_flexible_residues, crdpdb, outside, info,
												xbPmfMapInfo->xbpmf_1d_pw_parms,xbPmfMapInfo->xbpmf_2d_hb_pw_parms,
												xbPmfMapInfo->xbpmf_2d_xb_pw_parms,xbPmfMapInfo->xbpmf_1d_map,xbPmfMapInfo->xbpmf_hb_map,
												xbPmfMapInfo->recep_acceptor_natom,xbPmfMapInfo->recep_acceptor_crdpdb,
												xbPmfMapInfo->recep_acceptor_atomtype,xbPmfMapInfo->recep_natom, xbPmfMapInfo->recep_crdpdb,
												xbPmfMapInfo->recep.atomtype, xbligand.atomtype,xbPmfMapInfo->xbpmf_hb_label,
												xbPmfMapInfo->xbpmf_xb_label,xbpmf_ligand_hb_donorH_ids,
												xbpmf_ligand_xb_donorX_id,xbpmf_ligand_at_index,
												xbPmfMapInfo->xbpmf_receptor_at_index,xbpmf_ligand_hb_acceptor,
												xbpmf_ligand_hb_donor,xbpmf_ligand_xb_donor,
												xbpmf_receptor_hb_acceptor ,ad4_unbound_model);
						//    ; //error xbzhang
						else
								eb = calculateBindingEnergies( natom, ntor, unbound_internal_FE, torsFreeEnergy,
												B_have_flexible_residues, crdpdb, charge, abs_charge, type, map,
												info, outside,ignore_inter, elec, emap, &elec_total, &emap_total,
												nonbondlist, ad_energy_tables, Nnb, B_calcIntElec,
												B_include_1_4_interactions, scale_1_4, qsp_abs_charge,
												B_use_non_bond_cutoff, ad4_unbound_model,
												xb_empirical_vdw, xb_empirical_es,
												ad_vdw, ad_es, ad_desolv, xbEmpiricalMapInfo->xb_vdw_profile, xbEmpiricalMapInfo->xb_es_profile,
												xbEmpiricalMapInfo->xb_desolv_profile, xbEmpiricalMapInfo->xbempirical_parms, halogen_found,
												xbEmpiricalMapInfo->xbempirical_recep_crdpdb,
												xbempirical_ligand_xbdonor,
												xbEmpiricalMapInfo->xbempirical_receptor_acceptor_index);

						if(xbpmf_scoring==0)
						{
								pr(logFile, "\n\n\t\tIntermolecular Energy Analysis\n");
								pr(logFile,     "\t\t==============================\n\n");
								pr(logFile, "Atom  vdW+Hb+Elec  vdW+Hbond  Electrosta  Partial          Coordinates         \n");
								if(xb_empirical_scoring)
										pr(logFile, "Type  +XB Energy   +XB Energy tic Energy  Charge      x         y         z    \n");
								else
										pr(logFile, "Type    Energy      Energy    tic Energy  Charge      x         y         z    \n");
								pr(logFile, "____  __________  __________  __________  _______  ________  ________  ________\n");
								//          "1234  0123456789  0123456789  0123456789  1234567  12345678  12345678  12345678"

								charge_total = 0.;
								etot = 0.;
								for (i = 0;  i < natom;  i++) {
										etot = emap[i] + elec[i];
										pr(logFile, "%4d  %10.2f  %10.2f  %10.2f  %7.3f  %8.4f  %8.4f  %8.4f\n", (type[i]+1), etot, emap[i], elec[i], charge[i], crdpdb[i][X], crdpdb[i][Y], crdpdb[i][Z]);
										charge_total += charge[i];
								} /*i*/
								pr(logFile, "      __________  __________  __________  _______\n");
								pr(logFile, "Total %10.2lf  %10.2lf  %10.2lf  %7.3lf\n",        (double)(emap_total + elec_total), (double)emap_total, (double)elec_total, (double)charge_total);
								pr(logFile, "      __________  __________  __________  _______\n");
								pr(logFile, "      vdW+Hb+Elec  vdW+Hbond  Electrosta  Partial\n");
								if(xb_empirical_scoring)
										pr(logFile, "      +XB Energy   +XB Energy tic Energy  Charge\n\n");
								else
										pr(logFile, "        Energy      Energy    tic Energy  Charge\n\n");

								if(xb_empirical_scoring){
										pr(logFile, "Total Intermolecular Interaction Energy   = %+.3lf kcal/mol\n", (double)(eb.e_inter + eb.e_intra) );
										pr(logFile, "Total Intermolecular vdW + HB + XB Energy = %+.3lf kcal/mol\n", (double)emap_total);
								}
								else{
										pr(logFile, "Total Intermolecular Interaction Energy   = %+.3lf kcal/mol\n", (double)(eb.e_inter + eb.e_intra) );
										pr(logFile, "Total Intermolecular vdW + Hbond Energy   = %+.3lf kcal/mol\n", (double)emap_total);
								}
								pr(logFile, "Total Intermolecular Electrostatic Energy = %+.3lf kcal/mol\n\n\n", (double)elec_total);
						}

						printEnergies( &eb, "epdb: USER    ", ligand_is_inhibitor, emap_total, elec_total, B_have_flexible_residues, ad4_unbound_model );
						pr(logFile, "\n");

						// remember to re-center the ligand
						for ( i=0; i<true_ligand_atoms; i++ ) {
								for (xyz = 0;  xyz < SPACE;  xyz++) {
										crdpdb[i][xyz] -= lig_center[xyz];
								}
						}

						// restore the saved unbound internal FE
						//unbound_internal_FE = unbound_internal_FE_saved;
						//ad4_unbound_model = ad4_unbound_model_saved;

						(void) fflush(logFile);
						break;
#endif
						/*____________________________________________________________________________*/

				case DPF_TERMINATION:
						/*
						 *  ga_termination energy 0.1
						 *  ga_termination evals 25000  // the best energy did not change in this time
						 *  ga_termination time 120 s
						 */
						/*
						   (void) sscanf( line, "%*s %d", &i );
						   */
						(void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/

				case GA_CROSSOVER_MODE:
						/*
						 * ga_crossover_mode OnePt
						 * ga_crossover_mode TwoPt
						 * ga_crossover_mode Uniform
						 * ga_crossover_mode Arithmetic
						 *
						 * Xover_Mode c_mode = OnePt;  //  can be: OnePt, TwoPt, Uniform or Arithmetic
						 */
						(void) sscanf( line, "%*s %s", c_mode_str );
						if (strcmp(c_mode_str, "onept") == 0) {
								c_mode = OnePt;
								pr(logFile, "One-point crossover will be used in GA and LGA searches.\n");
						} else if (strcmp(c_mode_str, "twopt") == 0) {
								c_mode = TwoPt;
								pr(logFile, "Two-point crossover will be used in GA and LGA searches.\n");
						} else if (strcmp(c_mode_str, "uniform") == 0) {
								c_mode = Uniform;
								pr(logFile, "Uniform crossover will be used in GA and LGA searches.\n");
						} else if (strcmp(c_mode_str, "arithmetic") == 0) {
								c_mode = Arithmetic;
								pr(logFile, "Arithmetic crossover will be used in GA and LGA searches.\n");
						} else if (strcmp(c_mode_str, "branch") == 0) {
								c_mode = Branch;
								pr(logFile, "Branch crossover will be used in GA and LGA searches.\n");
						} else {
								c_mode = TwoPt; // default
						}
						(void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/

				case GA_TOURNAMENT_SELECTION:
						/*
						 * ga_tournament_selection
						 */

						// M Pique - does not appear to work so disabling for now (Oct 2009)
						//s_mode = Tournament;
						//pr(logFile, "Tournament selection will be used in GA and LGA searches.\n");
						prStr( error_message, "%s:  ERROR! Tournament selection is not yet implemented! Instead proportional selection will be used in GA and LGA searches\n\n", programname);
						pr_2x( logFile, stderr, error_message );
						s_mode = Proportional;
						(void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/

				case GA_LINEAR_RANKING_SELECTION:
						/*
						 * ga_linear_ranking_selection [probability_ratio Real]
						 */

						(void) sscanf( line, "%*s %s", c_mode_str );
						if (strcmp(c_mode_str, "probability_ratio") == 0){
								(void) sscanf( line, "%*s %*s %f", &linear_ranking_selection_probability_ratio);
						}

						s_mode = LinearRanking;
						pr(logFile, "Linear ranking selection will be used in GA and LGA searches.\n");
						(void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/

				case GA_PROPORTIONAL_SELECTION:
						/*
						 * ga_proportional_selection
						 */

						s_mode = Proportional;
						pr(logFile, "Proportional selection will be used in GA and LGA searches.\n");
						(void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/

				case GA_BOLTZMAN_SELECTION:
						/*
						 * ga_boltzman_selection
						 */

						prStr( error_message, "%s:  ERROR! Boltzman selection is not yet implemented! Instead proportional selection will be used in GA and LGA searches\n\n", programname);
						pr_2x( logFile, stderr, error_message );
						s_mode = Proportional;
						(void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/


				case DPF_POPFILE:
						/*
						 *  output_pop_file
						 *
						 *  Used to write out the population to a file at the end of
						 *  every GA.
						 */
						(void) sscanf( line, "%*s %s", FN_pop_file);
						(void) fflush(logFile);
						pr( logFile, "The population will be written to the file \"%s\" at the end of every generation.\n", FN_pop_file);
						break;

						/*____________________________________________________________________________*/
#ifdef USE_CONFSAMPLER		
				case DPF_CONFSAMPLER:
						/*
						 * confsampler
						 *
						 * Scan a region around conformations saved in sHist array.
						 *
						 */

						(void) sscanf( line, "%*s %s %d", confsampler_type, &confsampler_samples);
						pr( logFile, "Scanning local regions around each docked conformation.\n");

						exit_if_missing_elecmap_desolvmap_about("confsampler");

						if (strcmp(confsampler_type, "systematic") == 0) {
								systematic_conformation_sampler(sHist, nconf, vt, crdpdb, tlist, lig_center, natom, type, info);
						}

						else {
								random_conformation_sampler(sHist, nconf, confsampler_samples, vt, crdpdb, tlist, lig_center, natom, type, info);
						}
						(void) fflush(logFile);

						break;
#endif
						/*____________________________________________________________________________*/

				case DPF_COPYRIGHT:
						/*
						 * 'copyright' to show the Gnu GPL copyright
						 */
						//        show_copyright(logFile);
						//        (void) fflush(logFile);
						break;

						/*____________________________________________________________________________*/

				case DPF_WARRANTY:
						/*
						 * 'warranty' to show the Gnu GPL warranty
						 */
						//        show_warranty(logFile);
						//        (void) fflush(logFile);
						break;

						/*_12yy_______________________________________________________________________*/

				case DPF_:
						/*
						 *
						 */
						/*
						   (void) sscanf( line, "%*s %d", &i );
						   (void) fflush(logFile);
						   break;
						   */

						//______________________________________________________________________________

				default:
						printf("line:%s\n",line);
						/*
						 **  Do nothing...
						 */
						break;

						//______________________________________________________________________________

		} /* switch( dpf_keyword ) */

} /* while PARSING-DPF parFile */
#ifdef PERF_PROFILING
return_current_time(slaveDockInfo.SlaveMainPostLGATime);

#endif
/* __________________________________________________________________________
 **
 ** Close the docking parameter file...
 ** __________________________________________________________________________
 */
//pr( logFile, ">>> Closing the docking parameter file (DPF)...\n\n" );
//pr( logFile, UnderLine );
(void) fclose( parFile );

#ifdef AUTODOCK_MPI
// pkcoff: change to support unduplicated map file loading
if (mapusagetype == RELOAD_MAPS)
{
		free(info);
		if(xb_empirical_scoring){
				free(xbEmpiricalMapInfo);
		}
		if(xbpmf_scoring)
		{
				free(xbPmfMapInfo);
		}
}
free(ad_energy_tables);
free(unbound_energy_tables);

#endif

//______________________________________________________________________________
/*
 ** Print the time and date when the docking has finished...
 */

pr( logFile, "This docking finished at:\t\t\t" );
M_printdate( logFile, 1 );
pr( logFile, "\n\n\n" );

//success( hostnm, jobStart, tms_jobStart );

if(write_stateFile){
		fprintf(stateFile,"</autodock>\n");
		(void) fclose( stateFile );
}
(void) fclose( logFile );

// delete arrays
delete []nonbondlist;


//________________________________________________________________________________
/*
 ** End of Boinc
 */
#ifdef BOINCCOMPOUND
boinc_fraction_done(1.);
#endif
#ifdef BOINC
boinc_finish(0);       /* should not return */
#endif

#ifdef PERF_PROFILING

return_current_time(slaveDockInfo.slaveMainEndTime);
time(&slaveDockInfo.slaveMainEndTime_t);

#endif
ProgEnd=time(NULL);
Progduration=ProgEnd-ProgStart;
MICduration=MICEnd-MICStart;
printf("Compute time:%ld\nProgram time:%ld\n",MICduration,Progduration);
return 0;

} /* END OF PROGRAM */

/* AutoDock main private utility functions
*/
static void exit_if_missing_elecmap_desolvmap_about(char* keyword)
{

		char error_message[LINE_LEN];

		if (xbpmf_scoring==0 && !B_found_elecmap) {
				prStr(error_message, "%s:  %s command: no \"elecmap\" command has been specified!\n", programname, keyword);
				printf(error_message);fflush(0);
				slaveExit(-1);
		} else if (xbpmf_scoring==0 && !B_found_desolvmap) {
				prStr(error_message, "%s:  %s command: no \"desolvmap\" command has been specified!\n", programname, keyword);
				printf(error_message);fflush(0);
				slaveExit(-1);
		} else if (!B_found_about_keyword){
				prStr(error_message, "%s:  %s command: no \"about\" command has been specified!\n", programname, keyword);
				printf(error_message);fflush(0);
				slaveExit(-1);
		}
}

/*************************
// YTLIU_EDIT 2013.01.04
 *************************/
Boole readXBPMFPairwiseParms(char* xbpmf_1d_parm_fn,
				char* xbpmf_2d_hb_parm_fn,
				char* xbpmf_2d_xb_parm_fn,
				Real xbpmf_1d_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM],
				Real xbpmf_2d_hb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
				Real xbpmf_2d_xb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM],
				Clock jobStart,
				struct tms tms_jobStart)
{
		FILE *FP_1d;
		FILE *FP_2d_hb;
		FILE *FP_2d_xb;

		char line[LINE_LEN];

		pr(logFile,"\nSetting up XBPMF 1D Atom Type Pairwise Potentials\n");
		//if(openFile(xbpmf_1d_parm_fn, "r", &FP_1d, jobStart, tms_jobStart, TRUE))
		//if(openfile(xbpmf_1d_parm_fn, "r", &FP_1d))
		if((FP_1d=fopen(xbpmf_1d_parm_fn,"r"))!=NULL)	
		{
				while(fgets(line, LINE_LEN, FP_1d))
				{
						char xbpmf_at1[LINE_LEN];
						char xbpmf_at2[LINE_LEN];
						int xbpmf_shell_serial = 0;
						Real xbpmf_at_potential = 0.0;
						(void)sscanf(line, "%[^-]-%[^-]-%d %f", xbpmf_at1, xbpmf_at2, &xbpmf_shell_serial,&xbpmf_at_potential);
						int xbpmf_at1_serial = M_lookupXBPMFATindex(xbpmf_at1);
						int xbpmf_at2_serial = M_lookupXBPMFATindex(xbpmf_at2);
						xbpmf_1d_pw_parms[xbpmf_at1_serial][xbpmf_at2_serial][xbpmf_shell_serial] = xbpmf_at_potential;
						//			pr( logFile, "%s-%s-%d%20.5f\n",xbpmf_at1, xbpmf_at2,xbpmf_shell_serial,xbpmf_1d_pw_parms[xbpmf_at1_serial][xbpmf_at2_serial][xbpmf_shell_serial] );
				}
		}
		else
		{
				(void) fclose(FP_1d);
				return FALSE;
		}
		(void) fclose(FP_1d);

		pr(logFile,"\nSetting up XBPMF 2D HB Atom Type Pairwise Potentials\n");
		//if(openFile(xbpmf_2d_hb_parm_fn, "r", &FP_2d_hb, jobStart, tms_jobStart, TRUE))
		//if(openfile(xbpmf_2d_hb_parm_fn, "r", &FP_2d_hb))
		if((FP_2d_hb=fopen(xbpmf_2d_hb_parm_fn, "r"))!=NULL)
		{
				while(fgets(line, LINE_LEN, FP_2d_hb))
				{
						char xbpmf_at1[LINE_LEN];
						char xbpmf_at2[LINE_LEN];
						int xbpmf_shell_serial = 0;
						int xbpmf_bin_serial = 0;
						Real xbpmf_at_potential = 0.0;
						(void)sscanf(line, "%[^-]-%[^-]-%d-%d %f", xbpmf_at1, xbpmf_at2, &xbpmf_shell_serial, &xbpmf_bin_serial, &xbpmf_at_potential);
						int xbpmf_at1_serial = M_lookupXBPMFATindex(xbpmf_at1);
						int xbpmf_at2_serial = M_lookupXBPMFATindex(xbpmf_at2);
						xbpmf_2d_hb_pw_parms[xbpmf_at1_serial][xbpmf_at2_serial][xbpmf_shell_serial][xbpmf_bin_serial] = xbpmf_at_potential;
						//			pr( logFile, "%s-%s-%d-%d%20.5f\n",xbpmf_at1, xbpmf_at2,xbpmf_shell_serial,xbpmf_bin_serial,xbpmf_2d_hb_pw_parms[xbpmf_at1_serial][xbpmf_at2_serial][xbpmf_shell_serial][xbpmf_bin_serial]);
				}
		}
		else
		{
				(void) fclose(FP_2d_hb);
				return FALSE;
		}
		(void) fclose(FP_2d_hb);

		pr(logFile,"\nSetting up XBPMF 2D XB Atom Type Pairwise Potentials\n");
		//if(openFile(xbpmf_2d_xb_parm_fn, "r", &FP_2d_xb, jobStart, tms_jobStart, TRUE))
		//if(openfile(xbpmf_2d_xb_parm_fn, "r", &FP_2d_xb))
		if((FP_2d_xb=fopen(xbpmf_2d_xb_parm_fn, "r"))!=NULL)
		{
				while(fgets(line, LINE_LEN, FP_2d_xb))
				{
						char xbpmf_at1[LINE_LEN];
						char xbpmf_at2[LINE_LEN];
						int xbpmf_shell_serial = 0;
						int xbpmf_bin_serial = 0;
						Real xbpmf_at_potential = 0.0;
						(void)sscanf(line, "%[^-]-%[^-]-%d-%d %f", xbpmf_at1, xbpmf_at2, &xbpmf_shell_serial, &xbpmf_bin_serial, &xbpmf_at_potential);
						int xbpmf_at1_serial = M_lookupXBPMFATindex(xbpmf_at1);
						int xbpmf_at2_serial = M_lookupXBPMFATindex(xbpmf_at2);
						xbpmf_2d_xb_pw_parms[xbpmf_at1_serial][xbpmf_at2_serial][xbpmf_shell_serial][xbpmf_bin_serial] = xbpmf_at_potential;
						//			pr( logFile, "%s-%s-%d-%d%20.5f\n",xbpmf_at1, xbpmf_at2,xbpmf_shell_serial,xbpmf_bin_serial,xbpmf_2d_xb_pw_parms[xbpmf_at1_serial][xbpmf_at2_serial][xbpmf_shell_serial][xbpmf_bin_serial]);
				}
		}
		else
		{
				(void) fclose(FP_2d_xb);
				return FALSE;
		}
		(void) fclose(FP_2d_xb);

		pr(logFile,"\nXBPMF Atom Type Pairwise Potentials have been successfully set up\n\n");
		return TRUE;
}


/************************
// YTLIU_EDIT 2013.01.25
 ************************/
static void initializeXBEmpiricalParms(XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES])
{
		int i, j;
		for(i=0; i<MAX_XBDONOR_TYPES; i++){
				for(j=0; j<MAX_XBACCEPTOR_TYPES; j++){
						(void) strcpy(xbempirical_parms[i][j].xb_donor,"  ");
						(void) strcpy(xbempirical_parms[i][j].xb_acceptor,"  ");
						xbempirical_parms[i][j].xb_vdw_m = 0;
						xbempirical_parms[i][j].xb_vdw_n = 0;
						xbempirical_parms[i][j].Epsij_xb = 0.0;
						xbempirical_parms[i][j].Rij_xb = 0.0;
						xbempirical_parms[i][j].ESxb_freq = 0.0;
						xbempirical_parms[i][j].ESxb_initial_phase = 0.0;
						xbempirical_parms[i][j].ESxb_constant = 0.0;
						xbempirical_parms[i][j].ESxb_amp_coeff1 = 0.0;
						xbempirical_parms[i][j].ESxb_amp_coeff2 = 0.0;
						xbempirical_parms[i][j].ESxb_amp_coeff3 = 0.0;
						xbempirical_parms[i][j].ESxb_amp_coeff4 = 0.0;
				}
		}
		(void) strcpy(xbempirical_parms[Cl-Cl][OA-OA].xb_donor,"Cl");
		(void) strcpy(xbempirical_parms[Cl-Cl][OA-OA].xb_acceptor,"OA");
		xbempirical_parms[Cl-Cl][OA-OA].xb_vdw_m = 6;
		xbempirical_parms[Cl-Cl][OA-OA].xb_vdw_n = 12;
		xbempirical_parms[Cl-Cl][OA-OA].Epsij_xb = 0.621;
		xbempirical_parms[Cl-Cl][OA-OA].Rij_xb = 3.289;
		xbempirical_parms[Cl-Cl][OA-OA].ESxb_freq = 2.8821;
		xbempirical_parms[Cl-Cl][OA-OA].ESxb_initial_phase = 6.6342;
		xbempirical_parms[Cl-Cl][OA-OA].ESxb_constant = 0.0022;
		xbempirical_parms[Cl-Cl][OA-OA].ESxb_amp_coeff1 = -0.1392;
		xbempirical_parms[Cl-Cl][OA-OA].ESxb_amp_coeff2 = 3.2398;
		xbempirical_parms[Cl-Cl][OA-OA].ESxb_amp_coeff3 = -2.5001;
		xbempirical_parms[Cl-Cl][OA-OA].ESxb_amp_coeff4 = 7.4872;

		(void) strcpy(xbempirical_parms[Cl-Cl][OS-OA].xb_donor,"Cl");
		(void) strcpy(xbempirical_parms[Cl-Cl][OS-OA].xb_acceptor,"OS");
		xbempirical_parms[Cl-Cl][OS-OA].xb_vdw_m = 6;
		xbempirical_parms[Cl-Cl][OS-OA].xb_vdw_n = 12;
		xbempirical_parms[Cl-Cl][OS-OA].Epsij_xb = 0.621;
		xbempirical_parms[Cl-Cl][OS-OA].Rij_xb = 3.289;
		xbempirical_parms[Cl-Cl][OS-OA].ESxb_freq = 2.8821;
		xbempirical_parms[Cl-Cl][OS-OA].ESxb_initial_phase = 6.6342;
		xbempirical_parms[Cl-Cl][OS-OA].ESxb_constant = 0.0022;
		xbempirical_parms[Cl-Cl][OS-OA].ESxb_amp_coeff1 = -0.1392;
		xbempirical_parms[Cl-Cl][OS-OA].ESxb_amp_coeff2 = 3.2398;
		xbempirical_parms[Cl-Cl][OS-OA].ESxb_amp_coeff3 = -2.5001;
		xbempirical_parms[Cl-Cl][OS-OA].ESxb_amp_coeff4 = 7.4872;

		(void) strcpy(xbempirical_parms[Cl-Cl][NA-OA].xb_donor,"Cl");
		(void) strcpy(xbempirical_parms[Cl-Cl][NA-OA].xb_acceptor,"NA");
		xbempirical_parms[Cl-Cl][NA-OA].xb_vdw_m = 6;
		xbempirical_parms[Cl-Cl][NA-OA].xb_vdw_n = 12;
		xbempirical_parms[Cl-Cl][NA-OA].Epsij_xb = 0.127;
		xbempirical_parms[Cl-Cl][NA-OA].Rij_xb = 3.821;
		xbempirical_parms[Cl-Cl][NA-OA].ESxb_freq = -2.7452;
		xbempirical_parms[Cl-Cl][NA-OA].ESxb_initial_phase = 2.2497;
		xbempirical_parms[Cl-Cl][NA-OA].ESxb_constant = -0.1502;
		xbempirical_parms[Cl-Cl][NA-OA].ESxb_amp_coeff1 = 0.2221;
		xbempirical_parms[Cl-Cl][NA-OA].ESxb_amp_coeff2 = -0.0759;
		xbempirical_parms[Cl-Cl][NA-OA].ESxb_amp_coeff3 = -1.8917;
		xbempirical_parms[Cl-Cl][NA-OA].ESxb_amp_coeff4 = 10.2050;

		(void) strcpy(xbempirical_parms[Cl-Cl][NS-OA].xb_donor,"Cl");
		(void) strcpy(xbempirical_parms[Cl-Cl][NS-OA].xb_acceptor,"NS");
		xbempirical_parms[Cl-Cl][NS-OA].xb_vdw_m = 6;
		xbempirical_parms[Cl-Cl][NS-OA].xb_vdw_n = 12;
		xbempirical_parms[Cl-Cl][NS-OA].Epsij_xb = 0.127;
		xbempirical_parms[Cl-Cl][NS-OA].Rij_xb = 3.821;
		xbempirical_parms[Cl-Cl][NS-OA].ESxb_freq = -2.7452;
		xbempirical_parms[Cl-Cl][NS-OA].ESxb_initial_phase = 2.2497;
		xbempirical_parms[Cl-Cl][NS-OA].ESxb_constant = -0.1502;
		xbempirical_parms[Cl-Cl][NS-OA].ESxb_amp_coeff1 = 0.2221;
		xbempirical_parms[Cl-Cl][NS-OA].ESxb_amp_coeff2 = -0.0759;
		xbempirical_parms[Cl-Cl][NS-OA].ESxb_amp_coeff3 = -1.8917;
		xbempirical_parms[Cl-Cl][NS-OA].ESxb_amp_coeff4 = 10.2050;

		(void) strcpy(xbempirical_parms[Cl-Cl][SA-OA].xb_donor,"Cl");
		(void) strcpy(xbempirical_parms[Cl-Cl][SA-OA].xb_acceptor,"SA");
		xbempirical_parms[Cl-Cl][SA-OA].xb_vdw_m = 6;
		xbempirical_parms[Cl-Cl][SA-OA].xb_vdw_n = 12;
		xbempirical_parms[Cl-Cl][SA-OA].Epsij_xb = 0.621;
		xbempirical_parms[Cl-Cl][SA-OA].Rij_xb = 3.289;
		xbempirical_parms[Cl-Cl][SA-OA].ESxb_freq = 2.8821;
		xbempirical_parms[Cl-Cl][SA-OA].ESxb_initial_phase = 6.6342;
		xbempirical_parms[Cl-Cl][SA-OA].ESxb_constant = 0.0022;
		xbempirical_parms[Cl-Cl][SA-OA].ESxb_amp_coeff1 = -0.1392;
		xbempirical_parms[Cl-Cl][SA-OA].ESxb_amp_coeff2 = 3.2398;
		xbempirical_parms[Cl-Cl][SA-OA].ESxb_amp_coeff3 = -2.5001;
		xbempirical_parms[Cl-Cl][SA-OA].ESxb_amp_coeff4 = 7.4872;

		(void) strcpy(xbempirical_parms[Br-Cl][OA-OA].xb_donor,"Br");
		(void) strcpy(xbempirical_parms[Br-Cl][OA-OA].xb_acceptor,"OA");
		xbempirical_parms[Br-Cl][OA-OA].xb_vdw_m = 6;
		xbempirical_parms[Br-Cl][OA-OA].xb_vdw_n = 12;
		xbempirical_parms[Br-Cl][OA-OA].Epsij_xb = 0.785;
		xbempirical_parms[Br-Cl][OA-OA].Rij_xb = 3.305;
		xbempirical_parms[Br-Cl][OA-OA].ESxb_freq = -2.5905;
		xbempirical_parms[Br-Cl][OA-OA].ESxb_initial_phase = 8.0770;
		xbempirical_parms[Br-Cl][OA-OA].ESxb_constant = 0.1274;
		xbempirical_parms[Br-Cl][OA-OA].ESxb_amp_coeff1 = 0.1691;
		xbempirical_parms[Br-Cl][OA-OA].ESxb_amp_coeff2 = -2.0143;
		xbempirical_parms[Br-Cl][OA-OA].ESxb_amp_coeff3 = -1.8838;
		xbempirical_parms[Br-Cl][OA-OA].ESxb_amp_coeff4 = 6.8629;

		(void) strcpy(xbempirical_parms[Br-Cl][OS-OA].xb_donor,"Br");
		(void) strcpy(xbempirical_parms[Br-Cl][OS-OA].xb_acceptor,"OS");
		xbempirical_parms[Br-Cl][OS-OA].xb_vdw_m = 6;
		xbempirical_parms[Br-Cl][OS-OA].xb_vdw_n = 12;
		xbempirical_parms[Br-Cl][OS-OA].Epsij_xb = 0.785;
		xbempirical_parms[Br-Cl][OS-OA].Rij_xb = 3.305;
		xbempirical_parms[Br-Cl][OS-OA].ESxb_freq = -2.5905;
		xbempirical_parms[Br-Cl][OS-OA].ESxb_initial_phase = 8.0770;
		xbempirical_parms[Br-Cl][OS-OA].ESxb_constant = 0.1274;
		xbempirical_parms[Br-Cl][OS-OA].ESxb_amp_coeff1 = 0.1691;
		xbempirical_parms[Br-Cl][OS-OA].ESxb_amp_coeff2 = -2.0143;
		xbempirical_parms[Br-Cl][OS-OA].ESxb_amp_coeff3 = -1.8838;
		xbempirical_parms[Br-Cl][OS-OA].ESxb_amp_coeff4 = 6.8629;

		(void) strcpy(xbempirical_parms[Br-Cl][NA-OA].xb_donor,"Br");
		(void) strcpy(xbempirical_parms[Br-Cl][NA-OA].xb_acceptor,"NA");
		xbempirical_parms[Br-Cl][NA-OA].xb_vdw_m = 6;
		xbempirical_parms[Br-Cl][NA-OA].xb_vdw_n = 12;
		xbempirical_parms[Br-Cl][NA-OA].Epsij_xb = 0.275;
		xbempirical_parms[Br-Cl][NA-OA].Rij_xb = 3.689;
		xbempirical_parms[Br-Cl][NA-OA].ESxb_freq = 2.3276;
		xbempirical_parms[Br-Cl][NA-OA].ESxb_initial_phase = -4.1852;
		xbempirical_parms[Br-Cl][NA-OA].ESxb_constant = -0.0700;
		xbempirical_parms[Br-Cl][NA-OA].ESxb_amp_coeff1 = -0.2742;
		xbempirical_parms[Br-Cl][NA-OA].ESxb_amp_coeff2 = 2.8433;
		xbempirical_parms[Br-Cl][NA-OA].ESxb_amp_coeff3 = -1.7521;
		xbempirical_parms[Br-Cl][NA-OA].ESxb_amp_coeff4 = 6.5965;

		(void) strcpy(xbempirical_parms[Br-Cl][NS-OA].xb_donor,"Br");
		(void) strcpy(xbempirical_parms[Br-Cl][NS-OA].xb_acceptor,"NS");
		xbempirical_parms[Br-Cl][NS-OA].xb_vdw_m = 6;
		xbempirical_parms[Br-Cl][NS-OA].xb_vdw_n = 12;
		xbempirical_parms[Br-Cl][NS-OA].Epsij_xb = 0.275;
		xbempirical_parms[Br-Cl][NS-OA].Rij_xb = 3.689;
		xbempirical_parms[Br-Cl][NS-OA].ESxb_freq = 2.3276;
		xbempirical_parms[Br-Cl][NS-OA].ESxb_initial_phase = -4.1852;
		xbempirical_parms[Br-Cl][NS-OA].ESxb_constant = -0.0700;
		xbempirical_parms[Br-Cl][NS-OA].ESxb_amp_coeff1 = -0.2742;
		xbempirical_parms[Br-Cl][NS-OA].ESxb_amp_coeff2 = 2.8433;
		xbempirical_parms[Br-Cl][NS-OA].ESxb_amp_coeff3 = -1.7521;
		xbempirical_parms[Br-Cl][NS-OA].ESxb_amp_coeff4 = 6.5965;

		(void) strcpy(xbempirical_parms[Br-Cl][SA-OA].xb_donor,"Br");
		(void) strcpy(xbempirical_parms[Br-Cl][SA-OA].xb_acceptor,"SA");
		xbempirical_parms[Br-Cl][SA-OA].xb_vdw_m = 6;
		xbempirical_parms[Br-Cl][SA-OA].xb_vdw_n = 12;
		xbempirical_parms[Br-Cl][SA-OA].Epsij_xb = 0.785;
		xbempirical_parms[Br-Cl][SA-OA].Rij_xb = 3.305;
		xbempirical_parms[Br-Cl][SA-OA].ESxb_freq = -2.5905;
		xbempirical_parms[Br-Cl][SA-OA].ESxb_initial_phase = 8.0770;
		xbempirical_parms[Br-Cl][SA-OA].ESxb_constant = 0.1274;
		xbempirical_parms[Br-Cl][SA-OA].ESxb_amp_coeff1 = 0.1691;
		xbempirical_parms[Br-Cl][SA-OA].ESxb_amp_coeff2 = -2.0143;
		xbempirical_parms[Br-Cl][SA-OA].ESxb_amp_coeff3 = -1.8838;
		xbempirical_parms[Br-Cl][SA-OA].ESxb_amp_coeff4 = 6.8629;

		(void) strcpy(xbempirical_parms[I-Cl][OA-OA].xb_donor,"I");
		(void) strcpy(xbempirical_parms[I-Cl][OA-OA].xb_acceptor,"OA");
		xbempirical_parms[I-Cl][OA-OA].xb_vdw_m = 6;
		xbempirical_parms[I-Cl][OA-OA].xb_vdw_n = 12;
		xbempirical_parms[I-Cl][OA-OA].Epsij_xb = 0.739;
		xbempirical_parms[I-Cl][OA-OA].Rij_xb = 3.436;
		xbempirical_parms[I-Cl][OA-OA].ESxb_freq = 2.3743;
		xbempirical_parms[I-Cl][OA-OA].ESxb_initial_phase = 1.9520;
		xbempirical_parms[I-Cl][OA-OA].ESxb_constant = 0.0684;
		xbempirical_parms[I-Cl][OA-OA].ESxb_amp_coeff1 = -0.2389;
		xbempirical_parms[I-Cl][OA-OA].ESxb_amp_coeff2 = 18.4009;
		xbempirical_parms[I-Cl][OA-OA].ESxb_amp_coeff3 = -1.8233;
		xbempirical_parms[I-Cl][OA-OA].ESxb_amp_coeff4 = 4.9968;

		(void) strcpy(xbempirical_parms[I-Cl][OS-OA].xb_donor,"I");
		(void) strcpy(xbempirical_parms[I-Cl][OS-OA].xb_acceptor,"OS");
		xbempirical_parms[I-Cl][OS-OA].xb_vdw_m = 6;
		xbempirical_parms[I-Cl][OS-OA].xb_vdw_n = 12;
		xbempirical_parms[I-Cl][OS-OA].Epsij_xb = 0.739;
		xbempirical_parms[I-Cl][OS-OA].Rij_xb = 3.436;
		xbempirical_parms[I-Cl][OS-OA].ESxb_freq = 2.3743;
		xbempirical_parms[I-Cl][OS-OA].ESxb_initial_phase = 1.9520;
		xbempirical_parms[I-Cl][OS-OA].ESxb_constant = 0.0684;
		xbempirical_parms[I-Cl][OS-OA].ESxb_amp_coeff1 = -0.2389;
		xbempirical_parms[I-Cl][OS-OA].ESxb_amp_coeff2 = 18.4009;
		xbempirical_parms[I-Cl][OS-OA].ESxb_amp_coeff3 = -1.8233;
		xbempirical_parms[I-Cl][OS-OA].ESxb_amp_coeff4 = 4.9968;

		(void) strcpy(xbempirical_parms[I-Cl][NA-OA].xb_donor,"I");
		(void) strcpy(xbempirical_parms[I-Cl][NA-OA].xb_acceptor,"NA");
		xbempirical_parms[I-Cl][NA-OA].xb_vdw_m = 6;
		xbempirical_parms[I-Cl][NA-OA].xb_vdw_n = 12;
		xbempirical_parms[I-Cl][NA-OA].Epsij_xb = 0.273;
		xbempirical_parms[I-Cl][NA-OA].Rij_xb = 3.808;
		xbempirical_parms[I-Cl][NA-OA].ESxb_freq = 2.3602;
		xbempirical_parms[I-Cl][NA-OA].ESxb_initial_phase = -4.2228;
		xbempirical_parms[I-Cl][NA-OA].ESxb_constant = -0.1999;
		xbempirical_parms[I-Cl][NA-OA].ESxb_amp_coeff1 = -0.4749;
		xbempirical_parms[I-Cl][NA-OA].ESxb_amp_coeff2 = 1.0780;
		xbempirical_parms[I-Cl][NA-OA].ESxb_amp_coeff3 = -1.5692;
		xbempirical_parms[I-Cl][NA-OA].ESxb_amp_coeff4 = 7.6104;

		(void) strcpy(xbempirical_parms[I-Cl][NS-OA].xb_donor,"I");
		(void) strcpy(xbempirical_parms[I-Cl][NS-OA].xb_acceptor,"NS");
		xbempirical_parms[I-Cl][NS-OA].xb_vdw_m = 6;
		xbempirical_parms[I-Cl][NS-OA].xb_vdw_n = 12;
		xbempirical_parms[I-Cl][NS-OA].Epsij_xb = 0.273;
		xbempirical_parms[I-Cl][NS-OA].Rij_xb = 3.808;
		xbempirical_parms[I-Cl][NS-OA].ESxb_freq = 2.3602;
		xbempirical_parms[I-Cl][NS-OA].ESxb_initial_phase = -4.2228;
		xbempirical_parms[I-Cl][NS-OA].ESxb_constant = -0.1999;
		xbempirical_parms[I-Cl][NS-OA].ESxb_amp_coeff1 = -0.4749;
		xbempirical_parms[I-Cl][NS-OA].ESxb_amp_coeff2 = 1.0780;
		xbempirical_parms[I-Cl][NS-OA].ESxb_amp_coeff3 = -1.5692;
		xbempirical_parms[I-Cl][NS-OA].ESxb_amp_coeff4 = 7.6104;

		(void) strcpy(xbempirical_parms[I-Cl][SA-OA].xb_donor,"I");
		(void) strcpy(xbempirical_parms[I-Cl][SA-OA].xb_acceptor,"SA");
		xbempirical_parms[I-Cl][SA-OA].xb_vdw_m = 6;
		xbempirical_parms[I-Cl][SA-OA].xb_vdw_n = 12;
		xbempirical_parms[I-Cl][SA-OA].Epsij_xb = 0.739;
		xbempirical_parms[I-Cl][SA-OA].Rij_xb = 3.436;
		xbempirical_parms[I-Cl][SA-OA].ESxb_freq = 2.3743;
		xbempirical_parms[I-Cl][SA-OA].ESxb_initial_phase = 1.9520;
		xbempirical_parms[I-Cl][SA-OA].ESxb_constant = 0.0684;
		xbempirical_parms[I-Cl][SA-OA].ESxb_amp_coeff1 = -0.2389;
		xbempirical_parms[I-Cl][SA-OA].ESxb_amp_coeff4 = 4.9968;
}

static Boole setupXBEmpiricalParms(char* xbemp_parm_fn, XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES]){
		FILE* FP_xbemp;
		int l;
		char line[LINE_LEN];
		char xbdonor_at[MAX_LEN_AUTOGRID_TYPE + 1];
		char xbacceptor_at[MAX_LEN_AUTOGRID_TYPE + 1];
		int dindex, aindex;

		if((FP_xbemp = fopen(xbemp_parm_fn, "r")) == NULL)
				return FALSE;
		else
		{
				while(fgets(line, LINE_LEN, FP_xbemp))
				{
						l = (int)strindex(line, " ");
						if (l == -1) {
								l = (int)strindex(line, "\t");
								if (l == -1) {
										l = (int)strlen(line);
								}
						}

						if((line[0]=='\n') || (line[0]=='\0') || (line[0]=='#')){
								continue;
						}
						else if(equal(line,"PAR",3)){
								(void) sscanf(line, "%*s %s %s",xbdonor_at,xbacceptor_at);
								dindex = M_lookupXBPMFATindex(xbdonor_at);
								aindex = M_lookupXBPMFATindex(xbacceptor_at);
								(void) sscanf(line,"%*s %s %s %d %d %f %f %f %f %f %f %f %f %f",
												xbempirical_parms[dindex-Cl][aindex-OA].xb_donor,
												xbempirical_parms[dindex-Cl][aindex-OA].xb_acceptor,
												&xbempirical_parms[dindex-Cl][aindex-OA].xb_vdw_m,
												&xbempirical_parms[dindex-Cl][aindex-OA].xb_vdw_n,
												&xbempirical_parms[dindex-Cl][aindex-OA].Epsij_xb,
												&xbempirical_parms[dindex-Cl][aindex-OA].Rij_xb,
												&xbempirical_parms[dindex-Cl][aindex-OA].ESxb_freq,
												&xbempirical_parms[dindex-Cl][aindex-OA].ESxb_initial_phase,
												&xbempirical_parms[dindex-Cl][aindex-OA].ESxb_constant,
												&xbempirical_parms[dindex-Cl][aindex-OA].ESxb_amp_coeff1,
												&xbempirical_parms[dindex-Cl][aindex-OA].ESxb_amp_coeff2,
												&xbempirical_parms[dindex-Cl][aindex-OA].ESxb_amp_coeff3,
												&xbempirical_parms[dindex-Cl][aindex-OA].ESxb_amp_coeff4);
						}
				}
		}
		return TRUE;
}


#ifdef BOINC
/*  Dummy graphics API entry points.
 *  This app does not do graphics, but it still must provide these callbacks.
 */

void app_graphics_render(int xs, int ys, double time_of_day) {}
void app_graphics_reread_prefs(){}
void boinc_app_mouse_move(int x, int y, bool left, bool middle, bool right ){}
void boinc_app_mouse_button(int x, int y, int which, bool is_down){}
void boinc_app_key_press(int wParam, int lParam){}
void boinc_app_key_release(int wParam, int lParam){}
#endif

/* EOF */
