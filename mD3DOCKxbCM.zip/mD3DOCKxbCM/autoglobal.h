/*

   $Id: autoglobal.h,v 1.18 2009/06/05 00:08:17 rhuey Exp $

   AutoDock 

   Copyright (C) 2009 The Scripps Research Institute. All rights reserved.

   AutoDock is a Trade Mark of The Scripps Research Institute.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

#ifndef _AUTOGLOBAL
#define _AUTOGLOBAL

#include <sys/types.h>
#include <string.h>
#include <stdio.h>

#include "structs.h"

/******************************************************************************/
/*      Name: autoglobal.h                                                    */
/*  Function: Global variables for Autodock modules.                          */
/*Copyright (C) 2009 The Scripps Research Institute. All rights reserved. */
/*----------------------------------------------------------------------------*/
/*    Author: Garrett M. Morris                                               */
/*                                                                            */
/*            e-mail: garrett@scripps.edu				      */
/*                                                                            */
/*            The Scripps Research Institute                                  */
/*            Department of Molecular Biology, MB5                            */
/*            10666 North Torrey Pines Road                                   */
/*            La Jolla, CA 92037.                                             */
/*                                                                            */
/*      Date: 03/18/93                                                        */
/*----------------------------------------------------------------------------*/
/*    Inputs: None.                                                           */
/*   Returns: Nothing.                                                        */
/*   Globals: programname, AutoDockHelp, command_mode,          */
/*            command_in_fp, command_out_fp, GPF, logFile.                    */
/*----------------------------------------------------------------------------*/
/* Modification Record                                                        */
/* Date     Inits   Comments                                                  */
/* 03/18/93 GMM     Created.                                                  */
/******************************************************************************/


/*----------------------------------------------------------------------------*/
/* Globals,                                                                   */
/*----------------------------------------------------------------------------*/
//#pragma offload_attribute(push,target(mic))
__declspec(target(mic))char    M_dpfname[256];
__declspec(target(mic))char    dlgName[256];
__declspec(target(mic))char    *programname;
__declspec(target(mic))int		MaxNumThreads=10;
__declspec(target(mic))int 	NpOnNodes;
__declspec(target(mic))char    dock_param_fn[PATH_MAX];
__declspec(target(mic))char    grid_param_fn[PATH_MAX];

__declspec(target(mic))int     command_mode = FALSE;
__declspec(target(mic))int     debug = 0;
__declspec(target(mic))int	    ElecMap = 0;
__declspec(target(mic))int	    DesolvMap = 0;
__declspec(target(mic))int     ignore_errors = FALSE;
__declspec(target(mic))int     keepresnum = 1;
__declspec(target(mic))int     parse_tors_mode = FALSE;
__declspec(target(mic))int	    true_ligand_atoms = 0;
__declspec(target(mic))int     write_stateFile = FALSE;

__declspec(target(mic))FILE    *command_in_fp;
__declspec(target(mic))FILE    *command_out_fp;
__declspec(target(mic))FILE    *parFile;
__declspec(target(mic))FILE    *GPF;
__declspec(target(mic))FILE    *logFile;
__declspec(target(mic))FILE    *stateFile;

/**************************
//YTLIU_EDIT 2012.12.30
 **************************/
__declspec(target(mic))char    xbdock_receptor_fn[PATH_MAX];
__declspec(target(mic))Boole  xbdock_receptor_in = FALSE;
__declspec(target(mic))char    xbdock_ligand_fn[PATH_MAX];
__declspec(target(mic))Boole  xbdock_ligand_in = FALSE;
__declspec(target(mic))char    xbpmf_1d_fn[PATH_MAX] = "ixbpmf_1d_param.dat";
__declspec(target(mic))char    xbpmf_hb_fn[PATH_MAX] = "ixbpmf_hb_param.dat";
__declspec(target(mic))char    xbpmf_xb_fn[PATH_MAX] = "ixbpmf_xb_param.dat";
__declspec(target(mic))Boole xbpmf_1d_parm = FALSE;
__declspec(target(mic))Boole xbpmf_hb_parm = FALSE;
__declspec(target(mic))Boole xbpmf_xb_parm = FALSE;
__declspec(target(mic))Real    xbpmf_dist_delta = 0.1;
__declspec(target(mic))Real    xbpmf_angle_delta = 5.0;
//FILE    *receptorFile;
__declspec(target(mic))Boole  xbpmf_scoring = FALSE;
__declspec(target(mic))Boole  xb_empirical_scoring = FALSE;
/**************************
//YTLIU_EDIT 2013.01.24
 **************************/
__declspec(target(mic))char xbempirical_parm_fn[PATH_MAX];
/**************************
//YTLIU_EDIT 2013.01.25
 **************************/
__declspec(target(mic))char xbempirical_receptor_fn[PATH_MAX];
__declspec(target(mic))Boole xbempirical_receptor_in = FALSE;


__declspec(target(mic))Linear_FE_Model AD3;
__declspec(target(mic))Linear_FE_Model AD4_wrt_3;
__declspec(target(mic))Linear_FE_Model AD4;
__declspec(target(mic))Real	idct = 1.0;
__declspec(target(mic))Unbound_Model ad4_unbound_model = Unbound_Default;
#pragma offload_attribute(push,target(mic))
int threadID = -1;
int global_ntor;
Real *rho_ptr = NULL;
Real *lb_rho_ptr = NULL;
//Global_Search *GlobalSearchMethod = NULL;
//Local_Search *LocalSearchMethod = NULL;
//Global_Search *GlobalSearchMethod = NULL;
//// Local_Search *UnboundLocalSearchMethod = NULL;

// For energy breakdown of non-bonded interactions
int     Nnb_array[3] = {0};    // number of nonbonds in the ligand, intermolecular and receptor groups

// For energy breakdown of non-bonded interactions
Real    nb_group_energy[3] = {0.0};  // total energy of each nonbond group (intra-ligand, inter, and intra-receptor)
#pragma offload_attribute(pop)
#pragma omp threadprivate (threadID,global_ntor, rho_ptr, lb_rho_ptr, nb_group_energy, Nnb_array)
//#pragma offload_attribute(pop)
__declspec(target(mic))int numThreads=0;
//Eval evaluate[MAX_NUM_THREADS];
//int num_maps = 0;
__declspec(target(mic))char loadedMapFileNames[MAX_MAPS][FILENAME_MAX] = {'\0'};
__declspec(target(mic))char atomTypeMap[MAX_MAPS][3] = {'\0'};
__declspec(target(mic))char loadedMapFileNamesCopy[FILENAME_MAX] = {'\0'};
__declspec(target(mic))MapType mapCopyOneRow[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS];
__declspec(target(mic))char atomTypeMapCopy[3] = {'\0'};
#pragma offload_attribute(push,target(mic))
__declspec(target(mic))GridMapSetInfo *info;  // this information is from the AVS field file
__declspec(target(mic))xbempirical_map_info *xbEmpiricalMapInfo;
xbpmf_map_info *xbPmfMapInfo;
char dockingDirectoryBaseName[FILENAME_MAX];
MapType map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS];
#pragma offload_attribute(pop)
#define RUN_ON_MIC 112
#define RUN_ON_CPU 16
__declspec(target(mic))int MIC_or_CPU=RUN_ON_CPU;
__declspec(target(mic))int M_MIC_STATUS=M_MIC_BEGIN;
//#pragma offload_attribute(pop)
/**************************
//YTLIU_EDIT 2013.01.04
 **************************/


#endif /*_AUTOGLOBAL*/
/* EOF */
