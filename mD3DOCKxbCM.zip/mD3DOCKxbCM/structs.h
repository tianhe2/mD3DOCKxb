/*

   $Id: structs.h,v 1.23 2009/10/02 22:10:48 rhuey Exp $

   AutoDock  

   Copyright (C) 2009 The Scripps Research Institute. All rights reserved.

   AutoDock is a Trade Mark of The Scripps Research Institute.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

#ifndef _STRUCTS_H
#define _STRUCTS_H
//#pragma offload_attribute(push,target(mic))
#include "constants.h"
#include "typedefs.h"

/*************************
// YTLIU_EDIT 2013.01.05
 *************************/
#define MAX_LEN_AUTOGRID_TYPE 7
//#ifndef _PARAMETERS_H
//#include "parameters.h"
//#endif
/* *****************************************************************************
 *      Name: structs.h                                                       *
 *  Function: Defines structures used in Molecular Applications.              *
 *Copyright (C) 2009 The Scripps Research Institute. All rights reserved.
 *----------------------------------------------------------------------------*
 *    Author: Garrett Matthew Morris, The Scripps Research Institute          *
 *      Date: SEP/07/1995                                                     *
 *----------------------------------------------------------------------------*
 *    Inputs: none                                                            *
 *   Returns: nothing                                                         *
 *   Globals: none                                                            *
 *----------------------------------------------------------------------------*
 * Modification Record                                                        *
 * Date     Inits   Comments                                                  *
 * 02/28/95 GMM     This header added                                         *
 ***************************************************************************** */

/* ____________________________________________________________________________ */

#ifdef USE_INT_AS_LONG
typedef int FourByteLong;
typedef unsigned int UnsignedFourByteLong;
#else
typedef long FourByteLong;
typedef unsigned long UnsignedFourByteLong;
#endif

/* ____________________________________________________________________________ */

typedef double Vector [3];  // for vectors and points

/* ____________________________________________________________________________ */

typedef struct coord
{
		double x;			/* Cartesian x-coordinate */
		double y;			/* Cartesian y-coordinate */
		double z;			/* Cartesian z-coordinate */
} Coord;

/* ____________________________________________________________________________ */

typedef struct quat
{
		double nx;			/* unit vector's x-component */
		double ny;			/* unit vector's y-component */
		double nz;			/* unit vector's z-component */
		double ang;			/* angle of rotation about unit-vector */
		double w;			/* quaternion's w-component */
		double x;			/* quaternion's x-component */
		double y;			/* quaternion's y-component */
		double z;			/* quaternion's z-component */
		double qmag;			/* quaternion's 4-D magnitude */
} Quat;

typedef struct quaternion
{
		double v[4];
} Quaternion;

#define NX 0
#define NY 1
#define NZ 2

typedef struct axis
{
		double v[3];
} Axis;

typedef struct axisangle
{
		Axis axis;
		double angle;
} AxisAngle;


/* ____________________________________________________________________________ */

typedef struct energy
{
		double total;			/* total energy */
		double intra;			/* intramolecular energy, a.k.a. "internal" energy */
		double inter;			/* intermolecular energy */
		double FE;			/* estimated Free Energy of binding */
} Energy;

/* ____________________________________________________________________________ */

typedef struct state
{
		Coord T;			/* coordinates of center of molecule */
		Quat Q;			/* rigid-body orientation */
		double tor[MAX_TORS];		/* torsion angles in radians */
		int ntor;			/* number of torsions in molecule */
		int hasEnergy;		/* if 0, this state has an undefined energy */
		Energy e;			/* energy structure */
} State;

/* ____________________________________________________________________________ */

typedef struct molecule
{
		Real crdpdb[MAX_ATOMS][SPACE];	    /* original coordinates of atoms */
		Real crd[MAX_ATOMS][SPACE];      	/* current coordinates of atoms */
		char atomstr[MAX_ATOMS][MAX_CHARS];	/* strings describing atoms, from PDB file, cols,1-30. */
		int natom;			                /* number of atoms in molecule */
		Real vt[MAX_TORS][SPACE];        	/* vectors  of torsions */
		int tlist[MAX_TORS][MAX_ATOMS];	    /* torsion list of movable atoms */
		State S;		                    	/* state of molecule */
} Molecule;

/* ____________________________________________________________________________ */


/********************************************
//YTLIU_EDIT 2012.12.29
 ********************************************/
typedef struct receptor
{
		Real crdpdb[MAX_RECEPTOR_ATOMS][SPACE];
		Real crd[MAX_RECEPTOR_ATOMS][SPACE];      	/* current coordinates of atoms */
		//	char atomstr[MAX_RECEPTOR_ATOMS][MAX_CHARS];	/* strings describing atoms, from PDB file, cols,1-30. */
		char atomtype[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1]; /* atom type*/
		Real charge[MAX_RECEPTOR_ATOMS];	/*partial charge*/
		int natom;			                /* number of atoms in molecule */
		//	Real vt[MAX_TORS][SPACE];        	/* vectors  of torsions */
		//	int tlist[MAX_TORS][MAX_ATOMS];	    /* torsion list of movable atoms */
		//	State S;		                    	/* state of molecule */
} Receptor;

/********************************************
//YTLIU_EDIT 2013.01.04
 ********************************************/
typedef struct xbligand
{
		Real crdpdb[MAX_ATOMS][SPACE];
		Real crd[MAX_ATOMS][SPACE];      	/* current coordinates of atoms */
		char atomstr[MAX_ATOMS][MAX_CHARS];	/* strings describing atoms, from PDB file, cols,1-30. */
		char atomtype[MAX_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1]; /* atom type*/
		Real charge[MAX_ATOMS];	/*partial charge*/
		int natom;			                /* number of atoms in molecule */
		//	Real vt[MAX_TORS][SPACE];        	/* vectors  of torsions */
		//	int tlist[MAX_TORS][MAX_ATOMS];	    /* torsion list of movable atoms */
		//	State S;		                    	/* state of molecule */
} XBLigand;


/******************************
// YTLIU_EDIT 2013.01.24
 ******************************/
typedef struct xbempiricalparm
{
		char xb_donor[MAX_LEN_AUTOGRID_TYPE + 1];
		char xb_acceptor[MAX_LEN_AUTOGRID_TYPE + 1];
		int xb_vdw_m;
		int xb_vdw_n;
		Real Epsij_xb;
		Real Rij_xb;
		Real ESxb_freq;
		Real ESxb_initial_phase;
		Real ESxb_constant;
		Real ESxb_amp_coeff1;
		Real ESxb_amp_coeff2;
		Real ESxb_amp_coeff3;
		Real ESxb_amp_coeff4;
} XBEmpiricalParm;

typedef struct {
		int *base;
		int top;
		int size;
		FILE *trace;
} integer_stack_t;

typedef integer_stack_t * M_stack;
/* ____________________________________________________________________________ */

typedef struct rotamer
{
		double tor[MAX_TORS_IN_ROTAMER];	/* torsion angles in radians */
		int ntor;			/* number of torsions */
} Rotamer;

/* ____________________________________________________________________________ */

typedef struct chargestruct
{
		double charge;
		double abs_charge;
		double qsp_abs_charge;
} Charge;

/* ____________________________________________________________________________ */

typedef struct atom
{
		double    coords[3];			    /* transformed coordinates */
		double    crdpdb[3];			    /* input PDB coordintates */
		double    crdreo[3];			    /* reoriented coordintates */
		Boole     has_charge;			    /* TRUE if the atom has a charge */

		double    charge;
		double    abs_charge;
		double    qsp_abs_charge;

		int       type;			        /* atom type as integer */
		char      type_string[MAX_CHARS]; /* atom type as string */
		Boole     is_hydrogen;		    /* TRUE if atom is a hydrogen */

		int       serial;			        /* serial ID */
		char      name[5];			    /* PDB atom name; formerly "pdbaname" */
		char      stuff[MAX_CHARS];       /* PDB atom string; formerly "atomstuff" */

		int       nnb;			        /* number of non-bonds for this atom */
} Atom;
/* ____________________________________________________________________________ */

typedef struct bond
{
		Atom *atom1;
		Atom *atom2;
		double bondLength;
		Coord bondVector;
} Bond;
/* ____________________________________________________________________________ */

typedef struct pair_id
{
		Atom *atom1;			/* pointer to one atom in pair */
		Atom *atom2;			/* pointer to other atom */
} PairID;
/* ____________________________________________________________________________ */

typedef struct dist_constraint
{
		PairID bond;			/* two atoms defining distance constraint */
		double length;		/* current bond length */
		double lower;			/* lower bound on distance */
		double upper;			/* upper bound on distance */
} DisCon;

/* ____________________________________________________________________________ */

typedef struct torsion
{
		PairID rotbnd;		/* atom serial-IDs of rotatable bond */
		int nmoved;			/* number of atoms moved by this */
		int IDmove[MAX_ATOMS];	/* atom serial-IDs of atoms moved by this */
		Coord vt;			/* bond-vector of rotatable bond */
} Torsion;

/* ______________________________________________________________________________
 ** Molecular fragments, side-chains, even entire ligands */

typedef struct group
{
		int natom;			/* Number of atoms in fragment */
		Atom atm[MAX_ATOMS];		/* Atom data */
		int ntor;			/* Number of torsions in fragment */
		Torsion tors[MAX_TORS];	/* Torsion data */
		int nnb;			/* Number of non-bonds in fragment */
		PairID nbs[MAX_NONBONDS];	/* Non-bond data */
		Boole B_constrain;		/* TRUE if any distance constraints */
		DisCon distcon;		/* Distance constraint data */
		char pdbqfilnam[PATH_MAX];	/* PDBQ filename holding these data */
} Group;

typedef union 
{
		double real;
		FourByteLong integer;
		unsigned char bit;
} Element;

typedef struct
{
		unsigned int vector;
		unsigned int index;
} Lookup;

typedef struct      grid_map_set_info
{
		double          spacing; // uniform grid spacing in Angstroms
		double          inv_spacing; // reciprocal of the uniform grid spacing in Angstroms^-1
		char            FN_gdfld[PATH_MAX]; // filename of the field file
		char            FN_gpf[PATH_MAX]; // filename of the AutoGrid parameter file
		int             num_points[3]; // the actual dimensions of the grid minus 1; should be an even number
		int             num_points1[3]; // the actual dimensions of the grid; should be an odd number
		int             num_alloc[3]; // the dimensions allocated, >= num_points1; if this is a power of 2, it should be faster
		double          hi[3]; // maximum coordinates, in Angstroms
		double          lo[3]; // minimum coordinates, in Angstroms
		double          center[3]; // central coordinates, in Angstroms
		char            FN_receptor[PATH_MAX]; // filename of the receptor used to calculate the grids
		char            atom_type_name[MAX_MAPS][3]; // array of atom type names, corresponding to the grids
		int             num_atom_types; // number of atom types
		int             num_all_maps; // number of all maps, = num_atom_types + 2
		int             num_alloc_maps; // allocated number of maps, >= num_all_maps

}                   GridMapSetInfo;
typedef struct
{
		int xbempirical_receptor_acceptor_index[MAX_RECEPTOR_ATOMS];
		Receptor xbempirical_recep;           /* receptor */
		int xbempirical_recep_natom;
		Real xbempirical_recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN];
		//char xbempirical_recep_acceptor_atomtype[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1];
		Real xbempirical_recep_charge[MAX_RECEPTOR_ATOMS];
		Boole xbempirical_recep_B_haveCharges;
		char xbempirical_recep_pdbaname[MAX_RECEPTOR_ATOMS][5];
		Atom xbempirical_recep_atoms[MAX_RECEPTOR_ATOMS];
		Real xb_vdw_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8];
		Real xb_es_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8];
		Real xb_desolv_profile[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_XBDONOR_TYPES][8];
		XBEmpiricalParm xbempirical_parms[MAX_XBDONOR_TYPES][MAX_XBACCEPTOR_TYPES];
}   xbempirical_map_info;

typedef struct
{
		Receptor recep;		  /* receptor */
		int recep_natom;
		int recep_acceptor_natom;
		Real recep_crdpdb[MAX_RECEPTOR_ATOMS][NTRN];
		Real recep_acceptor_crdpdb[MAX_RECEPTOR_ATOMS][NTRN];
		char recep_acceptor_atomtype[MAX_RECEPTOR_ATOMS][MAX_LEN_AUTOGRID_TYPE + 1];
		Real recep_charge[MAX_RECEPTOR_ATOMS];
		Boole recep_B_haveCharges;
		char recep_pdbaname[MAX_RECEPTOR_ATOMS][5];
		Atom recep_atoms[MAX_RECEPTOR_ATOMS];
		int xbpmf_hb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS];
		int xbpmf_xb_label[MAX_ATOMS][MAX_RECEPTOR_ATOMS];
		int xbpmf_receptor_at_index[MAX_RECEPTOR_ATOMS];
		//    int xbpmf_receptor_hb_acceptor[MAX_RECEPTOR_ATOMS];
		Real xbpmf_1d_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM];
		Real xbpmf_2d_hb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM];
		Real xbpmf_2d_xb_pw_parms[XBPMF_AT_NUM][XBPMF_AT_NUM][XBPMF_SHELL_NUM][XBPMF_BIN_NUM];
		MapType xbpmf_1d_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM];
		MapType xbpmf_hb_map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][XBPMF_AT_NUM];
}   xbpmf_map_info;



/* ______________________________________________________________________________
 ** Parameter Dictionary */

/* ______________________________________________________________________________ */
enum hbond_type
{ NON, DS, D1, AS, A1, A2 };	/* hbonding character: */

typedef struct parameter_entry
{				// was "parm_info" in earlier AutoGrid 4 code
		char autogrid_type[MAX_LEN_AUTOGRID_TYPE + 1];	/* autogrid_type is a string based on babel_types assigned by PyBabel */
		double Rij;			/* Lennard-Jones equilibrium separation */
		double epsij;			/* Lennard-Jones energy well-depth */
		double vol;			/* solvation volume */
		double solpar;		/* solvation parameter */
		hbond_type hbond;		/* hbonding character: 
NON: none, 
DS: spherical donor 
D1: directional donor
AS: spherical acceptor
A1: acceptor of 1 directional hbond
A2: acceptor of 2 directional hbonds */
		double Rij_hb;		/* 12-10 Lennard-Jones equilibrium separation */
		double epsij_hb;		/* 12-10 Lennard-Jones energy well-depth */
		int rec_index;		/* used to set up receptor atom_types */
		int map_index;		/* used to set up map atom_types */
		int bond_index;		/* used to set up bonds; corresponds to the enum in mdist.h */
} ParameterEntry;

#define is_hydrogen_type(t) ((strcmp(t,"H")==0) || (strcmp(t,"HD")==0) || (strcmp(t,"HS")==0))

typedef ParameterEntry PE;
typedef struct linear_FE_model
{
		double coeff_vdW;                 // Free energy coefficient for van der Waals term
		double coeff_hbond;               // Free energy coefficient for H-bonding term
		double coeff_estat;               // Free energy coefficient for electrostatics term
		double coeff_desolv;              // Free energy coefficient for desolvation term
		double coeff_tors;                // Free energy coefficient for torsional term

		double stderr_vdW;                // Free energy standard error for van der Waals term
		double stderr_hbond;              // Free energy standard error for H-bonding term
		double stderr_estat;              // Free energy standard error for electrostatics term
		double stderr_desolv;             // Free energy standard error for desolvation term
		double stderr_tors;               // Free energy standard error for torsional term
} Linear_FE_Model;

/* ______________________________________________________________________________ */
/* Energy Lookup Tables */

typedef struct energy_tables
{
		Real e_vdW_Hb[NEINT][MAX_ATOM_TYPES][MAX_ATOM_TYPES];  // vdW & Hb energies
		Real sol_fn[NEINT];                            // distance-dependent desolvation function
		Real epsilon_fn[NDIEL];                        // distance-dependent dielectric function
		Real r_epsilon_fn[NDIEL];                      // r * distance-dependent dielectric function
} EnergyTables;

/* ______________________________________________________________________________ */
/* Nonbonded pair parameters */
typedef struct nonbond_param
{
		int a1;           // ATM1
		int a2;           // ATM2
		int t1;           // TYPE1
		int t2;           // TYPE2
		int nonbond_type; // NBTYPE
		double desolv;
		double q1q2;      // product of atom partial charges

		nonbond_param() : a1(0), a2(0) {}
} NonbondParam;

/* ______________________________________________________________________________ */
/* Statistics */

typedef struct statistics 
{
		int number;
		Real minimum;
		Real mean;
		Real maximum;
		/* Real standard_deviation; */
} Statistics;

/* ______________________________________________________________________________ */
/* EnergyBreakdown */

typedef struct energy_breakdown
{
		Real e_inter_moving_fixed;      // (1)  // trilinterp( 0, true_ligand_atoms, ...)
		/*************************
		// YTLIU_EDIT 2013.01.06
		 *************************/
		// XBPMF: (1) = (X1) + (X2) + (X3) + (X4)
		// XB Empirical Corrected: (1) = (Y1) + (Y2) - (Y3) - (Y4) - (Y5)
		Real e_mf_outside_grid_penalty; // (X1)
		Real e_mf_xbpmf_1d;		    // (X2)
		Real e_mf_xbpmf_2d_hb;	    // (X3)
		Real e_mf_xbpmf_2d_xb;	    // (X4)
		Real e_mf_xb_empirical_vdw;	    // (Y1)
		Real e_mf_xb_empirical_es;	    // (Y2)
		Real e_mf_ad_vdw;    	    // (Y3)
		Real e_mf_ad_es;                // (Y4)
		Real e_mf_ad_desolv;            // (Y5)

		Real e_intra_moving_fixed_rec;  // (2)  // trilinterp( true_ligand_atoms, natom, ...)
		/*************************
		// YTLIU_EDIT 2013.01.06
		 *************************/
		// XBPMF: (2) = (Z1) + (Z2) + (Z3) + (Z4)
		// XB Empirical: (2) = (W1) + (W2) - (W3) - (W4) - (W5)
		Real e_mfr_outside_grid_penalty; // (Z1)
		Real e_mfr_xbpmf_1d;             // (Z2)
		Real e_mfr_xbpmf_2d_hb;          // (Z3)
		Real e_mfr_xbpmf_2d_xb;          // (Z4)
		Real e_mfr_xb_empirical_vdw;     // (W1)
		Real e_mfr_xb_empirical_es;      // (W2)
		Real e_mfr_ad_vdw;		     // (W3)
		Real e_mfr_ad_es;		     // (W4)
		Real e_mfr_ad_desolv;	     // (W5)

		Real e_intra_moving_moving_lig; // (3)  // eintcal( 0, nb_array[0], ...)            // nb_group_energy[INTRA_LIGAND]
		Real e_inter_moving_moving;     // (4)  // eintcal( nb_array[0], nb_array[1], ...)  // nb_group_energy[INTER]
		Real e_intra_moving_moving_rec; // (5)  // eintcal( nb_array[1], nb_array[2], ...)  // nb_group_energy[INTRA_RECEPTOR]

		Real e_inter;                   // total    intermolecular energy = (1) + (4)
		Real e_intra;                   // total    intramolecular energy = (3)  +  (2) + (5)
		Real e_intra_lig;               // ligand   intramolecular energy = (3)
		Real e_intra_rec;               // receptor intramolecular energy = (2) + (5)

		Real e_torsFreeEnergy;          // empirical torsional free energy penalty
		Real e_unbound_internal_FE;     // computed internal free energy of the unbound state
		Real deltaG;                    // estimated change in free energy upon binding

} EnergyBreakdown;

/*______________________________________________________________________________
 **PSO Work Structures */

typedef struct velocity {
		int size;
		double v[D_max];
} Velocity;
/*______________________________________________________________________________*/

typedef struct position {
		int size;
		double x[D_max];
		double f;		// fitness value of particle
		double prev_x[D_max];		// previous fitness value of particle
} Position;
//#pragma offload_attribute(pop)
#endif
/* EOF */
